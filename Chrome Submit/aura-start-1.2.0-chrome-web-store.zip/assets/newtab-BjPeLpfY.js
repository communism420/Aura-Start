import { c as clientExports, j as jsxRuntimeExports } from "./styles-DQF6R_Dz.js";
import { A as App } from "./App-D_4hLAqz.js";
clientExports.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, {}));
