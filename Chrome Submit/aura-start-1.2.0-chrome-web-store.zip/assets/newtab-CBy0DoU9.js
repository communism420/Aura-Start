import { c as clientExports, j as jsxRuntimeExports } from "./styles-BYF_6Y4u.js";
import { A as App } from "./App-J6eamuxu.js";
clientExports.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, {}));
