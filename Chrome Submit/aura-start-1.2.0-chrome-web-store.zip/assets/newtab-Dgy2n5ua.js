import { c as clientExports, j as jsxRuntimeExports } from "./styles-BKwOH7Tr.js";
import { A as App } from "./App-BNSi0Aty.js";
clientExports.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, {}));
