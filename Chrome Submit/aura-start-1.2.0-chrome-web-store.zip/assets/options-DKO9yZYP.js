import { c as clientExports, j as jsxRuntimeExports } from "./styles-ChpDSAn1.js";
import { A as App } from "./App-BGHUt6dv.js";
clientExports.createRoot(document.getElementById("options-root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, { initialSettingsOpen: true }));
