import { c as clientExports, j as jsxRuntimeExports } from "./styles-CKZU7jcl.js";
import { A as App } from "./App-CuV4mTAM.js";
clientExports.createRoot(document.getElementById("options-root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, { initialSettingsOpen: true }));
