import { c as clientExports, j as jsxRuntimeExports } from "./styles-GFzegHIy.js";
import { A as App } from "./App-DsatNCOm.js";
clientExports.createRoot(document.getElementById("options-root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, { initialSettingsOpen: true }));
