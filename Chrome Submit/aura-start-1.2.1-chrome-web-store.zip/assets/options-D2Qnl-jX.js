import { c as clientExports, j as jsxRuntimeExports } from "./styles-GKiyHuFd.js";
import { A as App } from "./App-CLzBifKf.js";
clientExports.createRoot(document.getElementById("options-root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, { initialSettingsOpen: true }));
