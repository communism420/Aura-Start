import { c as clientExports, j as jsxRuntimeExports } from "./styles-DByIKg65.js";
import { A as App } from "./App-DF4uNyqC.js";
clientExports.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, {}));
