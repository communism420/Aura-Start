import { c as clientExports, j as jsxRuntimeExports } from "./styles-B39v75gm.js";
import { A as App } from "./App-CxM2k0iJ.js";
clientExports.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, {}));
