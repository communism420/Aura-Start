import { c as clientExports, j as jsxRuntimeExports } from "./styles-DTGPEarR.js";
import { A as App } from "./App-5lMXNZmR.js";
clientExports.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, {}));
