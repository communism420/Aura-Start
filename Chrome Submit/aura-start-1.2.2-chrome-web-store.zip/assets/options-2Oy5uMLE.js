import { c as clientExports, j as jsxRuntimeExports } from "./styles-DGUFygUc.js";
import { A as App } from "./App-CG2OZ8AO.js";
clientExports.createRoot(document.getElementById("options-root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, { initialSettingsOpen: true }));
