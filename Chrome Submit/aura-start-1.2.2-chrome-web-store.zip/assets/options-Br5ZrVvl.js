import { c as clientExports, j as jsxRuntimeExports } from "./styles-Csl0dEND.js";
import { A as App } from "./App-C1j8r1Ro.js";
clientExports.createRoot(document.getElementById("options-root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, { initialSettingsOpen: true }));
