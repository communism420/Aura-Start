import { c as clientExports, j as jsxRuntimeExports } from "./styles-B4b_JHdX.js";
import { A as App } from "./App-Bew2qLZx.js";
clientExports.createRoot(document.getElementById("options-root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, { initialSettingsOpen: true }));
