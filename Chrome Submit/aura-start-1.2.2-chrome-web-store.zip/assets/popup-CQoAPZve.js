import { c as clientExports, j as jsxRuntimeExports, u as useAuraStore, D as DEFAULT_SETTINGS, r as reactExports, t, E as ExternalLink, a as Download, S as Settings, e as exportJsonBackup } from "./styles-DTGPEarR.js";
function hasChromeRuntime() {
  return typeof chrome !== "undefined" && Boolean(chrome.runtime);
}
function PopupApp() {
  const data = useAuraStore((state) => state.data);
  const status = useAuraStore((state) => state.status);
  const error = useAuraStore((state) => state.error);
  const load = useAuraStore((state) => state.load);
  const addToast = useAuraStore((state) => state.addToast);
  const language = (data == null ? void 0 : data.settings.language) ?? DEFAULT_SETTINGS.language;
  reactExports.useEffect(() => {
    void load();
  }, [load]);
  const openNewTab = () => {
    var _a;
    if (typeof chrome !== "undefined" && ((_a = chrome.tabs) == null ? void 0 : _a.create)) {
      void chrome.tabs.create({});
      window.close();
      return;
    }
    window.open("newtab.html", "_blank", "noopener");
  };
  const openSettings = () => {
    if (hasChromeRuntime() && chrome.runtime.openOptionsPage) {
      void chrome.runtime.openOptionsPage();
      window.close();
      return;
    }
    window.open("options.html", "_blank", "noopener");
  };
  const exportBackup = () => {
    if (!data) return;
    try {
      exportJsonBackup(data);
    } catch (caught) {
      addToast({
        type: "error",
        title: t(language, "exportFailed"),
        message: caught instanceof Error ? caught.message : t(language, "couldNotExportBackup")
      });
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "w-80 bg-[var(--bg)] p-3 text-[var(--text)]", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "surface-flat rounded-xl p-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-lg font-semibold", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { className: "aura-logo aura-logo-popup", src: "/logo.png", alt: "", "aria-hidden": "true" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Aura Start" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "muted mt-1 text-xs", children: t(language, "brandSlogan") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "muted text-xs", children: status === "ready" && data ? t(language, "groupsLinksCount", {
        groups: data.groups.length,
        links: data.groups.reduce((count, group) => count + group.links.length, 0)
      }) : status === "corrupt" ? t(language, "storageNeedsRecovery") : t(language, "loadingLocalData") }),
      error ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 text-xs text-[var(--danger)]", children: error }) : null
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-primary w-full justify-start", type: "button", onClick: openNewTab, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { size: 17 }),
        t(language, "openNewTab")
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary w-full justify-start", disabled: !data, type: "button", onClick: exportBackup, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { size: 17 }),
        t(language, "exportJsonBackup")
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary w-full justify-start", type: "button", onClick: openSettings, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { size: 17 }),
        t(language, "settings")
      ] })
    ] })
  ] }) });
}
clientExports.createRoot(document.getElementById("popup-root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(PopupApp, {}));
