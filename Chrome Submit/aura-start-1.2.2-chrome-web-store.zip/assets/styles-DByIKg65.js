var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
function getDefaultExportFromCjs(x) {
  return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
}
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production_min = {};
var react = { exports: {} };
var react_production_min = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var hasRequiredReact_production_min;
function requireReact_production_min() {
  if (hasRequiredReact_production_min) return react_production_min;
  hasRequiredReact_production_min = 1;
  var l = Symbol.for("react.element"), n = Symbol.for("react.portal"), p = Symbol.for("react.fragment"), q = Symbol.for("react.strict_mode"), r = Symbol.for("react.profiler"), t2 = Symbol.for("react.provider"), u = Symbol.for("react.context"), v = Symbol.for("react.forward_ref"), w = Symbol.for("react.suspense"), x = Symbol.for("react.memo"), y = Symbol.for("react.lazy"), z = Symbol.iterator;
  function A(a) {
    if (null === a || "object" !== typeof a) return null;
    a = z && a[z] || a["@@iterator"];
    return "function" === typeof a ? a : null;
  }
  var B = { isMounted: function() {
    return false;
  }, enqueueForceUpdate: function() {
  }, enqueueReplaceState: function() {
  }, enqueueSetState: function() {
  } }, C = Object.assign, D = {};
  function E(a, b, e) {
    this.props = a;
    this.context = b;
    this.refs = D;
    this.updater = e || B;
  }
  E.prototype.isReactComponent = {};
  E.prototype.setState = function(a, b) {
    if ("object" !== typeof a && "function" !== typeof a && null != a) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, a, b, "setState");
  };
  E.prototype.forceUpdate = function(a) {
    this.updater.enqueueForceUpdate(this, a, "forceUpdate");
  };
  function F() {
  }
  F.prototype = E.prototype;
  function G(a, b, e) {
    this.props = a;
    this.context = b;
    this.refs = D;
    this.updater = e || B;
  }
  var H = G.prototype = new F();
  H.constructor = G;
  C(H, E.prototype);
  H.isPureReactComponent = true;
  var I = Array.isArray, J = Object.prototype.hasOwnProperty, K = { current: null }, L = { key: true, ref: true, __self: true, __source: true };
  function M(a, b, e) {
    var d, c = {}, k = null, h = null;
    if (null != b) for (d in void 0 !== b.ref && (h = b.ref), void 0 !== b.key && (k = "" + b.key), b) J.call(b, d) && !L.hasOwnProperty(d) && (c[d] = b[d]);
    var g = arguments.length - 2;
    if (1 === g) c.children = e;
    else if (1 < g) {
      for (var f = Array(g), m = 0; m < g; m++) f[m] = arguments[m + 2];
      c.children = f;
    }
    if (a && a.defaultProps) for (d in g = a.defaultProps, g) void 0 === c[d] && (c[d] = g[d]);
    return { $$typeof: l, type: a, key: k, ref: h, props: c, _owner: K.current };
  }
  function N(a, b) {
    return { $$typeof: l, type: a.type, key: b, ref: a.ref, props: a.props, _owner: a._owner };
  }
  function O(a) {
    return "object" === typeof a && null !== a && a.$$typeof === l;
  }
  function escape(a) {
    var b = { "=": "=0", ":": "=2" };
    return "$" + a.replace(/[=:]/g, function(a2) {
      return b[a2];
    });
  }
  var P = /\/+/g;
  function Q(a, b) {
    return "object" === typeof a && null !== a && null != a.key ? escape("" + a.key) : b.toString(36);
  }
  function R(a, b, e, d, c) {
    var k = typeof a;
    if ("undefined" === k || "boolean" === k) a = null;
    var h = false;
    if (null === a) h = true;
    else switch (k) {
      case "string":
      case "number":
        h = true;
        break;
      case "object":
        switch (a.$$typeof) {
          case l:
          case n:
            h = true;
        }
    }
    if (h) return h = a, c = c(h), a = "" === d ? "." + Q(h, 0) : d, I(c) ? (e = "", null != a && (e = a.replace(P, "$&/") + "/"), R(c, b, e, "", function(a2) {
      return a2;
    })) : null != c && (O(c) && (c = N(c, e + (!c.key || h && h.key === c.key ? "" : ("" + c.key).replace(P, "$&/") + "/") + a)), b.push(c)), 1;
    h = 0;
    d = "" === d ? "." : d + ":";
    if (I(a)) for (var g = 0; g < a.length; g++) {
      k = a[g];
      var f = d + Q(k, g);
      h += R(k, b, e, f, c);
    }
    else if (f = A(a), "function" === typeof f) for (a = f.call(a), g = 0; !(k = a.next()).done; ) k = k.value, f = d + Q(k, g++), h += R(k, b, e, f, c);
    else if ("object" === k) throw b = String(a), Error("Objects are not valid as a React child (found: " + ("[object Object]" === b ? "object with keys {" + Object.keys(a).join(", ") + "}" : b) + "). If you meant to render a collection of children, use an array instead.");
    return h;
  }
  function S(a, b, e) {
    if (null == a) return a;
    var d = [], c = 0;
    R(a, d, "", "", function(a2) {
      return b.call(e, a2, c++);
    });
    return d;
  }
  function T(a) {
    if (-1 === a._status) {
      var b = a._result;
      b = b();
      b.then(function(b2) {
        if (0 === a._status || -1 === a._status) a._status = 1, a._result = b2;
      }, function(b2) {
        if (0 === a._status || -1 === a._status) a._status = 2, a._result = b2;
      });
      -1 === a._status && (a._status = 0, a._result = b);
    }
    if (1 === a._status) return a._result.default;
    throw a._result;
  }
  var U = { current: null }, V = { transition: null }, W = { ReactCurrentDispatcher: U, ReactCurrentBatchConfig: V, ReactCurrentOwner: K };
  function X() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  react_production_min.Children = { map: S, forEach: function(a, b, e) {
    S(a, function() {
      b.apply(this, arguments);
    }, e);
  }, count: function(a) {
    var b = 0;
    S(a, function() {
      b++;
    });
    return b;
  }, toArray: function(a) {
    return S(a, function(a2) {
      return a2;
    }) || [];
  }, only: function(a) {
    if (!O(a)) throw Error("React.Children.only expected to receive a single React element child.");
    return a;
  } };
  react_production_min.Component = E;
  react_production_min.Fragment = p;
  react_production_min.Profiler = r;
  react_production_min.PureComponent = G;
  react_production_min.StrictMode = q;
  react_production_min.Suspense = w;
  react_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = W;
  react_production_min.act = X;
  react_production_min.cloneElement = function(a, b, e) {
    if (null === a || void 0 === a) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + a + ".");
    var d = C({}, a.props), c = a.key, k = a.ref, h = a._owner;
    if (null != b) {
      void 0 !== b.ref && (k = b.ref, h = K.current);
      void 0 !== b.key && (c = "" + b.key);
      if (a.type && a.type.defaultProps) var g = a.type.defaultProps;
      for (f in b) J.call(b, f) && !L.hasOwnProperty(f) && (d[f] = void 0 === b[f] && void 0 !== g ? g[f] : b[f]);
    }
    var f = arguments.length - 2;
    if (1 === f) d.children = e;
    else if (1 < f) {
      g = Array(f);
      for (var m = 0; m < f; m++) g[m] = arguments[m + 2];
      d.children = g;
    }
    return { $$typeof: l, type: a.type, key: c, ref: k, props: d, _owner: h };
  };
  react_production_min.createContext = function(a) {
    a = { $$typeof: u, _currentValue: a, _currentValue2: a, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null };
    a.Provider = { $$typeof: t2, _context: a };
    return a.Consumer = a;
  };
  react_production_min.createElement = M;
  react_production_min.createFactory = function(a) {
    var b = M.bind(null, a);
    b.type = a;
    return b;
  };
  react_production_min.createRef = function() {
    return { current: null };
  };
  react_production_min.forwardRef = function(a) {
    return { $$typeof: v, render: a };
  };
  react_production_min.isValidElement = O;
  react_production_min.lazy = function(a) {
    return { $$typeof: y, _payload: { _status: -1, _result: a }, _init: T };
  };
  react_production_min.memo = function(a, b) {
    return { $$typeof: x, type: a, compare: void 0 === b ? null : b };
  };
  react_production_min.startTransition = function(a) {
    var b = V.transition;
    V.transition = {};
    try {
      a();
    } finally {
      V.transition = b;
    }
  };
  react_production_min.unstable_act = X;
  react_production_min.useCallback = function(a, b) {
    return U.current.useCallback(a, b);
  };
  react_production_min.useContext = function(a) {
    return U.current.useContext(a);
  };
  react_production_min.useDebugValue = function() {
  };
  react_production_min.useDeferredValue = function(a) {
    return U.current.useDeferredValue(a);
  };
  react_production_min.useEffect = function(a, b) {
    return U.current.useEffect(a, b);
  };
  react_production_min.useId = function() {
    return U.current.useId();
  };
  react_production_min.useImperativeHandle = function(a, b, e) {
    return U.current.useImperativeHandle(a, b, e);
  };
  react_production_min.useInsertionEffect = function(a, b) {
    return U.current.useInsertionEffect(a, b);
  };
  react_production_min.useLayoutEffect = function(a, b) {
    return U.current.useLayoutEffect(a, b);
  };
  react_production_min.useMemo = function(a, b) {
    return U.current.useMemo(a, b);
  };
  react_production_min.useReducer = function(a, b, e) {
    return U.current.useReducer(a, b, e);
  };
  react_production_min.useRef = function(a) {
    return U.current.useRef(a);
  };
  react_production_min.useState = function(a) {
    return U.current.useState(a);
  };
  react_production_min.useSyncExternalStore = function(a, b, e) {
    return U.current.useSyncExternalStore(a, b, e);
  };
  react_production_min.useTransition = function() {
    return U.current.useTransition();
  };
  react_production_min.version = "18.3.1";
  return react_production_min;
}
var hasRequiredReact;
function requireReact() {
  if (hasRequiredReact) return react.exports;
  hasRequiredReact = 1;
  {
    react.exports = requireReact_production_min();
  }
  return react.exports;
}
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var hasRequiredReactJsxRuntime_production_min;
function requireReactJsxRuntime_production_min() {
  if (hasRequiredReactJsxRuntime_production_min) return reactJsxRuntime_production_min;
  hasRequiredReactJsxRuntime_production_min = 1;
  var f = requireReact(), k = Symbol.for("react.element"), l = Symbol.for("react.fragment"), m = Object.prototype.hasOwnProperty, n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p = { key: true, ref: true, __self: true, __source: true };
  function q(c, a, g) {
    var b, d = {}, e = null, h = null;
    void 0 !== g && (e = "" + g);
    void 0 !== a.key && (e = "" + a.key);
    void 0 !== a.ref && (h = a.ref);
    for (b in a) m.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
    if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
    return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
  }
  reactJsxRuntime_production_min.Fragment = l;
  reactJsxRuntime_production_min.jsx = q;
  reactJsxRuntime_production_min.jsxs = q;
  return reactJsxRuntime_production_min;
}
var hasRequiredJsxRuntime;
function requireJsxRuntime() {
  if (hasRequiredJsxRuntime) return jsxRuntime.exports;
  hasRequiredJsxRuntime = 1;
  {
    jsxRuntime.exports = requireReactJsxRuntime_production_min();
  }
  return jsxRuntime.exports;
}
var jsxRuntimeExports = requireJsxRuntime();
var client = {};
var reactDom = { exports: {} };
var reactDom_production_min = {};
var scheduler = { exports: {} };
var scheduler_production_min = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var hasRequiredScheduler_production_min;
function requireScheduler_production_min() {
  if (hasRequiredScheduler_production_min) return scheduler_production_min;
  hasRequiredScheduler_production_min = 1;
  (function(exports) {
    function f(a, b) {
      var c = a.length;
      a.push(b);
      a: for (; 0 < c; ) {
        var d = c - 1 >>> 1, e = a[d];
        if (0 < g(e, b)) a[d] = b, a[c] = e, c = d;
        else break a;
      }
    }
    function h(a) {
      return 0 === a.length ? null : a[0];
    }
    function k(a) {
      if (0 === a.length) return null;
      var b = a[0], c = a.pop();
      if (c !== b) {
        a[0] = c;
        a: for (var d = 0, e = a.length, w = e >>> 1; d < w; ) {
          var m = 2 * (d + 1) - 1, C = a[m], n = m + 1, x = a[n];
          if (0 > g(C, c)) n < e && 0 > g(x, C) ? (a[d] = x, a[n] = c, d = n) : (a[d] = C, a[m] = c, d = m);
          else if (n < e && 0 > g(x, c)) a[d] = x, a[n] = c, d = n;
          else break a;
        }
      }
      return b;
    }
    function g(a, b) {
      var c = a.sortIndex - b.sortIndex;
      return 0 !== c ? c : a.id - b.id;
    }
    if ("object" === typeof performance && "function" === typeof performance.now) {
      var l = performance;
      exports.unstable_now = function() {
        return l.now();
      };
    } else {
      var p = Date, q = p.now();
      exports.unstable_now = function() {
        return p.now() - q;
      };
    }
    var r = [], t2 = [], u = 1, v = null, y = 3, z = false, A = false, B = false, D = "function" === typeof setTimeout ? setTimeout : null, E = "function" === typeof clearTimeout ? clearTimeout : null, F = "undefined" !== typeof setImmediate ? setImmediate : null;
    "undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
    function G(a) {
      for (var b = h(t2); null !== b; ) {
        if (null === b.callback) k(t2);
        else if (b.startTime <= a) k(t2), b.sortIndex = b.expirationTime, f(r, b);
        else break;
        b = h(t2);
      }
    }
    function H(a) {
      B = false;
      G(a);
      if (!A) if (null !== h(r)) A = true, I(J);
      else {
        var b = h(t2);
        null !== b && K(H, b.startTime - a);
      }
    }
    function J(a, b) {
      A = false;
      B && (B = false, E(L), L = -1);
      z = true;
      var c = y;
      try {
        G(b);
        for (v = h(r); null !== v && (!(v.expirationTime > b) || a && !M()); ) {
          var d = v.callback;
          if ("function" === typeof d) {
            v.callback = null;
            y = v.priorityLevel;
            var e = d(v.expirationTime <= b);
            b = exports.unstable_now();
            "function" === typeof e ? v.callback = e : v === h(r) && k(r);
            G(b);
          } else k(r);
          v = h(r);
        }
        if (null !== v) var w = true;
        else {
          var m = h(t2);
          null !== m && K(H, m.startTime - b);
          w = false;
        }
        return w;
      } finally {
        v = null, y = c, z = false;
      }
    }
    var N = false, O = null, L = -1, P = 5, Q = -1;
    function M() {
      return exports.unstable_now() - Q < P ? false : true;
    }
    function R() {
      if (null !== O) {
        var a = exports.unstable_now();
        Q = a;
        var b = true;
        try {
          b = O(true, a);
        } finally {
          b ? S() : (N = false, O = null);
        }
      } else N = false;
    }
    var S;
    if ("function" === typeof F) S = function() {
      F(R);
    };
    else if ("undefined" !== typeof MessageChannel) {
      var T = new MessageChannel(), U = T.port2;
      T.port1.onmessage = R;
      S = function() {
        U.postMessage(null);
      };
    } else S = function() {
      D(R, 0);
    };
    function I(a) {
      O = a;
      N || (N = true, S());
    }
    function K(a, b) {
      L = D(function() {
        a(exports.unstable_now());
      }, b);
    }
    exports.unstable_IdlePriority = 5;
    exports.unstable_ImmediatePriority = 1;
    exports.unstable_LowPriority = 4;
    exports.unstable_NormalPriority = 3;
    exports.unstable_Profiling = null;
    exports.unstable_UserBlockingPriority = 2;
    exports.unstable_cancelCallback = function(a) {
      a.callback = null;
    };
    exports.unstable_continueExecution = function() {
      A || z || (A = true, I(J));
    };
    exports.unstable_forceFrameRate = function(a) {
      0 > a || 125 < a ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : P = 0 < a ? Math.floor(1e3 / a) : 5;
    };
    exports.unstable_getCurrentPriorityLevel = function() {
      return y;
    };
    exports.unstable_getFirstCallbackNode = function() {
      return h(r);
    };
    exports.unstable_next = function(a) {
      switch (y) {
        case 1:
        case 2:
        case 3:
          var b = 3;
          break;
        default:
          b = y;
      }
      var c = y;
      y = b;
      try {
        return a();
      } finally {
        y = c;
      }
    };
    exports.unstable_pauseExecution = function() {
    };
    exports.unstable_requestPaint = function() {
    };
    exports.unstable_runWithPriority = function(a, b) {
      switch (a) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          a = 3;
      }
      var c = y;
      y = a;
      try {
        return b();
      } finally {
        y = c;
      }
    };
    exports.unstable_scheduleCallback = function(a, b, c) {
      var d = exports.unstable_now();
      "object" === typeof c && null !== c ? (c = c.delay, c = "number" === typeof c && 0 < c ? d + c : d) : c = d;
      switch (a) {
        case 1:
          var e = -1;
          break;
        case 2:
          e = 250;
          break;
        case 5:
          e = 1073741823;
          break;
        case 4:
          e = 1e4;
          break;
        default:
          e = 5e3;
      }
      e = c + e;
      a = { id: u++, callback: b, priorityLevel: a, startTime: c, expirationTime: e, sortIndex: -1 };
      c > d ? (a.sortIndex = c, f(t2, a), null === h(r) && a === h(t2) && (B ? (E(L), L = -1) : B = true, K(H, c - d))) : (a.sortIndex = e, f(r, a), A || z || (A = true, I(J)));
      return a;
    };
    exports.unstable_shouldYield = M;
    exports.unstable_wrapCallback = function(a) {
      var b = y;
      return function() {
        var c = y;
        y = b;
        try {
          return a.apply(this, arguments);
        } finally {
          y = c;
        }
      };
    };
  })(scheduler_production_min);
  return scheduler_production_min;
}
var hasRequiredScheduler;
function requireScheduler() {
  if (hasRequiredScheduler) return scheduler.exports;
  hasRequiredScheduler = 1;
  {
    scheduler.exports = requireScheduler_production_min();
  }
  return scheduler.exports;
}
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var hasRequiredReactDom_production_min;
function requireReactDom_production_min() {
  if (hasRequiredReactDom_production_min) return reactDom_production_min;
  hasRequiredReactDom_production_min = 1;
  var aa = requireReact(), ca = requireScheduler();
  function p(a) {
    for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1; c < arguments.length; c++) b += "&args[]=" + encodeURIComponent(arguments[c]);
    return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  var da = /* @__PURE__ */ new Set(), ea = {};
  function fa(a, b) {
    ha(a, b);
    ha(a + "Capture", b);
  }
  function ha(a, b) {
    ea[a] = b;
    for (a = 0; a < b.length; a++) da.add(b[a]);
  }
  var ia = !("undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement), ja = Object.prototype.hasOwnProperty, ka = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, la = {}, ma = {};
  function oa(a) {
    if (ja.call(ma, a)) return true;
    if (ja.call(la, a)) return false;
    if (ka.test(a)) return ma[a] = true;
    la[a] = true;
    return false;
  }
  function pa(a, b, c, d) {
    if (null !== c && 0 === c.type) return false;
    switch (typeof b) {
      case "function":
      case "symbol":
        return true;
      case "boolean":
        if (d) return false;
        if (null !== c) return !c.acceptsBooleans;
        a = a.toLowerCase().slice(0, 5);
        return "data-" !== a && "aria-" !== a;
      default:
        return false;
    }
  }
  function qa(a, b, c, d) {
    if (null === b || "undefined" === typeof b || pa(a, b, c, d)) return true;
    if (d) return false;
    if (null !== c) switch (c.type) {
      case 3:
        return !b;
      case 4:
        return false === b;
      case 5:
        return isNaN(b);
      case 6:
        return isNaN(b) || 1 > b;
    }
    return false;
  }
  function v(a, b, c, d, e, f, g) {
    this.acceptsBooleans = 2 === b || 3 === b || 4 === b;
    this.attributeName = d;
    this.attributeNamespace = e;
    this.mustUseProperty = c;
    this.propertyName = a;
    this.type = b;
    this.sanitizeURL = f;
    this.removeEmptyString = g;
  }
  var z = {};
  "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a) {
    z[a] = new v(a, 0, false, a, null, false, false);
  });
  [["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(a) {
    var b = a[0];
    z[b] = new v(b, 1, false, a[1], null, false, false);
  });
  ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(a) {
    z[a] = new v(a, 2, false, a.toLowerCase(), null, false, false);
  });
  ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(a) {
    z[a] = new v(a, 2, false, a, null, false, false);
  });
  "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a) {
    z[a] = new v(a, 3, false, a.toLowerCase(), null, false, false);
  });
  ["checked", "multiple", "muted", "selected"].forEach(function(a) {
    z[a] = new v(a, 3, true, a, null, false, false);
  });
  ["capture", "download"].forEach(function(a) {
    z[a] = new v(a, 4, false, a, null, false, false);
  });
  ["cols", "rows", "size", "span"].forEach(function(a) {
    z[a] = new v(a, 6, false, a, null, false, false);
  });
  ["rowSpan", "start"].forEach(function(a) {
    z[a] = new v(a, 5, false, a.toLowerCase(), null, false, false);
  });
  var ra = /[\-:]([a-z])/g;
  function sa(a) {
    return a[1].toUpperCase();
  }
  "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a) {
    var b = a.replace(
      ra,
      sa
    );
    z[b] = new v(b, 1, false, a, null, false, false);
  });
  "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a) {
    var b = a.replace(ra, sa);
    z[b] = new v(b, 1, false, a, "http://www.w3.org/1999/xlink", false, false);
  });
  ["xml:base", "xml:lang", "xml:space"].forEach(function(a) {
    var b = a.replace(ra, sa);
    z[b] = new v(b, 1, false, a, "http://www.w3.org/XML/1998/namespace", false, false);
  });
  ["tabIndex", "crossOrigin"].forEach(function(a) {
    z[a] = new v(a, 1, false, a.toLowerCase(), null, false, false);
  });
  z.xlinkHref = new v("xlinkHref", 1, false, "xlink:href", "http://www.w3.org/1999/xlink", true, false);
  ["src", "href", "action", "formAction"].forEach(function(a) {
    z[a] = new v(a, 1, false, a.toLowerCase(), null, true, true);
  });
  function ta(a, b, c, d) {
    var e = z.hasOwnProperty(b) ? z[b] : null;
    if (null !== e ? 0 !== e.type : d || !(2 < b.length) || "o" !== b[0] && "O" !== b[0] || "n" !== b[1] && "N" !== b[1]) qa(b, c, e, d) && (c = null), d || null === e ? oa(b) && (null === c ? a.removeAttribute(b) : a.setAttribute(b, "" + c)) : e.mustUseProperty ? a[e.propertyName] = null === c ? 3 === e.type ? false : "" : c : (b = e.attributeName, d = e.attributeNamespace, null === c ? a.removeAttribute(b) : (e = e.type, c = 3 === e || 4 === e && true === c ? "" : "" + c, d ? a.setAttributeNS(d, b, c) : a.setAttribute(b, c)));
  }
  var ua = aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, va = Symbol.for("react.element"), wa = Symbol.for("react.portal"), ya = Symbol.for("react.fragment"), za = Symbol.for("react.strict_mode"), Aa = Symbol.for("react.profiler"), Ba = Symbol.for("react.provider"), Ca = Symbol.for("react.context"), Da = Symbol.for("react.forward_ref"), Ea = Symbol.for("react.suspense"), Fa = Symbol.for("react.suspense_list"), Ga = Symbol.for("react.memo"), Ha = Symbol.for("react.lazy");
  var Ia = Symbol.for("react.offscreen");
  var Ja = Symbol.iterator;
  function Ka(a) {
    if (null === a || "object" !== typeof a) return null;
    a = Ja && a[Ja] || a["@@iterator"];
    return "function" === typeof a ? a : null;
  }
  var A = Object.assign, La;
  function Ma(a) {
    if (void 0 === La) try {
      throw Error();
    } catch (c) {
      var b = c.stack.trim().match(/\n( *(at )?)/);
      La = b && b[1] || "";
    }
    return "\n" + La + a;
  }
  var Na = false;
  function Oa(a, b) {
    if (!a || Na) return "";
    Na = true;
    var c = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (b) if (b = function() {
        throw Error();
      }, Object.defineProperty(b.prototype, "props", { set: function() {
        throw Error();
      } }), "object" === typeof Reflect && Reflect.construct) {
        try {
          Reflect.construct(b, []);
        } catch (l) {
          var d = l;
        }
        Reflect.construct(a, [], b);
      } else {
        try {
          b.call();
        } catch (l) {
          d = l;
        }
        a.call(b.prototype);
      }
      else {
        try {
          throw Error();
        } catch (l) {
          d = l;
        }
        a();
      }
    } catch (l) {
      if (l && d && "string" === typeof l.stack) {
        for (var e = l.stack.split("\n"), f = d.stack.split("\n"), g = e.length - 1, h = f.length - 1; 1 <= g && 0 <= h && e[g] !== f[h]; ) h--;
        for (; 1 <= g && 0 <= h; g--, h--) if (e[g] !== f[h]) {
          if (1 !== g || 1 !== h) {
            do
              if (g--, h--, 0 > h || e[g] !== f[h]) {
                var k = "\n" + e[g].replace(" at new ", " at ");
                a.displayName && k.includes("<anonymous>") && (k = k.replace("<anonymous>", a.displayName));
                return k;
              }
            while (1 <= g && 0 <= h);
          }
          break;
        }
      }
    } finally {
      Na = false, Error.prepareStackTrace = c;
    }
    return (a = a ? a.displayName || a.name : "") ? Ma(a) : "";
  }
  function Pa(a) {
    switch (a.tag) {
      case 5:
        return Ma(a.type);
      case 16:
        return Ma("Lazy");
      case 13:
        return Ma("Suspense");
      case 19:
        return Ma("SuspenseList");
      case 0:
      case 2:
      case 15:
        return a = Oa(a.type, false), a;
      case 11:
        return a = Oa(a.type.render, false), a;
      case 1:
        return a = Oa(a.type, true), a;
      default:
        return "";
    }
  }
  function Qa(a) {
    if (null == a) return null;
    if ("function" === typeof a) return a.displayName || a.name || null;
    if ("string" === typeof a) return a;
    switch (a) {
      case ya:
        return "Fragment";
      case wa:
        return "Portal";
      case Aa:
        return "Profiler";
      case za:
        return "StrictMode";
      case Ea:
        return "Suspense";
      case Fa:
        return "SuspenseList";
    }
    if ("object" === typeof a) switch (a.$$typeof) {
      case Ca:
        return (a.displayName || "Context") + ".Consumer";
      case Ba:
        return (a._context.displayName || "Context") + ".Provider";
      case Da:
        var b = a.render;
        a = a.displayName;
        a || (a = b.displayName || b.name || "", a = "" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
        return a;
      case Ga:
        return b = a.displayName || null, null !== b ? b : Qa(a.type) || "Memo";
      case Ha:
        b = a._payload;
        a = a._init;
        try {
          return Qa(a(b));
        } catch (c) {
        }
    }
    return null;
  }
  function Ra(a) {
    var b = a.type;
    switch (a.tag) {
      case 24:
        return "Cache";
      case 9:
        return (b.displayName || "Context") + ".Consumer";
      case 10:
        return (b._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return a = b.render, a = a.displayName || a.name || "", b.displayName || ("" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
      case 7:
        return "Fragment";
      case 5:
        return b;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return Qa(b);
      case 8:
        return b === za ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if ("function" === typeof b) return b.displayName || b.name || null;
        if ("string" === typeof b) return b;
    }
    return null;
  }
  function Sa(a) {
    switch (typeof a) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return a;
      case "object":
        return a;
      default:
        return "";
    }
  }
  function Ta(a) {
    var b = a.type;
    return (a = a.nodeName) && "input" === a.toLowerCase() && ("checkbox" === b || "radio" === b);
  }
  function Ua(a) {
    var b = Ta(a) ? "checked" : "value", c = Object.getOwnPropertyDescriptor(a.constructor.prototype, b), d = "" + a[b];
    if (!a.hasOwnProperty(b) && "undefined" !== typeof c && "function" === typeof c.get && "function" === typeof c.set) {
      var e = c.get, f = c.set;
      Object.defineProperty(a, b, { configurable: true, get: function() {
        return e.call(this);
      }, set: function(a2) {
        d = "" + a2;
        f.call(this, a2);
      } });
      Object.defineProperty(a, b, { enumerable: c.enumerable });
      return { getValue: function() {
        return d;
      }, setValue: function(a2) {
        d = "" + a2;
      }, stopTracking: function() {
        a._valueTracker = null;
        delete a[b];
      } };
    }
  }
  function Va(a) {
    a._valueTracker || (a._valueTracker = Ua(a));
  }
  function Wa(a) {
    if (!a) return false;
    var b = a._valueTracker;
    if (!b) return true;
    var c = b.getValue();
    var d = "";
    a && (d = Ta(a) ? a.checked ? "true" : "false" : a.value);
    a = d;
    return a !== c ? (b.setValue(a), true) : false;
  }
  function Xa(a) {
    a = a || ("undefined" !== typeof document ? document : void 0);
    if ("undefined" === typeof a) return null;
    try {
      return a.activeElement || a.body;
    } catch (b) {
      return a.body;
    }
  }
  function Ya(a, b) {
    var c = b.checked;
    return A({}, b, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: null != c ? c : a._wrapperState.initialChecked });
  }
  function Za(a, b) {
    var c = null == b.defaultValue ? "" : b.defaultValue, d = null != b.checked ? b.checked : b.defaultChecked;
    c = Sa(null != b.value ? b.value : c);
    a._wrapperState = { initialChecked: d, initialValue: c, controlled: "checkbox" === b.type || "radio" === b.type ? null != b.checked : null != b.value };
  }
  function ab(a, b) {
    b = b.checked;
    null != b && ta(a, "checked", b, false);
  }
  function bb(a, b) {
    ab(a, b);
    var c = Sa(b.value), d = b.type;
    if (null != c) if ("number" === d) {
      if (0 === c && "" === a.value || a.value != c) a.value = "" + c;
    } else a.value !== "" + c && (a.value = "" + c);
    else if ("submit" === d || "reset" === d) {
      a.removeAttribute("value");
      return;
    }
    b.hasOwnProperty("value") ? cb(a, b.type, c) : b.hasOwnProperty("defaultValue") && cb(a, b.type, Sa(b.defaultValue));
    null == b.checked && null != b.defaultChecked && (a.defaultChecked = !!b.defaultChecked);
  }
  function db(a, b, c) {
    if (b.hasOwnProperty("value") || b.hasOwnProperty("defaultValue")) {
      var d = b.type;
      if (!("submit" !== d && "reset" !== d || void 0 !== b.value && null !== b.value)) return;
      b = "" + a._wrapperState.initialValue;
      c || b === a.value || (a.value = b);
      a.defaultValue = b;
    }
    c = a.name;
    "" !== c && (a.name = "");
    a.defaultChecked = !!a._wrapperState.initialChecked;
    "" !== c && (a.name = c);
  }
  function cb(a, b, c) {
    if ("number" !== b || Xa(a.ownerDocument) !== a) null == c ? a.defaultValue = "" + a._wrapperState.initialValue : a.defaultValue !== "" + c && (a.defaultValue = "" + c);
  }
  var eb = Array.isArray;
  function fb(a, b, c, d) {
    a = a.options;
    if (b) {
      b = {};
      for (var e = 0; e < c.length; e++) b["$" + c[e]] = true;
      for (c = 0; c < a.length; c++) e = b.hasOwnProperty("$" + a[c].value), a[c].selected !== e && (a[c].selected = e), e && d && (a[c].defaultSelected = true);
    } else {
      c = "" + Sa(c);
      b = null;
      for (e = 0; e < a.length; e++) {
        if (a[e].value === c) {
          a[e].selected = true;
          d && (a[e].defaultSelected = true);
          return;
        }
        null !== b || a[e].disabled || (b = a[e]);
      }
      null !== b && (b.selected = true);
    }
  }
  function gb(a, b) {
    if (null != b.dangerouslySetInnerHTML) throw Error(p(91));
    return A({}, b, { value: void 0, defaultValue: void 0, children: "" + a._wrapperState.initialValue });
  }
  function hb(a, b) {
    var c = b.value;
    if (null == c) {
      c = b.children;
      b = b.defaultValue;
      if (null != c) {
        if (null != b) throw Error(p(92));
        if (eb(c)) {
          if (1 < c.length) throw Error(p(93));
          c = c[0];
        }
        b = c;
      }
      null == b && (b = "");
      c = b;
    }
    a._wrapperState = { initialValue: Sa(c) };
  }
  function ib(a, b) {
    var c = Sa(b.value), d = Sa(b.defaultValue);
    null != c && (c = "" + c, c !== a.value && (a.value = c), null == b.defaultValue && a.defaultValue !== c && (a.defaultValue = c));
    null != d && (a.defaultValue = "" + d);
  }
  function jb(a) {
    var b = a.textContent;
    b === a._wrapperState.initialValue && "" !== b && null !== b && (a.value = b);
  }
  function kb(a) {
    switch (a) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function lb(a, b) {
    return null == a || "http://www.w3.org/1999/xhtml" === a ? kb(b) : "http://www.w3.org/2000/svg" === a && "foreignObject" === b ? "http://www.w3.org/1999/xhtml" : a;
  }
  var mb, nb = (function(a) {
    return "undefined" !== typeof MSApp && MSApp.execUnsafeLocalFunction ? function(b, c, d, e) {
      MSApp.execUnsafeLocalFunction(function() {
        return a(b, c, d, e);
      });
    } : a;
  })(function(a, b) {
    if ("http://www.w3.org/2000/svg" !== a.namespaceURI || "innerHTML" in a) a.innerHTML = b;
    else {
      mb = mb || document.createElement("div");
      mb.innerHTML = "<svg>" + b.valueOf().toString() + "</svg>";
      for (b = mb.firstChild; a.firstChild; ) a.removeChild(a.firstChild);
      for (; b.firstChild; ) a.appendChild(b.firstChild);
    }
  });
  function ob(a, b) {
    if (b) {
      var c = a.firstChild;
      if (c && c === a.lastChild && 3 === c.nodeType) {
        c.nodeValue = b;
        return;
      }
    }
    a.textContent = b;
  }
  var pb = {
    animationIterationCount: true,
    aspectRatio: true,
    borderImageOutset: true,
    borderImageSlice: true,
    borderImageWidth: true,
    boxFlex: true,
    boxFlexGroup: true,
    boxOrdinalGroup: true,
    columnCount: true,
    columns: true,
    flex: true,
    flexGrow: true,
    flexPositive: true,
    flexShrink: true,
    flexNegative: true,
    flexOrder: true,
    gridArea: true,
    gridRow: true,
    gridRowEnd: true,
    gridRowSpan: true,
    gridRowStart: true,
    gridColumn: true,
    gridColumnEnd: true,
    gridColumnSpan: true,
    gridColumnStart: true,
    fontWeight: true,
    lineClamp: true,
    lineHeight: true,
    opacity: true,
    order: true,
    orphans: true,
    tabSize: true,
    widows: true,
    zIndex: true,
    zoom: true,
    fillOpacity: true,
    floodOpacity: true,
    stopOpacity: true,
    strokeDasharray: true,
    strokeDashoffset: true,
    strokeMiterlimit: true,
    strokeOpacity: true,
    strokeWidth: true
  }, qb = ["Webkit", "ms", "Moz", "O"];
  Object.keys(pb).forEach(function(a) {
    qb.forEach(function(b) {
      b = b + a.charAt(0).toUpperCase() + a.substring(1);
      pb[b] = pb[a];
    });
  });
  function rb(a, b, c) {
    return null == b || "boolean" === typeof b || "" === b ? "" : c || "number" !== typeof b || 0 === b || pb.hasOwnProperty(a) && pb[a] ? ("" + b).trim() : b + "px";
  }
  function sb(a, b) {
    a = a.style;
    for (var c in b) if (b.hasOwnProperty(c)) {
      var d = 0 === c.indexOf("--"), e = rb(c, b[c], d);
      "float" === c && (c = "cssFloat");
      d ? a.setProperty(c, e) : a[c] = e;
    }
  }
  var tb = A({ menuitem: true }, { area: true, base: true, br: true, col: true, embed: true, hr: true, img: true, input: true, keygen: true, link: true, meta: true, param: true, source: true, track: true, wbr: true });
  function ub(a, b) {
    if (b) {
      if (tb[a] && (null != b.children || null != b.dangerouslySetInnerHTML)) throw Error(p(137, a));
      if (null != b.dangerouslySetInnerHTML) {
        if (null != b.children) throw Error(p(60));
        if ("object" !== typeof b.dangerouslySetInnerHTML || !("__html" in b.dangerouslySetInnerHTML)) throw Error(p(61));
      }
      if (null != b.style && "object" !== typeof b.style) throw Error(p(62));
    }
  }
  function vb(a, b) {
    if (-1 === a.indexOf("-")) return "string" === typeof b.is;
    switch (a) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return false;
      default:
        return true;
    }
  }
  var wb = null;
  function xb(a) {
    a = a.target || a.srcElement || window;
    a.correspondingUseElement && (a = a.correspondingUseElement);
    return 3 === a.nodeType ? a.parentNode : a;
  }
  var yb = null, zb = null, Ab = null;
  function Bb(a) {
    if (a = Cb(a)) {
      if ("function" !== typeof yb) throw Error(p(280));
      var b = a.stateNode;
      b && (b = Db(b), yb(a.stateNode, a.type, b));
    }
  }
  function Eb(a) {
    zb ? Ab ? Ab.push(a) : Ab = [a] : zb = a;
  }
  function Fb() {
    if (zb) {
      var a = zb, b = Ab;
      Ab = zb = null;
      Bb(a);
      if (b) for (a = 0; a < b.length; a++) Bb(b[a]);
    }
  }
  function Gb(a, b) {
    return a(b);
  }
  function Hb() {
  }
  var Ib = false;
  function Jb(a, b, c) {
    if (Ib) return a(b, c);
    Ib = true;
    try {
      return Gb(a, b, c);
    } finally {
      if (Ib = false, null !== zb || null !== Ab) Hb(), Fb();
    }
  }
  function Kb(a, b) {
    var c = a.stateNode;
    if (null === c) return null;
    var d = Db(c);
    if (null === d) return null;
    c = d[b];
    a: switch (b) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (d = !d.disabled) || (a = a.type, d = !("button" === a || "input" === a || "select" === a || "textarea" === a));
        a = !d;
        break a;
      default:
        a = false;
    }
    if (a) return null;
    if (c && "function" !== typeof c) throw Error(p(231, b, typeof c));
    return c;
  }
  var Lb = false;
  if (ia) try {
    var Mb = {};
    Object.defineProperty(Mb, "passive", { get: function() {
      Lb = true;
    } });
    window.addEventListener("test", Mb, Mb);
    window.removeEventListener("test", Mb, Mb);
  } catch (a) {
    Lb = false;
  }
  function Nb(a, b, c, d, e, f, g, h, k) {
    var l = Array.prototype.slice.call(arguments, 3);
    try {
      b.apply(c, l);
    } catch (m) {
      this.onError(m);
    }
  }
  var Ob = false, Pb = null, Qb = false, Rb = null, Sb = { onError: function(a) {
    Ob = true;
    Pb = a;
  } };
  function Tb(a, b, c, d, e, f, g, h, k) {
    Ob = false;
    Pb = null;
    Nb.apply(Sb, arguments);
  }
  function Ub(a, b, c, d, e, f, g, h, k) {
    Tb.apply(this, arguments);
    if (Ob) {
      if (Ob) {
        var l = Pb;
        Ob = false;
        Pb = null;
      } else throw Error(p(198));
      Qb || (Qb = true, Rb = l);
    }
  }
  function Vb(a) {
    var b = a, c = a;
    if (a.alternate) for (; b.return; ) b = b.return;
    else {
      a = b;
      do
        b = a, 0 !== (b.flags & 4098) && (c = b.return), a = b.return;
      while (a);
    }
    return 3 === b.tag ? c : null;
  }
  function Wb(a) {
    if (13 === a.tag) {
      var b = a.memoizedState;
      null === b && (a = a.alternate, null !== a && (b = a.memoizedState));
      if (null !== b) return b.dehydrated;
    }
    return null;
  }
  function Xb(a) {
    if (Vb(a) !== a) throw Error(p(188));
  }
  function Yb(a) {
    var b = a.alternate;
    if (!b) {
      b = Vb(a);
      if (null === b) throw Error(p(188));
      return b !== a ? null : a;
    }
    for (var c = a, d = b; ; ) {
      var e = c.return;
      if (null === e) break;
      var f = e.alternate;
      if (null === f) {
        d = e.return;
        if (null !== d) {
          c = d;
          continue;
        }
        break;
      }
      if (e.child === f.child) {
        for (f = e.child; f; ) {
          if (f === c) return Xb(e), a;
          if (f === d) return Xb(e), b;
          f = f.sibling;
        }
        throw Error(p(188));
      }
      if (c.return !== d.return) c = e, d = f;
      else {
        for (var g = false, h = e.child; h; ) {
          if (h === c) {
            g = true;
            c = e;
            d = f;
            break;
          }
          if (h === d) {
            g = true;
            d = e;
            c = f;
            break;
          }
          h = h.sibling;
        }
        if (!g) {
          for (h = f.child; h; ) {
            if (h === c) {
              g = true;
              c = f;
              d = e;
              break;
            }
            if (h === d) {
              g = true;
              d = f;
              c = e;
              break;
            }
            h = h.sibling;
          }
          if (!g) throw Error(p(189));
        }
      }
      if (c.alternate !== d) throw Error(p(190));
    }
    if (3 !== c.tag) throw Error(p(188));
    return c.stateNode.current === c ? a : b;
  }
  function Zb(a) {
    a = Yb(a);
    return null !== a ? $b(a) : null;
  }
  function $b(a) {
    if (5 === a.tag || 6 === a.tag) return a;
    for (a = a.child; null !== a; ) {
      var b = $b(a);
      if (null !== b) return b;
      a = a.sibling;
    }
    return null;
  }
  var ac = ca.unstable_scheduleCallback, bc = ca.unstable_cancelCallback, cc = ca.unstable_shouldYield, dc = ca.unstable_requestPaint, B = ca.unstable_now, ec = ca.unstable_getCurrentPriorityLevel, fc = ca.unstable_ImmediatePriority, gc = ca.unstable_UserBlockingPriority, hc = ca.unstable_NormalPriority, ic = ca.unstable_LowPriority, jc = ca.unstable_IdlePriority, kc = null, lc = null;
  function mc(a) {
    if (lc && "function" === typeof lc.onCommitFiberRoot) try {
      lc.onCommitFiberRoot(kc, a, void 0, 128 === (a.current.flags & 128));
    } catch (b) {
    }
  }
  var oc = Math.clz32 ? Math.clz32 : nc, pc = Math.log, qc = Math.LN2;
  function nc(a) {
    a >>>= 0;
    return 0 === a ? 32 : 31 - (pc(a) / qc | 0) | 0;
  }
  var rc = 64, sc = 4194304;
  function tc(a) {
    switch (a & -a) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return a & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return a & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return a;
    }
  }
  function uc(a, b) {
    var c = a.pendingLanes;
    if (0 === c) return 0;
    var d = 0, e = a.suspendedLanes, f = a.pingedLanes, g = c & 268435455;
    if (0 !== g) {
      var h = g & ~e;
      0 !== h ? d = tc(h) : (f &= g, 0 !== f && (d = tc(f)));
    } else g = c & ~e, 0 !== g ? d = tc(g) : 0 !== f && (d = tc(f));
    if (0 === d) return 0;
    if (0 !== b && b !== d && 0 === (b & e) && (e = d & -d, f = b & -b, e >= f || 16 === e && 0 !== (f & 4194240))) return b;
    0 !== (d & 4) && (d |= c & 16);
    b = a.entangledLanes;
    if (0 !== b) for (a = a.entanglements, b &= d; 0 < b; ) c = 31 - oc(b), e = 1 << c, d |= a[c], b &= ~e;
    return d;
  }
  function vc(a, b) {
    switch (a) {
      case 1:
      case 2:
      case 4:
        return b + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return b + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function wc(a, b) {
    for (var c = a.suspendedLanes, d = a.pingedLanes, e = a.expirationTimes, f = a.pendingLanes; 0 < f; ) {
      var g = 31 - oc(f), h = 1 << g, k = e[g];
      if (-1 === k) {
        if (0 === (h & c) || 0 !== (h & d)) e[g] = vc(h, b);
      } else k <= b && (a.expiredLanes |= h);
      f &= ~h;
    }
  }
  function xc(a) {
    a = a.pendingLanes & -1073741825;
    return 0 !== a ? a : a & 1073741824 ? 1073741824 : 0;
  }
  function yc() {
    var a = rc;
    rc <<= 1;
    0 === (rc & 4194240) && (rc = 64);
    return a;
  }
  function zc(a) {
    for (var b = [], c = 0; 31 > c; c++) b.push(a);
    return b;
  }
  function Ac(a, b, c) {
    a.pendingLanes |= b;
    536870912 !== b && (a.suspendedLanes = 0, a.pingedLanes = 0);
    a = a.eventTimes;
    b = 31 - oc(b);
    a[b] = c;
  }
  function Bc(a, b) {
    var c = a.pendingLanes & ~b;
    a.pendingLanes = b;
    a.suspendedLanes = 0;
    a.pingedLanes = 0;
    a.expiredLanes &= b;
    a.mutableReadLanes &= b;
    a.entangledLanes &= b;
    b = a.entanglements;
    var d = a.eventTimes;
    for (a = a.expirationTimes; 0 < c; ) {
      var e = 31 - oc(c), f = 1 << e;
      b[e] = 0;
      d[e] = -1;
      a[e] = -1;
      c &= ~f;
    }
  }
  function Cc(a, b) {
    var c = a.entangledLanes |= b;
    for (a = a.entanglements; c; ) {
      var d = 31 - oc(c), e = 1 << d;
      e & b | a[d] & b && (a[d] |= b);
      c &= ~e;
    }
  }
  var C = 0;
  function Dc(a) {
    a &= -a;
    return 1 < a ? 4 < a ? 0 !== (a & 268435455) ? 16 : 536870912 : 4 : 1;
  }
  var Ec, Fc, Gc, Hc, Ic, Jc = false, Kc = [], Lc = null, Mc = null, Nc = null, Oc = /* @__PURE__ */ new Map(), Pc = /* @__PURE__ */ new Map(), Qc = [], Rc = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
  function Sc(a, b) {
    switch (a) {
      case "focusin":
      case "focusout":
        Lc = null;
        break;
      case "dragenter":
      case "dragleave":
        Mc = null;
        break;
      case "mouseover":
      case "mouseout":
        Nc = null;
        break;
      case "pointerover":
      case "pointerout":
        Oc.delete(b.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Pc.delete(b.pointerId);
    }
  }
  function Tc(a, b, c, d, e, f) {
    if (null === a || a.nativeEvent !== f) return a = { blockedOn: b, domEventName: c, eventSystemFlags: d, nativeEvent: f, targetContainers: [e] }, null !== b && (b = Cb(b), null !== b && Fc(b)), a;
    a.eventSystemFlags |= d;
    b = a.targetContainers;
    null !== e && -1 === b.indexOf(e) && b.push(e);
    return a;
  }
  function Uc(a, b, c, d, e) {
    switch (b) {
      case "focusin":
        return Lc = Tc(Lc, a, b, c, d, e), true;
      case "dragenter":
        return Mc = Tc(Mc, a, b, c, d, e), true;
      case "mouseover":
        return Nc = Tc(Nc, a, b, c, d, e), true;
      case "pointerover":
        var f = e.pointerId;
        Oc.set(f, Tc(Oc.get(f) || null, a, b, c, d, e));
        return true;
      case "gotpointercapture":
        return f = e.pointerId, Pc.set(f, Tc(Pc.get(f) || null, a, b, c, d, e)), true;
    }
    return false;
  }
  function Vc(a) {
    var b = Wc(a.target);
    if (null !== b) {
      var c = Vb(b);
      if (null !== c) {
        if (b = c.tag, 13 === b) {
          if (b = Wb(c), null !== b) {
            a.blockedOn = b;
            Ic(a.priority, function() {
              Gc(c);
            });
            return;
          }
        } else if (3 === b && c.stateNode.current.memoizedState.isDehydrated) {
          a.blockedOn = 3 === c.tag ? c.stateNode.containerInfo : null;
          return;
        }
      }
    }
    a.blockedOn = null;
  }
  function Xc(a) {
    if (null !== a.blockedOn) return false;
    for (var b = a.targetContainers; 0 < b.length; ) {
      var c = Yc(a.domEventName, a.eventSystemFlags, b[0], a.nativeEvent);
      if (null === c) {
        c = a.nativeEvent;
        var d = new c.constructor(c.type, c);
        wb = d;
        c.target.dispatchEvent(d);
        wb = null;
      } else return b = Cb(c), null !== b && Fc(b), a.blockedOn = c, false;
      b.shift();
    }
    return true;
  }
  function Zc(a, b, c) {
    Xc(a) && c.delete(b);
  }
  function $c() {
    Jc = false;
    null !== Lc && Xc(Lc) && (Lc = null);
    null !== Mc && Xc(Mc) && (Mc = null);
    null !== Nc && Xc(Nc) && (Nc = null);
    Oc.forEach(Zc);
    Pc.forEach(Zc);
  }
  function ad(a, b) {
    a.blockedOn === b && (a.blockedOn = null, Jc || (Jc = true, ca.unstable_scheduleCallback(ca.unstable_NormalPriority, $c)));
  }
  function bd(a) {
    function b(b2) {
      return ad(b2, a);
    }
    if (0 < Kc.length) {
      ad(Kc[0], a);
      for (var c = 1; c < Kc.length; c++) {
        var d = Kc[c];
        d.blockedOn === a && (d.blockedOn = null);
      }
    }
    null !== Lc && ad(Lc, a);
    null !== Mc && ad(Mc, a);
    null !== Nc && ad(Nc, a);
    Oc.forEach(b);
    Pc.forEach(b);
    for (c = 0; c < Qc.length; c++) d = Qc[c], d.blockedOn === a && (d.blockedOn = null);
    for (; 0 < Qc.length && (c = Qc[0], null === c.blockedOn); ) Vc(c), null === c.blockedOn && Qc.shift();
  }
  var cd = ua.ReactCurrentBatchConfig, dd = true;
  function ed(a, b, c, d) {
    var e = C, f = cd.transition;
    cd.transition = null;
    try {
      C = 1, fd(a, b, c, d);
    } finally {
      C = e, cd.transition = f;
    }
  }
  function gd(a, b, c, d) {
    var e = C, f = cd.transition;
    cd.transition = null;
    try {
      C = 4, fd(a, b, c, d);
    } finally {
      C = e, cd.transition = f;
    }
  }
  function fd(a, b, c, d) {
    if (dd) {
      var e = Yc(a, b, c, d);
      if (null === e) hd(a, b, d, id, c), Sc(a, d);
      else if (Uc(e, a, b, c, d)) d.stopPropagation();
      else if (Sc(a, d), b & 4 && -1 < Rc.indexOf(a)) {
        for (; null !== e; ) {
          var f = Cb(e);
          null !== f && Ec(f);
          f = Yc(a, b, c, d);
          null === f && hd(a, b, d, id, c);
          if (f === e) break;
          e = f;
        }
        null !== e && d.stopPropagation();
      } else hd(a, b, d, null, c);
    }
  }
  var id = null;
  function Yc(a, b, c, d) {
    id = null;
    a = xb(d);
    a = Wc(a);
    if (null !== a) if (b = Vb(a), null === b) a = null;
    else if (c = b.tag, 13 === c) {
      a = Wb(b);
      if (null !== a) return a;
      a = null;
    } else if (3 === c) {
      if (b.stateNode.current.memoizedState.isDehydrated) return 3 === b.tag ? b.stateNode.containerInfo : null;
      a = null;
    } else b !== a && (a = null);
    id = a;
    return null;
  }
  function jd(a) {
    switch (a) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (ec()) {
          case fc:
            return 1;
          case gc:
            return 4;
          case hc:
          case ic:
            return 16;
          case jc:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var kd = null, ld = null, md = null;
  function nd() {
    if (md) return md;
    var a, b = ld, c = b.length, d, e = "value" in kd ? kd.value : kd.textContent, f = e.length;
    for (a = 0; a < c && b[a] === e[a]; a++) ;
    var g = c - a;
    for (d = 1; d <= g && b[c - d] === e[f - d]; d++) ;
    return md = e.slice(a, 1 < d ? 1 - d : void 0);
  }
  function od(a) {
    var b = a.keyCode;
    "charCode" in a ? (a = a.charCode, 0 === a && 13 === b && (a = 13)) : a = b;
    10 === a && (a = 13);
    return 32 <= a || 13 === a ? a : 0;
  }
  function pd() {
    return true;
  }
  function qd() {
    return false;
  }
  function rd(a) {
    function b(b2, d, e, f, g) {
      this._reactName = b2;
      this._targetInst = e;
      this.type = d;
      this.nativeEvent = f;
      this.target = g;
      this.currentTarget = null;
      for (var c in a) a.hasOwnProperty(c) && (b2 = a[c], this[c] = b2 ? b2(f) : f[c]);
      this.isDefaultPrevented = (null != f.defaultPrevented ? f.defaultPrevented : false === f.returnValue) ? pd : qd;
      this.isPropagationStopped = qd;
      return this;
    }
    A(b.prototype, { preventDefault: function() {
      this.defaultPrevented = true;
      var a2 = this.nativeEvent;
      a2 && (a2.preventDefault ? a2.preventDefault() : "unknown" !== typeof a2.returnValue && (a2.returnValue = false), this.isDefaultPrevented = pd);
    }, stopPropagation: function() {
      var a2 = this.nativeEvent;
      a2 && (a2.stopPropagation ? a2.stopPropagation() : "unknown" !== typeof a2.cancelBubble && (a2.cancelBubble = true), this.isPropagationStopped = pd);
    }, persist: function() {
    }, isPersistent: pd });
    return b;
  }
  var sd = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(a) {
    return a.timeStamp || Date.now();
  }, defaultPrevented: 0, isTrusted: 0 }, td = rd(sd), ud = A({}, sd, { view: 0, detail: 0 }), vd = rd(ud), wd, xd, yd, Ad = A({}, ud, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: zd, button: 0, buttons: 0, relatedTarget: function(a) {
    return void 0 === a.relatedTarget ? a.fromElement === a.srcElement ? a.toElement : a.fromElement : a.relatedTarget;
  }, movementX: function(a) {
    if ("movementX" in a) return a.movementX;
    a !== yd && (yd && "mousemove" === a.type ? (wd = a.screenX - yd.screenX, xd = a.screenY - yd.screenY) : xd = wd = 0, yd = a);
    return wd;
  }, movementY: function(a) {
    return "movementY" in a ? a.movementY : xd;
  } }), Bd = rd(Ad), Cd = A({}, Ad, { dataTransfer: 0 }), Dd = rd(Cd), Ed = A({}, ud, { relatedTarget: 0 }), Fd = rd(Ed), Gd = A({}, sd, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), Hd = rd(Gd), Id = A({}, sd, { clipboardData: function(a) {
    return "clipboardData" in a ? a.clipboardData : window.clipboardData;
  } }), Jd = rd(Id), Kd = A({}, sd, { data: 0 }), Ld = rd(Kd), Md = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, Nd = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  }, Od = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
  function Pd(a) {
    var b = this.nativeEvent;
    return b.getModifierState ? b.getModifierState(a) : (a = Od[a]) ? !!b[a] : false;
  }
  function zd() {
    return Pd;
  }
  var Qd = A({}, ud, { key: function(a) {
    if (a.key) {
      var b = Md[a.key] || a.key;
      if ("Unidentified" !== b) return b;
    }
    return "keypress" === a.type ? (a = od(a), 13 === a ? "Enter" : String.fromCharCode(a)) : "keydown" === a.type || "keyup" === a.type ? Nd[a.keyCode] || "Unidentified" : "";
  }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: zd, charCode: function(a) {
    return "keypress" === a.type ? od(a) : 0;
  }, keyCode: function(a) {
    return "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
  }, which: function(a) {
    return "keypress" === a.type ? od(a) : "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
  } }), Rd = rd(Qd), Sd = A({}, Ad, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), Td = rd(Sd), Ud = A({}, ud, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: zd }), Vd = rd(Ud), Wd = A({}, sd, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), Xd = rd(Wd), Yd = A({}, Ad, {
    deltaX: function(a) {
      return "deltaX" in a ? a.deltaX : "wheelDeltaX" in a ? -a.wheelDeltaX : 0;
    },
    deltaY: function(a) {
      return "deltaY" in a ? a.deltaY : "wheelDeltaY" in a ? -a.wheelDeltaY : "wheelDelta" in a ? -a.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  }), Zd = rd(Yd), $d = [9, 13, 27, 32], ae = ia && "CompositionEvent" in window, be = null;
  ia && "documentMode" in document && (be = document.documentMode);
  var ce = ia && "TextEvent" in window && !be, de = ia && (!ae || be && 8 < be && 11 >= be), ee = String.fromCharCode(32), fe = false;
  function ge(a, b) {
    switch (a) {
      case "keyup":
        return -1 !== $d.indexOf(b.keyCode);
      case "keydown":
        return 229 !== b.keyCode;
      case "keypress":
      case "mousedown":
      case "focusout":
        return true;
      default:
        return false;
    }
  }
  function he(a) {
    a = a.detail;
    return "object" === typeof a && "data" in a ? a.data : null;
  }
  var ie = false;
  function je(a, b) {
    switch (a) {
      case "compositionend":
        return he(b);
      case "keypress":
        if (32 !== b.which) return null;
        fe = true;
        return ee;
      case "textInput":
        return a = b.data, a === ee && fe ? null : a;
      default:
        return null;
    }
  }
  function ke(a, b) {
    if (ie) return "compositionend" === a || !ae && ge(a, b) ? (a = nd(), md = ld = kd = null, ie = false, a) : null;
    switch (a) {
      case "paste":
        return null;
      case "keypress":
        if (!(b.ctrlKey || b.altKey || b.metaKey) || b.ctrlKey && b.altKey) {
          if (b.char && 1 < b.char.length) return b.char;
          if (b.which) return String.fromCharCode(b.which);
        }
        return null;
      case "compositionend":
        return de && "ko" !== b.locale ? null : b.data;
      default:
        return null;
    }
  }
  var le = { color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true };
  function me(a) {
    var b = a && a.nodeName && a.nodeName.toLowerCase();
    return "input" === b ? !!le[a.type] : "textarea" === b ? true : false;
  }
  function ne(a, b, c, d) {
    Eb(d);
    b = oe(b, "onChange");
    0 < b.length && (c = new td("onChange", "change", null, c, d), a.push({ event: c, listeners: b }));
  }
  var pe = null, qe = null;
  function re(a) {
    se(a, 0);
  }
  function te(a) {
    var b = ue(a);
    if (Wa(b)) return a;
  }
  function ve(a, b) {
    if ("change" === a) return b;
  }
  var we = false;
  if (ia) {
    var xe;
    if (ia) {
      var ye = "oninput" in document;
      if (!ye) {
        var ze = document.createElement("div");
        ze.setAttribute("oninput", "return;");
        ye = "function" === typeof ze.oninput;
      }
      xe = ye;
    } else xe = false;
    we = xe && (!document.documentMode || 9 < document.documentMode);
  }
  function Ae() {
    pe && (pe.detachEvent("onpropertychange", Be), qe = pe = null);
  }
  function Be(a) {
    if ("value" === a.propertyName && te(qe)) {
      var b = [];
      ne(b, qe, a, xb(a));
      Jb(re, b);
    }
  }
  function Ce(a, b, c) {
    "focusin" === a ? (Ae(), pe = b, qe = c, pe.attachEvent("onpropertychange", Be)) : "focusout" === a && Ae();
  }
  function De(a) {
    if ("selectionchange" === a || "keyup" === a || "keydown" === a) return te(qe);
  }
  function Ee(a, b) {
    if ("click" === a) return te(b);
  }
  function Fe(a, b) {
    if ("input" === a || "change" === a) return te(b);
  }
  function Ge(a, b) {
    return a === b && (0 !== a || 1 / a === 1 / b) || a !== a && b !== b;
  }
  var He = "function" === typeof Object.is ? Object.is : Ge;
  function Ie(a, b) {
    if (He(a, b)) return true;
    if ("object" !== typeof a || null === a || "object" !== typeof b || null === b) return false;
    var c = Object.keys(a), d = Object.keys(b);
    if (c.length !== d.length) return false;
    for (d = 0; d < c.length; d++) {
      var e = c[d];
      if (!ja.call(b, e) || !He(a[e], b[e])) return false;
    }
    return true;
  }
  function Je(a) {
    for (; a && a.firstChild; ) a = a.firstChild;
    return a;
  }
  function Ke(a, b) {
    var c = Je(a);
    a = 0;
    for (var d; c; ) {
      if (3 === c.nodeType) {
        d = a + c.textContent.length;
        if (a <= b && d >= b) return { node: c, offset: b - a };
        a = d;
      }
      a: {
        for (; c; ) {
          if (c.nextSibling) {
            c = c.nextSibling;
            break a;
          }
          c = c.parentNode;
        }
        c = void 0;
      }
      c = Je(c);
    }
  }
  function Le(a, b) {
    return a && b ? a === b ? true : a && 3 === a.nodeType ? false : b && 3 === b.nodeType ? Le(a, b.parentNode) : "contains" in a ? a.contains(b) : a.compareDocumentPosition ? !!(a.compareDocumentPosition(b) & 16) : false : false;
  }
  function Me() {
    for (var a = window, b = Xa(); b instanceof a.HTMLIFrameElement; ) {
      try {
        var c = "string" === typeof b.contentWindow.location.href;
      } catch (d) {
        c = false;
      }
      if (c) a = b.contentWindow;
      else break;
      b = Xa(a.document);
    }
    return b;
  }
  function Ne(a) {
    var b = a && a.nodeName && a.nodeName.toLowerCase();
    return b && ("input" === b && ("text" === a.type || "search" === a.type || "tel" === a.type || "url" === a.type || "password" === a.type) || "textarea" === b || "true" === a.contentEditable);
  }
  function Oe(a) {
    var b = Me(), c = a.focusedElem, d = a.selectionRange;
    if (b !== c && c && c.ownerDocument && Le(c.ownerDocument.documentElement, c)) {
      if (null !== d && Ne(c)) {
        if (b = d.start, a = d.end, void 0 === a && (a = b), "selectionStart" in c) c.selectionStart = b, c.selectionEnd = Math.min(a, c.value.length);
        else if (a = (b = c.ownerDocument || document) && b.defaultView || window, a.getSelection) {
          a = a.getSelection();
          var e = c.textContent.length, f = Math.min(d.start, e);
          d = void 0 === d.end ? f : Math.min(d.end, e);
          !a.extend && f > d && (e = d, d = f, f = e);
          e = Ke(c, f);
          var g = Ke(
            c,
            d
          );
          e && g && (1 !== a.rangeCount || a.anchorNode !== e.node || a.anchorOffset !== e.offset || a.focusNode !== g.node || a.focusOffset !== g.offset) && (b = b.createRange(), b.setStart(e.node, e.offset), a.removeAllRanges(), f > d ? (a.addRange(b), a.extend(g.node, g.offset)) : (b.setEnd(g.node, g.offset), a.addRange(b)));
        }
      }
      b = [];
      for (a = c; a = a.parentNode; ) 1 === a.nodeType && b.push({ element: a, left: a.scrollLeft, top: a.scrollTop });
      "function" === typeof c.focus && c.focus();
      for (c = 0; c < b.length; c++) a = b[c], a.element.scrollLeft = a.left, a.element.scrollTop = a.top;
    }
  }
  var Pe = ia && "documentMode" in document && 11 >= document.documentMode, Qe = null, Re = null, Se = null, Te = false;
  function Ue(a, b, c) {
    var d = c.window === c ? c.document : 9 === c.nodeType ? c : c.ownerDocument;
    Te || null == Qe || Qe !== Xa(d) || (d = Qe, "selectionStart" in d && Ne(d) ? d = { start: d.selectionStart, end: d.selectionEnd } : (d = (d.ownerDocument && d.ownerDocument.defaultView || window).getSelection(), d = { anchorNode: d.anchorNode, anchorOffset: d.anchorOffset, focusNode: d.focusNode, focusOffset: d.focusOffset }), Se && Ie(Se, d) || (Se = d, d = oe(Re, "onSelect"), 0 < d.length && (b = new td("onSelect", "select", null, b, c), a.push({ event: b, listeners: d }), b.target = Qe)));
  }
  function Ve(a, b) {
    var c = {};
    c[a.toLowerCase()] = b.toLowerCase();
    c["Webkit" + a] = "webkit" + b;
    c["Moz" + a] = "moz" + b;
    return c;
  }
  var We = { animationend: Ve("Animation", "AnimationEnd"), animationiteration: Ve("Animation", "AnimationIteration"), animationstart: Ve("Animation", "AnimationStart"), transitionend: Ve("Transition", "TransitionEnd") }, Xe = {}, Ye = {};
  ia && (Ye = document.createElement("div").style, "AnimationEvent" in window || (delete We.animationend.animation, delete We.animationiteration.animation, delete We.animationstart.animation), "TransitionEvent" in window || delete We.transitionend.transition);
  function Ze(a) {
    if (Xe[a]) return Xe[a];
    if (!We[a]) return a;
    var b = We[a], c;
    for (c in b) if (b.hasOwnProperty(c) && c in Ye) return Xe[a] = b[c];
    return a;
  }
  var $e = Ze("animationend"), af = Ze("animationiteration"), bf = Ze("animationstart"), cf = Ze("transitionend"), df = /* @__PURE__ */ new Map(), ef = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
  function ff(a, b) {
    df.set(a, b);
    fa(b, [a]);
  }
  for (var gf = 0; gf < ef.length; gf++) {
    var hf = ef[gf], jf = hf.toLowerCase(), kf = hf[0].toUpperCase() + hf.slice(1);
    ff(jf, "on" + kf);
  }
  ff($e, "onAnimationEnd");
  ff(af, "onAnimationIteration");
  ff(bf, "onAnimationStart");
  ff("dblclick", "onDoubleClick");
  ff("focusin", "onFocus");
  ff("focusout", "onBlur");
  ff(cf, "onTransitionEnd");
  ha("onMouseEnter", ["mouseout", "mouseover"]);
  ha("onMouseLeave", ["mouseout", "mouseover"]);
  ha("onPointerEnter", ["pointerout", "pointerover"]);
  ha("onPointerLeave", ["pointerout", "pointerover"]);
  fa("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
  fa("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
  fa("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
  fa("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
  fa("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
  fa("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
  var lf = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), mf = new Set("cancel close invalid load scroll toggle".split(" ").concat(lf));
  function nf(a, b, c) {
    var d = a.type || "unknown-event";
    a.currentTarget = c;
    Ub(d, b, void 0, a);
    a.currentTarget = null;
  }
  function se(a, b) {
    b = 0 !== (b & 4);
    for (var c = 0; c < a.length; c++) {
      var d = a[c], e = d.event;
      d = d.listeners;
      a: {
        var f = void 0;
        if (b) for (var g = d.length - 1; 0 <= g; g--) {
          var h = d[g], k = h.instance, l = h.currentTarget;
          h = h.listener;
          if (k !== f && e.isPropagationStopped()) break a;
          nf(e, h, l);
          f = k;
        }
        else for (g = 0; g < d.length; g++) {
          h = d[g];
          k = h.instance;
          l = h.currentTarget;
          h = h.listener;
          if (k !== f && e.isPropagationStopped()) break a;
          nf(e, h, l);
          f = k;
        }
      }
    }
    if (Qb) throw a = Rb, Qb = false, Rb = null, a;
  }
  function D(a, b) {
    var c = b[of];
    void 0 === c && (c = b[of] = /* @__PURE__ */ new Set());
    var d = a + "__bubble";
    c.has(d) || (pf(b, a, 2, false), c.add(d));
  }
  function qf(a, b, c) {
    var d = 0;
    b && (d |= 4);
    pf(c, a, d, b);
  }
  var rf = "_reactListening" + Math.random().toString(36).slice(2);
  function sf(a) {
    if (!a[rf]) {
      a[rf] = true;
      da.forEach(function(b2) {
        "selectionchange" !== b2 && (mf.has(b2) || qf(b2, false, a), qf(b2, true, a));
      });
      var b = 9 === a.nodeType ? a : a.ownerDocument;
      null === b || b[rf] || (b[rf] = true, qf("selectionchange", false, b));
    }
  }
  function pf(a, b, c, d) {
    switch (jd(b)) {
      case 1:
        var e = ed;
        break;
      case 4:
        e = gd;
        break;
      default:
        e = fd;
    }
    c = e.bind(null, b, c, a);
    e = void 0;
    !Lb || "touchstart" !== b && "touchmove" !== b && "wheel" !== b || (e = true);
    d ? void 0 !== e ? a.addEventListener(b, c, { capture: true, passive: e }) : a.addEventListener(b, c, true) : void 0 !== e ? a.addEventListener(b, c, { passive: e }) : a.addEventListener(b, c, false);
  }
  function hd(a, b, c, d, e) {
    var f = d;
    if (0 === (b & 1) && 0 === (b & 2) && null !== d) a: for (; ; ) {
      if (null === d) return;
      var g = d.tag;
      if (3 === g || 4 === g) {
        var h = d.stateNode.containerInfo;
        if (h === e || 8 === h.nodeType && h.parentNode === e) break;
        if (4 === g) for (g = d.return; null !== g; ) {
          var k = g.tag;
          if (3 === k || 4 === k) {
            if (k = g.stateNode.containerInfo, k === e || 8 === k.nodeType && k.parentNode === e) return;
          }
          g = g.return;
        }
        for (; null !== h; ) {
          g = Wc(h);
          if (null === g) return;
          k = g.tag;
          if (5 === k || 6 === k) {
            d = f = g;
            continue a;
          }
          h = h.parentNode;
        }
      }
      d = d.return;
    }
    Jb(function() {
      var d2 = f, e2 = xb(c), g2 = [];
      a: {
        var h2 = df.get(a);
        if (void 0 !== h2) {
          var k2 = td, n = a;
          switch (a) {
            case "keypress":
              if (0 === od(c)) break a;
            case "keydown":
            case "keyup":
              k2 = Rd;
              break;
            case "focusin":
              n = "focus";
              k2 = Fd;
              break;
            case "focusout":
              n = "blur";
              k2 = Fd;
              break;
            case "beforeblur":
            case "afterblur":
              k2 = Fd;
              break;
            case "click":
              if (2 === c.button) break a;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              k2 = Bd;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              k2 = Dd;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              k2 = Vd;
              break;
            case $e:
            case af:
            case bf:
              k2 = Hd;
              break;
            case cf:
              k2 = Xd;
              break;
            case "scroll":
              k2 = vd;
              break;
            case "wheel":
              k2 = Zd;
              break;
            case "copy":
            case "cut":
            case "paste":
              k2 = Jd;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              k2 = Td;
          }
          var t2 = 0 !== (b & 4), J = !t2 && "scroll" === a, x = t2 ? null !== h2 ? h2 + "Capture" : null : h2;
          t2 = [];
          for (var w = d2, u; null !== w; ) {
            u = w;
            var F = u.stateNode;
            5 === u.tag && null !== F && (u = F, null !== x && (F = Kb(w, x), null != F && t2.push(tf(w, F, u))));
            if (J) break;
            w = w.return;
          }
          0 < t2.length && (h2 = new k2(h2, n, null, c, e2), g2.push({ event: h2, listeners: t2 }));
        }
      }
      if (0 === (b & 7)) {
        a: {
          h2 = "mouseover" === a || "pointerover" === a;
          k2 = "mouseout" === a || "pointerout" === a;
          if (h2 && c !== wb && (n = c.relatedTarget || c.fromElement) && (Wc(n) || n[uf])) break a;
          if (k2 || h2) {
            h2 = e2.window === e2 ? e2 : (h2 = e2.ownerDocument) ? h2.defaultView || h2.parentWindow : window;
            if (k2) {
              if (n = c.relatedTarget || c.toElement, k2 = d2, n = n ? Wc(n) : null, null !== n && (J = Vb(n), n !== J || 5 !== n.tag && 6 !== n.tag)) n = null;
            } else k2 = null, n = d2;
            if (k2 !== n) {
              t2 = Bd;
              F = "onMouseLeave";
              x = "onMouseEnter";
              w = "mouse";
              if ("pointerout" === a || "pointerover" === a) t2 = Td, F = "onPointerLeave", x = "onPointerEnter", w = "pointer";
              J = null == k2 ? h2 : ue(k2);
              u = null == n ? h2 : ue(n);
              h2 = new t2(F, w + "leave", k2, c, e2);
              h2.target = J;
              h2.relatedTarget = u;
              F = null;
              Wc(e2) === d2 && (t2 = new t2(x, w + "enter", n, c, e2), t2.target = u, t2.relatedTarget = J, F = t2);
              J = F;
              if (k2 && n) b: {
                t2 = k2;
                x = n;
                w = 0;
                for (u = t2; u; u = vf(u)) w++;
                u = 0;
                for (F = x; F; F = vf(F)) u++;
                for (; 0 < w - u; ) t2 = vf(t2), w--;
                for (; 0 < u - w; ) x = vf(x), u--;
                for (; w--; ) {
                  if (t2 === x || null !== x && t2 === x.alternate) break b;
                  t2 = vf(t2);
                  x = vf(x);
                }
                t2 = null;
              }
              else t2 = null;
              null !== k2 && wf(g2, h2, k2, t2, false);
              null !== n && null !== J && wf(g2, J, n, t2, true);
            }
          }
        }
        a: {
          h2 = d2 ? ue(d2) : window;
          k2 = h2.nodeName && h2.nodeName.toLowerCase();
          if ("select" === k2 || "input" === k2 && "file" === h2.type) var na = ve;
          else if (me(h2)) if (we) na = Fe;
          else {
            na = De;
            var xa = Ce;
          }
          else (k2 = h2.nodeName) && "input" === k2.toLowerCase() && ("checkbox" === h2.type || "radio" === h2.type) && (na = Ee);
          if (na && (na = na(a, d2))) {
            ne(g2, na, c, e2);
            break a;
          }
          xa && xa(a, h2, d2);
          "focusout" === a && (xa = h2._wrapperState) && xa.controlled && "number" === h2.type && cb(h2, "number", h2.value);
        }
        xa = d2 ? ue(d2) : window;
        switch (a) {
          case "focusin":
            if (me(xa) || "true" === xa.contentEditable) Qe = xa, Re = d2, Se = null;
            break;
          case "focusout":
            Se = Re = Qe = null;
            break;
          case "mousedown":
            Te = true;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            Te = false;
            Ue(g2, c, e2);
            break;
          case "selectionchange":
            if (Pe) break;
          case "keydown":
          case "keyup":
            Ue(g2, c, e2);
        }
        var $a;
        if (ae) b: {
          switch (a) {
            case "compositionstart":
              var ba = "onCompositionStart";
              break b;
            case "compositionend":
              ba = "onCompositionEnd";
              break b;
            case "compositionupdate":
              ba = "onCompositionUpdate";
              break b;
          }
          ba = void 0;
        }
        else ie ? ge(a, c) && (ba = "onCompositionEnd") : "keydown" === a && 229 === c.keyCode && (ba = "onCompositionStart");
        ba && (de && "ko" !== c.locale && (ie || "onCompositionStart" !== ba ? "onCompositionEnd" === ba && ie && ($a = nd()) : (kd = e2, ld = "value" in kd ? kd.value : kd.textContent, ie = true)), xa = oe(d2, ba), 0 < xa.length && (ba = new Ld(ba, a, null, c, e2), g2.push({ event: ba, listeners: xa }), $a ? ba.data = $a : ($a = he(c), null !== $a && (ba.data = $a))));
        if ($a = ce ? je(a, c) : ke(a, c)) d2 = oe(d2, "onBeforeInput"), 0 < d2.length && (e2 = new Ld("onBeforeInput", "beforeinput", null, c, e2), g2.push({ event: e2, listeners: d2 }), e2.data = $a);
      }
      se(g2, b);
    });
  }
  function tf(a, b, c) {
    return { instance: a, listener: b, currentTarget: c };
  }
  function oe(a, b) {
    for (var c = b + "Capture", d = []; null !== a; ) {
      var e = a, f = e.stateNode;
      5 === e.tag && null !== f && (e = f, f = Kb(a, c), null != f && d.unshift(tf(a, f, e)), f = Kb(a, b), null != f && d.push(tf(a, f, e)));
      a = a.return;
    }
    return d;
  }
  function vf(a) {
    if (null === a) return null;
    do
      a = a.return;
    while (a && 5 !== a.tag);
    return a ? a : null;
  }
  function wf(a, b, c, d, e) {
    for (var f = b._reactName, g = []; null !== c && c !== d; ) {
      var h = c, k = h.alternate, l = h.stateNode;
      if (null !== k && k === d) break;
      5 === h.tag && null !== l && (h = l, e ? (k = Kb(c, f), null != k && g.unshift(tf(c, k, h))) : e || (k = Kb(c, f), null != k && g.push(tf(c, k, h))));
      c = c.return;
    }
    0 !== g.length && a.push({ event: b, listeners: g });
  }
  var xf = /\r\n?/g, yf = /\u0000|\uFFFD/g;
  function zf(a) {
    return ("string" === typeof a ? a : "" + a).replace(xf, "\n").replace(yf, "");
  }
  function Af(a, b, c) {
    b = zf(b);
    if (zf(a) !== b && c) throw Error(p(425));
  }
  function Bf() {
  }
  var Cf = null, Df = null;
  function Ef(a, b) {
    return "textarea" === a || "noscript" === a || "string" === typeof b.children || "number" === typeof b.children || "object" === typeof b.dangerouslySetInnerHTML && null !== b.dangerouslySetInnerHTML && null != b.dangerouslySetInnerHTML.__html;
  }
  var Ff = "function" === typeof setTimeout ? setTimeout : void 0, Gf = "function" === typeof clearTimeout ? clearTimeout : void 0, Hf = "function" === typeof Promise ? Promise : void 0, Jf = "function" === typeof queueMicrotask ? queueMicrotask : "undefined" !== typeof Hf ? function(a) {
    return Hf.resolve(null).then(a).catch(If);
  } : Ff;
  function If(a) {
    setTimeout(function() {
      throw a;
    });
  }
  function Kf(a, b) {
    var c = b, d = 0;
    do {
      var e = c.nextSibling;
      a.removeChild(c);
      if (e && 8 === e.nodeType) if (c = e.data, "/$" === c) {
        if (0 === d) {
          a.removeChild(e);
          bd(b);
          return;
        }
        d--;
      } else "$" !== c && "$?" !== c && "$!" !== c || d++;
      c = e;
    } while (c);
    bd(b);
  }
  function Lf(a) {
    for (; null != a; a = a.nextSibling) {
      var b = a.nodeType;
      if (1 === b || 3 === b) break;
      if (8 === b) {
        b = a.data;
        if ("$" === b || "$!" === b || "$?" === b) break;
        if ("/$" === b) return null;
      }
    }
    return a;
  }
  function Mf(a) {
    a = a.previousSibling;
    for (var b = 0; a; ) {
      if (8 === a.nodeType) {
        var c = a.data;
        if ("$" === c || "$!" === c || "$?" === c) {
          if (0 === b) return a;
          b--;
        } else "/$" === c && b++;
      }
      a = a.previousSibling;
    }
    return null;
  }
  var Nf = Math.random().toString(36).slice(2), Of = "__reactFiber$" + Nf, Pf = "__reactProps$" + Nf, uf = "__reactContainer$" + Nf, of = "__reactEvents$" + Nf, Qf = "__reactListeners$" + Nf, Rf = "__reactHandles$" + Nf;
  function Wc(a) {
    var b = a[Of];
    if (b) return b;
    for (var c = a.parentNode; c; ) {
      if (b = c[uf] || c[Of]) {
        c = b.alternate;
        if (null !== b.child || null !== c && null !== c.child) for (a = Mf(a); null !== a; ) {
          if (c = a[Of]) return c;
          a = Mf(a);
        }
        return b;
      }
      a = c;
      c = a.parentNode;
    }
    return null;
  }
  function Cb(a) {
    a = a[Of] || a[uf];
    return !a || 5 !== a.tag && 6 !== a.tag && 13 !== a.tag && 3 !== a.tag ? null : a;
  }
  function ue(a) {
    if (5 === a.tag || 6 === a.tag) return a.stateNode;
    throw Error(p(33));
  }
  function Db(a) {
    return a[Pf] || null;
  }
  var Sf = [], Tf = -1;
  function Uf(a) {
    return { current: a };
  }
  function E(a) {
    0 > Tf || (a.current = Sf[Tf], Sf[Tf] = null, Tf--);
  }
  function G(a, b) {
    Tf++;
    Sf[Tf] = a.current;
    a.current = b;
  }
  var Vf = {}, H = Uf(Vf), Wf = Uf(false), Xf = Vf;
  function Yf(a, b) {
    var c = a.type.contextTypes;
    if (!c) return Vf;
    var d = a.stateNode;
    if (d && d.__reactInternalMemoizedUnmaskedChildContext === b) return d.__reactInternalMemoizedMaskedChildContext;
    var e = {}, f;
    for (f in c) e[f] = b[f];
    d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = b, a.__reactInternalMemoizedMaskedChildContext = e);
    return e;
  }
  function Zf(a) {
    a = a.childContextTypes;
    return null !== a && void 0 !== a;
  }
  function $f() {
    E(Wf);
    E(H);
  }
  function ag(a, b, c) {
    if (H.current !== Vf) throw Error(p(168));
    G(H, b);
    G(Wf, c);
  }
  function bg(a, b, c) {
    var d = a.stateNode;
    b = b.childContextTypes;
    if ("function" !== typeof d.getChildContext) return c;
    d = d.getChildContext();
    for (var e in d) if (!(e in b)) throw Error(p(108, Ra(a) || "Unknown", e));
    return A({}, c, d);
  }
  function cg(a) {
    a = (a = a.stateNode) && a.__reactInternalMemoizedMergedChildContext || Vf;
    Xf = H.current;
    G(H, a);
    G(Wf, Wf.current);
    return true;
  }
  function dg(a, b, c) {
    var d = a.stateNode;
    if (!d) throw Error(p(169));
    c ? (a = bg(a, b, Xf), d.__reactInternalMemoizedMergedChildContext = a, E(Wf), E(H), G(H, a)) : E(Wf);
    G(Wf, c);
  }
  var eg = null, fg = false, gg = false;
  function hg(a) {
    null === eg ? eg = [a] : eg.push(a);
  }
  function ig(a) {
    fg = true;
    hg(a);
  }
  function jg() {
    if (!gg && null !== eg) {
      gg = true;
      var a = 0, b = C;
      try {
        var c = eg;
        for (C = 1; a < c.length; a++) {
          var d = c[a];
          do
            d = d(true);
          while (null !== d);
        }
        eg = null;
        fg = false;
      } catch (e) {
        throw null !== eg && (eg = eg.slice(a + 1)), ac(fc, jg), e;
      } finally {
        C = b, gg = false;
      }
    }
    return null;
  }
  var kg = [], lg = 0, mg = null, ng = 0, og = [], pg = 0, qg = null, rg = 1, sg = "";
  function tg(a, b) {
    kg[lg++] = ng;
    kg[lg++] = mg;
    mg = a;
    ng = b;
  }
  function ug(a, b, c) {
    og[pg++] = rg;
    og[pg++] = sg;
    og[pg++] = qg;
    qg = a;
    var d = rg;
    a = sg;
    var e = 32 - oc(d) - 1;
    d &= ~(1 << e);
    c += 1;
    var f = 32 - oc(b) + e;
    if (30 < f) {
      var g = e - e % 5;
      f = (d & (1 << g) - 1).toString(32);
      d >>= g;
      e -= g;
      rg = 1 << 32 - oc(b) + e | c << e | d;
      sg = f + a;
    } else rg = 1 << f | c << e | d, sg = a;
  }
  function vg(a) {
    null !== a.return && (tg(a, 1), ug(a, 1, 0));
  }
  function wg(a) {
    for (; a === mg; ) mg = kg[--lg], kg[lg] = null, ng = kg[--lg], kg[lg] = null;
    for (; a === qg; ) qg = og[--pg], og[pg] = null, sg = og[--pg], og[pg] = null, rg = og[--pg], og[pg] = null;
  }
  var xg = null, yg = null, I = false, zg = null;
  function Ag(a, b) {
    var c = Bg(5, null, null, 0);
    c.elementType = "DELETED";
    c.stateNode = b;
    c.return = a;
    b = a.deletions;
    null === b ? (a.deletions = [c], a.flags |= 16) : b.push(c);
  }
  function Cg(a, b) {
    switch (a.tag) {
      case 5:
        var c = a.type;
        b = 1 !== b.nodeType || c.toLowerCase() !== b.nodeName.toLowerCase() ? null : b;
        return null !== b ? (a.stateNode = b, xg = a, yg = Lf(b.firstChild), true) : false;
      case 6:
        return b = "" === a.pendingProps || 3 !== b.nodeType ? null : b, null !== b ? (a.stateNode = b, xg = a, yg = null, true) : false;
      case 13:
        return b = 8 !== b.nodeType ? null : b, null !== b ? (c = null !== qg ? { id: rg, overflow: sg } : null, a.memoizedState = { dehydrated: b, treeContext: c, retryLane: 1073741824 }, c = Bg(18, null, null, 0), c.stateNode = b, c.return = a, a.child = c, xg = a, yg = null, true) : false;
      default:
        return false;
    }
  }
  function Dg(a) {
    return 0 !== (a.mode & 1) && 0 === (a.flags & 128);
  }
  function Eg(a) {
    if (I) {
      var b = yg;
      if (b) {
        var c = b;
        if (!Cg(a, b)) {
          if (Dg(a)) throw Error(p(418));
          b = Lf(c.nextSibling);
          var d = xg;
          b && Cg(a, b) ? Ag(d, c) : (a.flags = a.flags & -4097 | 2, I = false, xg = a);
        }
      } else {
        if (Dg(a)) throw Error(p(418));
        a.flags = a.flags & -4097 | 2;
        I = false;
        xg = a;
      }
    }
  }
  function Fg(a) {
    for (a = a.return; null !== a && 5 !== a.tag && 3 !== a.tag && 13 !== a.tag; ) a = a.return;
    xg = a;
  }
  function Gg(a) {
    if (a !== xg) return false;
    if (!I) return Fg(a), I = true, false;
    var b;
    (b = 3 !== a.tag) && !(b = 5 !== a.tag) && (b = a.type, b = "head" !== b && "body" !== b && !Ef(a.type, a.memoizedProps));
    if (b && (b = yg)) {
      if (Dg(a)) throw Hg(), Error(p(418));
      for (; b; ) Ag(a, b), b = Lf(b.nextSibling);
    }
    Fg(a);
    if (13 === a.tag) {
      a = a.memoizedState;
      a = null !== a ? a.dehydrated : null;
      if (!a) throw Error(p(317));
      a: {
        a = a.nextSibling;
        for (b = 0; a; ) {
          if (8 === a.nodeType) {
            var c = a.data;
            if ("/$" === c) {
              if (0 === b) {
                yg = Lf(a.nextSibling);
                break a;
              }
              b--;
            } else "$" !== c && "$!" !== c && "$?" !== c || b++;
          }
          a = a.nextSibling;
        }
        yg = null;
      }
    } else yg = xg ? Lf(a.stateNode.nextSibling) : null;
    return true;
  }
  function Hg() {
    for (var a = yg; a; ) a = Lf(a.nextSibling);
  }
  function Ig() {
    yg = xg = null;
    I = false;
  }
  function Jg(a) {
    null === zg ? zg = [a] : zg.push(a);
  }
  var Kg = ua.ReactCurrentBatchConfig;
  function Lg(a, b, c) {
    a = c.ref;
    if (null !== a && "function" !== typeof a && "object" !== typeof a) {
      if (c._owner) {
        c = c._owner;
        if (c) {
          if (1 !== c.tag) throw Error(p(309));
          var d = c.stateNode;
        }
        if (!d) throw Error(p(147, a));
        var e = d, f = "" + a;
        if (null !== b && null !== b.ref && "function" === typeof b.ref && b.ref._stringRef === f) return b.ref;
        b = function(a2) {
          var b2 = e.refs;
          null === a2 ? delete b2[f] : b2[f] = a2;
        };
        b._stringRef = f;
        return b;
      }
      if ("string" !== typeof a) throw Error(p(284));
      if (!c._owner) throw Error(p(290, a));
    }
    return a;
  }
  function Mg(a, b) {
    a = Object.prototype.toString.call(b);
    throw Error(p(31, "[object Object]" === a ? "object with keys {" + Object.keys(b).join(", ") + "}" : a));
  }
  function Ng(a) {
    var b = a._init;
    return b(a._payload);
  }
  function Og(a) {
    function b(b2, c2) {
      if (a) {
        var d2 = b2.deletions;
        null === d2 ? (b2.deletions = [c2], b2.flags |= 16) : d2.push(c2);
      }
    }
    function c(c2, d2) {
      if (!a) return null;
      for (; null !== d2; ) b(c2, d2), d2 = d2.sibling;
      return null;
    }
    function d(a2, b2) {
      for (a2 = /* @__PURE__ */ new Map(); null !== b2; ) null !== b2.key ? a2.set(b2.key, b2) : a2.set(b2.index, b2), b2 = b2.sibling;
      return a2;
    }
    function e(a2, b2) {
      a2 = Pg(a2, b2);
      a2.index = 0;
      a2.sibling = null;
      return a2;
    }
    function f(b2, c2, d2) {
      b2.index = d2;
      if (!a) return b2.flags |= 1048576, c2;
      d2 = b2.alternate;
      if (null !== d2) return d2 = d2.index, d2 < c2 ? (b2.flags |= 2, c2) : d2;
      b2.flags |= 2;
      return c2;
    }
    function g(b2) {
      a && null === b2.alternate && (b2.flags |= 2);
      return b2;
    }
    function h(a2, b2, c2, d2) {
      if (null === b2 || 6 !== b2.tag) return b2 = Qg(c2, a2.mode, d2), b2.return = a2, b2;
      b2 = e(b2, c2);
      b2.return = a2;
      return b2;
    }
    function k(a2, b2, c2, d2) {
      var f2 = c2.type;
      if (f2 === ya) return m(a2, b2, c2.props.children, d2, c2.key);
      if (null !== b2 && (b2.elementType === f2 || "object" === typeof f2 && null !== f2 && f2.$$typeof === Ha && Ng(f2) === b2.type)) return d2 = e(b2, c2.props), d2.ref = Lg(a2, b2, c2), d2.return = a2, d2;
      d2 = Rg(c2.type, c2.key, c2.props, null, a2.mode, d2);
      d2.ref = Lg(a2, b2, c2);
      d2.return = a2;
      return d2;
    }
    function l(a2, b2, c2, d2) {
      if (null === b2 || 4 !== b2.tag || b2.stateNode.containerInfo !== c2.containerInfo || b2.stateNode.implementation !== c2.implementation) return b2 = Sg(c2, a2.mode, d2), b2.return = a2, b2;
      b2 = e(b2, c2.children || []);
      b2.return = a2;
      return b2;
    }
    function m(a2, b2, c2, d2, f2) {
      if (null === b2 || 7 !== b2.tag) return b2 = Tg(c2, a2.mode, d2, f2), b2.return = a2, b2;
      b2 = e(b2, c2);
      b2.return = a2;
      return b2;
    }
    function q(a2, b2, c2) {
      if ("string" === typeof b2 && "" !== b2 || "number" === typeof b2) return b2 = Qg("" + b2, a2.mode, c2), b2.return = a2, b2;
      if ("object" === typeof b2 && null !== b2) {
        switch (b2.$$typeof) {
          case va:
            return c2 = Rg(b2.type, b2.key, b2.props, null, a2.mode, c2), c2.ref = Lg(a2, null, b2), c2.return = a2, c2;
          case wa:
            return b2 = Sg(b2, a2.mode, c2), b2.return = a2, b2;
          case Ha:
            var d2 = b2._init;
            return q(a2, d2(b2._payload), c2);
        }
        if (eb(b2) || Ka(b2)) return b2 = Tg(b2, a2.mode, c2, null), b2.return = a2, b2;
        Mg(a2, b2);
      }
      return null;
    }
    function r(a2, b2, c2, d2) {
      var e2 = null !== b2 ? b2.key : null;
      if ("string" === typeof c2 && "" !== c2 || "number" === typeof c2) return null !== e2 ? null : h(a2, b2, "" + c2, d2);
      if ("object" === typeof c2 && null !== c2) {
        switch (c2.$$typeof) {
          case va:
            return c2.key === e2 ? k(a2, b2, c2, d2) : null;
          case wa:
            return c2.key === e2 ? l(a2, b2, c2, d2) : null;
          case Ha:
            return e2 = c2._init, r(
              a2,
              b2,
              e2(c2._payload),
              d2
            );
        }
        if (eb(c2) || Ka(c2)) return null !== e2 ? null : m(a2, b2, c2, d2, null);
        Mg(a2, c2);
      }
      return null;
    }
    function y(a2, b2, c2, d2, e2) {
      if ("string" === typeof d2 && "" !== d2 || "number" === typeof d2) return a2 = a2.get(c2) || null, h(b2, a2, "" + d2, e2);
      if ("object" === typeof d2 && null !== d2) {
        switch (d2.$$typeof) {
          case va:
            return a2 = a2.get(null === d2.key ? c2 : d2.key) || null, k(b2, a2, d2, e2);
          case wa:
            return a2 = a2.get(null === d2.key ? c2 : d2.key) || null, l(b2, a2, d2, e2);
          case Ha:
            var f2 = d2._init;
            return y(a2, b2, c2, f2(d2._payload), e2);
        }
        if (eb(d2) || Ka(d2)) return a2 = a2.get(c2) || null, m(b2, a2, d2, e2, null);
        Mg(b2, d2);
      }
      return null;
    }
    function n(e2, g2, h2, k2) {
      for (var l2 = null, m2 = null, u = g2, w = g2 = 0, x = null; null !== u && w < h2.length; w++) {
        u.index > w ? (x = u, u = null) : x = u.sibling;
        var n2 = r(e2, u, h2[w], k2);
        if (null === n2) {
          null === u && (u = x);
          break;
        }
        a && u && null === n2.alternate && b(e2, u);
        g2 = f(n2, g2, w);
        null === m2 ? l2 = n2 : m2.sibling = n2;
        m2 = n2;
        u = x;
      }
      if (w === h2.length) return c(e2, u), I && tg(e2, w), l2;
      if (null === u) {
        for (; w < h2.length; w++) u = q(e2, h2[w], k2), null !== u && (g2 = f(u, g2, w), null === m2 ? l2 = u : m2.sibling = u, m2 = u);
        I && tg(e2, w);
        return l2;
      }
      for (u = d(e2, u); w < h2.length; w++) x = y(u, e2, w, h2[w], k2), null !== x && (a && null !== x.alternate && u.delete(null === x.key ? w : x.key), g2 = f(x, g2, w), null === m2 ? l2 = x : m2.sibling = x, m2 = x);
      a && u.forEach(function(a2) {
        return b(e2, a2);
      });
      I && tg(e2, w);
      return l2;
    }
    function t2(e2, g2, h2, k2) {
      var l2 = Ka(h2);
      if ("function" !== typeof l2) throw Error(p(150));
      h2 = l2.call(h2);
      if (null == h2) throw Error(p(151));
      for (var u = l2 = null, m2 = g2, w = g2 = 0, x = null, n2 = h2.next(); null !== m2 && !n2.done; w++, n2 = h2.next()) {
        m2.index > w ? (x = m2, m2 = null) : x = m2.sibling;
        var t3 = r(e2, m2, n2.value, k2);
        if (null === t3) {
          null === m2 && (m2 = x);
          break;
        }
        a && m2 && null === t3.alternate && b(e2, m2);
        g2 = f(t3, g2, w);
        null === u ? l2 = t3 : u.sibling = t3;
        u = t3;
        m2 = x;
      }
      if (n2.done) return c(
        e2,
        m2
      ), I && tg(e2, w), l2;
      if (null === m2) {
        for (; !n2.done; w++, n2 = h2.next()) n2 = q(e2, n2.value, k2), null !== n2 && (g2 = f(n2, g2, w), null === u ? l2 = n2 : u.sibling = n2, u = n2);
        I && tg(e2, w);
        return l2;
      }
      for (m2 = d(e2, m2); !n2.done; w++, n2 = h2.next()) n2 = y(m2, e2, w, n2.value, k2), null !== n2 && (a && null !== n2.alternate && m2.delete(null === n2.key ? w : n2.key), g2 = f(n2, g2, w), null === u ? l2 = n2 : u.sibling = n2, u = n2);
      a && m2.forEach(function(a2) {
        return b(e2, a2);
      });
      I && tg(e2, w);
      return l2;
    }
    function J(a2, d2, f2, h2) {
      "object" === typeof f2 && null !== f2 && f2.type === ya && null === f2.key && (f2 = f2.props.children);
      if ("object" === typeof f2 && null !== f2) {
        switch (f2.$$typeof) {
          case va:
            a: {
              for (var k2 = f2.key, l2 = d2; null !== l2; ) {
                if (l2.key === k2) {
                  k2 = f2.type;
                  if (k2 === ya) {
                    if (7 === l2.tag) {
                      c(a2, l2.sibling);
                      d2 = e(l2, f2.props.children);
                      d2.return = a2;
                      a2 = d2;
                      break a;
                    }
                  } else if (l2.elementType === k2 || "object" === typeof k2 && null !== k2 && k2.$$typeof === Ha && Ng(k2) === l2.type) {
                    c(a2, l2.sibling);
                    d2 = e(l2, f2.props);
                    d2.ref = Lg(a2, l2, f2);
                    d2.return = a2;
                    a2 = d2;
                    break a;
                  }
                  c(a2, l2);
                  break;
                } else b(a2, l2);
                l2 = l2.sibling;
              }
              f2.type === ya ? (d2 = Tg(f2.props.children, a2.mode, h2, f2.key), d2.return = a2, a2 = d2) : (h2 = Rg(f2.type, f2.key, f2.props, null, a2.mode, h2), h2.ref = Lg(a2, d2, f2), h2.return = a2, a2 = h2);
            }
            return g(a2);
          case wa:
            a: {
              for (l2 = f2.key; null !== d2; ) {
                if (d2.key === l2) if (4 === d2.tag && d2.stateNode.containerInfo === f2.containerInfo && d2.stateNode.implementation === f2.implementation) {
                  c(a2, d2.sibling);
                  d2 = e(d2, f2.children || []);
                  d2.return = a2;
                  a2 = d2;
                  break a;
                } else {
                  c(a2, d2);
                  break;
                }
                else b(a2, d2);
                d2 = d2.sibling;
              }
              d2 = Sg(f2, a2.mode, h2);
              d2.return = a2;
              a2 = d2;
            }
            return g(a2);
          case Ha:
            return l2 = f2._init, J(a2, d2, l2(f2._payload), h2);
        }
        if (eb(f2)) return n(a2, d2, f2, h2);
        if (Ka(f2)) return t2(a2, d2, f2, h2);
        Mg(a2, f2);
      }
      return "string" === typeof f2 && "" !== f2 || "number" === typeof f2 ? (f2 = "" + f2, null !== d2 && 6 === d2.tag ? (c(a2, d2.sibling), d2 = e(d2, f2), d2.return = a2, a2 = d2) : (c(a2, d2), d2 = Qg(f2, a2.mode, h2), d2.return = a2, a2 = d2), g(a2)) : c(a2, d2);
    }
    return J;
  }
  var Ug = Og(true), Vg = Og(false), Wg = Uf(null), Xg = null, Yg = null, Zg = null;
  function $g() {
    Zg = Yg = Xg = null;
  }
  function ah(a) {
    var b = Wg.current;
    E(Wg);
    a._currentValue = b;
  }
  function bh(a, b, c) {
    for (; null !== a; ) {
      var d = a.alternate;
      (a.childLanes & b) !== b ? (a.childLanes |= b, null !== d && (d.childLanes |= b)) : null !== d && (d.childLanes & b) !== b && (d.childLanes |= b);
      if (a === c) break;
      a = a.return;
    }
  }
  function ch(a, b) {
    Xg = a;
    Zg = Yg = null;
    a = a.dependencies;
    null !== a && null !== a.firstContext && (0 !== (a.lanes & b) && (dh = true), a.firstContext = null);
  }
  function eh(a) {
    var b = a._currentValue;
    if (Zg !== a) if (a = { context: a, memoizedValue: b, next: null }, null === Yg) {
      if (null === Xg) throw Error(p(308));
      Yg = a;
      Xg.dependencies = { lanes: 0, firstContext: a };
    } else Yg = Yg.next = a;
    return b;
  }
  var fh = null;
  function gh(a) {
    null === fh ? fh = [a] : fh.push(a);
  }
  function hh(a, b, c, d) {
    var e = b.interleaved;
    null === e ? (c.next = c, gh(b)) : (c.next = e.next, e.next = c);
    b.interleaved = c;
    return ih(a, d);
  }
  function ih(a, b) {
    a.lanes |= b;
    var c = a.alternate;
    null !== c && (c.lanes |= b);
    c = a;
    for (a = a.return; null !== a; ) a.childLanes |= b, c = a.alternate, null !== c && (c.childLanes |= b), c = a, a = a.return;
    return 3 === c.tag ? c.stateNode : null;
  }
  var jh = false;
  function kh(a) {
    a.updateQueue = { baseState: a.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
  }
  function lh(a, b) {
    a = a.updateQueue;
    b.updateQueue === a && (b.updateQueue = { baseState: a.baseState, firstBaseUpdate: a.firstBaseUpdate, lastBaseUpdate: a.lastBaseUpdate, shared: a.shared, effects: a.effects });
  }
  function mh(a, b) {
    return { eventTime: a, lane: b, tag: 0, payload: null, callback: null, next: null };
  }
  function nh(a, b, c) {
    var d = a.updateQueue;
    if (null === d) return null;
    d = d.shared;
    if (0 !== (K & 2)) {
      var e = d.pending;
      null === e ? b.next = b : (b.next = e.next, e.next = b);
      d.pending = b;
      return ih(a, c);
    }
    e = d.interleaved;
    null === e ? (b.next = b, gh(d)) : (b.next = e.next, e.next = b);
    d.interleaved = b;
    return ih(a, c);
  }
  function oh(a, b, c) {
    b = b.updateQueue;
    if (null !== b && (b = b.shared, 0 !== (c & 4194240))) {
      var d = b.lanes;
      d &= a.pendingLanes;
      c |= d;
      b.lanes = c;
      Cc(a, c);
    }
  }
  function ph(a, b) {
    var c = a.updateQueue, d = a.alternate;
    if (null !== d && (d = d.updateQueue, c === d)) {
      var e = null, f = null;
      c = c.firstBaseUpdate;
      if (null !== c) {
        do {
          var g = { eventTime: c.eventTime, lane: c.lane, tag: c.tag, payload: c.payload, callback: c.callback, next: null };
          null === f ? e = f = g : f = f.next = g;
          c = c.next;
        } while (null !== c);
        null === f ? e = f = b : f = f.next = b;
      } else e = f = b;
      c = { baseState: d.baseState, firstBaseUpdate: e, lastBaseUpdate: f, shared: d.shared, effects: d.effects };
      a.updateQueue = c;
      return;
    }
    a = c.lastBaseUpdate;
    null === a ? c.firstBaseUpdate = b : a.next = b;
    c.lastBaseUpdate = b;
  }
  function qh(a, b, c, d) {
    var e = a.updateQueue;
    jh = false;
    var f = e.firstBaseUpdate, g = e.lastBaseUpdate, h = e.shared.pending;
    if (null !== h) {
      e.shared.pending = null;
      var k = h, l = k.next;
      k.next = null;
      null === g ? f = l : g.next = l;
      g = k;
      var m = a.alternate;
      null !== m && (m = m.updateQueue, h = m.lastBaseUpdate, h !== g && (null === h ? m.firstBaseUpdate = l : h.next = l, m.lastBaseUpdate = k));
    }
    if (null !== f) {
      var q = e.baseState;
      g = 0;
      m = l = k = null;
      h = f;
      do {
        var r = h.lane, y = h.eventTime;
        if ((d & r) === r) {
          null !== m && (m = m.next = {
            eventTime: y,
            lane: 0,
            tag: h.tag,
            payload: h.payload,
            callback: h.callback,
            next: null
          });
          a: {
            var n = a, t2 = h;
            r = b;
            y = c;
            switch (t2.tag) {
              case 1:
                n = t2.payload;
                if ("function" === typeof n) {
                  q = n.call(y, q, r);
                  break a;
                }
                q = n;
                break a;
              case 3:
                n.flags = n.flags & -65537 | 128;
              case 0:
                n = t2.payload;
                r = "function" === typeof n ? n.call(y, q, r) : n;
                if (null === r || void 0 === r) break a;
                q = A({}, q, r);
                break a;
              case 2:
                jh = true;
            }
          }
          null !== h.callback && 0 !== h.lane && (a.flags |= 64, r = e.effects, null === r ? e.effects = [h] : r.push(h));
        } else y = { eventTime: y, lane: r, tag: h.tag, payload: h.payload, callback: h.callback, next: null }, null === m ? (l = m = y, k = q) : m = m.next = y, g |= r;
        h = h.next;
        if (null === h) if (h = e.shared.pending, null === h) break;
        else r = h, h = r.next, r.next = null, e.lastBaseUpdate = r, e.shared.pending = null;
      } while (1);
      null === m && (k = q);
      e.baseState = k;
      e.firstBaseUpdate = l;
      e.lastBaseUpdate = m;
      b = e.shared.interleaved;
      if (null !== b) {
        e = b;
        do
          g |= e.lane, e = e.next;
        while (e !== b);
      } else null === f && (e.shared.lanes = 0);
      rh |= g;
      a.lanes = g;
      a.memoizedState = q;
    }
  }
  function sh(a, b, c) {
    a = b.effects;
    b.effects = null;
    if (null !== a) for (b = 0; b < a.length; b++) {
      var d = a[b], e = d.callback;
      if (null !== e) {
        d.callback = null;
        d = c;
        if ("function" !== typeof e) throw Error(p(191, e));
        e.call(d);
      }
    }
  }
  var th = {}, uh = Uf(th), vh = Uf(th), wh = Uf(th);
  function xh(a) {
    if (a === th) throw Error(p(174));
    return a;
  }
  function yh(a, b) {
    G(wh, b);
    G(vh, a);
    G(uh, th);
    a = b.nodeType;
    switch (a) {
      case 9:
      case 11:
        b = (b = b.documentElement) ? b.namespaceURI : lb(null, "");
        break;
      default:
        a = 8 === a ? b.parentNode : b, b = a.namespaceURI || null, a = a.tagName, b = lb(b, a);
    }
    E(uh);
    G(uh, b);
  }
  function zh() {
    E(uh);
    E(vh);
    E(wh);
  }
  function Ah(a) {
    xh(wh.current);
    var b = xh(uh.current);
    var c = lb(b, a.type);
    b !== c && (G(vh, a), G(uh, c));
  }
  function Bh(a) {
    vh.current === a && (E(uh), E(vh));
  }
  var L = Uf(0);
  function Ch(a) {
    for (var b = a; null !== b; ) {
      if (13 === b.tag) {
        var c = b.memoizedState;
        if (null !== c && (c = c.dehydrated, null === c || "$?" === c.data || "$!" === c.data)) return b;
      } else if (19 === b.tag && void 0 !== b.memoizedProps.revealOrder) {
        if (0 !== (b.flags & 128)) return b;
      } else if (null !== b.child) {
        b.child.return = b;
        b = b.child;
        continue;
      }
      if (b === a) break;
      for (; null === b.sibling; ) {
        if (null === b.return || b.return === a) return null;
        b = b.return;
      }
      b.sibling.return = b.return;
      b = b.sibling;
    }
    return null;
  }
  var Dh = [];
  function Eh() {
    for (var a = 0; a < Dh.length; a++) Dh[a]._workInProgressVersionPrimary = null;
    Dh.length = 0;
  }
  var Fh = ua.ReactCurrentDispatcher, Gh = ua.ReactCurrentBatchConfig, Hh = 0, M = null, N = null, O = null, Ih = false, Jh = false, Kh = 0, Lh = 0;
  function P() {
    throw Error(p(321));
  }
  function Mh(a, b) {
    if (null === b) return false;
    for (var c = 0; c < b.length && c < a.length; c++) if (!He(a[c], b[c])) return false;
    return true;
  }
  function Nh(a, b, c, d, e, f) {
    Hh = f;
    M = b;
    b.memoizedState = null;
    b.updateQueue = null;
    b.lanes = 0;
    Fh.current = null === a || null === a.memoizedState ? Oh : Ph;
    a = c(d, e);
    if (Jh) {
      f = 0;
      do {
        Jh = false;
        Kh = 0;
        if (25 <= f) throw Error(p(301));
        f += 1;
        O = N = null;
        b.updateQueue = null;
        Fh.current = Qh;
        a = c(d, e);
      } while (Jh);
    }
    Fh.current = Rh;
    b = null !== N && null !== N.next;
    Hh = 0;
    O = N = M = null;
    Ih = false;
    if (b) throw Error(p(300));
    return a;
  }
  function Sh() {
    var a = 0 !== Kh;
    Kh = 0;
    return a;
  }
  function Th() {
    var a = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
    null === O ? M.memoizedState = O = a : O = O.next = a;
    return O;
  }
  function Uh() {
    if (null === N) {
      var a = M.alternate;
      a = null !== a ? a.memoizedState : null;
    } else a = N.next;
    var b = null === O ? M.memoizedState : O.next;
    if (null !== b) O = b, N = a;
    else {
      if (null === a) throw Error(p(310));
      N = a;
      a = { memoizedState: N.memoizedState, baseState: N.baseState, baseQueue: N.baseQueue, queue: N.queue, next: null };
      null === O ? M.memoizedState = O = a : O = O.next = a;
    }
    return O;
  }
  function Vh(a, b) {
    return "function" === typeof b ? b(a) : b;
  }
  function Wh(a) {
    var b = Uh(), c = b.queue;
    if (null === c) throw Error(p(311));
    c.lastRenderedReducer = a;
    var d = N, e = d.baseQueue, f = c.pending;
    if (null !== f) {
      if (null !== e) {
        var g = e.next;
        e.next = f.next;
        f.next = g;
      }
      d.baseQueue = e = f;
      c.pending = null;
    }
    if (null !== e) {
      f = e.next;
      d = d.baseState;
      var h = g = null, k = null, l = f;
      do {
        var m = l.lane;
        if ((Hh & m) === m) null !== k && (k = k.next = { lane: 0, action: l.action, hasEagerState: l.hasEagerState, eagerState: l.eagerState, next: null }), d = l.hasEagerState ? l.eagerState : a(d, l.action);
        else {
          var q = {
            lane: m,
            action: l.action,
            hasEagerState: l.hasEagerState,
            eagerState: l.eagerState,
            next: null
          };
          null === k ? (h = k = q, g = d) : k = k.next = q;
          M.lanes |= m;
          rh |= m;
        }
        l = l.next;
      } while (null !== l && l !== f);
      null === k ? g = d : k.next = h;
      He(d, b.memoizedState) || (dh = true);
      b.memoizedState = d;
      b.baseState = g;
      b.baseQueue = k;
      c.lastRenderedState = d;
    }
    a = c.interleaved;
    if (null !== a) {
      e = a;
      do
        f = e.lane, M.lanes |= f, rh |= f, e = e.next;
      while (e !== a);
    } else null === e && (c.lanes = 0);
    return [b.memoizedState, c.dispatch];
  }
  function Xh(a) {
    var b = Uh(), c = b.queue;
    if (null === c) throw Error(p(311));
    c.lastRenderedReducer = a;
    var d = c.dispatch, e = c.pending, f = b.memoizedState;
    if (null !== e) {
      c.pending = null;
      var g = e = e.next;
      do
        f = a(f, g.action), g = g.next;
      while (g !== e);
      He(f, b.memoizedState) || (dh = true);
      b.memoizedState = f;
      null === b.baseQueue && (b.baseState = f);
      c.lastRenderedState = f;
    }
    return [f, d];
  }
  function Yh() {
  }
  function Zh(a, b) {
    var c = M, d = Uh(), e = b(), f = !He(d.memoizedState, e);
    f && (d.memoizedState = e, dh = true);
    d = d.queue;
    $h(ai.bind(null, c, d, a), [a]);
    if (d.getSnapshot !== b || f || null !== O && O.memoizedState.tag & 1) {
      c.flags |= 2048;
      bi(9, ci.bind(null, c, d, e, b), void 0, null);
      if (null === Q) throw Error(p(349));
      0 !== (Hh & 30) || di(c, b, e);
    }
    return e;
  }
  function di(a, b, c) {
    a.flags |= 16384;
    a = { getSnapshot: b, value: c };
    b = M.updateQueue;
    null === b ? (b = { lastEffect: null, stores: null }, M.updateQueue = b, b.stores = [a]) : (c = b.stores, null === c ? b.stores = [a] : c.push(a));
  }
  function ci(a, b, c, d) {
    b.value = c;
    b.getSnapshot = d;
    ei(b) && fi(a);
  }
  function ai(a, b, c) {
    return c(function() {
      ei(b) && fi(a);
    });
  }
  function ei(a) {
    var b = a.getSnapshot;
    a = a.value;
    try {
      var c = b();
      return !He(a, c);
    } catch (d) {
      return true;
    }
  }
  function fi(a) {
    var b = ih(a, 1);
    null !== b && gi(b, a, 1, -1);
  }
  function hi(a) {
    var b = Th();
    "function" === typeof a && (a = a());
    b.memoizedState = b.baseState = a;
    a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: Vh, lastRenderedState: a };
    b.queue = a;
    a = a.dispatch = ii.bind(null, M, a);
    return [b.memoizedState, a];
  }
  function bi(a, b, c, d) {
    a = { tag: a, create: b, destroy: c, deps: d, next: null };
    b = M.updateQueue;
    null === b ? (b = { lastEffect: null, stores: null }, M.updateQueue = b, b.lastEffect = a.next = a) : (c = b.lastEffect, null === c ? b.lastEffect = a.next = a : (d = c.next, c.next = a, a.next = d, b.lastEffect = a));
    return a;
  }
  function ji() {
    return Uh().memoizedState;
  }
  function ki(a, b, c, d) {
    var e = Th();
    M.flags |= a;
    e.memoizedState = bi(1 | b, c, void 0, void 0 === d ? null : d);
  }
  function li(a, b, c, d) {
    var e = Uh();
    d = void 0 === d ? null : d;
    var f = void 0;
    if (null !== N) {
      var g = N.memoizedState;
      f = g.destroy;
      if (null !== d && Mh(d, g.deps)) {
        e.memoizedState = bi(b, c, f, d);
        return;
      }
    }
    M.flags |= a;
    e.memoizedState = bi(1 | b, c, f, d);
  }
  function mi(a, b) {
    return ki(8390656, 8, a, b);
  }
  function $h(a, b) {
    return li(2048, 8, a, b);
  }
  function ni(a, b) {
    return li(4, 2, a, b);
  }
  function oi(a, b) {
    return li(4, 4, a, b);
  }
  function pi(a, b) {
    if ("function" === typeof b) return a = a(), b(a), function() {
      b(null);
    };
    if (null !== b && void 0 !== b) return a = a(), b.current = a, function() {
      b.current = null;
    };
  }
  function qi(a, b, c) {
    c = null !== c && void 0 !== c ? c.concat([a]) : null;
    return li(4, 4, pi.bind(null, b, a), c);
  }
  function ri() {
  }
  function si(a, b) {
    var c = Uh();
    b = void 0 === b ? null : b;
    var d = c.memoizedState;
    if (null !== d && null !== b && Mh(b, d[1])) return d[0];
    c.memoizedState = [a, b];
    return a;
  }
  function ti(a, b) {
    var c = Uh();
    b = void 0 === b ? null : b;
    var d = c.memoizedState;
    if (null !== d && null !== b && Mh(b, d[1])) return d[0];
    a = a();
    c.memoizedState = [a, b];
    return a;
  }
  function ui(a, b, c) {
    if (0 === (Hh & 21)) return a.baseState && (a.baseState = false, dh = true), a.memoizedState = c;
    He(c, b) || (c = yc(), M.lanes |= c, rh |= c, a.baseState = true);
    return b;
  }
  function vi(a, b) {
    var c = C;
    C = 0 !== c && 4 > c ? c : 4;
    a(true);
    var d = Gh.transition;
    Gh.transition = {};
    try {
      a(false), b();
    } finally {
      C = c, Gh.transition = d;
    }
  }
  function wi() {
    return Uh().memoizedState;
  }
  function xi(a, b, c) {
    var d = yi(a);
    c = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
    if (zi(a)) Ai(b, c);
    else if (c = hh(a, b, c, d), null !== c) {
      var e = R();
      gi(c, a, d, e);
      Bi(c, b, d);
    }
  }
  function ii(a, b, c) {
    var d = yi(a), e = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
    if (zi(a)) Ai(b, e);
    else {
      var f = a.alternate;
      if (0 === a.lanes && (null === f || 0 === f.lanes) && (f = b.lastRenderedReducer, null !== f)) try {
        var g = b.lastRenderedState, h = f(g, c);
        e.hasEagerState = true;
        e.eagerState = h;
        if (He(h, g)) {
          var k = b.interleaved;
          null === k ? (e.next = e, gh(b)) : (e.next = k.next, k.next = e);
          b.interleaved = e;
          return;
        }
      } catch (l) {
      } finally {
      }
      c = hh(a, b, e, d);
      null !== c && (e = R(), gi(c, a, d, e), Bi(c, b, d));
    }
  }
  function zi(a) {
    var b = a.alternate;
    return a === M || null !== b && b === M;
  }
  function Ai(a, b) {
    Jh = Ih = true;
    var c = a.pending;
    null === c ? b.next = b : (b.next = c.next, c.next = b);
    a.pending = b;
  }
  function Bi(a, b, c) {
    if (0 !== (c & 4194240)) {
      var d = b.lanes;
      d &= a.pendingLanes;
      c |= d;
      b.lanes = c;
      Cc(a, c);
    }
  }
  var Rh = { readContext: eh, useCallback: P, useContext: P, useEffect: P, useImperativeHandle: P, useInsertionEffect: P, useLayoutEffect: P, useMemo: P, useReducer: P, useRef: P, useState: P, useDebugValue: P, useDeferredValue: P, useTransition: P, useMutableSource: P, useSyncExternalStore: P, useId: P, unstable_isNewReconciler: false }, Oh = { readContext: eh, useCallback: function(a, b) {
    Th().memoizedState = [a, void 0 === b ? null : b];
    return a;
  }, useContext: eh, useEffect: mi, useImperativeHandle: function(a, b, c) {
    c = null !== c && void 0 !== c ? c.concat([a]) : null;
    return ki(
      4194308,
      4,
      pi.bind(null, b, a),
      c
    );
  }, useLayoutEffect: function(a, b) {
    return ki(4194308, 4, a, b);
  }, useInsertionEffect: function(a, b) {
    return ki(4, 2, a, b);
  }, useMemo: function(a, b) {
    var c = Th();
    b = void 0 === b ? null : b;
    a = a();
    c.memoizedState = [a, b];
    return a;
  }, useReducer: function(a, b, c) {
    var d = Th();
    b = void 0 !== c ? c(b) : b;
    d.memoizedState = d.baseState = b;
    a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: a, lastRenderedState: b };
    d.queue = a;
    a = a.dispatch = xi.bind(null, M, a);
    return [d.memoizedState, a];
  }, useRef: function(a) {
    var b = Th();
    a = { current: a };
    return b.memoizedState = a;
  }, useState: hi, useDebugValue: ri, useDeferredValue: function(a) {
    return Th().memoizedState = a;
  }, useTransition: function() {
    var a = hi(false), b = a[0];
    a = vi.bind(null, a[1]);
    Th().memoizedState = a;
    return [b, a];
  }, useMutableSource: function() {
  }, useSyncExternalStore: function(a, b, c) {
    var d = M, e = Th();
    if (I) {
      if (void 0 === c) throw Error(p(407));
      c = c();
    } else {
      c = b();
      if (null === Q) throw Error(p(349));
      0 !== (Hh & 30) || di(d, b, c);
    }
    e.memoizedState = c;
    var f = { value: c, getSnapshot: b };
    e.queue = f;
    mi(ai.bind(
      null,
      d,
      f,
      a
    ), [a]);
    d.flags |= 2048;
    bi(9, ci.bind(null, d, f, c, b), void 0, null);
    return c;
  }, useId: function() {
    var a = Th(), b = Q.identifierPrefix;
    if (I) {
      var c = sg;
      var d = rg;
      c = (d & ~(1 << 32 - oc(d) - 1)).toString(32) + c;
      b = ":" + b + "R" + c;
      c = Kh++;
      0 < c && (b += "H" + c.toString(32));
      b += ":";
    } else c = Lh++, b = ":" + b + "r" + c.toString(32) + ":";
    return a.memoizedState = b;
  }, unstable_isNewReconciler: false }, Ph = {
    readContext: eh,
    useCallback: si,
    useContext: eh,
    useEffect: $h,
    useImperativeHandle: qi,
    useInsertionEffect: ni,
    useLayoutEffect: oi,
    useMemo: ti,
    useReducer: Wh,
    useRef: ji,
    useState: function() {
      return Wh(Vh);
    },
    useDebugValue: ri,
    useDeferredValue: function(a) {
      var b = Uh();
      return ui(b, N.memoizedState, a);
    },
    useTransition: function() {
      var a = Wh(Vh)[0], b = Uh().memoizedState;
      return [a, b];
    },
    useMutableSource: Yh,
    useSyncExternalStore: Zh,
    useId: wi,
    unstable_isNewReconciler: false
  }, Qh = { readContext: eh, useCallback: si, useContext: eh, useEffect: $h, useImperativeHandle: qi, useInsertionEffect: ni, useLayoutEffect: oi, useMemo: ti, useReducer: Xh, useRef: ji, useState: function() {
    return Xh(Vh);
  }, useDebugValue: ri, useDeferredValue: function(a) {
    var b = Uh();
    return null === N ? b.memoizedState = a : ui(b, N.memoizedState, a);
  }, useTransition: function() {
    var a = Xh(Vh)[0], b = Uh().memoizedState;
    return [a, b];
  }, useMutableSource: Yh, useSyncExternalStore: Zh, useId: wi, unstable_isNewReconciler: false };
  function Ci(a, b) {
    if (a && a.defaultProps) {
      b = A({}, b);
      a = a.defaultProps;
      for (var c in a) void 0 === b[c] && (b[c] = a[c]);
      return b;
    }
    return b;
  }
  function Di(a, b, c, d) {
    b = a.memoizedState;
    c = c(d, b);
    c = null === c || void 0 === c ? b : A({}, b, c);
    a.memoizedState = c;
    0 === a.lanes && (a.updateQueue.baseState = c);
  }
  var Ei = { isMounted: function(a) {
    return (a = a._reactInternals) ? Vb(a) === a : false;
  }, enqueueSetState: function(a, b, c) {
    a = a._reactInternals;
    var d = R(), e = yi(a), f = mh(d, e);
    f.payload = b;
    void 0 !== c && null !== c && (f.callback = c);
    b = nh(a, f, e);
    null !== b && (gi(b, a, e, d), oh(b, a, e));
  }, enqueueReplaceState: function(a, b, c) {
    a = a._reactInternals;
    var d = R(), e = yi(a), f = mh(d, e);
    f.tag = 1;
    f.payload = b;
    void 0 !== c && null !== c && (f.callback = c);
    b = nh(a, f, e);
    null !== b && (gi(b, a, e, d), oh(b, a, e));
  }, enqueueForceUpdate: function(a, b) {
    a = a._reactInternals;
    var c = R(), d = yi(a), e = mh(c, d);
    e.tag = 2;
    void 0 !== b && null !== b && (e.callback = b);
    b = nh(a, e, d);
    null !== b && (gi(b, a, d, c), oh(b, a, d));
  } };
  function Fi(a, b, c, d, e, f, g) {
    a = a.stateNode;
    return "function" === typeof a.shouldComponentUpdate ? a.shouldComponentUpdate(d, f, g) : b.prototype && b.prototype.isPureReactComponent ? !Ie(c, d) || !Ie(e, f) : true;
  }
  function Gi(a, b, c) {
    var d = false, e = Vf;
    var f = b.contextType;
    "object" === typeof f && null !== f ? f = eh(f) : (e = Zf(b) ? Xf : H.current, d = b.contextTypes, f = (d = null !== d && void 0 !== d) ? Yf(a, e) : Vf);
    b = new b(c, f);
    a.memoizedState = null !== b.state && void 0 !== b.state ? b.state : null;
    b.updater = Ei;
    a.stateNode = b;
    b._reactInternals = a;
    d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = e, a.__reactInternalMemoizedMaskedChildContext = f);
    return b;
  }
  function Hi(a, b, c, d) {
    a = b.state;
    "function" === typeof b.componentWillReceiveProps && b.componentWillReceiveProps(c, d);
    "function" === typeof b.UNSAFE_componentWillReceiveProps && b.UNSAFE_componentWillReceiveProps(c, d);
    b.state !== a && Ei.enqueueReplaceState(b, b.state, null);
  }
  function Ii(a, b, c, d) {
    var e = a.stateNode;
    e.props = c;
    e.state = a.memoizedState;
    e.refs = {};
    kh(a);
    var f = b.contextType;
    "object" === typeof f && null !== f ? e.context = eh(f) : (f = Zf(b) ? Xf : H.current, e.context = Yf(a, f));
    e.state = a.memoizedState;
    f = b.getDerivedStateFromProps;
    "function" === typeof f && (Di(a, b, f, c), e.state = a.memoizedState);
    "function" === typeof b.getDerivedStateFromProps || "function" === typeof e.getSnapshotBeforeUpdate || "function" !== typeof e.UNSAFE_componentWillMount && "function" !== typeof e.componentWillMount || (b = e.state, "function" === typeof e.componentWillMount && e.componentWillMount(), "function" === typeof e.UNSAFE_componentWillMount && e.UNSAFE_componentWillMount(), b !== e.state && Ei.enqueueReplaceState(e, e.state, null), qh(a, c, e, d), e.state = a.memoizedState);
    "function" === typeof e.componentDidMount && (a.flags |= 4194308);
  }
  function Ji(a, b) {
    try {
      var c = "", d = b;
      do
        c += Pa(d), d = d.return;
      while (d);
      var e = c;
    } catch (f) {
      e = "\nError generating stack: " + f.message + "\n" + f.stack;
    }
    return { value: a, source: b, stack: e, digest: null };
  }
  function Ki(a, b, c) {
    return { value: a, source: null, stack: null != c ? c : null, digest: null != b ? b : null };
  }
  function Li(a, b) {
    try {
      console.error(b.value);
    } catch (c) {
      setTimeout(function() {
        throw c;
      });
    }
  }
  var Mi = "function" === typeof WeakMap ? WeakMap : Map;
  function Ni(a, b, c) {
    c = mh(-1, c);
    c.tag = 3;
    c.payload = { element: null };
    var d = b.value;
    c.callback = function() {
      Oi || (Oi = true, Pi = d);
      Li(a, b);
    };
    return c;
  }
  function Qi(a, b, c) {
    c = mh(-1, c);
    c.tag = 3;
    var d = a.type.getDerivedStateFromError;
    if ("function" === typeof d) {
      var e = b.value;
      c.payload = function() {
        return d(e);
      };
      c.callback = function() {
        Li(a, b);
      };
    }
    var f = a.stateNode;
    null !== f && "function" === typeof f.componentDidCatch && (c.callback = function() {
      Li(a, b);
      "function" !== typeof d && (null === Ri ? Ri = /* @__PURE__ */ new Set([this]) : Ri.add(this));
      var c2 = b.stack;
      this.componentDidCatch(b.value, { componentStack: null !== c2 ? c2 : "" });
    });
    return c;
  }
  function Si(a, b, c) {
    var d = a.pingCache;
    if (null === d) {
      d = a.pingCache = new Mi();
      var e = /* @__PURE__ */ new Set();
      d.set(b, e);
    } else e = d.get(b), void 0 === e && (e = /* @__PURE__ */ new Set(), d.set(b, e));
    e.has(c) || (e.add(c), a = Ti.bind(null, a, b, c), b.then(a, a));
  }
  function Ui(a) {
    do {
      var b;
      if (b = 13 === a.tag) b = a.memoizedState, b = null !== b ? null !== b.dehydrated ? true : false : true;
      if (b) return a;
      a = a.return;
    } while (null !== a);
    return null;
  }
  function Vi(a, b, c, d, e) {
    if (0 === (a.mode & 1)) return a === b ? a.flags |= 65536 : (a.flags |= 128, c.flags |= 131072, c.flags &= -52805, 1 === c.tag && (null === c.alternate ? c.tag = 17 : (b = mh(-1, 1), b.tag = 2, nh(c, b, 1))), c.lanes |= 1), a;
    a.flags |= 65536;
    a.lanes = e;
    return a;
  }
  var Wi = ua.ReactCurrentOwner, dh = false;
  function Xi(a, b, c, d) {
    b.child = null === a ? Vg(b, null, c, d) : Ug(b, a.child, c, d);
  }
  function Yi(a, b, c, d, e) {
    c = c.render;
    var f = b.ref;
    ch(b, e);
    d = Nh(a, b, c, d, f, e);
    c = Sh();
    if (null !== a && !dh) return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
    I && c && vg(b);
    b.flags |= 1;
    Xi(a, b, d, e);
    return b.child;
  }
  function $i(a, b, c, d, e) {
    if (null === a) {
      var f = c.type;
      if ("function" === typeof f && !aj(f) && void 0 === f.defaultProps && null === c.compare && void 0 === c.defaultProps) return b.tag = 15, b.type = f, bj(a, b, f, d, e);
      a = Rg(c.type, null, d, b, b.mode, e);
      a.ref = b.ref;
      a.return = b;
      return b.child = a;
    }
    f = a.child;
    if (0 === (a.lanes & e)) {
      var g = f.memoizedProps;
      c = c.compare;
      c = null !== c ? c : Ie;
      if (c(g, d) && a.ref === b.ref) return Zi(a, b, e);
    }
    b.flags |= 1;
    a = Pg(f, d);
    a.ref = b.ref;
    a.return = b;
    return b.child = a;
  }
  function bj(a, b, c, d, e) {
    if (null !== a) {
      var f = a.memoizedProps;
      if (Ie(f, d) && a.ref === b.ref) if (dh = false, b.pendingProps = d = f, 0 !== (a.lanes & e)) 0 !== (a.flags & 131072) && (dh = true);
      else return b.lanes = a.lanes, Zi(a, b, e);
    }
    return cj(a, b, c, d, e);
  }
  function dj(a, b, c) {
    var d = b.pendingProps, e = d.children, f = null !== a ? a.memoizedState : null;
    if ("hidden" === d.mode) if (0 === (b.mode & 1)) b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, G(ej, fj), fj |= c;
    else {
      if (0 === (c & 1073741824)) return a = null !== f ? f.baseLanes | c : c, b.lanes = b.childLanes = 1073741824, b.memoizedState = { baseLanes: a, cachePool: null, transitions: null }, b.updateQueue = null, G(ej, fj), fj |= a, null;
      b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null };
      d = null !== f ? f.baseLanes : c;
      G(ej, fj);
      fj |= d;
    }
    else null !== f ? (d = f.baseLanes | c, b.memoizedState = null) : d = c, G(ej, fj), fj |= d;
    Xi(a, b, e, c);
    return b.child;
  }
  function gj(a, b) {
    var c = b.ref;
    if (null === a && null !== c || null !== a && a.ref !== c) b.flags |= 512, b.flags |= 2097152;
  }
  function cj(a, b, c, d, e) {
    var f = Zf(c) ? Xf : H.current;
    f = Yf(b, f);
    ch(b, e);
    c = Nh(a, b, c, d, f, e);
    d = Sh();
    if (null !== a && !dh) return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
    I && d && vg(b);
    b.flags |= 1;
    Xi(a, b, c, e);
    return b.child;
  }
  function hj(a, b, c, d, e) {
    if (Zf(c)) {
      var f = true;
      cg(b);
    } else f = false;
    ch(b, e);
    if (null === b.stateNode) ij(a, b), Gi(b, c, d), Ii(b, c, d, e), d = true;
    else if (null === a) {
      var g = b.stateNode, h = b.memoizedProps;
      g.props = h;
      var k = g.context, l = c.contextType;
      "object" === typeof l && null !== l ? l = eh(l) : (l = Zf(c) ? Xf : H.current, l = Yf(b, l));
      var m = c.getDerivedStateFromProps, q = "function" === typeof m || "function" === typeof g.getSnapshotBeforeUpdate;
      q || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h !== d || k !== l) && Hi(b, g, d, l);
      jh = false;
      var r = b.memoizedState;
      g.state = r;
      qh(b, d, g, e);
      k = b.memoizedState;
      h !== d || r !== k || Wf.current || jh ? ("function" === typeof m && (Di(b, c, m, d), k = b.memoizedState), (h = jh || Fi(b, c, h, d, r, k, l)) ? (q || "function" !== typeof g.UNSAFE_componentWillMount && "function" !== typeof g.componentWillMount || ("function" === typeof g.componentWillMount && g.componentWillMount(), "function" === typeof g.UNSAFE_componentWillMount && g.UNSAFE_componentWillMount()), "function" === typeof g.componentDidMount && (b.flags |= 4194308)) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), b.memoizedProps = d, b.memoizedState = k), g.props = d, g.state = k, g.context = l, d = h) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), d = false);
    } else {
      g = b.stateNode;
      lh(a, b);
      h = b.memoizedProps;
      l = b.type === b.elementType ? h : Ci(b.type, h);
      g.props = l;
      q = b.pendingProps;
      r = g.context;
      k = c.contextType;
      "object" === typeof k && null !== k ? k = eh(k) : (k = Zf(c) ? Xf : H.current, k = Yf(b, k));
      var y = c.getDerivedStateFromProps;
      (m = "function" === typeof y || "function" === typeof g.getSnapshotBeforeUpdate) || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h !== q || r !== k) && Hi(b, g, d, k);
      jh = false;
      r = b.memoizedState;
      g.state = r;
      qh(b, d, g, e);
      var n = b.memoizedState;
      h !== q || r !== n || Wf.current || jh ? ("function" === typeof y && (Di(b, c, y, d), n = b.memoizedState), (l = jh || Fi(b, c, l, d, r, n, k) || false) ? (m || "function" !== typeof g.UNSAFE_componentWillUpdate && "function" !== typeof g.componentWillUpdate || ("function" === typeof g.componentWillUpdate && g.componentWillUpdate(d, n, k), "function" === typeof g.UNSAFE_componentWillUpdate && g.UNSAFE_componentWillUpdate(d, n, k)), "function" === typeof g.componentDidUpdate && (b.flags |= 4), "function" === typeof g.getSnapshotBeforeUpdate && (b.flags |= 1024)) : ("function" !== typeof g.componentDidUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 1024), b.memoizedProps = d, b.memoizedState = n), g.props = d, g.state = n, g.context = k, d = l) : ("function" !== typeof g.componentDidUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 1024), d = false);
    }
    return jj(a, b, c, d, f, e);
  }
  function jj(a, b, c, d, e, f) {
    gj(a, b);
    var g = 0 !== (b.flags & 128);
    if (!d && !g) return e && dg(b, c, false), Zi(a, b, f);
    d = b.stateNode;
    Wi.current = b;
    var h = g && "function" !== typeof c.getDerivedStateFromError ? null : d.render();
    b.flags |= 1;
    null !== a && g ? (b.child = Ug(b, a.child, null, f), b.child = Ug(b, null, h, f)) : Xi(a, b, h, f);
    b.memoizedState = d.state;
    e && dg(b, c, true);
    return b.child;
  }
  function kj(a) {
    var b = a.stateNode;
    b.pendingContext ? ag(a, b.pendingContext, b.pendingContext !== b.context) : b.context && ag(a, b.context, false);
    yh(a, b.containerInfo);
  }
  function lj(a, b, c, d, e) {
    Ig();
    Jg(e);
    b.flags |= 256;
    Xi(a, b, c, d);
    return b.child;
  }
  var mj = { dehydrated: null, treeContext: null, retryLane: 0 };
  function nj(a) {
    return { baseLanes: a, cachePool: null, transitions: null };
  }
  function oj(a, b, c) {
    var d = b.pendingProps, e = L.current, f = false, g = 0 !== (b.flags & 128), h;
    (h = g) || (h = null !== a && null === a.memoizedState ? false : 0 !== (e & 2));
    if (h) f = true, b.flags &= -129;
    else if (null === a || null !== a.memoizedState) e |= 1;
    G(L, e & 1);
    if (null === a) {
      Eg(b);
      a = b.memoizedState;
      if (null !== a && (a = a.dehydrated, null !== a)) return 0 === (b.mode & 1) ? b.lanes = 1 : "$!" === a.data ? b.lanes = 8 : b.lanes = 1073741824, null;
      g = d.children;
      a = d.fallback;
      return f ? (d = b.mode, f = b.child, g = { mode: "hidden", children: g }, 0 === (d & 1) && null !== f ? (f.childLanes = 0, f.pendingProps = g) : f = pj(g, d, 0, null), a = Tg(a, d, c, null), f.return = b, a.return = b, f.sibling = a, b.child = f, b.child.memoizedState = nj(c), b.memoizedState = mj, a) : qj(b, g);
    }
    e = a.memoizedState;
    if (null !== e && (h = e.dehydrated, null !== h)) return rj(a, b, g, d, h, e, c);
    if (f) {
      f = d.fallback;
      g = b.mode;
      e = a.child;
      h = e.sibling;
      var k = { mode: "hidden", children: d.children };
      0 === (g & 1) && b.child !== e ? (d = b.child, d.childLanes = 0, d.pendingProps = k, b.deletions = null) : (d = Pg(e, k), d.subtreeFlags = e.subtreeFlags & 14680064);
      null !== h ? f = Pg(h, f) : (f = Tg(f, g, c, null), f.flags |= 2);
      f.return = b;
      d.return = b;
      d.sibling = f;
      b.child = d;
      d = f;
      f = b.child;
      g = a.child.memoizedState;
      g = null === g ? nj(c) : { baseLanes: g.baseLanes | c, cachePool: null, transitions: g.transitions };
      f.memoizedState = g;
      f.childLanes = a.childLanes & ~c;
      b.memoizedState = mj;
      return d;
    }
    f = a.child;
    a = f.sibling;
    d = Pg(f, { mode: "visible", children: d.children });
    0 === (b.mode & 1) && (d.lanes = c);
    d.return = b;
    d.sibling = null;
    null !== a && (c = b.deletions, null === c ? (b.deletions = [a], b.flags |= 16) : c.push(a));
    b.child = d;
    b.memoizedState = null;
    return d;
  }
  function qj(a, b) {
    b = pj({ mode: "visible", children: b }, a.mode, 0, null);
    b.return = a;
    return a.child = b;
  }
  function sj(a, b, c, d) {
    null !== d && Jg(d);
    Ug(b, a.child, null, c);
    a = qj(b, b.pendingProps.children);
    a.flags |= 2;
    b.memoizedState = null;
    return a;
  }
  function rj(a, b, c, d, e, f, g) {
    if (c) {
      if (b.flags & 256) return b.flags &= -257, d = Ki(Error(p(422))), sj(a, b, g, d);
      if (null !== b.memoizedState) return b.child = a.child, b.flags |= 128, null;
      f = d.fallback;
      e = b.mode;
      d = pj({ mode: "visible", children: d.children }, e, 0, null);
      f = Tg(f, e, g, null);
      f.flags |= 2;
      d.return = b;
      f.return = b;
      d.sibling = f;
      b.child = d;
      0 !== (b.mode & 1) && Ug(b, a.child, null, g);
      b.child.memoizedState = nj(g);
      b.memoizedState = mj;
      return f;
    }
    if (0 === (b.mode & 1)) return sj(a, b, g, null);
    if ("$!" === e.data) {
      d = e.nextSibling && e.nextSibling.dataset;
      if (d) var h = d.dgst;
      d = h;
      f = Error(p(419));
      d = Ki(f, d, void 0);
      return sj(a, b, g, d);
    }
    h = 0 !== (g & a.childLanes);
    if (dh || h) {
      d = Q;
      if (null !== d) {
        switch (g & -g) {
          case 4:
            e = 2;
            break;
          case 16:
            e = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            e = 32;
            break;
          case 536870912:
            e = 268435456;
            break;
          default:
            e = 0;
        }
        e = 0 !== (e & (d.suspendedLanes | g)) ? 0 : e;
        0 !== e && e !== f.retryLane && (f.retryLane = e, ih(a, e), gi(d, a, e, -1));
      }
      tj();
      d = Ki(Error(p(421)));
      return sj(a, b, g, d);
    }
    if ("$?" === e.data) return b.flags |= 128, b.child = a.child, b = uj.bind(null, a), e._reactRetry = b, null;
    a = f.treeContext;
    yg = Lf(e.nextSibling);
    xg = b;
    I = true;
    zg = null;
    null !== a && (og[pg++] = rg, og[pg++] = sg, og[pg++] = qg, rg = a.id, sg = a.overflow, qg = b);
    b = qj(b, d.children);
    b.flags |= 4096;
    return b;
  }
  function vj(a, b, c) {
    a.lanes |= b;
    var d = a.alternate;
    null !== d && (d.lanes |= b);
    bh(a.return, b, c);
  }
  function wj(a, b, c, d, e) {
    var f = a.memoizedState;
    null === f ? a.memoizedState = { isBackwards: b, rendering: null, renderingStartTime: 0, last: d, tail: c, tailMode: e } : (f.isBackwards = b, f.rendering = null, f.renderingStartTime = 0, f.last = d, f.tail = c, f.tailMode = e);
  }
  function xj(a, b, c) {
    var d = b.pendingProps, e = d.revealOrder, f = d.tail;
    Xi(a, b, d.children, c);
    d = L.current;
    if (0 !== (d & 2)) d = d & 1 | 2, b.flags |= 128;
    else {
      if (null !== a && 0 !== (a.flags & 128)) a: for (a = b.child; null !== a; ) {
        if (13 === a.tag) null !== a.memoizedState && vj(a, c, b);
        else if (19 === a.tag) vj(a, c, b);
        else if (null !== a.child) {
          a.child.return = a;
          a = a.child;
          continue;
        }
        if (a === b) break a;
        for (; null === a.sibling; ) {
          if (null === a.return || a.return === b) break a;
          a = a.return;
        }
        a.sibling.return = a.return;
        a = a.sibling;
      }
      d &= 1;
    }
    G(L, d);
    if (0 === (b.mode & 1)) b.memoizedState = null;
    else switch (e) {
      case "forwards":
        c = b.child;
        for (e = null; null !== c; ) a = c.alternate, null !== a && null === Ch(a) && (e = c), c = c.sibling;
        c = e;
        null === c ? (e = b.child, b.child = null) : (e = c.sibling, c.sibling = null);
        wj(b, false, e, c, f);
        break;
      case "backwards":
        c = null;
        e = b.child;
        for (b.child = null; null !== e; ) {
          a = e.alternate;
          if (null !== a && null === Ch(a)) {
            b.child = e;
            break;
          }
          a = e.sibling;
          e.sibling = c;
          c = e;
          e = a;
        }
        wj(b, true, c, null, f);
        break;
      case "together":
        wj(b, false, null, null, void 0);
        break;
      default:
        b.memoizedState = null;
    }
    return b.child;
  }
  function ij(a, b) {
    0 === (b.mode & 1) && null !== a && (a.alternate = null, b.alternate = null, b.flags |= 2);
  }
  function Zi(a, b, c) {
    null !== a && (b.dependencies = a.dependencies);
    rh |= b.lanes;
    if (0 === (c & b.childLanes)) return null;
    if (null !== a && b.child !== a.child) throw Error(p(153));
    if (null !== b.child) {
      a = b.child;
      c = Pg(a, a.pendingProps);
      b.child = c;
      for (c.return = b; null !== a.sibling; ) a = a.sibling, c = c.sibling = Pg(a, a.pendingProps), c.return = b;
      c.sibling = null;
    }
    return b.child;
  }
  function yj(a, b, c) {
    switch (b.tag) {
      case 3:
        kj(b);
        Ig();
        break;
      case 5:
        Ah(b);
        break;
      case 1:
        Zf(b.type) && cg(b);
        break;
      case 4:
        yh(b, b.stateNode.containerInfo);
        break;
      case 10:
        var d = b.type._context, e = b.memoizedProps.value;
        G(Wg, d._currentValue);
        d._currentValue = e;
        break;
      case 13:
        d = b.memoizedState;
        if (null !== d) {
          if (null !== d.dehydrated) return G(L, L.current & 1), b.flags |= 128, null;
          if (0 !== (c & b.child.childLanes)) return oj(a, b, c);
          G(L, L.current & 1);
          a = Zi(a, b, c);
          return null !== a ? a.sibling : null;
        }
        G(L, L.current & 1);
        break;
      case 19:
        d = 0 !== (c & b.childLanes);
        if (0 !== (a.flags & 128)) {
          if (d) return xj(a, b, c);
          b.flags |= 128;
        }
        e = b.memoizedState;
        null !== e && (e.rendering = null, e.tail = null, e.lastEffect = null);
        G(L, L.current);
        if (d) break;
        else return null;
      case 22:
      case 23:
        return b.lanes = 0, dj(a, b, c);
    }
    return Zi(a, b, c);
  }
  var zj, Aj, Bj, Cj;
  zj = function(a, b) {
    for (var c = b.child; null !== c; ) {
      if (5 === c.tag || 6 === c.tag) a.appendChild(c.stateNode);
      else if (4 !== c.tag && null !== c.child) {
        c.child.return = c;
        c = c.child;
        continue;
      }
      if (c === b) break;
      for (; null === c.sibling; ) {
        if (null === c.return || c.return === b) return;
        c = c.return;
      }
      c.sibling.return = c.return;
      c = c.sibling;
    }
  };
  Aj = function() {
  };
  Bj = function(a, b, c, d) {
    var e = a.memoizedProps;
    if (e !== d) {
      a = b.stateNode;
      xh(uh.current);
      var f = null;
      switch (c) {
        case "input":
          e = Ya(a, e);
          d = Ya(a, d);
          f = [];
          break;
        case "select":
          e = A({}, e, { value: void 0 });
          d = A({}, d, { value: void 0 });
          f = [];
          break;
        case "textarea":
          e = gb(a, e);
          d = gb(a, d);
          f = [];
          break;
        default:
          "function" !== typeof e.onClick && "function" === typeof d.onClick && (a.onclick = Bf);
      }
      ub(c, d);
      var g;
      c = null;
      for (l in e) if (!d.hasOwnProperty(l) && e.hasOwnProperty(l) && null != e[l]) if ("style" === l) {
        var h = e[l];
        for (g in h) h.hasOwnProperty(g) && (c || (c = {}), c[g] = "");
      } else "dangerouslySetInnerHTML" !== l && "children" !== l && "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && "autoFocus" !== l && (ea.hasOwnProperty(l) ? f || (f = []) : (f = f || []).push(l, null));
      for (l in d) {
        var k = d[l];
        h = null != e ? e[l] : void 0;
        if (d.hasOwnProperty(l) && k !== h && (null != k || null != h)) if ("style" === l) if (h) {
          for (g in h) !h.hasOwnProperty(g) || k && k.hasOwnProperty(g) || (c || (c = {}), c[g] = "");
          for (g in k) k.hasOwnProperty(g) && h[g] !== k[g] && (c || (c = {}), c[g] = k[g]);
        } else c || (f || (f = []), f.push(
          l,
          c
        )), c = k;
        else "dangerouslySetInnerHTML" === l ? (k = k ? k.__html : void 0, h = h ? h.__html : void 0, null != k && h !== k && (f = f || []).push(l, k)) : "children" === l ? "string" !== typeof k && "number" !== typeof k || (f = f || []).push(l, "" + k) : "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && (ea.hasOwnProperty(l) ? (null != k && "onScroll" === l && D("scroll", a), f || h === k || (f = [])) : (f = f || []).push(l, k));
      }
      c && (f = f || []).push("style", c);
      var l = f;
      if (b.updateQueue = l) b.flags |= 4;
    }
  };
  Cj = function(a, b, c, d) {
    c !== d && (b.flags |= 4);
  };
  function Dj(a, b) {
    if (!I) switch (a.tailMode) {
      case "hidden":
        b = a.tail;
        for (var c = null; null !== b; ) null !== b.alternate && (c = b), b = b.sibling;
        null === c ? a.tail = null : c.sibling = null;
        break;
      case "collapsed":
        c = a.tail;
        for (var d = null; null !== c; ) null !== c.alternate && (d = c), c = c.sibling;
        null === d ? b || null === a.tail ? a.tail = null : a.tail.sibling = null : d.sibling = null;
    }
  }
  function S(a) {
    var b = null !== a.alternate && a.alternate.child === a.child, c = 0, d = 0;
    if (b) for (var e = a.child; null !== e; ) c |= e.lanes | e.childLanes, d |= e.subtreeFlags & 14680064, d |= e.flags & 14680064, e.return = a, e = e.sibling;
    else for (e = a.child; null !== e; ) c |= e.lanes | e.childLanes, d |= e.subtreeFlags, d |= e.flags, e.return = a, e = e.sibling;
    a.subtreeFlags |= d;
    a.childLanes = c;
    return b;
  }
  function Ej(a, b, c) {
    var d = b.pendingProps;
    wg(b);
    switch (b.tag) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return S(b), null;
      case 1:
        return Zf(b.type) && $f(), S(b), null;
      case 3:
        d = b.stateNode;
        zh();
        E(Wf);
        E(H);
        Eh();
        d.pendingContext && (d.context = d.pendingContext, d.pendingContext = null);
        if (null === a || null === a.child) Gg(b) ? b.flags |= 4 : null === a || a.memoizedState.isDehydrated && 0 === (b.flags & 256) || (b.flags |= 1024, null !== zg && (Fj(zg), zg = null));
        Aj(a, b);
        S(b);
        return null;
      case 5:
        Bh(b);
        var e = xh(wh.current);
        c = b.type;
        if (null !== a && null != b.stateNode) Bj(a, b, c, d, e), a.ref !== b.ref && (b.flags |= 512, b.flags |= 2097152);
        else {
          if (!d) {
            if (null === b.stateNode) throw Error(p(166));
            S(b);
            return null;
          }
          a = xh(uh.current);
          if (Gg(b)) {
            d = b.stateNode;
            c = b.type;
            var f = b.memoizedProps;
            d[Of] = b;
            d[Pf] = f;
            a = 0 !== (b.mode & 1);
            switch (c) {
              case "dialog":
                D("cancel", d);
                D("close", d);
                break;
              case "iframe":
              case "object":
              case "embed":
                D("load", d);
                break;
              case "video":
              case "audio":
                for (e = 0; e < lf.length; e++) D(lf[e], d);
                break;
              case "source":
                D("error", d);
                break;
              case "img":
              case "image":
              case "link":
                D(
                  "error",
                  d
                );
                D("load", d);
                break;
              case "details":
                D("toggle", d);
                break;
              case "input":
                Za(d, f);
                D("invalid", d);
                break;
              case "select":
                d._wrapperState = { wasMultiple: !!f.multiple };
                D("invalid", d);
                break;
              case "textarea":
                hb(d, f), D("invalid", d);
            }
            ub(c, f);
            e = null;
            for (var g in f) if (f.hasOwnProperty(g)) {
              var h = f[g];
              "children" === g ? "string" === typeof h ? d.textContent !== h && (true !== f.suppressHydrationWarning && Af(d.textContent, h, a), e = ["children", h]) : "number" === typeof h && d.textContent !== "" + h && (true !== f.suppressHydrationWarning && Af(
                d.textContent,
                h,
                a
              ), e = ["children", "" + h]) : ea.hasOwnProperty(g) && null != h && "onScroll" === g && D("scroll", d);
            }
            switch (c) {
              case "input":
                Va(d);
                db(d, f, true);
                break;
              case "textarea":
                Va(d);
                jb(d);
                break;
              case "select":
              case "option":
                break;
              default:
                "function" === typeof f.onClick && (d.onclick = Bf);
            }
            d = e;
            b.updateQueue = d;
            null !== d && (b.flags |= 4);
          } else {
            g = 9 === e.nodeType ? e : e.ownerDocument;
            "http://www.w3.org/1999/xhtml" === a && (a = kb(c));
            "http://www.w3.org/1999/xhtml" === a ? "script" === c ? (a = g.createElement("div"), a.innerHTML = "<script><\/script>", a = a.removeChild(a.firstChild)) : "string" === typeof d.is ? a = g.createElement(c, { is: d.is }) : (a = g.createElement(c), "select" === c && (g = a, d.multiple ? g.multiple = true : d.size && (g.size = d.size))) : a = g.createElementNS(a, c);
            a[Of] = b;
            a[Pf] = d;
            zj(a, b, false, false);
            b.stateNode = a;
            a: {
              g = vb(c, d);
              switch (c) {
                case "dialog":
                  D("cancel", a);
                  D("close", a);
                  e = d;
                  break;
                case "iframe":
                case "object":
                case "embed":
                  D("load", a);
                  e = d;
                  break;
                case "video":
                case "audio":
                  for (e = 0; e < lf.length; e++) D(lf[e], a);
                  e = d;
                  break;
                case "source":
                  D("error", a);
                  e = d;
                  break;
                case "img":
                case "image":
                case "link":
                  D(
                    "error",
                    a
                  );
                  D("load", a);
                  e = d;
                  break;
                case "details":
                  D("toggle", a);
                  e = d;
                  break;
                case "input":
                  Za(a, d);
                  e = Ya(a, d);
                  D("invalid", a);
                  break;
                case "option":
                  e = d;
                  break;
                case "select":
                  a._wrapperState = { wasMultiple: !!d.multiple };
                  e = A({}, d, { value: void 0 });
                  D("invalid", a);
                  break;
                case "textarea":
                  hb(a, d);
                  e = gb(a, d);
                  D("invalid", a);
                  break;
                default:
                  e = d;
              }
              ub(c, e);
              h = e;
              for (f in h) if (h.hasOwnProperty(f)) {
                var k = h[f];
                "style" === f ? sb(a, k) : "dangerouslySetInnerHTML" === f ? (k = k ? k.__html : void 0, null != k && nb(a, k)) : "children" === f ? "string" === typeof k ? ("textarea" !== c || "" !== k) && ob(a, k) : "number" === typeof k && ob(a, "" + k) : "suppressContentEditableWarning" !== f && "suppressHydrationWarning" !== f && "autoFocus" !== f && (ea.hasOwnProperty(f) ? null != k && "onScroll" === f && D("scroll", a) : null != k && ta(a, f, k, g));
              }
              switch (c) {
                case "input":
                  Va(a);
                  db(a, d, false);
                  break;
                case "textarea":
                  Va(a);
                  jb(a);
                  break;
                case "option":
                  null != d.value && a.setAttribute("value", "" + Sa(d.value));
                  break;
                case "select":
                  a.multiple = !!d.multiple;
                  f = d.value;
                  null != f ? fb(a, !!d.multiple, f, false) : null != d.defaultValue && fb(
                    a,
                    !!d.multiple,
                    d.defaultValue,
                    true
                  );
                  break;
                default:
                  "function" === typeof e.onClick && (a.onclick = Bf);
              }
              switch (c) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  d = !!d.autoFocus;
                  break a;
                case "img":
                  d = true;
                  break a;
                default:
                  d = false;
              }
            }
            d && (b.flags |= 4);
          }
          null !== b.ref && (b.flags |= 512, b.flags |= 2097152);
        }
        S(b);
        return null;
      case 6:
        if (a && null != b.stateNode) Cj(a, b, a.memoizedProps, d);
        else {
          if ("string" !== typeof d && null === b.stateNode) throw Error(p(166));
          c = xh(wh.current);
          xh(uh.current);
          if (Gg(b)) {
            d = b.stateNode;
            c = b.memoizedProps;
            d[Of] = b;
            if (f = d.nodeValue !== c) {
              if (a = xg, null !== a) switch (a.tag) {
                case 3:
                  Af(d.nodeValue, c, 0 !== (a.mode & 1));
                  break;
                case 5:
                  true !== a.memoizedProps.suppressHydrationWarning && Af(d.nodeValue, c, 0 !== (a.mode & 1));
              }
            }
            f && (b.flags |= 4);
          } else d = (9 === c.nodeType ? c : c.ownerDocument).createTextNode(d), d[Of] = b, b.stateNode = d;
        }
        S(b);
        return null;
      case 13:
        E(L);
        d = b.memoizedState;
        if (null === a || null !== a.memoizedState && null !== a.memoizedState.dehydrated) {
          if (I && null !== yg && 0 !== (b.mode & 1) && 0 === (b.flags & 128)) Hg(), Ig(), b.flags |= 98560, f = false;
          else if (f = Gg(b), null !== d && null !== d.dehydrated) {
            if (null === a) {
              if (!f) throw Error(p(318));
              f = b.memoizedState;
              f = null !== f ? f.dehydrated : null;
              if (!f) throw Error(p(317));
              f[Of] = b;
            } else Ig(), 0 === (b.flags & 128) && (b.memoizedState = null), b.flags |= 4;
            S(b);
            f = false;
          } else null !== zg && (Fj(zg), zg = null), f = true;
          if (!f) return b.flags & 65536 ? b : null;
        }
        if (0 !== (b.flags & 128)) return b.lanes = c, b;
        d = null !== d;
        d !== (null !== a && null !== a.memoizedState) && d && (b.child.flags |= 8192, 0 !== (b.mode & 1) && (null === a || 0 !== (L.current & 1) ? 0 === T && (T = 3) : tj()));
        null !== b.updateQueue && (b.flags |= 4);
        S(b);
        return null;
      case 4:
        return zh(), Aj(a, b), null === a && sf(b.stateNode.containerInfo), S(b), null;
      case 10:
        return ah(b.type._context), S(b), null;
      case 17:
        return Zf(b.type) && $f(), S(b), null;
      case 19:
        E(L);
        f = b.memoizedState;
        if (null === f) return S(b), null;
        d = 0 !== (b.flags & 128);
        g = f.rendering;
        if (null === g) if (d) Dj(f, false);
        else {
          if (0 !== T || null !== a && 0 !== (a.flags & 128)) for (a = b.child; null !== a; ) {
            g = Ch(a);
            if (null !== g) {
              b.flags |= 128;
              Dj(f, false);
              d = g.updateQueue;
              null !== d && (b.updateQueue = d, b.flags |= 4);
              b.subtreeFlags = 0;
              d = c;
              for (c = b.child; null !== c; ) f = c, a = d, f.flags &= 14680066, g = f.alternate, null === g ? (f.childLanes = 0, f.lanes = a, f.child = null, f.subtreeFlags = 0, f.memoizedProps = null, f.memoizedState = null, f.updateQueue = null, f.dependencies = null, f.stateNode = null) : (f.childLanes = g.childLanes, f.lanes = g.lanes, f.child = g.child, f.subtreeFlags = 0, f.deletions = null, f.memoizedProps = g.memoizedProps, f.memoizedState = g.memoizedState, f.updateQueue = g.updateQueue, f.type = g.type, a = g.dependencies, f.dependencies = null === a ? null : { lanes: a.lanes, firstContext: a.firstContext }), c = c.sibling;
              G(L, L.current & 1 | 2);
              return b.child;
            }
            a = a.sibling;
          }
          null !== f.tail && B() > Gj && (b.flags |= 128, d = true, Dj(f, false), b.lanes = 4194304);
        }
        else {
          if (!d) if (a = Ch(g), null !== a) {
            if (b.flags |= 128, d = true, c = a.updateQueue, null !== c && (b.updateQueue = c, b.flags |= 4), Dj(f, true), null === f.tail && "hidden" === f.tailMode && !g.alternate && !I) return S(b), null;
          } else 2 * B() - f.renderingStartTime > Gj && 1073741824 !== c && (b.flags |= 128, d = true, Dj(f, false), b.lanes = 4194304);
          f.isBackwards ? (g.sibling = b.child, b.child = g) : (c = f.last, null !== c ? c.sibling = g : b.child = g, f.last = g);
        }
        if (null !== f.tail) return b = f.tail, f.rendering = b, f.tail = b.sibling, f.renderingStartTime = B(), b.sibling = null, c = L.current, G(L, d ? c & 1 | 2 : c & 1), b;
        S(b);
        return null;
      case 22:
      case 23:
        return Hj(), d = null !== b.memoizedState, null !== a && null !== a.memoizedState !== d && (b.flags |= 8192), d && 0 !== (b.mode & 1) ? 0 !== (fj & 1073741824) && (S(b), b.subtreeFlags & 6 && (b.flags |= 8192)) : S(b), null;
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(p(156, b.tag));
  }
  function Ij(a, b) {
    wg(b);
    switch (b.tag) {
      case 1:
        return Zf(b.type) && $f(), a = b.flags, a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
      case 3:
        return zh(), E(Wf), E(H), Eh(), a = b.flags, 0 !== (a & 65536) && 0 === (a & 128) ? (b.flags = a & -65537 | 128, b) : null;
      case 5:
        return Bh(b), null;
      case 13:
        E(L);
        a = b.memoizedState;
        if (null !== a && null !== a.dehydrated) {
          if (null === b.alternate) throw Error(p(340));
          Ig();
        }
        a = b.flags;
        return a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
      case 19:
        return E(L), null;
      case 4:
        return zh(), null;
      case 10:
        return ah(b.type._context), null;
      case 22:
      case 23:
        return Hj(), null;
      case 24:
        return null;
      default:
        return null;
    }
  }
  var Jj = false, U = false, Kj = "function" === typeof WeakSet ? WeakSet : Set, V = null;
  function Lj(a, b) {
    var c = a.ref;
    if (null !== c) if ("function" === typeof c) try {
      c(null);
    } catch (d) {
      W(a, b, d);
    }
    else c.current = null;
  }
  function Mj(a, b, c) {
    try {
      c();
    } catch (d) {
      W(a, b, d);
    }
  }
  var Nj = false;
  function Oj(a, b) {
    Cf = dd;
    a = Me();
    if (Ne(a)) {
      if ("selectionStart" in a) var c = { start: a.selectionStart, end: a.selectionEnd };
      else a: {
        c = (c = a.ownerDocument) && c.defaultView || window;
        var d = c.getSelection && c.getSelection();
        if (d && 0 !== d.rangeCount) {
          c = d.anchorNode;
          var e = d.anchorOffset, f = d.focusNode;
          d = d.focusOffset;
          try {
            c.nodeType, f.nodeType;
          } catch (F) {
            c = null;
            break a;
          }
          var g = 0, h = -1, k = -1, l = 0, m = 0, q = a, r = null;
          b: for (; ; ) {
            for (var y; ; ) {
              q !== c || 0 !== e && 3 !== q.nodeType || (h = g + e);
              q !== f || 0 !== d && 3 !== q.nodeType || (k = g + d);
              3 === q.nodeType && (g += q.nodeValue.length);
              if (null === (y = q.firstChild)) break;
              r = q;
              q = y;
            }
            for (; ; ) {
              if (q === a) break b;
              r === c && ++l === e && (h = g);
              r === f && ++m === d && (k = g);
              if (null !== (y = q.nextSibling)) break;
              q = r;
              r = q.parentNode;
            }
            q = y;
          }
          c = -1 === h || -1 === k ? null : { start: h, end: k };
        } else c = null;
      }
      c = c || { start: 0, end: 0 };
    } else c = null;
    Df = { focusedElem: a, selectionRange: c };
    dd = false;
    for (V = b; null !== V; ) if (b = V, a = b.child, 0 !== (b.subtreeFlags & 1028) && null !== a) a.return = b, V = a;
    else for (; null !== V; ) {
      b = V;
      try {
        var n = b.alternate;
        if (0 !== (b.flags & 1024)) switch (b.tag) {
          case 0:
          case 11:
          case 15:
            break;
          case 1:
            if (null !== n) {
              var t2 = n.memoizedProps, J = n.memoizedState, x = b.stateNode, w = x.getSnapshotBeforeUpdate(b.elementType === b.type ? t2 : Ci(b.type, t2), J);
              x.__reactInternalSnapshotBeforeUpdate = w;
            }
            break;
          case 3:
            var u = b.stateNode.containerInfo;
            1 === u.nodeType ? u.textContent = "" : 9 === u.nodeType && u.documentElement && u.removeChild(u.documentElement);
            break;
          case 5:
          case 6:
          case 4:
          case 17:
            break;
          default:
            throw Error(p(163));
        }
      } catch (F) {
        W(b, b.return, F);
      }
      a = b.sibling;
      if (null !== a) {
        a.return = b.return;
        V = a;
        break;
      }
      V = b.return;
    }
    n = Nj;
    Nj = false;
    return n;
  }
  function Pj(a, b, c) {
    var d = b.updateQueue;
    d = null !== d ? d.lastEffect : null;
    if (null !== d) {
      var e = d = d.next;
      do {
        if ((e.tag & a) === a) {
          var f = e.destroy;
          e.destroy = void 0;
          void 0 !== f && Mj(b, c, f);
        }
        e = e.next;
      } while (e !== d);
    }
  }
  function Qj(a, b) {
    b = b.updateQueue;
    b = null !== b ? b.lastEffect : null;
    if (null !== b) {
      var c = b = b.next;
      do {
        if ((c.tag & a) === a) {
          var d = c.create;
          c.destroy = d();
        }
        c = c.next;
      } while (c !== b);
    }
  }
  function Rj(a) {
    var b = a.ref;
    if (null !== b) {
      var c = a.stateNode;
      switch (a.tag) {
        case 5:
          a = c;
          break;
        default:
          a = c;
      }
      "function" === typeof b ? b(a) : b.current = a;
    }
  }
  function Sj(a) {
    var b = a.alternate;
    null !== b && (a.alternate = null, Sj(b));
    a.child = null;
    a.deletions = null;
    a.sibling = null;
    5 === a.tag && (b = a.stateNode, null !== b && (delete b[Of], delete b[Pf], delete b[of], delete b[Qf], delete b[Rf]));
    a.stateNode = null;
    a.return = null;
    a.dependencies = null;
    a.memoizedProps = null;
    a.memoizedState = null;
    a.pendingProps = null;
    a.stateNode = null;
    a.updateQueue = null;
  }
  function Tj(a) {
    return 5 === a.tag || 3 === a.tag || 4 === a.tag;
  }
  function Uj(a) {
    a: for (; ; ) {
      for (; null === a.sibling; ) {
        if (null === a.return || Tj(a.return)) return null;
        a = a.return;
      }
      a.sibling.return = a.return;
      for (a = a.sibling; 5 !== a.tag && 6 !== a.tag && 18 !== a.tag; ) {
        if (a.flags & 2) continue a;
        if (null === a.child || 4 === a.tag) continue a;
        else a.child.return = a, a = a.child;
      }
      if (!(a.flags & 2)) return a.stateNode;
    }
  }
  function Vj(a, b, c) {
    var d = a.tag;
    if (5 === d || 6 === d) a = a.stateNode, b ? 8 === c.nodeType ? c.parentNode.insertBefore(a, b) : c.insertBefore(a, b) : (8 === c.nodeType ? (b = c.parentNode, b.insertBefore(a, c)) : (b = c, b.appendChild(a)), c = c._reactRootContainer, null !== c && void 0 !== c || null !== b.onclick || (b.onclick = Bf));
    else if (4 !== d && (a = a.child, null !== a)) for (Vj(a, b, c), a = a.sibling; null !== a; ) Vj(a, b, c), a = a.sibling;
  }
  function Wj(a, b, c) {
    var d = a.tag;
    if (5 === d || 6 === d) a = a.stateNode, b ? c.insertBefore(a, b) : c.appendChild(a);
    else if (4 !== d && (a = a.child, null !== a)) for (Wj(a, b, c), a = a.sibling; null !== a; ) Wj(a, b, c), a = a.sibling;
  }
  var X = null, Xj = false;
  function Yj(a, b, c) {
    for (c = c.child; null !== c; ) Zj(a, b, c), c = c.sibling;
  }
  function Zj(a, b, c) {
    if (lc && "function" === typeof lc.onCommitFiberUnmount) try {
      lc.onCommitFiberUnmount(kc, c);
    } catch (h) {
    }
    switch (c.tag) {
      case 5:
        U || Lj(c, b);
      case 6:
        var d = X, e = Xj;
        X = null;
        Yj(a, b, c);
        X = d;
        Xj = e;
        null !== X && (Xj ? (a = X, c = c.stateNode, 8 === a.nodeType ? a.parentNode.removeChild(c) : a.removeChild(c)) : X.removeChild(c.stateNode));
        break;
      case 18:
        null !== X && (Xj ? (a = X, c = c.stateNode, 8 === a.nodeType ? Kf(a.parentNode, c) : 1 === a.nodeType && Kf(a, c), bd(a)) : Kf(X, c.stateNode));
        break;
      case 4:
        d = X;
        e = Xj;
        X = c.stateNode.containerInfo;
        Xj = true;
        Yj(a, b, c);
        X = d;
        Xj = e;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (!U && (d = c.updateQueue, null !== d && (d = d.lastEffect, null !== d))) {
          e = d = d.next;
          do {
            var f = e, g = f.destroy;
            f = f.tag;
            void 0 !== g && (0 !== (f & 2) ? Mj(c, b, g) : 0 !== (f & 4) && Mj(c, b, g));
            e = e.next;
          } while (e !== d);
        }
        Yj(a, b, c);
        break;
      case 1:
        if (!U && (Lj(c, b), d = c.stateNode, "function" === typeof d.componentWillUnmount)) try {
          d.props = c.memoizedProps, d.state = c.memoizedState, d.componentWillUnmount();
        } catch (h) {
          W(c, b, h);
        }
        Yj(a, b, c);
        break;
      case 21:
        Yj(a, b, c);
        break;
      case 22:
        c.mode & 1 ? (U = (d = U) || null !== c.memoizedState, Yj(a, b, c), U = d) : Yj(a, b, c);
        break;
      default:
        Yj(a, b, c);
    }
  }
  function ak(a) {
    var b = a.updateQueue;
    if (null !== b) {
      a.updateQueue = null;
      var c = a.stateNode;
      null === c && (c = a.stateNode = new Kj());
      b.forEach(function(b2) {
        var d = bk.bind(null, a, b2);
        c.has(b2) || (c.add(b2), b2.then(d, d));
      });
    }
  }
  function ck(a, b) {
    var c = b.deletions;
    if (null !== c) for (var d = 0; d < c.length; d++) {
      var e = c[d];
      try {
        var f = a, g = b, h = g;
        a: for (; null !== h; ) {
          switch (h.tag) {
            case 5:
              X = h.stateNode;
              Xj = false;
              break a;
            case 3:
              X = h.stateNode.containerInfo;
              Xj = true;
              break a;
            case 4:
              X = h.stateNode.containerInfo;
              Xj = true;
              break a;
          }
          h = h.return;
        }
        if (null === X) throw Error(p(160));
        Zj(f, g, e);
        X = null;
        Xj = false;
        var k = e.alternate;
        null !== k && (k.return = null);
        e.return = null;
      } catch (l) {
        W(e, b, l);
      }
    }
    if (b.subtreeFlags & 12854) for (b = b.child; null !== b; ) dk(b, a), b = b.sibling;
  }
  function dk(a, b) {
    var c = a.alternate, d = a.flags;
    switch (a.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        ck(b, a);
        ek(a);
        if (d & 4) {
          try {
            Pj(3, a, a.return), Qj(3, a);
          } catch (t2) {
            W(a, a.return, t2);
          }
          try {
            Pj(5, a, a.return);
          } catch (t2) {
            W(a, a.return, t2);
          }
        }
        break;
      case 1:
        ck(b, a);
        ek(a);
        d & 512 && null !== c && Lj(c, c.return);
        break;
      case 5:
        ck(b, a);
        ek(a);
        d & 512 && null !== c && Lj(c, c.return);
        if (a.flags & 32) {
          var e = a.stateNode;
          try {
            ob(e, "");
          } catch (t2) {
            W(a, a.return, t2);
          }
        }
        if (d & 4 && (e = a.stateNode, null != e)) {
          var f = a.memoizedProps, g = null !== c ? c.memoizedProps : f, h = a.type, k = a.updateQueue;
          a.updateQueue = null;
          if (null !== k) try {
            "input" === h && "radio" === f.type && null != f.name && ab(e, f);
            vb(h, g);
            var l = vb(h, f);
            for (g = 0; g < k.length; g += 2) {
              var m = k[g], q = k[g + 1];
              "style" === m ? sb(e, q) : "dangerouslySetInnerHTML" === m ? nb(e, q) : "children" === m ? ob(e, q) : ta(e, m, q, l);
            }
            switch (h) {
              case "input":
                bb(e, f);
                break;
              case "textarea":
                ib(e, f);
                break;
              case "select":
                var r = e._wrapperState.wasMultiple;
                e._wrapperState.wasMultiple = !!f.multiple;
                var y = f.value;
                null != y ? fb(e, !!f.multiple, y, false) : r !== !!f.multiple && (null != f.defaultValue ? fb(
                  e,
                  !!f.multiple,
                  f.defaultValue,
                  true
                ) : fb(e, !!f.multiple, f.multiple ? [] : "", false));
            }
            e[Pf] = f;
          } catch (t2) {
            W(a, a.return, t2);
          }
        }
        break;
      case 6:
        ck(b, a);
        ek(a);
        if (d & 4) {
          if (null === a.stateNode) throw Error(p(162));
          e = a.stateNode;
          f = a.memoizedProps;
          try {
            e.nodeValue = f;
          } catch (t2) {
            W(a, a.return, t2);
          }
        }
        break;
      case 3:
        ck(b, a);
        ek(a);
        if (d & 4 && null !== c && c.memoizedState.isDehydrated) try {
          bd(b.containerInfo);
        } catch (t2) {
          W(a, a.return, t2);
        }
        break;
      case 4:
        ck(b, a);
        ek(a);
        break;
      case 13:
        ck(b, a);
        ek(a);
        e = a.child;
        e.flags & 8192 && (f = null !== e.memoizedState, e.stateNode.isHidden = f, !f || null !== e.alternate && null !== e.alternate.memoizedState || (fk = B()));
        d & 4 && ak(a);
        break;
      case 22:
        m = null !== c && null !== c.memoizedState;
        a.mode & 1 ? (U = (l = U) || m, ck(b, a), U = l) : ck(b, a);
        ek(a);
        if (d & 8192) {
          l = null !== a.memoizedState;
          if ((a.stateNode.isHidden = l) && !m && 0 !== (a.mode & 1)) for (V = a, m = a.child; null !== m; ) {
            for (q = V = m; null !== V; ) {
              r = V;
              y = r.child;
              switch (r.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                  Pj(4, r, r.return);
                  break;
                case 1:
                  Lj(r, r.return);
                  var n = r.stateNode;
                  if ("function" === typeof n.componentWillUnmount) {
                    d = r;
                    c = r.return;
                    try {
                      b = d, n.props = b.memoizedProps, n.state = b.memoizedState, n.componentWillUnmount();
                    } catch (t2) {
                      W(d, c, t2);
                    }
                  }
                  break;
                case 5:
                  Lj(r, r.return);
                  break;
                case 22:
                  if (null !== r.memoizedState) {
                    gk(q);
                    continue;
                  }
              }
              null !== y ? (y.return = r, V = y) : gk(q);
            }
            m = m.sibling;
          }
          a: for (m = null, q = a; ; ) {
            if (5 === q.tag) {
              if (null === m) {
                m = q;
                try {
                  e = q.stateNode, l ? (f = e.style, "function" === typeof f.setProperty ? f.setProperty("display", "none", "important") : f.display = "none") : (h = q.stateNode, k = q.memoizedProps.style, g = void 0 !== k && null !== k && k.hasOwnProperty("display") ? k.display : null, h.style.display = rb("display", g));
                } catch (t2) {
                  W(a, a.return, t2);
                }
              }
            } else if (6 === q.tag) {
              if (null === m) try {
                q.stateNode.nodeValue = l ? "" : q.memoizedProps;
              } catch (t2) {
                W(a, a.return, t2);
              }
            } else if ((22 !== q.tag && 23 !== q.tag || null === q.memoizedState || q === a) && null !== q.child) {
              q.child.return = q;
              q = q.child;
              continue;
            }
            if (q === a) break a;
            for (; null === q.sibling; ) {
              if (null === q.return || q.return === a) break a;
              m === q && (m = null);
              q = q.return;
            }
            m === q && (m = null);
            q.sibling.return = q.return;
            q = q.sibling;
          }
        }
        break;
      case 19:
        ck(b, a);
        ek(a);
        d & 4 && ak(a);
        break;
      case 21:
        break;
      default:
        ck(
          b,
          a
        ), ek(a);
    }
  }
  function ek(a) {
    var b = a.flags;
    if (b & 2) {
      try {
        a: {
          for (var c = a.return; null !== c; ) {
            if (Tj(c)) {
              var d = c;
              break a;
            }
            c = c.return;
          }
          throw Error(p(160));
        }
        switch (d.tag) {
          case 5:
            var e = d.stateNode;
            d.flags & 32 && (ob(e, ""), d.flags &= -33);
            var f = Uj(a);
            Wj(a, f, e);
            break;
          case 3:
          case 4:
            var g = d.stateNode.containerInfo, h = Uj(a);
            Vj(a, h, g);
            break;
          default:
            throw Error(p(161));
        }
      } catch (k) {
        W(a, a.return, k);
      }
      a.flags &= -3;
    }
    b & 4096 && (a.flags &= -4097);
  }
  function hk(a, b, c) {
    V = a;
    ik(a);
  }
  function ik(a, b, c) {
    for (var d = 0 !== (a.mode & 1); null !== V; ) {
      var e = V, f = e.child;
      if (22 === e.tag && d) {
        var g = null !== e.memoizedState || Jj;
        if (!g) {
          var h = e.alternate, k = null !== h && null !== h.memoizedState || U;
          h = Jj;
          var l = U;
          Jj = g;
          if ((U = k) && !l) for (V = e; null !== V; ) g = V, k = g.child, 22 === g.tag && null !== g.memoizedState ? jk(e) : null !== k ? (k.return = g, V = k) : jk(e);
          for (; null !== f; ) V = f, ik(f), f = f.sibling;
          V = e;
          Jj = h;
          U = l;
        }
        kk(a);
      } else 0 !== (e.subtreeFlags & 8772) && null !== f ? (f.return = e, V = f) : kk(a);
    }
  }
  function kk(a) {
    for (; null !== V; ) {
      var b = V;
      if (0 !== (b.flags & 8772)) {
        var c = b.alternate;
        try {
          if (0 !== (b.flags & 8772)) switch (b.tag) {
            case 0:
            case 11:
            case 15:
              U || Qj(5, b);
              break;
            case 1:
              var d = b.stateNode;
              if (b.flags & 4 && !U) if (null === c) d.componentDidMount();
              else {
                var e = b.elementType === b.type ? c.memoizedProps : Ci(b.type, c.memoizedProps);
                d.componentDidUpdate(e, c.memoizedState, d.__reactInternalSnapshotBeforeUpdate);
              }
              var f = b.updateQueue;
              null !== f && sh(b, f, d);
              break;
            case 3:
              var g = b.updateQueue;
              if (null !== g) {
                c = null;
                if (null !== b.child) switch (b.child.tag) {
                  case 5:
                    c = b.child.stateNode;
                    break;
                  case 1:
                    c = b.child.stateNode;
                }
                sh(b, g, c);
              }
              break;
            case 5:
              var h = b.stateNode;
              if (null === c && b.flags & 4) {
                c = h;
                var k = b.memoizedProps;
                switch (b.type) {
                  case "button":
                  case "input":
                  case "select":
                  case "textarea":
                    k.autoFocus && c.focus();
                    break;
                  case "img":
                    k.src && (c.src = k.src);
                }
              }
              break;
            case 6:
              break;
            case 4:
              break;
            case 12:
              break;
            case 13:
              if (null === b.memoizedState) {
                var l = b.alternate;
                if (null !== l) {
                  var m = l.memoizedState;
                  if (null !== m) {
                    var q = m.dehydrated;
                    null !== q && bd(q);
                  }
                }
              }
              break;
            case 19:
            case 17:
            case 21:
            case 22:
            case 23:
            case 25:
              break;
            default:
              throw Error(p(163));
          }
          U || b.flags & 512 && Rj(b);
        } catch (r) {
          W(b, b.return, r);
        }
      }
      if (b === a) {
        V = null;
        break;
      }
      c = b.sibling;
      if (null !== c) {
        c.return = b.return;
        V = c;
        break;
      }
      V = b.return;
    }
  }
  function gk(a) {
    for (; null !== V; ) {
      var b = V;
      if (b === a) {
        V = null;
        break;
      }
      var c = b.sibling;
      if (null !== c) {
        c.return = b.return;
        V = c;
        break;
      }
      V = b.return;
    }
  }
  function jk(a) {
    for (; null !== V; ) {
      var b = V;
      try {
        switch (b.tag) {
          case 0:
          case 11:
          case 15:
            var c = b.return;
            try {
              Qj(4, b);
            } catch (k) {
              W(b, c, k);
            }
            break;
          case 1:
            var d = b.stateNode;
            if ("function" === typeof d.componentDidMount) {
              var e = b.return;
              try {
                d.componentDidMount();
              } catch (k) {
                W(b, e, k);
              }
            }
            var f = b.return;
            try {
              Rj(b);
            } catch (k) {
              W(b, f, k);
            }
            break;
          case 5:
            var g = b.return;
            try {
              Rj(b);
            } catch (k) {
              W(b, g, k);
            }
        }
      } catch (k) {
        W(b, b.return, k);
      }
      if (b === a) {
        V = null;
        break;
      }
      var h = b.sibling;
      if (null !== h) {
        h.return = b.return;
        V = h;
        break;
      }
      V = b.return;
    }
  }
  var lk = Math.ceil, mk = ua.ReactCurrentDispatcher, nk = ua.ReactCurrentOwner, ok = ua.ReactCurrentBatchConfig, K = 0, Q = null, Y = null, Z = 0, fj = 0, ej = Uf(0), T = 0, pk = null, rh = 0, qk = 0, rk = 0, sk = null, tk = null, fk = 0, Gj = Infinity, uk = null, Oi = false, Pi = null, Ri = null, vk = false, wk = null, xk = 0, yk = 0, zk = null, Ak = -1, Bk = 0;
  function R() {
    return 0 !== (K & 6) ? B() : -1 !== Ak ? Ak : Ak = B();
  }
  function yi(a) {
    if (0 === (a.mode & 1)) return 1;
    if (0 !== (K & 2) && 0 !== Z) return Z & -Z;
    if (null !== Kg.transition) return 0 === Bk && (Bk = yc()), Bk;
    a = C;
    if (0 !== a) return a;
    a = window.event;
    a = void 0 === a ? 16 : jd(a.type);
    return a;
  }
  function gi(a, b, c, d) {
    if (50 < yk) throw yk = 0, zk = null, Error(p(185));
    Ac(a, c, d);
    if (0 === (K & 2) || a !== Q) a === Q && (0 === (K & 2) && (qk |= c), 4 === T && Ck(a, Z)), Dk(a, d), 1 === c && 0 === K && 0 === (b.mode & 1) && (Gj = B() + 500, fg && jg());
  }
  function Dk(a, b) {
    var c = a.callbackNode;
    wc(a, b);
    var d = uc(a, a === Q ? Z : 0);
    if (0 === d) null !== c && bc(c), a.callbackNode = null, a.callbackPriority = 0;
    else if (b = d & -d, a.callbackPriority !== b) {
      null != c && bc(c);
      if (1 === b) 0 === a.tag ? ig(Ek.bind(null, a)) : hg(Ek.bind(null, a)), Jf(function() {
        0 === (K & 6) && jg();
      }), c = null;
      else {
        switch (Dc(d)) {
          case 1:
            c = fc;
            break;
          case 4:
            c = gc;
            break;
          case 16:
            c = hc;
            break;
          case 536870912:
            c = jc;
            break;
          default:
            c = hc;
        }
        c = Fk(c, Gk.bind(null, a));
      }
      a.callbackPriority = b;
      a.callbackNode = c;
    }
  }
  function Gk(a, b) {
    Ak = -1;
    Bk = 0;
    if (0 !== (K & 6)) throw Error(p(327));
    var c = a.callbackNode;
    if (Hk() && a.callbackNode !== c) return null;
    var d = uc(a, a === Q ? Z : 0);
    if (0 === d) return null;
    if (0 !== (d & 30) || 0 !== (d & a.expiredLanes) || b) b = Ik(a, d);
    else {
      b = d;
      var e = K;
      K |= 2;
      var f = Jk();
      if (Q !== a || Z !== b) uk = null, Gj = B() + 500, Kk(a, b);
      do
        try {
          Lk();
          break;
        } catch (h) {
          Mk(a, h);
        }
      while (1);
      $g();
      mk.current = f;
      K = e;
      null !== Y ? b = 0 : (Q = null, Z = 0, b = T);
    }
    if (0 !== b) {
      2 === b && (e = xc(a), 0 !== e && (d = e, b = Nk(a, e)));
      if (1 === b) throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B()), c;
      if (6 === b) Ck(a, d);
      else {
        e = a.current.alternate;
        if (0 === (d & 30) && !Ok(e) && (b = Ik(a, d), 2 === b && (f = xc(a), 0 !== f && (d = f, b = Nk(a, f))), 1 === b)) throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B()), c;
        a.finishedWork = e;
        a.finishedLanes = d;
        switch (b) {
          case 0:
          case 1:
            throw Error(p(345));
          case 2:
            Pk(a, tk, uk);
            break;
          case 3:
            Ck(a, d);
            if ((d & 130023424) === d && (b = fk + 500 - B(), 10 < b)) {
              if (0 !== uc(a, 0)) break;
              e = a.suspendedLanes;
              if ((e & d) !== d) {
                R();
                a.pingedLanes |= a.suspendedLanes & e;
                break;
              }
              a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), b);
              break;
            }
            Pk(a, tk, uk);
            break;
          case 4:
            Ck(a, d);
            if ((d & 4194240) === d) break;
            b = a.eventTimes;
            for (e = -1; 0 < d; ) {
              var g = 31 - oc(d);
              f = 1 << g;
              g = b[g];
              g > e && (e = g);
              d &= ~f;
            }
            d = e;
            d = B() - d;
            d = (120 > d ? 120 : 480 > d ? 480 : 1080 > d ? 1080 : 1920 > d ? 1920 : 3e3 > d ? 3e3 : 4320 > d ? 4320 : 1960 * lk(d / 1960)) - d;
            if (10 < d) {
              a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), d);
              break;
            }
            Pk(a, tk, uk);
            break;
          case 5:
            Pk(a, tk, uk);
            break;
          default:
            throw Error(p(329));
        }
      }
    }
    Dk(a, B());
    return a.callbackNode === c ? Gk.bind(null, a) : null;
  }
  function Nk(a, b) {
    var c = sk;
    a.current.memoizedState.isDehydrated && (Kk(a, b).flags |= 256);
    a = Ik(a, b);
    2 !== a && (b = tk, tk = c, null !== b && Fj(b));
    return a;
  }
  function Fj(a) {
    null === tk ? tk = a : tk.push.apply(tk, a);
  }
  function Ok(a) {
    for (var b = a; ; ) {
      if (b.flags & 16384) {
        var c = b.updateQueue;
        if (null !== c && (c = c.stores, null !== c)) for (var d = 0; d < c.length; d++) {
          var e = c[d], f = e.getSnapshot;
          e = e.value;
          try {
            if (!He(f(), e)) return false;
          } catch (g) {
            return false;
          }
        }
      }
      c = b.child;
      if (b.subtreeFlags & 16384 && null !== c) c.return = b, b = c;
      else {
        if (b === a) break;
        for (; null === b.sibling; ) {
          if (null === b.return || b.return === a) return true;
          b = b.return;
        }
        b.sibling.return = b.return;
        b = b.sibling;
      }
    }
    return true;
  }
  function Ck(a, b) {
    b &= ~rk;
    b &= ~qk;
    a.suspendedLanes |= b;
    a.pingedLanes &= ~b;
    for (a = a.expirationTimes; 0 < b; ) {
      var c = 31 - oc(b), d = 1 << c;
      a[c] = -1;
      b &= ~d;
    }
  }
  function Ek(a) {
    if (0 !== (K & 6)) throw Error(p(327));
    Hk();
    var b = uc(a, 0);
    if (0 === (b & 1)) return Dk(a, B()), null;
    var c = Ik(a, b);
    if (0 !== a.tag && 2 === c) {
      var d = xc(a);
      0 !== d && (b = d, c = Nk(a, d));
    }
    if (1 === c) throw c = pk, Kk(a, 0), Ck(a, b), Dk(a, B()), c;
    if (6 === c) throw Error(p(345));
    a.finishedWork = a.current.alternate;
    a.finishedLanes = b;
    Pk(a, tk, uk);
    Dk(a, B());
    return null;
  }
  function Qk(a, b) {
    var c = K;
    K |= 1;
    try {
      return a(b);
    } finally {
      K = c, 0 === K && (Gj = B() + 500, fg && jg());
    }
  }
  function Rk(a) {
    null !== wk && 0 === wk.tag && 0 === (K & 6) && Hk();
    var b = K;
    K |= 1;
    var c = ok.transition, d = C;
    try {
      if (ok.transition = null, C = 1, a) return a();
    } finally {
      C = d, ok.transition = c, K = b, 0 === (K & 6) && jg();
    }
  }
  function Hj() {
    fj = ej.current;
    E(ej);
  }
  function Kk(a, b) {
    a.finishedWork = null;
    a.finishedLanes = 0;
    var c = a.timeoutHandle;
    -1 !== c && (a.timeoutHandle = -1, Gf(c));
    if (null !== Y) for (c = Y.return; null !== c; ) {
      var d = c;
      wg(d);
      switch (d.tag) {
        case 1:
          d = d.type.childContextTypes;
          null !== d && void 0 !== d && $f();
          break;
        case 3:
          zh();
          E(Wf);
          E(H);
          Eh();
          break;
        case 5:
          Bh(d);
          break;
        case 4:
          zh();
          break;
        case 13:
          E(L);
          break;
        case 19:
          E(L);
          break;
        case 10:
          ah(d.type._context);
          break;
        case 22:
        case 23:
          Hj();
      }
      c = c.return;
    }
    Q = a;
    Y = a = Pg(a.current, null);
    Z = fj = b;
    T = 0;
    pk = null;
    rk = qk = rh = 0;
    tk = sk = null;
    if (null !== fh) {
      for (b = 0; b < fh.length; b++) if (c = fh[b], d = c.interleaved, null !== d) {
        c.interleaved = null;
        var e = d.next, f = c.pending;
        if (null !== f) {
          var g = f.next;
          f.next = e;
          d.next = g;
        }
        c.pending = d;
      }
      fh = null;
    }
    return a;
  }
  function Mk(a, b) {
    do {
      var c = Y;
      try {
        $g();
        Fh.current = Rh;
        if (Ih) {
          for (var d = M.memoizedState; null !== d; ) {
            var e = d.queue;
            null !== e && (e.pending = null);
            d = d.next;
          }
          Ih = false;
        }
        Hh = 0;
        O = N = M = null;
        Jh = false;
        Kh = 0;
        nk.current = null;
        if (null === c || null === c.return) {
          T = 1;
          pk = b;
          Y = null;
          break;
        }
        a: {
          var f = a, g = c.return, h = c, k = b;
          b = Z;
          h.flags |= 32768;
          if (null !== k && "object" === typeof k && "function" === typeof k.then) {
            var l = k, m = h, q = m.tag;
            if (0 === (m.mode & 1) && (0 === q || 11 === q || 15 === q)) {
              var r = m.alternate;
              r ? (m.updateQueue = r.updateQueue, m.memoizedState = r.memoizedState, m.lanes = r.lanes) : (m.updateQueue = null, m.memoizedState = null);
            }
            var y = Ui(g);
            if (null !== y) {
              y.flags &= -257;
              Vi(y, g, h, f, b);
              y.mode & 1 && Si(f, l, b);
              b = y;
              k = l;
              var n = b.updateQueue;
              if (null === n) {
                var t2 = /* @__PURE__ */ new Set();
                t2.add(k);
                b.updateQueue = t2;
              } else n.add(k);
              break a;
            } else {
              if (0 === (b & 1)) {
                Si(f, l, b);
                tj();
                break a;
              }
              k = Error(p(426));
            }
          } else if (I && h.mode & 1) {
            var J = Ui(g);
            if (null !== J) {
              0 === (J.flags & 65536) && (J.flags |= 256);
              Vi(J, g, h, f, b);
              Jg(Ji(k, h));
              break a;
            }
          }
          f = k = Ji(k, h);
          4 !== T && (T = 2);
          null === sk ? sk = [f] : sk.push(f);
          f = g;
          do {
            switch (f.tag) {
              case 3:
                f.flags |= 65536;
                b &= -b;
                f.lanes |= b;
                var x = Ni(f, k, b);
                ph(f, x);
                break a;
              case 1:
                h = k;
                var w = f.type, u = f.stateNode;
                if (0 === (f.flags & 128) && ("function" === typeof w.getDerivedStateFromError || null !== u && "function" === typeof u.componentDidCatch && (null === Ri || !Ri.has(u)))) {
                  f.flags |= 65536;
                  b &= -b;
                  f.lanes |= b;
                  var F = Qi(f, h, b);
                  ph(f, F);
                  break a;
                }
            }
            f = f.return;
          } while (null !== f);
        }
        Sk(c);
      } catch (na) {
        b = na;
        Y === c && null !== c && (Y = c = c.return);
        continue;
      }
      break;
    } while (1);
  }
  function Jk() {
    var a = mk.current;
    mk.current = Rh;
    return null === a ? Rh : a;
  }
  function tj() {
    if (0 === T || 3 === T || 2 === T) T = 4;
    null === Q || 0 === (rh & 268435455) && 0 === (qk & 268435455) || Ck(Q, Z);
  }
  function Ik(a, b) {
    var c = K;
    K |= 2;
    var d = Jk();
    if (Q !== a || Z !== b) uk = null, Kk(a, b);
    do
      try {
        Tk();
        break;
      } catch (e) {
        Mk(a, e);
      }
    while (1);
    $g();
    K = c;
    mk.current = d;
    if (null !== Y) throw Error(p(261));
    Q = null;
    Z = 0;
    return T;
  }
  function Tk() {
    for (; null !== Y; ) Uk(Y);
  }
  function Lk() {
    for (; null !== Y && !cc(); ) Uk(Y);
  }
  function Uk(a) {
    var b = Vk(a.alternate, a, fj);
    a.memoizedProps = a.pendingProps;
    null === b ? Sk(a) : Y = b;
    nk.current = null;
  }
  function Sk(a) {
    var b = a;
    do {
      var c = b.alternate;
      a = b.return;
      if (0 === (b.flags & 32768)) {
        if (c = Ej(c, b, fj), null !== c) {
          Y = c;
          return;
        }
      } else {
        c = Ij(c, b);
        if (null !== c) {
          c.flags &= 32767;
          Y = c;
          return;
        }
        if (null !== a) a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null;
        else {
          T = 6;
          Y = null;
          return;
        }
      }
      b = b.sibling;
      if (null !== b) {
        Y = b;
        return;
      }
      Y = b = a;
    } while (null !== b);
    0 === T && (T = 5);
  }
  function Pk(a, b, c) {
    var d = C, e = ok.transition;
    try {
      ok.transition = null, C = 1, Wk(a, b, c, d);
    } finally {
      ok.transition = e, C = d;
    }
    return null;
  }
  function Wk(a, b, c, d) {
    do
      Hk();
    while (null !== wk);
    if (0 !== (K & 6)) throw Error(p(327));
    c = a.finishedWork;
    var e = a.finishedLanes;
    if (null === c) return null;
    a.finishedWork = null;
    a.finishedLanes = 0;
    if (c === a.current) throw Error(p(177));
    a.callbackNode = null;
    a.callbackPriority = 0;
    var f = c.lanes | c.childLanes;
    Bc(a, f);
    a === Q && (Y = Q = null, Z = 0);
    0 === (c.subtreeFlags & 2064) && 0 === (c.flags & 2064) || vk || (vk = true, Fk(hc, function() {
      Hk();
      return null;
    }));
    f = 0 !== (c.flags & 15990);
    if (0 !== (c.subtreeFlags & 15990) || f) {
      f = ok.transition;
      ok.transition = null;
      var g = C;
      C = 1;
      var h = K;
      K |= 4;
      nk.current = null;
      Oj(a, c);
      dk(c, a);
      Oe(Df);
      dd = !!Cf;
      Df = Cf = null;
      a.current = c;
      hk(c);
      dc();
      K = h;
      C = g;
      ok.transition = f;
    } else a.current = c;
    vk && (vk = false, wk = a, xk = e);
    f = a.pendingLanes;
    0 === f && (Ri = null);
    mc(c.stateNode);
    Dk(a, B());
    if (null !== b) for (d = a.onRecoverableError, c = 0; c < b.length; c++) e = b[c], d(e.value, { componentStack: e.stack, digest: e.digest });
    if (Oi) throw Oi = false, a = Pi, Pi = null, a;
    0 !== (xk & 1) && 0 !== a.tag && Hk();
    f = a.pendingLanes;
    0 !== (f & 1) ? a === zk ? yk++ : (yk = 0, zk = a) : yk = 0;
    jg();
    return null;
  }
  function Hk() {
    if (null !== wk) {
      var a = Dc(xk), b = ok.transition, c = C;
      try {
        ok.transition = null;
        C = 16 > a ? 16 : a;
        if (null === wk) var d = false;
        else {
          a = wk;
          wk = null;
          xk = 0;
          if (0 !== (K & 6)) throw Error(p(331));
          var e = K;
          K |= 4;
          for (V = a.current; null !== V; ) {
            var f = V, g = f.child;
            if (0 !== (V.flags & 16)) {
              var h = f.deletions;
              if (null !== h) {
                for (var k = 0; k < h.length; k++) {
                  var l = h[k];
                  for (V = l; null !== V; ) {
                    var m = V;
                    switch (m.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Pj(8, m, f);
                    }
                    var q = m.child;
                    if (null !== q) q.return = m, V = q;
                    else for (; null !== V; ) {
                      m = V;
                      var r = m.sibling, y = m.return;
                      Sj(m);
                      if (m === l) {
                        V = null;
                        break;
                      }
                      if (null !== r) {
                        r.return = y;
                        V = r;
                        break;
                      }
                      V = y;
                    }
                  }
                }
                var n = f.alternate;
                if (null !== n) {
                  var t2 = n.child;
                  if (null !== t2) {
                    n.child = null;
                    do {
                      var J = t2.sibling;
                      t2.sibling = null;
                      t2 = J;
                    } while (null !== t2);
                  }
                }
                V = f;
              }
            }
            if (0 !== (f.subtreeFlags & 2064) && null !== g) g.return = f, V = g;
            else b: for (; null !== V; ) {
              f = V;
              if (0 !== (f.flags & 2048)) switch (f.tag) {
                case 0:
                case 11:
                case 15:
                  Pj(9, f, f.return);
              }
              var x = f.sibling;
              if (null !== x) {
                x.return = f.return;
                V = x;
                break b;
              }
              V = f.return;
            }
          }
          var w = a.current;
          for (V = w; null !== V; ) {
            g = V;
            var u = g.child;
            if (0 !== (g.subtreeFlags & 2064) && null !== u) u.return = g, V = u;
            else b: for (g = w; null !== V; ) {
              h = V;
              if (0 !== (h.flags & 2048)) try {
                switch (h.tag) {
                  case 0:
                  case 11:
                  case 15:
                    Qj(9, h);
                }
              } catch (na) {
                W(h, h.return, na);
              }
              if (h === g) {
                V = null;
                break b;
              }
              var F = h.sibling;
              if (null !== F) {
                F.return = h.return;
                V = F;
                break b;
              }
              V = h.return;
            }
          }
          K = e;
          jg();
          if (lc && "function" === typeof lc.onPostCommitFiberRoot) try {
            lc.onPostCommitFiberRoot(kc, a);
          } catch (na) {
          }
          d = true;
        }
        return d;
      } finally {
        C = c, ok.transition = b;
      }
    }
    return false;
  }
  function Xk(a, b, c) {
    b = Ji(c, b);
    b = Ni(a, b, 1);
    a = nh(a, b, 1);
    b = R();
    null !== a && (Ac(a, 1, b), Dk(a, b));
  }
  function W(a, b, c) {
    if (3 === a.tag) Xk(a, a, c);
    else for (; null !== b; ) {
      if (3 === b.tag) {
        Xk(b, a, c);
        break;
      } else if (1 === b.tag) {
        var d = b.stateNode;
        if ("function" === typeof b.type.getDerivedStateFromError || "function" === typeof d.componentDidCatch && (null === Ri || !Ri.has(d))) {
          a = Ji(c, a);
          a = Qi(b, a, 1);
          b = nh(b, a, 1);
          a = R();
          null !== b && (Ac(b, 1, a), Dk(b, a));
          break;
        }
      }
      b = b.return;
    }
  }
  function Ti(a, b, c) {
    var d = a.pingCache;
    null !== d && d.delete(b);
    b = R();
    a.pingedLanes |= a.suspendedLanes & c;
    Q === a && (Z & c) === c && (4 === T || 3 === T && (Z & 130023424) === Z && 500 > B() - fk ? Kk(a, 0) : rk |= c);
    Dk(a, b);
  }
  function Yk(a, b) {
    0 === b && (0 === (a.mode & 1) ? b = 1 : (b = sc, sc <<= 1, 0 === (sc & 130023424) && (sc = 4194304)));
    var c = R();
    a = ih(a, b);
    null !== a && (Ac(a, b, c), Dk(a, c));
  }
  function uj(a) {
    var b = a.memoizedState, c = 0;
    null !== b && (c = b.retryLane);
    Yk(a, c);
  }
  function bk(a, b) {
    var c = 0;
    switch (a.tag) {
      case 13:
        var d = a.stateNode;
        var e = a.memoizedState;
        null !== e && (c = e.retryLane);
        break;
      case 19:
        d = a.stateNode;
        break;
      default:
        throw Error(p(314));
    }
    null !== d && d.delete(b);
    Yk(a, c);
  }
  var Vk;
  Vk = function(a, b, c) {
    if (null !== a) if (a.memoizedProps !== b.pendingProps || Wf.current) dh = true;
    else {
      if (0 === (a.lanes & c) && 0 === (b.flags & 128)) return dh = false, yj(a, b, c);
      dh = 0 !== (a.flags & 131072) ? true : false;
    }
    else dh = false, I && 0 !== (b.flags & 1048576) && ug(b, ng, b.index);
    b.lanes = 0;
    switch (b.tag) {
      case 2:
        var d = b.type;
        ij(a, b);
        a = b.pendingProps;
        var e = Yf(b, H.current);
        ch(b, c);
        e = Nh(null, b, d, a, e, c);
        var f = Sh();
        b.flags |= 1;
        "object" === typeof e && null !== e && "function" === typeof e.render && void 0 === e.$$typeof ? (b.tag = 1, b.memoizedState = null, b.updateQueue = null, Zf(d) ? (f = true, cg(b)) : f = false, b.memoizedState = null !== e.state && void 0 !== e.state ? e.state : null, kh(b), e.updater = Ei, b.stateNode = e, e._reactInternals = b, Ii(b, d, a, c), b = jj(null, b, d, true, f, c)) : (b.tag = 0, I && f && vg(b), Xi(null, b, e, c), b = b.child);
        return b;
      case 16:
        d = b.elementType;
        a: {
          ij(a, b);
          a = b.pendingProps;
          e = d._init;
          d = e(d._payload);
          b.type = d;
          e = b.tag = Zk(d);
          a = Ci(d, a);
          switch (e) {
            case 0:
              b = cj(null, b, d, a, c);
              break a;
            case 1:
              b = hj(null, b, d, a, c);
              break a;
            case 11:
              b = Yi(null, b, d, a, c);
              break a;
            case 14:
              b = $i(null, b, d, Ci(d.type, a), c);
              break a;
          }
          throw Error(p(
            306,
            d,
            ""
          ));
        }
        return b;
      case 0:
        return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), cj(a, b, d, e, c);
      case 1:
        return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), hj(a, b, d, e, c);
      case 3:
        a: {
          kj(b);
          if (null === a) throw Error(p(387));
          d = b.pendingProps;
          f = b.memoizedState;
          e = f.element;
          lh(a, b);
          qh(b, d, null, c);
          var g = b.memoizedState;
          d = g.element;
          if (f.isDehydrated) if (f = { element: d, isDehydrated: false, cache: g.cache, pendingSuspenseBoundaries: g.pendingSuspenseBoundaries, transitions: g.transitions }, b.updateQueue.baseState = f, b.memoizedState = f, b.flags & 256) {
            e = Ji(Error(p(423)), b);
            b = lj(a, b, d, c, e);
            break a;
          } else if (d !== e) {
            e = Ji(Error(p(424)), b);
            b = lj(a, b, d, c, e);
            break a;
          } else for (yg = Lf(b.stateNode.containerInfo.firstChild), xg = b, I = true, zg = null, c = Vg(b, null, d, c), b.child = c; c; ) c.flags = c.flags & -3 | 4096, c = c.sibling;
          else {
            Ig();
            if (d === e) {
              b = Zi(a, b, c);
              break a;
            }
            Xi(a, b, d, c);
          }
          b = b.child;
        }
        return b;
      case 5:
        return Ah(b), null === a && Eg(b), d = b.type, e = b.pendingProps, f = null !== a ? a.memoizedProps : null, g = e.children, Ef(d, e) ? g = null : null !== f && Ef(d, f) && (b.flags |= 32), gj(a, b), Xi(a, b, g, c), b.child;
      case 6:
        return null === a && Eg(b), null;
      case 13:
        return oj(a, b, c);
      case 4:
        return yh(b, b.stateNode.containerInfo), d = b.pendingProps, null === a ? b.child = Ug(b, null, d, c) : Xi(a, b, d, c), b.child;
      case 11:
        return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), Yi(a, b, d, e, c);
      case 7:
        return Xi(a, b, b.pendingProps, c), b.child;
      case 8:
        return Xi(a, b, b.pendingProps.children, c), b.child;
      case 12:
        return Xi(a, b, b.pendingProps.children, c), b.child;
      case 10:
        a: {
          d = b.type._context;
          e = b.pendingProps;
          f = b.memoizedProps;
          g = e.value;
          G(Wg, d._currentValue);
          d._currentValue = g;
          if (null !== f) if (He(f.value, g)) {
            if (f.children === e.children && !Wf.current) {
              b = Zi(a, b, c);
              break a;
            }
          } else for (f = b.child, null !== f && (f.return = b); null !== f; ) {
            var h = f.dependencies;
            if (null !== h) {
              g = f.child;
              for (var k = h.firstContext; null !== k; ) {
                if (k.context === d) {
                  if (1 === f.tag) {
                    k = mh(-1, c & -c);
                    k.tag = 2;
                    var l = f.updateQueue;
                    if (null !== l) {
                      l = l.shared;
                      var m = l.pending;
                      null === m ? k.next = k : (k.next = m.next, m.next = k);
                      l.pending = k;
                    }
                  }
                  f.lanes |= c;
                  k = f.alternate;
                  null !== k && (k.lanes |= c);
                  bh(
                    f.return,
                    c,
                    b
                  );
                  h.lanes |= c;
                  break;
                }
                k = k.next;
              }
            } else if (10 === f.tag) g = f.type === b.type ? null : f.child;
            else if (18 === f.tag) {
              g = f.return;
              if (null === g) throw Error(p(341));
              g.lanes |= c;
              h = g.alternate;
              null !== h && (h.lanes |= c);
              bh(g, c, b);
              g = f.sibling;
            } else g = f.child;
            if (null !== g) g.return = f;
            else for (g = f; null !== g; ) {
              if (g === b) {
                g = null;
                break;
              }
              f = g.sibling;
              if (null !== f) {
                f.return = g.return;
                g = f;
                break;
              }
              g = g.return;
            }
            f = g;
          }
          Xi(a, b, e.children, c);
          b = b.child;
        }
        return b;
      case 9:
        return e = b.type, d = b.pendingProps.children, ch(b, c), e = eh(e), d = d(e), b.flags |= 1, Xi(a, b, d, c), b.child;
      case 14:
        return d = b.type, e = Ci(d, b.pendingProps), e = Ci(d.type, e), $i(a, b, d, e, c);
      case 15:
        return bj(a, b, b.type, b.pendingProps, c);
      case 17:
        return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), ij(a, b), b.tag = 1, Zf(d) ? (a = true, cg(b)) : a = false, ch(b, c), Gi(b, d, e), Ii(b, d, e, c), jj(null, b, d, true, a, c);
      case 19:
        return xj(a, b, c);
      case 22:
        return dj(a, b, c);
    }
    throw Error(p(156, b.tag));
  };
  function Fk(a, b) {
    return ac(a, b);
  }
  function $k(a, b, c, d) {
    this.tag = a;
    this.key = c;
    this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null;
    this.index = 0;
    this.ref = null;
    this.pendingProps = b;
    this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null;
    this.mode = d;
    this.subtreeFlags = this.flags = 0;
    this.deletions = null;
    this.childLanes = this.lanes = 0;
    this.alternate = null;
  }
  function Bg(a, b, c, d) {
    return new $k(a, b, c, d);
  }
  function aj(a) {
    a = a.prototype;
    return !(!a || !a.isReactComponent);
  }
  function Zk(a) {
    if ("function" === typeof a) return aj(a) ? 1 : 0;
    if (void 0 !== a && null !== a) {
      a = a.$$typeof;
      if (a === Da) return 11;
      if (a === Ga) return 14;
    }
    return 2;
  }
  function Pg(a, b) {
    var c = a.alternate;
    null === c ? (c = Bg(a.tag, b, a.key, a.mode), c.elementType = a.elementType, c.type = a.type, c.stateNode = a.stateNode, c.alternate = a, a.alternate = c) : (c.pendingProps = b, c.type = a.type, c.flags = 0, c.subtreeFlags = 0, c.deletions = null);
    c.flags = a.flags & 14680064;
    c.childLanes = a.childLanes;
    c.lanes = a.lanes;
    c.child = a.child;
    c.memoizedProps = a.memoizedProps;
    c.memoizedState = a.memoizedState;
    c.updateQueue = a.updateQueue;
    b = a.dependencies;
    c.dependencies = null === b ? null : { lanes: b.lanes, firstContext: b.firstContext };
    c.sibling = a.sibling;
    c.index = a.index;
    c.ref = a.ref;
    return c;
  }
  function Rg(a, b, c, d, e, f) {
    var g = 2;
    d = a;
    if ("function" === typeof a) aj(a) && (g = 1);
    else if ("string" === typeof a) g = 5;
    else a: switch (a) {
      case ya:
        return Tg(c.children, e, f, b);
      case za:
        g = 8;
        e |= 8;
        break;
      case Aa:
        return a = Bg(12, c, b, e | 2), a.elementType = Aa, a.lanes = f, a;
      case Ea:
        return a = Bg(13, c, b, e), a.elementType = Ea, a.lanes = f, a;
      case Fa:
        return a = Bg(19, c, b, e), a.elementType = Fa, a.lanes = f, a;
      case Ia:
        return pj(c, e, f, b);
      default:
        if ("object" === typeof a && null !== a) switch (a.$$typeof) {
          case Ba:
            g = 10;
            break a;
          case Ca:
            g = 9;
            break a;
          case Da:
            g = 11;
            break a;
          case Ga:
            g = 14;
            break a;
          case Ha:
            g = 16;
            d = null;
            break a;
        }
        throw Error(p(130, null == a ? a : typeof a, ""));
    }
    b = Bg(g, c, b, e);
    b.elementType = a;
    b.type = d;
    b.lanes = f;
    return b;
  }
  function Tg(a, b, c, d) {
    a = Bg(7, a, d, b);
    a.lanes = c;
    return a;
  }
  function pj(a, b, c, d) {
    a = Bg(22, a, d, b);
    a.elementType = Ia;
    a.lanes = c;
    a.stateNode = { isHidden: false };
    return a;
  }
  function Qg(a, b, c) {
    a = Bg(6, a, null, b);
    a.lanes = c;
    return a;
  }
  function Sg(a, b, c) {
    b = Bg(4, null !== a.children ? a.children : [], a.key, b);
    b.lanes = c;
    b.stateNode = { containerInfo: a.containerInfo, pendingChildren: null, implementation: a.implementation };
    return b;
  }
  function al(a, b, c, d, e) {
    this.tag = b;
    this.containerInfo = a;
    this.finishedWork = this.pingCache = this.current = this.pendingChildren = null;
    this.timeoutHandle = -1;
    this.callbackNode = this.pendingContext = this.context = null;
    this.callbackPriority = 0;
    this.eventTimes = zc(0);
    this.expirationTimes = zc(-1);
    this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0;
    this.entanglements = zc(0);
    this.identifierPrefix = d;
    this.onRecoverableError = e;
    this.mutableSourceEagerHydrationData = null;
  }
  function bl(a, b, c, d, e, f, g, h, k) {
    a = new al(a, b, c, h, k);
    1 === b ? (b = 1, true === f && (b |= 8)) : b = 0;
    f = Bg(3, null, null, b);
    a.current = f;
    f.stateNode = a;
    f.memoizedState = { element: d, isDehydrated: c, cache: null, transitions: null, pendingSuspenseBoundaries: null };
    kh(f);
    return a;
  }
  function cl(a, b, c) {
    var d = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
    return { $$typeof: wa, key: null == d ? null : "" + d, children: a, containerInfo: b, implementation: c };
  }
  function dl(a) {
    if (!a) return Vf;
    a = a._reactInternals;
    a: {
      if (Vb(a) !== a || 1 !== a.tag) throw Error(p(170));
      var b = a;
      do {
        switch (b.tag) {
          case 3:
            b = b.stateNode.context;
            break a;
          case 1:
            if (Zf(b.type)) {
              b = b.stateNode.__reactInternalMemoizedMergedChildContext;
              break a;
            }
        }
        b = b.return;
      } while (null !== b);
      throw Error(p(171));
    }
    if (1 === a.tag) {
      var c = a.type;
      if (Zf(c)) return bg(a, c, b);
    }
    return b;
  }
  function el(a, b, c, d, e, f, g, h, k) {
    a = bl(c, d, true, a, e, f, g, h, k);
    a.context = dl(null);
    c = a.current;
    d = R();
    e = yi(c);
    f = mh(d, e);
    f.callback = void 0 !== b && null !== b ? b : null;
    nh(c, f, e);
    a.current.lanes = e;
    Ac(a, e, d);
    Dk(a, d);
    return a;
  }
  function fl(a, b, c, d) {
    var e = b.current, f = R(), g = yi(e);
    c = dl(c);
    null === b.context ? b.context = c : b.pendingContext = c;
    b = mh(f, g);
    b.payload = { element: a };
    d = void 0 === d ? null : d;
    null !== d && (b.callback = d);
    a = nh(e, b, g);
    null !== a && (gi(a, e, g, f), oh(a, e, g));
    return g;
  }
  function gl(a) {
    a = a.current;
    if (!a.child) return null;
    switch (a.child.tag) {
      case 5:
        return a.child.stateNode;
      default:
        return a.child.stateNode;
    }
  }
  function hl(a, b) {
    a = a.memoizedState;
    if (null !== a && null !== a.dehydrated) {
      var c = a.retryLane;
      a.retryLane = 0 !== c && c < b ? c : b;
    }
  }
  function il(a, b) {
    hl(a, b);
    (a = a.alternate) && hl(a, b);
  }
  function jl() {
    return null;
  }
  var kl = "function" === typeof reportError ? reportError : function(a) {
    console.error(a);
  };
  function ll(a) {
    this._internalRoot = a;
  }
  ml.prototype.render = ll.prototype.render = function(a) {
    var b = this._internalRoot;
    if (null === b) throw Error(p(409));
    fl(a, b, null, null);
  };
  ml.prototype.unmount = ll.prototype.unmount = function() {
    var a = this._internalRoot;
    if (null !== a) {
      this._internalRoot = null;
      var b = a.containerInfo;
      Rk(function() {
        fl(null, a, null, null);
      });
      b[uf] = null;
    }
  };
  function ml(a) {
    this._internalRoot = a;
  }
  ml.prototype.unstable_scheduleHydration = function(a) {
    if (a) {
      var b = Hc();
      a = { blockedOn: null, target: a, priority: b };
      for (var c = 0; c < Qc.length && 0 !== b && b < Qc[c].priority; c++) ;
      Qc.splice(c, 0, a);
      0 === c && Vc(a);
    }
  };
  function nl(a) {
    return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType);
  }
  function ol(a) {
    return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType && (8 !== a.nodeType || " react-mount-point-unstable " !== a.nodeValue));
  }
  function pl() {
  }
  function ql(a, b, c, d, e) {
    if (e) {
      if ("function" === typeof d) {
        var f = d;
        d = function() {
          var a2 = gl(g);
          f.call(a2);
        };
      }
      var g = el(b, d, a, 0, null, false, false, "", pl);
      a._reactRootContainer = g;
      a[uf] = g.current;
      sf(8 === a.nodeType ? a.parentNode : a);
      Rk();
      return g;
    }
    for (; e = a.lastChild; ) a.removeChild(e);
    if ("function" === typeof d) {
      var h = d;
      d = function() {
        var a2 = gl(k);
        h.call(a2);
      };
    }
    var k = bl(a, 0, false, null, null, false, false, "", pl);
    a._reactRootContainer = k;
    a[uf] = k.current;
    sf(8 === a.nodeType ? a.parentNode : a);
    Rk(function() {
      fl(b, k, c, d);
    });
    return k;
  }
  function rl(a, b, c, d, e) {
    var f = c._reactRootContainer;
    if (f) {
      var g = f;
      if ("function" === typeof e) {
        var h = e;
        e = function() {
          var a2 = gl(g);
          h.call(a2);
        };
      }
      fl(b, g, a, e);
    } else g = ql(c, b, a, e, d);
    return gl(g);
  }
  Ec = function(a) {
    switch (a.tag) {
      case 3:
        var b = a.stateNode;
        if (b.current.memoizedState.isDehydrated) {
          var c = tc(b.pendingLanes);
          0 !== c && (Cc(b, c | 1), Dk(b, B()), 0 === (K & 6) && (Gj = B() + 500, jg()));
        }
        break;
      case 13:
        Rk(function() {
          var b2 = ih(a, 1);
          if (null !== b2) {
            var c2 = R();
            gi(b2, a, 1, c2);
          }
        }), il(a, 1);
    }
  };
  Fc = function(a) {
    if (13 === a.tag) {
      var b = ih(a, 134217728);
      if (null !== b) {
        var c = R();
        gi(b, a, 134217728, c);
      }
      il(a, 134217728);
    }
  };
  Gc = function(a) {
    if (13 === a.tag) {
      var b = yi(a), c = ih(a, b);
      if (null !== c) {
        var d = R();
        gi(c, a, b, d);
      }
      il(a, b);
    }
  };
  Hc = function() {
    return C;
  };
  Ic = function(a, b) {
    var c = C;
    try {
      return C = a, b();
    } finally {
      C = c;
    }
  };
  yb = function(a, b, c) {
    switch (b) {
      case "input":
        bb(a, c);
        b = c.name;
        if ("radio" === c.type && null != b) {
          for (c = a; c.parentNode; ) c = c.parentNode;
          c = c.querySelectorAll("input[name=" + JSON.stringify("" + b) + '][type="radio"]');
          for (b = 0; b < c.length; b++) {
            var d = c[b];
            if (d !== a && d.form === a.form) {
              var e = Db(d);
              if (!e) throw Error(p(90));
              Wa(d);
              bb(d, e);
            }
          }
        }
        break;
      case "textarea":
        ib(a, c);
        break;
      case "select":
        b = c.value, null != b && fb(a, !!c.multiple, b, false);
    }
  };
  Gb = Qk;
  Hb = Rk;
  var sl = { usingClientEntryPoint: false, Events: [Cb, ue, Db, Eb, Fb, Qk] }, tl = { findFiberByHostInstance: Wc, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" };
  var ul = { bundleType: tl.bundleType, version: tl.version, rendererPackageName: tl.rendererPackageName, rendererConfig: tl.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: ua.ReactCurrentDispatcher, findHostInstanceByFiber: function(a) {
    a = Zb(a);
    return null === a ? null : a.stateNode;
  }, findFiberByHostInstance: tl.findFiberByHostInstance || jl, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
  if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) {
    var vl = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!vl.isDisabled && vl.supportsFiber) try {
      kc = vl.inject(ul), lc = vl;
    } catch (a) {
    }
  }
  reactDom_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = sl;
  reactDom_production_min.createPortal = function(a, b) {
    var c = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
    if (!nl(b)) throw Error(p(200));
    return cl(a, b, null, c);
  };
  reactDom_production_min.createRoot = function(a, b) {
    if (!nl(a)) throw Error(p(299));
    var c = false, d = "", e = kl;
    null !== b && void 0 !== b && (true === b.unstable_strictMode && (c = true), void 0 !== b.identifierPrefix && (d = b.identifierPrefix), void 0 !== b.onRecoverableError && (e = b.onRecoverableError));
    b = bl(a, 1, false, null, null, c, false, d, e);
    a[uf] = b.current;
    sf(8 === a.nodeType ? a.parentNode : a);
    return new ll(b);
  };
  reactDom_production_min.findDOMNode = function(a) {
    if (null == a) return null;
    if (1 === a.nodeType) return a;
    var b = a._reactInternals;
    if (void 0 === b) {
      if ("function" === typeof a.render) throw Error(p(188));
      a = Object.keys(a).join(",");
      throw Error(p(268, a));
    }
    a = Zb(b);
    a = null === a ? null : a.stateNode;
    return a;
  };
  reactDom_production_min.flushSync = function(a) {
    return Rk(a);
  };
  reactDom_production_min.hydrate = function(a, b, c) {
    if (!ol(b)) throw Error(p(200));
    return rl(null, a, b, true, c);
  };
  reactDom_production_min.hydrateRoot = function(a, b, c) {
    if (!nl(a)) throw Error(p(405));
    var d = null != c && c.hydratedSources || null, e = false, f = "", g = kl;
    null !== c && void 0 !== c && (true === c.unstable_strictMode && (e = true), void 0 !== c.identifierPrefix && (f = c.identifierPrefix), void 0 !== c.onRecoverableError && (g = c.onRecoverableError));
    b = el(b, null, a, 1, null != c ? c : null, e, false, f, g);
    a[uf] = b.current;
    sf(a);
    if (d) for (a = 0; a < d.length; a++) c = d[a], e = c._getVersion, e = e(c._source), null == b.mutableSourceEagerHydrationData ? b.mutableSourceEagerHydrationData = [c, e] : b.mutableSourceEagerHydrationData.push(
      c,
      e
    );
    return new ml(b);
  };
  reactDom_production_min.render = function(a, b, c) {
    if (!ol(b)) throw Error(p(200));
    return rl(null, a, b, false, c);
  };
  reactDom_production_min.unmountComponentAtNode = function(a) {
    if (!ol(a)) throw Error(p(40));
    return a._reactRootContainer ? (Rk(function() {
      rl(null, null, a, false, function() {
        a._reactRootContainer = null;
        a[uf] = null;
      });
    }), true) : false;
  };
  reactDom_production_min.unstable_batchedUpdates = Qk;
  reactDom_production_min.unstable_renderSubtreeIntoContainer = function(a, b, c, d) {
    if (!ol(c)) throw Error(p(200));
    if (null == a || void 0 === a._reactInternals) throw Error(p(38));
    return rl(a, b, c, false, d);
  };
  reactDom_production_min.version = "18.3.1-next-f1338f8080-20240426";
  return reactDom_production_min;
}
var hasRequiredReactDom;
function requireReactDom() {
  if (hasRequiredReactDom) return reactDom.exports;
  hasRequiredReactDom = 1;
  function checkDCE() {
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") {
      return;
    }
    try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
    } catch (err) {
      console.error(err);
    }
  }
  {
    checkDCE();
    reactDom.exports = requireReactDom_production_min();
  }
  return reactDom.exports;
}
var hasRequiredClient;
function requireClient() {
  if (hasRequiredClient) return client;
  hasRequiredClient = 1;
  var m = requireReactDom();
  {
    client.createRoot = m.createRoot;
    client.hydrateRoot = m.hydrateRoot;
  }
  return client;
}
var clientExports = requireClient();
var reactExports = requireReact();
const React = /* @__PURE__ */ getDefaultExportFromCjs(reactExports);
const translationCompletions = {
  "ru": {
    "csv": "CSV",
    "markdown": "Markdown",
    "url": "URL",
    "googleDriveConnectedShort": "Google Drive",
    "googleDriveSyncTitle": "Синхронизация Google Drive",
    "importPreviewPayload": "Данные",
    "urlHostRequired": "URL должен содержать корректный хост.",
    "urlHttpOnly": "Разрешены только ссылки http и https.",
    "urlInvalidExample": "Введите корректный URL, например https://example.com.",
    "urlRequired": "URL обязателен.",
    "groupTitleRequired": "Название группы обязательно.",
    "linkTitleRequired": "Название ссылки обязательно.",
    "restorePointNameRequired": "Название точки восстановления обязательно.",
    "aFineStartInternalUrlConverted": '"{title}" в "{groupTitle}" использовала внутренний URL A Fine Start, поэтому была преобразована в https://afinestart.me/bookmarks/.',
    "aFineStartLinkSkipped": '"{title}" в "{groupTitle}" пропущена: {reason}'
  },
  "es": {
    "aFineStartImported": "Se importaron {groups} grupos y {links} enlaces de A Fine Start",
    "aFineStartImportStepCopy": "Copie el código de exportación.",
    "aFineStartImportStepMode": "Elija Fusionar o Reemplazar.",
    "aFineStartImportStepOpen": "Abra A Fine Start.",
    "aFineStartImportStepPaste": "Pégalo aquí.",
    "aFineStartImportStepReview": "Revise la vista previa y luego importe.",
    "aFineStartImportStepSettings": "Vaya a Configuración -> Exportar marcadores.",
    "aFineStartImportStepsTitle": "Importar desde A Fine Start",
    "aFineStartInternalUrlConverted": '"{title}" en "{groupTitle}" usaba una URL interna de A Fine Start, así que se convirtió a https://afinestart.me/bookmarks/.',
    "aFineStartLinkSkipped": '"{title}" en "{groupTitle}" se omitió: {reason}',
    "allRestorePointsDeleted": "Todos los puntos de restauración eliminados",
    "auto": "Auto",
    "commandConnectGoogleDrive": "Conectar Google Drive",
    "commandCreateNewGroup": "Crear nuevo grupo",
    "commandCreateNewLink": "Crear nuevo enlace",
    "commandDisconnectGoogleDrive": "Desconectar Google Drive/eliminar copia de seguridad",
    "commandExportBackup": "Exportar copia de seguridad",
    "commandFailed": "El comando falló.",
    "commandImportBackup": "Importar copia de seguridad",
    "commandImportFromAFineStart": "Importar desde A Fine Start",
    "commandOpenKeyboardShortcuts": "Abrir atajos de teclado",
    "commandOpenPrivacyPromise": "Abrir promesa de privacidad",
    "commandOpenRestorePoints": "Abrir puntos de restauración",
    "commandOpenSettings": "Abrir configuración",
    "commandOpensSettingsSection": "Abre Configuración para que puedas revisar y confirmar.",
    "commandPalette": "Paleta de comandos",
    "commandPaletteShortcutNote": "Ctrl+K/Cmd+K abre la paleta de comandos cuando el navegador asigna ese acceso directo a Aura Start. Si no funciona, marque chrome://extensions/shortcuts o use este botón.",
    "commandSearchLinks": "Buscar enlaces",
    "commandToggleEditMode": "Alternar modo de edición",
    "commandToggleTheme": "Alternar tema",
    "csv": "CSV",
    "googleDriveAccountDisconnected": "Cuenta de Google desconectada",
    "googleDriveAccountDisconnectedDescription": "Aura Start vuelve a ser solo local. Tus datos locales no fueron eliminados.",
    "googleDriveAlreadySynced": "Los datos locales y Google Drive ya están sincronizados.",
    "googleDriveAutoSyncActive": "Después de la conexión, los cambios locales se sincronizan con Google Drive automáticamente.",
    "googleDriveBackingUp": "Realizando copia de seguridad en Google Drive...",
    "googleDriveBackupDeletedAndAccountDisconnected": "Copia de seguridad de Google Drive eliminada y cuenta desconectada",
    "googleDriveBackupDeletedAndAccountDisconnectedDescription": "Aura Start eliminó su archivo de sincronización oculto Google Drive y desconectó la cuenta de Google. Los datos locales permanecieron en este dispositivo.",
    "googleDriveBackupDeleteFailedAccountDisconnected": "Aura Start se desconectó localmente sin abrir el inicio de sesión de Google, pero no pudo eliminar la copia de seguridad Google Drive: {message}",
    "googleDriveBackupSuccess": "Copia de seguridad de Google Drive guardada",
    "googleDriveBackupSuccessDescription": "Aura Start actualizó el archivo de sincronización oculto en los datos de tu aplicación Google Drive.",
    "googleDriveBackupToDrive": "Copia de seguridad en Google Drive",
    "googleDriveCloudNewer": "La versión en la nube es más nueva",
    "googleDriveCloudNewerDescription": "Revise la sección de sincronización Google Drive y elija Restaurar desde Google Drive si desea reemplazar los datos locales.",
    "googleDriveConflictDescription": "Los datos locales y Google Drive cambiaron después de la última sincronización. Elija qué copia debería ganar.",
    "googleDriveConflictDetected": "Conflicto detectado",
    "googleDriveConflictTimes": "Local: {local}. Nube: {cloud}.",
    "googleDriveConnect": "Conectar Google Drive",
    "googleDriveConnected": "Google Drive conectado",
    "googleDriveConnectedNoFile": "Google Drive conectado. Aún no se ha encontrado ningún archivo de sincronización.",
    "googleDriveConnectedShort": "Google Drive",
    "googleDriveConnecting": "Conectando Google Drive...",
    "googleDriveDeleteBackupAndDisconnect": "Eliminar y desconectar",
    "googleDriveDeleteBackupAndDisconnectConfirm": "Eliminar copia de seguridad y desconectar",
    "googleDriveDeleteBackupAndDisconnectConfirmMessage": "Esto eliminará la copia de seguridad oculta Aura Start de los datos de tu aplicación Google Drive y desconectará la cuenta de Google de esta extensión. Tus datos Aura Start locales permanecerán en este dispositivo. Aura Start no abrirá el inicio de sesión de Google mientras se desconecta; Si la autorización ya no está disponible, se desconectará localmente y la copia de seguridad de Drive podrá permanecer hasta que se vuelva a conectar.",
    "googleDriveDeleteBackupAndDisconnecting": "Eliminando Google Drive copia de seguridad y desconectando la cuenta...",
    "googleDriveDeleteSyncFile": "Eliminar el archivo de sincronización Google Drive",
    "googleDriveDeleteSyncFileConfirmMessage": "Esto eliminará el archivo de sincronización Aura Start oculto de los datos de tu aplicación Google Drive. Tus datos Aura Start locales permanecerán en este dispositivo.",
    "googleDriveDeletingSyncFile": "Eliminando el archivo de sincronización Google Drive...",
    "googleDriveDisconnectAccount": "Desconectar la cuenta de Google",
    "googleDriveDisconnectConfirmMessage": "Esto desconectará el acceso a la cuenta de Google desde Aura Start. Los datos locales permanecen en este dispositivo y el archivo de sincronización Google Drive no se elimina.",
    "googleDriveDisconnecting": "Desconectando la cuenta de Google...",
    "googleDriveDisconnectedWithoutGoogleWindow": "Aura Start se desconectó localmente sin abrir el inicio de sesión de Google. La autorización de Google no estaba disponible, por lo que la copia de seguridad de Drive puede permanecer hasta que la vuelvas a conectar y la elimines.",
    "googleDriveExportLocalBackup": "Exportar primero el JSON local",
    "googleDriveGoogleWindow": "Conectar abre directamente la ventana de autorización de Google; no hace falta configurar manualmente el client ID en Aura Start.",
    "googleDriveKeepCloud": "Mantenga la nube y reemplace la local",
    "googleDriveKeepLocal": "Mantener local y subir",
    "googleDriveLastCloudUpdate": "Nube actualizada: {time}",
    "googleDriveLastSynced": "Última sincronización: {time}",
    "googleDriveLocalUploaded": "Versión local cargada en Google Drive.",
    "googleDriveManualExportStillWorks": "La exportación e importación manual JSON todavía funcionan de forma independiente.",
    "googleDriveMinimalScope": "La autorización de Google solo solicita el permiso de datos de la aplicación Drive necesario para la sincronización de Aura Start.",
    "googleDriveNoFileUploadedLocal": "No existía ningún archivo de sincronización, por lo que Aura Start cargó la copia local.",
    "googleDriveNoFullDrive": "Aura Start no solicita acceso a tus Google Drive completos o a tus archivos de Drive visibles.",
    "googleDriveNoBackupFoundAccountDisconnectedDescription": "No se encontró ningún archivo de sincronización Google Drive oculto. Aura Start desconectó la cuenta de Google y mantuvo los datos locales en este dispositivo.",
    "googleDriveNoTracking": "Aura Start no rastrea, escanea ni perfila nada en su Google Drive.",
    "googleDriveNoSyncFileFound": "No se encontró ningún archivo de sincronización Google Drive.",
    "googleDriveNotConnected": "No conectado",
    "googleDriveNeedsReconnect": "Google Drive necesita iniciar sesión para continuar con la sincronización. Se guardaron los cambios locales.",
    "googleDriveReconnect": "Vuelva a conectar Google Drive",
    "googleDriveRestoreFromDrive": "Restaurar desde Google Drive",
    "googleDriveRestoreSuccess": "Google Drive datos restaurados",
    "googleDriveRestoreSuccessDescription": "Se creó un punto de restauración local antes de reemplazar los datos locales.",
    "googleDriveRestoring": "Restaurando desde Google Drive...",
    "googleDriveSyncDescription": "Copia de seguridad y sincronización opcionales a través de los datos privados ocultos de tu aplicación Google Drive.",
    "googleDriveSyncDisabled": "Sincronización deshabilitada",
    "googleDriveSyncFailed": "Error de sincronización de Google Drive",
    "googleDriveSyncFileDeleted": "Archivo de sincronización de Google Drive eliminado",
    "googleDriveSyncFileDeletedDescription": "Solo se eliminó el archivo oculto Aura Start appDataFolder. Los datos locales permanecieron en este dispositivo.",
    "googleDriveSyncFileFound": "Se encontró el archivo de sincronización Google Drive existente.",
    "googleDriveSyncing": "Sincronizando Google Drive...",
    "googleDriveSyncMode": "Modo de sincronización",
    "googleDriveSyncMode_auto": "Auto",
    "googleDriveSyncMode_manual": "Manual",
    "googleDriveSyncMode_off": "Desactivado",
    "googleDriveSyncModeUpdated": "Google Drive modo de sincronización actualizado.",
    "googleDriveSyncOffByDefault": "La sincronización está desactivada de forma predeterminada y Aura Start almacena los datos localmente primero.",
    "googleDriveSyncTitle": "Sincronización de Google Drive",
    "googleDriveSyncUsesAppData": "El archivo de sincronización se almacena solo en el Google Drive appDataFolder oculto.",
    "googleDriveTokenRevokeFailed": "El token almacenado en caché se eliminó, pero la revocación del token de Google informó: {message}",
    "deleteRestorePointAria": "Eliminar punto de restauración {name}",
    "deleteAllOldRestorePoints": "Eliminar todos los puntos de restauración antiguos",
    "deleteAllRestorePointsMessage": "Esto elimina todos los puntos de restauración locales. Los grupos y enlaces actuales permanecen sin cambios.",
    "deleteThisLink": "¿Eliminar este enlace?",
    "deleteThisLinkMessage": 'Esto elimina "{title}". Puede deshacer la notificación si el almacenamiento se actualiza correctamente.',
    "deleteSelected": "Eliminar seleccionado",
    "deleteGroupAria": "Eliminar {title}",
    "exportAFineStartDescription": "Vuelva a un código de importación compatible con A Fine Start. Las descripciones y etiquetas Aura Start no se incluyen si ese formato no las admite.",
    "exportAllData": "Exportar todos los datos",
    "exportBackupBeforeImport": "El modo Reemplazar crea un punto de restauración antes de cambiar los datos locales. Exporte una copia de seguridad primero si desea una copia adicional.",
    "exportBackupTitle": "Exportar / Copia de seguridad",
    "exportCsvDescription": "Formato de hoja de cálculo y archivo.",
    "exportHtmlDescription": "Importar a los favoritos del navegador.",
    "exportJsonDescription": "Restauración completa y copia de seguridad de migración.",
    "exportMarkdownDescription": "Lista agrupada legible.",
    "exportRestorePoint": "Exportar punto de restauración",
    "exportTrustMessage": "Las exportaciones se crean localmente en su navegador. Aura Start no carga tus datos a un servidor.",
    "groupNotFound": "No se encontró el grupo.",
    "importBackupDescription": "Importe copias de seguridad Aura Start o pegue un código de exportación A Fine Start. Los datos se validan antes de cambiar el almacenamiento local.",
    "importFailed": "La importación falló.",
    "importPreviewGroupsLinks": "{groups} grupos, {links} enlaces",
    "importPreviewMode": "Modo",
    "importPreviewPayload": "Datos",
    "importPreviewPotentialDuplicates": "Posibles duplicados",
    "importPreviewRejected": "Rechazado",
    "importPreviewValid": "Importación válida",
    "importPreviewWillAdd": "Se importará",
    "importReplaceConfirmAction": "Reemplazar datos",
    "importReplaceConfirmMessage": "Esto reemplazará los grupos, enlaces y configuraciones actuales después de que Aura Start cree un punto de restauración primero. Exporta un Full Backup JSON si quieres una copia adicional.",
    "importReplaceConfirmTitle": "¿Reemplazar los datos actuales de Aura Start?",
    "invalidExportCode": "Código de exportación no válido.",
    "keyboardShortcuts": "Atajos de teclado",
    "keepThis": "Conservar esto",
    "linkNotFound": "No se encontró el enlace.",
    "localStorageCouldNotInitialize": "No se pudo inicializar el almacenamiento local.",
    "markdown": "Markdown",
    "merge": "Combinar",
    "noAds": "Sin anuncios",
    "noAnalytics": "Sin análisis",
    "noBackend": "Sin backend",
    "noBrowserBookmarksPermission": "Sin permiso de marcadores del navegador",
    "noBrowserHistoryPermission": "Sin permiso del historial del navegador",
    "noRestorePointsDescription": "Cree uno manualmente, o Aura Start crea uno antes de importar, reemplazar, eliminar, restablecer, restaurar y duplicar las acciones de eliminación.",
    "noRequiredAccount": "No se requiere cuenta",
    "noResults": "Sin resultados",
    "noTracking": "Sin seguimiento",
    "noCommandsFound": "No se encontraron comandos",
    "noValidLinksFound": "No se encontraron enlaces válidos.",
    "noUploadHappens": "Solo se leen archivos locales. No se sube nada.",
    "driveSyncAppDataFolderOnly": "La sincronización de Drive usa solo el alcance oculto appDataFolder",
    "driveSyncOptionalOffByDefault": "La sincronización de Google Drive es opcional y está desactivada de forma predeterminada",
    "openLinksInNewTabDescription": "Cuando está habilitado, las tarjetas de enlace y los resultados de búsqueda se abren en una nueva pestaña. Cuando están deshabilitados, se abren en la pestaña actual.",
    "pasteAFineStartPlaceholder": "Pegue el código de A Fine Start Configuración -> Exportar marcadores",
    "pressEscToClear": "Presione Esc para borrar",
    "pressSlashToSearch": "Presione / para buscar",
    "privacyPolicy": "Política de privacidad",
    "privacyPromise": "Promesa de privacidad",
    "recoveryDescription": "Los datos almacenados no pasaron la validación. Aura Start no lo sobrescribirá silenciosamente. Exporte la carga útil sin procesar antes de restablecerla si desea inspeccionarla o recuperarla manualmente.",
    "renameGroupAria": "Cambiar nombre {title}",
    "replace": "Reemplazar",
    "reviewImport": "Revisar importación",
    "restoreCurrentDataFirst": "Primero se creó un punto de restauración de datos actuales.",
    "resetAllDataMessage": "Esto borra grupos, enlaces y configuraciones después de crear un punto de restauración.",
    "restorePointActionFailed": "La acción del punto de restauración falló.",
    "restorePointFailed": "Error en el punto de restauración.",
    "restorePointImported": "Punto de restauración importado",
    "restorePointNotFound": "No se encontró el punto de restauración.",
    "restorePointRestored": "Punto de restauración restaurado",
    "restorePointsDescription": "Aura Start mantiene hasta {count} puntos de restauración locales antes de operaciones destructivas. Exporte Full Backup JSON para obtener un historial de copias de seguridad a largo plazo.",
    "restoreFromGoogleDriveOnboarding": "Restaurar desde Google Drive",
    "restoreReasonAuto": "auto",
    "restoreReasonManual": "manual",
    "restoreThisPoint": "¿Restaurar este punto?",
    "restoreThisPointMessage": "Esto reemplazará los grupos y configuraciones actuales con el punto de restauración local seleccionado.",
    "searchModifiers": "Modificadores de búsqueda",
    "searchModifiersExamples": "Utilice tag:work, group:tools, url:github o title:docs.",
    "searchModifiersHint": "Modificadores: tag:work, group:tools, url:github, title:docs",
    "searchPlaceholder": "Buscar título, URL, descripción y etiquetas",
    "searchShortcuts": "Buscar atajos",
    "shortcutClearSearch": "Borrar búsqueda",
    "shortcutCreateNewGroup": "Crear nuevo grupo",
    "shortcutCreateNewLink": "Crear nuevo enlace",
    "shortcutFocusSearch": "Enfocar búsqueda",
    "shortcutOpenCommandPalette": "Abrir paleta de comandos",
    "shortcutOpenSelectedResult": "Abrir resultado seleccionado",
    "shortcutToggleEditMode": "Alternar modo de edición",
    "storageCorrupt": "Los datos almacenados están corruptos.",
    "storageFallbackNotice": "El almacenamiento de reserva de desarrollo está activo porque chrome.storage.local no está disponible.",
    "tools": "Herramientas",
    "typeACommand": "Escribe un comando",
    "unsafeUrlSkipped": "Se omitió una URL insegura.",
    "url": "URL",
    "urlHostRequired": "La URL debe incluir un host válido.",
    "urlHttpOnly": "Solo se permiten enlaces http y https.",
    "urlInvalidExample": "Introduce una URL válida, por ejemplo https://example.com.",
    "urlRequired": "La URL es obligatoria.",
    "groupTitleRequired": "El título del grupo es obligatorio.",
    "linkTitleRequired": "El título del enlace es obligatorio.",
    "restorePointNameRequired": "El nombre del punto de restauración es obligatorio.",
    "validImport": "Importación válida: {groups} grupos, {links} enlaces."
  },
  "de": {
    "addLinkTo": "Link zu {title} hinzufügen",
    "aFineStartImported": "Importierte {groups} Gruppen und {links} Links von A Fine Start",
    "aFineStartImportStepCopy": "Kopieren Sie den Exportcode.",
    "aFineStartImportStepMode": "Wählen Sie Zusammenführen oder Ersetzen.",
    "aFineStartImportStepOpen": "Öffnen Sie A Fine Start.",
    "aFineStartImportStepPaste": "Fügen Sie es hier ein.",
    "aFineStartImportStepReview": "Überprüfen Sie die Vorschau und importieren Sie sie dann.",
    "aFineStartImportStepSettings": "Gehen Sie zu Einstellungen -> Lesezeichen exportieren.",
    "aFineStartImportStepsTitle": "Import aus A Fine Start",
    "aFineStartInternalUrlConverted": '"{title}" in "{groupTitle}" verwendete eine interne A Fine Start-URL und wurde daher in https://afinestart.me/bookmarks/ umgewandelt.',
    "aFineStartLinkSkipped": '"{title}" in "{groupTitle}" wurde übersprungen: {reason}',
    "allRestorePointsDeleted": "Alle Wiederherstellungspunkte gelöscht",
    "auto": "Auto",
    "clearSearch": "Suche löschen",
    "closeDialog": "Dialog schließen",
    "commandConnectGoogleDrive": "Google Drive verbinden",
    "commandCreateNewGroup": "Neue Gruppe erstellen",
    "commandCreateNewLink": "Neuen Link erstellen",
    "commandDisconnectGoogleDrive": "Google Drive trennen / Sicherung löschen",
    "commandExportBackup": "Backup exportieren",
    "commandFailed": "Der Befehl ist fehlgeschlagen.",
    "commandImportBackup": "Backup importieren",
    "commandImportFromAFineStart": "Import aus A Fine Start",
    "commandOpenKeyboardShortcuts": "Tastenkürzel öffnen",
    "commandOpenPrivacyPromise": "Datenschutzversprechen öffnen",
    "commandOpenRestorePoints": "Öffnen Sie Wiederherstellungspunkte",
    "commandOpenSettings": "Einstellungen öffnen",
    "commandOpensSettingsSection": "Öffnet die Einstellungen, damit Sie sie überprüfen und bestätigen können.",
    "commandPalette": "Befehlspalette",
    "commandPaletteShortcutNote": "Ctrl+K/Cmd+K öffnet die Befehlspalette, wenn der Browser diese Verknüpfung Aura Start zuweist. Wenn es nicht funktioniert, überprüfen Sie chrome://extensions/shortcuts oder verwenden Sie diese Schaltfläche.",
    "commandSearchLinks": "Links suchen",
    "commandToggleEditMode": "Bearbeitungsmodus umschalten",
    "commandToggleTheme": "Thema umschalten",
    "couldNotCompleteAction": "Diese Aktion konnte nicht abgeschlossen werden.",
    "couldNotCreateGroupForLink": "Für diesen Link konnte keine Gruppe erstellt werden.",
    "couldNotCreateRestorePoint": "Wiederherstellungspunkt konnte nicht erstellt werden.",
    "couldNotDeleteLink": "Der Link konnte nicht gelöscht werden.",
    "couldNotExportBackup": "Das Backup konnte nicht exportiert werden.",
    "couldNotLoadLocalData": "Lokale Daten konnten nicht geladen werden.",
    "couldNotMoveLink": "Link konnte nicht verschoben werden.",
    "couldNotParseImportData": "Diese Importdaten konnten nicht analysiert werden.",
    "couldNotReadImportFile": "Diese Importdatei konnte nicht gelesen werden.",
    "couldNotReorderGroups": "Gruppen konnten nicht neu angeordnet werden.",
    "couldNotResetLocalData": "Lokale Daten konnten nicht zurückgesetzt werden.",
    "couldNotSaveGroup": "Die Gruppe konnte nicht gespeichert werden.",
    "couldNotSaveLink": "Link konnte nicht gespeichert werden.",
    "couldNotUpdateGroup": "Die Gruppe konnte nicht aktualisiert werden.",
    "couldNotUpdateSettings": "Die Einstellungen konnten nicht aktualisiert werden.",
    "csv": "CSV",
    "googleDriveAccountDisconnected": "Google-Konto getrennt",
    "googleDriveAccountDisconnectedDescription": "Aura Start ist wieder nur lokal. Ihre lokalen Daten wurden nicht gelöscht.",
    "googleDriveAlreadySynced": "Lokale und Google Drive-Daten sind bereits synchronisiert.",
    "googleDriveAutoSyncActive": "Nach der Verbindung werden lokale Änderungen automatisch mit Google Drive synchronisiert.",
    "googleDriveBackingUp": "Sichern auf Google Drive...",
    "googleDriveBackupDeletedAndAccountDisconnected": "Google Drive Backup gelöscht und Kontoverbindung getrennt",
    "googleDriveBackupDeletedAndAccountDisconnectedDescription": "Aura Start hat seine versteckte Synchronisierungsdatei Google Drive gelöscht und die Verbindung zum Google-Konto getrennt. Lokale Daten blieben auf diesem Gerät.",
    "googleDriveBackupDeleteFailedAccountDisconnected": "Aura Start wurde lokal getrennt, ohne die Google-Anmeldung zu öffnen, konnte aber das Google Drive-Backup nicht löschen: {message}",
    "googleDriveBackupSuccess": "Google Drive Backup gespeichert",
    "googleDriveBackupSuccessDescription": "Aura Start hat die versteckte Synchronisierungsdatei in Ihren Google Drive App-Daten aktualisiert.",
    "googleDriveBackupToDrive": "Sicherung auf Google Drive",
    "googleDriveCloudNewer": "Die Cloud-Version ist neuer",
    "googleDriveCloudNewerDescription": "Überprüfen Sie den Abschnitt „Synchronisierung Google Drive“ und wählen Sie „Aus Google Drive wiederherstellen“, wenn Sie lokale Daten ersetzen möchten.",
    "googleDriveConflictDescription": "Sowohl lokale als auch Google Drive-Daten haben sich nach der letzten Synchronisierung geändert. Wählen Sie, welches Exemplar gewinnen soll.",
    "googleDriveConflictDetected": "Konflikt erkannt",
    "googleDriveConflictTimes": "Lokal: {local}. Wolke: {cloud}.",
    "googleDriveConnect": "Google Drive verbinden",
    "googleDriveConnected": "Google Drive verbunden",
    "googleDriveConnectedNoFile": "Google Drive verbunden. Es wurde noch keine Synchronisierungsdatei gefunden.",
    "googleDriveConnectedShort": "Google Drive",
    "googleDriveConnecting": "Google Drive wird verbunden...",
    "googleDriveDeleteBackupAndDisconnect": "Löschen und trennen",
    "googleDriveDeleteBackupAndDisconnectConfirm": "Backup löschen und trennen",
    "googleDriveDeleteBackupAndDisconnectConfirmMessage": "Dadurch wird das versteckte Aura Start-Backup aus Ihren Google Drive-App-Daten gelöscht und das Google-Konto von dieser Erweiterung getrennt. Ihre lokalen Aura Start-Daten bleiben auf diesem Gerät. Aura Start öffnet die Google-Anmeldung nicht, während die Verbindung getrennt wird. Wenn die Autorisierung nicht mehr verfügbar ist, wird die Verbindung lokal getrennt und die Laufwerksicherung bleibt möglicherweise bestehen, bis Sie die Verbindung erneut herstellen.",
    "googleDriveDeleteBackupAndDisconnecting": "Google Drive Backup wird gelöscht und Konto getrennt...",
    "googleDriveDeleteSyncFile": "Löschen Sie die Synchronisierungsdatei Google Drive",
    "googleDriveDeleteSyncFileConfirmMessage": "Dadurch wird die versteckte Aura Start-Synchronisierungsdatei aus Ihren Google Drive-App-Daten gelöscht. Ihre lokalen Aura Start-Daten bleiben auf diesem Gerät.",
    "googleDriveDeletingSyncFile": "Google Drive-Synchronisierungsdatei wird gelöscht...",
    "googleDriveDisconnectAccount": "Trennen Sie das Google-Konto",
    "googleDriveDisconnectConfirmMessage": "Dadurch wird der Zugriff auf das Google-Konto von Aura Start getrennt. Lokale Daten bleiben auf diesem Gerät und die Synchronisierungsdatei Google Drive wird nicht gelöscht.",
    "googleDriveDisconnecting": "Google-Konto wird getrennt...",
    "googleDriveDisconnectedWithoutGoogleWindow": "Aura Start lokal getrennt, ohne die Google-Anmeldung zu öffnen. Da keine Google-Autorisierung verfügbar war, bleibt die Drive-Sicherung möglicherweise bestehen, bis Sie die Verbindung erneut herstellen und löschen.",
    "googleDriveExportLocalBackup": "Exportieren Sie zuerst den lokalen JSON",
    "googleDriveGoogleWindow": "Connect öffnet direkt das Autorisierungsfenster von Google; In Aura Start ist keine manuelle Einrichtung der Client-ID erforderlich.",
    "googleDriveKeepCloud": "Behalten Sie die Cloud und ersetzen Sie sie lokal",
    "googleDriveKeepLocal": "Lokal bleiben und hochladen",
    "googleDriveLastCloudUpdate": "Cloud aktualisiert: {time}",
    "googleDriveLastSynced": "Zuletzt synchronisiert: {time}",
    "googleDriveLocalUploaded": "Lokale Version hochgeladen auf Google Drive.",
    "googleDriveManualExportStillWorks": "Manueller JSON-Export und -Import funktionieren weiterhin unabhängig voneinander.",
    "googleDriveMinimalScope": "Bei der Google-Autorisierung wird nur nach der Datenberechtigung der Drive-App gefragt, die für die Aura Start-Synchronisierung erforderlich ist.",
    "googleDriveNoFileUploadedLocal": "Da keine Synchronisierungsdatei vorhanden war, hat Aura Start die lokale Kopie hochgeladen.",
    "googleDriveNoFullDrive": "Aura Start fordert keinen Zugriff auf Ihre vollständigen Google Drive oder sichtbaren Drive-Dateien an.",
    "googleDriveNoBackupFoundAccountDisconnectedDescription": "Es wurde keine versteckte Google Drive-Synchronisierungsdatei gefunden. Aura Start hat das Google-Konto getrennt und lokale Daten auf diesem Gerät gespeichert.",
    "googleDriveNoTracking": "Aura Start verfolgt, scannt oder profiliert nichts in Ihrem Google Drive.",
    "googleDriveNoSyncFileFound": "Keine Google Drive-Synchronisierungsdatei gefunden.",
    "googleDriveNotConnected": "Nicht verbunden",
    "googleDriveNeedsReconnect": "Google Drive muss angemeldet sein, um mit der Synchronisierung fortzufahren. Lokale Änderungen wurden gespeichert.",
    "googleDriveReconnect": "Google Drive erneut verbinden",
    "googleDriveRestoreFromDrive": "Wiederherstellung von Google Drive",
    "googleDriveRestoreSuccess": "Google Drive Daten wiederhergestellt",
    "googleDriveRestoreSuccessDescription": "Vor dem Ersetzen lokaler Daten wurde ein lokaler Wiederherstellungspunkt erstellt.",
    "googleDriveRestoring": "Wiederherstellung von Google Drive...",
    "googleDriveSyncDescription": "Optionale Sicherung und Synchronisierung über Ihre privaten, versteckten Google Drive-App-Daten.",
    "googleDriveSyncDisabled": "Synchronisierung deaktiviert",
    "googleDriveSyncFailed": "Google Drive-Synchronisierung fehlgeschlagen",
    "googleDriveSyncFileDeleted": "Google Drive Synchronisierungsdatei gelöscht",
    "googleDriveSyncFileDeletedDescription": "Nur die versteckte Datei Aura Start appDataFolder wurde gelöscht. Lokale Daten blieben auf diesem Gerät.",
    "googleDriveSyncFileFound": "Vorhandene Google Drive-Synchronisierungsdatei gefunden.",
    "googleDriveSyncing": "Google Drive wird synchronisiert...",
    "googleDriveSyncMode": "Synchronisierungsmodus",
    "googleDriveSyncMode_auto": "Auto",
    "googleDriveSyncMode_manual": "Handbuch",
    "googleDriveSyncMode_off": "Aus",
    "googleDriveSyncModeUpdated": "Google Drive Synchronisierungsmodus aktualisiert.",
    "googleDriveSyncOffByDefault": "Die Synchronisierung ist standardmäßig deaktiviert und Aura Start speichert Daten zuerst lokal.",
    "googleDriveSyncTitle": "Google Drive-Synchronisierung",
    "googleDriveSyncUsesAppData": "Die Synchronisierungsdatei wird nur im versteckten Google Drive appDataFolder gespeichert.",
    "googleDriveTokenRevokeFailed": "Das zwischengespeicherte Token wurde entfernt, aber der Widerruf des Google-Tokens wurde gemeldet: {message}",
    "deleteRestorePointAria": "Wiederherstellungspunkt {name} löschen",
    "deleteRestorePointMessage": "Dadurch wird der ausgewählte Wiederherstellungspunkt aus dem lokalen Speicher entfernt.",
    "deleteAllOldRestorePoints": "Löschen Sie alle alten Wiederherstellungspunkte",
    "deleteAllRestorePointsMessage": "Dadurch werden alle lokalen Wiederherstellungspunkte entfernt. Aktuelle Gruppen und Links bleiben unverändert.",
    "deleteThisGroupMessage": "Dadurch werden „{title}“ und seine Links gelöscht, nachdem ein Wiederherstellungspunkt erstellt wurde.",
    "deleteThisGroupFallback": "diese Gruppe",
    "deleteThisLink": "Diesen Link löschen?",
    "deleteThisLinkMessage": "Dadurch wird „{title}“ gelöscht. Sie können die Benachrichtigung rückgängig machen, wenn die Speicheraktualisierung erfolgreich war.",
    "deleteSelected": "Ausgewählte löschen",
    "deleteGroupAria": "{title} löschen",
    "dragGroup": "Drag-Gruppe {title}",
    "dragLink": "Ziehen Sie {title}",
    "editLink": "Link bearbeiten",
    "editLinkAria": "Bearbeiten Sie {title}",
    "exportAFineStartDescription": "Wechseln Sie zurück zu einem A Fine Start-kompatiblen Importcode. Aura Start Beschreibungen und Tags sind nicht enthalten, wenn dieses Format sie nicht unterstützt.",
    "exportAllData": "Alle Daten exportieren",
    "exportBackupBeforeImport": "Der Ersetzungsmodus erstellt einen Wiederherstellungspunkt, bevor lokale Daten geändert werden. Exportieren Sie zunächst ein Backup, wenn Sie eine zusätzliche Kopie wünschen.",
    "exportBackupTitle": "Exportieren / Sichern",
    "exportCsvDescription": "Tabellenkalkulations- und Archivformat.",
    "exportFormatFailed": "{label}-Export fehlgeschlagen.",
    "exportHtmlDescription": "In Browser-Lesezeichen importieren.",
    "exportJsonDescription": "Vollständige Wiederherstellung und Migrationssicherung.",
    "exportMarkdownDescription": "Lesbare gruppierte Liste.",
    "exportRestorePoint": "Wiederherstellungspunkt exportieren",
    "exportTrustMessage": "Exporte werden lokal in Ihrem Browser erstellt. Aura Start lädt Ihre Daten nicht auf einen Server hoch.",
    "groupNotFound": "Gruppe wurde nicht gefunden.",
    "importBackupDescription": "Importieren Sie Aura Start-Backups oder fügen Sie einen A Fine Start-Exportcode ein. Daten werden validiert, bevor sie den lokalen Speicher ändern.",
    "importFailed": "Der Import ist fehlgeschlagen.",
    "importPreviewGroupsLinks": "{groups} Gruppen, {links} Links",
    "importPreviewMode": "Modus",
    "importPreviewPayload": "Daten",
    "importPreviewPotentialDuplicates": "Mögliche Duplikate",
    "importPreviewRejected": "Abgelehnt",
    "importPreviewValid": "Gültiger Import",
    "importPreviewWillAdd": "Wird importiert",
    "importReplaceConfirmAction": "Daten ersetzen",
    "importReplaceConfirmMessage": "Dadurch werden aktuelle Gruppen, Links und Einstellungen ersetzt, nachdem Aura Start zuerst einen Wiederherstellungspunkt erstellt hat. Exportieren Sie ein Full Backup JSON, wenn Sie eine zusätzliche Kopie wünschen.",
    "importReplaceConfirmTitle": "Aktuelle Aura Start-Daten ersetzen?",
    "invalidExportCode": "Ungültiger Exportcode.",
    "keyboardShortcuts": "Tastaturkürzel",
    "keepThis": "Dieses behalten",
    "linkNotFound": "Link wurde nicht gefunden.",
    "localStorageCouldNotInitialize": "Der lokale Speicher konnte nicht initialisiert werden.",
    "markdown": "Markdown",
    "mergeDescription": "Fügt importierte Gruppen hinzu und vermeidet ID-Konflikte.",
    "merge": "Zusammenführen",
    "moreWarnings": "{count} weitere Warnungen.",
    "newGroupTitle": "Neuer Gruppentitel",
    "noAds": "Keine Werbung",
    "noAnalytics": "Keine Analyse",
    "noBackend": "Kein Backend",
    "noBrowserBookmarksPermission": "Keine Browser-Lesezeichen-Berechtigung",
    "noBrowserHistoryPermission": "Keine Berechtigung zum Browserverlauf",
    "noRestorePointsDescription": "Erstellen Sie eines manuell oder Aura Start erstellt eines vor dem Import von Ersetzungs-, Lösch-, Zurücksetzungs-, Wiederherstellungs- und Duplikat-Löschaktionen.",
    "noRequiredAccount": "Kein erforderliches Konto",
    "noResults": "Keine Ergebnisse",
    "noTracking": "Keine Nachverfolgung",
    "noCommandsFound": "Keine Befehle gefunden",
    "noValidLinksFound": "Keine gültigen Links gefunden.",
    "noUploadHappens": "Es wird nur das Lesen lokaler Dateien verwendet. Es findet kein Upload statt.",
    "driveSyncAppDataFolderOnly": "Drive-Sync verwendet nur den verborgenen appDataFolder-Bereich",
    "driveSyncOptionalOffByDefault": "Google Drive-Synchronisierung ist optional und standardmäßig deaktiviert",
    "openLinksInNewTabDescription": "Wenn diese Option aktiviert ist, werden Linkkarten und Suchergebnisse in einem neuen Tab geöffnet. Wenn sie deaktiviert sind, werden sie im aktuellen Tab geöffnet.",
    "optionalNote": "Optionaler Hinweis",
    "pasteAFineStartPlaceholder": "Fügen Sie den Code aus A Fine Start Einstellungen -> Lesezeichen exportieren ein",
    "pickImportData": "Wählen Sie zunächst eine Datei aus oder fügen Sie gültige Importdaten ein.",
    "pressEscToClear": "Drücken Sie Esc zum Löschen",
    "pressSlashToSearch": "Drücken Sie / um zu suchen",
    "privacyPolicy": "Datenschutzrichtlinie",
    "privacyPromise": "Datenschutzversprechen",
    "recoveryDescription": "Die gespeicherten Daten haben die Validierung nicht bestanden. Aura Start wird es nicht stillschweigend überschreiben. Exportieren Sie die Rohnutzlast vor dem Zurücksetzen, wenn Sie sie manuell überprüfen oder wiederherstellen möchten.",
    "removedMessage": "„{title}“ wurde entfernt.",
    "renameGroupAria": "{title} umbenennen",
    "replaceDescription": "Erstellt einen Wiederherstellungspunkt, bevor alles ersetzt wird.",
    "replace": "Ersetzen",
    "reviewImport": "Import prüfen",
    "restoreCurrentDataFirst": "Zunächst wurde ein Wiederherstellungspunkt der aktuellen Daten erstellt.",
    "resetAllDataMessage": "Dadurch werden Gruppen, Links und Einstellungen nach dem Erstellen eines Wiederherstellungspunkts gelöscht.",
    "restorePointActionFailed": "Die Wiederherstellungspunktaktion ist fehlgeschlagen.",
    "restorePointFailed": "Wiederherstellungspunkt fehlgeschlagen.",
    "restorePointImported": "Importierter Wiederherstellungspunkt",
    "restorePointNotFound": "Der Wiederherstellungspunkt wurde nicht gefunden.",
    "restorePointRestored": "Wiederherstellungspunkt wiederhergestellt",
    "restorePointsDescription": "Aura Start behält vor destruktiven Vorgängen bis zu {count} lokale Wiederherstellungspunkte bei. Exportieren Sie Full Backup JSON für den langfristigen Sicherungsverlauf.",
    "restoreFromGoogleDriveOnboarding": "Wiederherstellung von Google Drive",
    "restoreThisPoint": "Diesen Punkt wiederherstellen?",
    "restoreThisPointMessage": "Dadurch werden die aktuellen Gruppen und Einstellungen durch den ausgewählten lokalen Wiederherstellungspunkt ersetzt.",
    "searchDescription": "Die Suche prüft Titel, URLs, Beschreibungen und Tags. Löschen Sie die Suche, um zu allen Gruppen zurückzukehren.",
    "searchModifiers": "Suchmodifikatoren",
    "searchModifiersExamples": "Verwenden Sie tag:work, group:tools, url:github oder title:docs.",
    "searchModifiersHint": "Modifikatoren: tag:work, group:tools, url:github, title:docs",
    "searchPlaceholder": "Titel, URL, Beschreibung und Tags suchen",
    "searchShortcuts": "Suchverknüpfungen",
    "settingsDescription": "Optimieren Sie das Layout, exportieren Sie Daten und verwalten Sie die lokale Wiederherstellung.",
    "shortcutClearSearch": "Suche löschen",
    "shortcutCreateNewGroup": "Neue Gruppe erstellen",
    "shortcutCreateNewLink": "Neuen Link erstellen",
    "shortcutFocusSearch": "Suche fokussieren",
    "shortcutOpenCommandPalette": "Öffnen Sie die Befehlspalette",
    "shortcutOpenSelectedResult": "Ausgewähltes Ergebnis öffnen",
    "shortcutToggleEditMode": "Bearbeitungsmodus umschalten",
    "startGroupTitle": "Start",
    "storageCorrupt": "Gespeicherte Daten sind beschädigt.",
    "storageFallbackNotice": "Der Entwicklungs-Fallback-Speicher ist aktiv, da chrome.storage.local nicht verfügbar ist.",
    "system": "System",
    "tags": "Tags",
    "tools": "Werkzeuge",
    "typeACommand": "Geben Sie einen Befehl ein",
    "unsafeUrlSkipped": "Unsichere URL übersprungen.",
    "updateAutomaticRestoreSafety": "Automatische Wiederherstellung der Sicherheit",
    "url": "URL",
    "urlHostRequired": "Die URL muss einen gültigen Host enthalten.",
    "urlHttpOnly": "Nur http- und https-Links sind erlaubt.",
    "urlInvalidExample": "Gib eine gültige URL ein, zum Beispiel https://example.com.",
    "urlRequired": "URL ist erforderlich.",
    "groupTitleRequired": "Gruppentitel ist erforderlich.",
    "linkTitleRequired": "Linktitel ist erforderlich.",
    "restorePointNameRequired": "Name des Wiederherstellungspunkts ist erforderlich.",
    "validImport": "Gültiger Import: {groups} Gruppen, {links} Links."
  },
  "fr": {
    "addLinkTo": "Ajouter un lien vers {title}",
    "aFineStartImported": "Groupes {groups} et liens {links} importés de A Fine Start",
    "aFineStartImportStepCopy": "Copiez le code d'exportation.",
    "aFineStartImportStepMode": "Choisissez Fusionner ou Remplacer.",
    "aFineStartImportStepOpen": "Ouvrez A Fine Start.",
    "aFineStartImportStepPaste": "Collez-le ici.",
    "aFineStartImportStepReview": "Vérifiez l'aperçu, puis importez.",
    "aFineStartImportStepSettings": "Accédez à Paramètres -> Exporter les favoris.",
    "aFineStartImportStepsTitle": "Importer depuis A Fine Start",
    "aFineStartInternalUrlConverted": '"{title}" dans "{groupTitle}" utilisait une URL interne A Fine Start, elle a donc été convertie en https://afinestart.me/bookmarks/.',
    "aFineStartLinkSkipped": '"{title}" dans "{groupTitle}" a été ignoré : {reason}',
    "allRestorePointsDeleted": "Tous les points de restauration supprimés",
    "auto": "Auto",
    "clearSearch": "Effacer la recherche",
    "closeDialog": "Fermer la boîte de dialogue",
    "compact": "Compact",
    "commandConnectGoogleDrive": "Connectez Google Drive",
    "commandCreateNewGroup": "Créer un nouveau groupe",
    "commandCreateNewLink": "Créer un nouveau lien",
    "commandDisconnectGoogleDrive": "Déconnecter Google Drive / supprimer la sauvegarde",
    "commandExportBackup": "Exporter la sauvegarde",
    "commandFailed": "La commande a échoué.",
    "commandImportBackup": "Importer une sauvegarde",
    "commandImportFromAFineStart": "Importer depuis A Fine Start",
    "commandOpenKeyboardShortcuts": "Ouvrir les raccourcis clavier",
    "commandOpenPrivacyPromise": "Ouvrir la promesse de confidentialité",
    "commandOpenRestorePoints": "Ouvrir des points de restauration",
    "commandOpenSettings": "Ouvrir les paramètres",
    "commandOpensSettingsSection": "Ouvre les paramètres afin que vous puissiez vérifier et confirmer.",
    "commandPalette": "Palette de commandes",
    "commandPaletteShortcutNote": "Ctrl+K/Cmd+K ouvre la palette de commandes lorsque le navigateur attribue ce raccourci à Aura Start. Si cela ne fonctionne pas, cochez chrome://extensions/shortcuts ou utilisez ce bouton.",
    "commandSearchLinks": "Rechercher des liens",
    "commandToggleEditMode": "Basculer en mode édition",
    "commandToggleTheme": "Changer de thème",
    "couldNotCompleteAction": "Impossible de terminer cette action.",
    "couldNotCreateGroupForLink": "Impossible de créer un groupe pour ce lien.",
    "couldNotCreateRestorePoint": "Impossible de créer un point de restauration.",
    "couldNotDeleteLink": "Impossible de supprimer le lien.",
    "couldNotExportBackup": "Impossible d'exporter la sauvegarde.",
    "couldNotLoadLocalData": "Les données locales n'ont pas pu être chargées.",
    "couldNotMoveLink": "Impossible de déplacer le lien.",
    "couldNotParseImportData": "Impossible d'analyser ces données d'importation.",
    "couldNotReadImportFile": "Impossible de lire ce fichier d'importation.",
    "couldNotReorderGroups": "Impossible de réorganiser les groupes.",
    "couldNotResetLocalData": "Impossible de réinitialiser les données locales.",
    "couldNotSaveGroup": "Impossible d'enregistrer le groupe.",
    "couldNotSaveLink": "Impossible d'enregistrer le lien.",
    "couldNotUpdateGroup": "Impossible de mettre à jour le groupe.",
    "couldNotUpdateSettings": "Impossible de mettre à jour les paramètres.",
    "csv": "CSV",
    "googleDriveAccountDisconnected": "Compte Google déconnecté",
    "googleDriveAccountDisconnectedDescription": "Aura Start est à nouveau local uniquement. Vos données locales n'ont pas été supprimées.",
    "googleDriveAlreadySynced": "Les données locales et Google Drive sont déjà synchronisées.",
    "googleDriveAutoSyncActive": "Après la connexion, les modifications locales sont automatiquement synchronisées avec Google Drive.",
    "googleDriveBackingUp": "Sauvegarde sur Google Drive...",
    "googleDriveBackupDeletedAndAccountDisconnected": "Sauvegarde Google Drive supprimée et compte déconnecté",
    "googleDriveBackupDeletedAndAccountDisconnectedDescription": "Aura Start a supprimé son fichier de synchronisation Google Drive masqué et a déconnecté le compte Google. Les données locales sont restées sur cet appareil.",
    "googleDriveBackupDeleteFailedAccountDisconnected": "Aura Start s'est déconnecté localement sans ouvrir la connexion Google, mais n'a pas pu supprimer la sauvegarde Google Drive : {message}",
    "googleDriveBackupSuccess": "Sauvegarde Google Drive enregistrée",
    "googleDriveBackupSuccessDescription": "Aura Start a mis à jour le fichier de synchronisation masqué dans les données de votre application Google Drive.",
    "googleDriveBackupToDrive": "Sauvegarde sur Google Drive",
    "googleDriveCloudNewer": "La version cloud est plus récente",
    "googleDriveCloudNewerDescription": "Consultez la section de synchronisation Google Drive et choisissez Restaurer à partir de Google Drive si vous souhaitez remplacer les données locales.",
    "googleDriveConflictDescription": "Les données locales et Google Drive ont toutes deux changé après la dernière synchronisation. Choisissez quelle copie devrait gagner.",
    "googleDriveConflictDetected": "Conflit détecté",
    "googleDriveConflictTimes": "Local : {local}. Nuage : {cloud}.",
    "googleDriveConnect": "Connectez Google Drive",
    "googleDriveConnected": "Google Drive connecté",
    "googleDriveConnectedNoFile": "Google Drive connecté. Aucun fichier de synchronisation trouvé pour l'instant.",
    "googleDriveConnectedShort": "Google Drive",
    "googleDriveConnecting": "Connexion de Google Drive...",
    "googleDriveDeleteBackupAndDisconnect": "Supprimer et déconnecter",
    "googleDriveDeleteBackupAndDisconnectConfirm": "Supprimer la sauvegarde et déconnecter",
    "googleDriveDeleteBackupAndDisconnectConfirmMessage": "Cela supprimera la sauvegarde cachée Aura Start des données de votre application Google Drive et déconnectera le compte Google de cette extension. Vos données locales Aura Start resteront sur cet appareil. Aura Start n'ouvrira pas la connexion Google lors de la déconnexion ; si l'autorisation n'est plus disponible, elle se déconnectera localement et la sauvegarde Drive pourra rester jusqu'à ce que vous vous reconnectiez.",
    "googleDriveDeleteBackupAndDisconnecting": "Suppression de la sauvegarde Google Drive et déconnexion du compte...",
    "googleDriveDeleteSyncFile": "Supprimer le fichier de synchronisation Google Drive",
    "googleDriveDeleteSyncFileConfirmMessage": "Cela supprimera le fichier de synchronisation Aura Start caché des données de votre application Google Drive. Vos données locales Aura Start resteront sur cet appareil.",
    "googleDriveDeletingSyncFile": "Suppression du fichier de synchronisation Google Drive...",
    "googleDriveDisconnectAccount": "Déconnecter le compte Google",
    "googleDriveDisconnectConfirmMessage": "Cela déconnectera l'accès au compte Google de Aura Start. Les données locales restent sur cet appareil et le fichier de synchronisation Google Drive n'est pas supprimé.",
    "googleDriveDisconnecting": "Déconnexion du compte Google...",
    "googleDriveDisconnectedWithoutGoogleWindow": "Aura Start s'est déconnecté localement sans ouvrir la connexion Google. L'autorisation Google n'était pas disponible, la sauvegarde Drive peut donc rester jusqu'à ce que vous vous reconnectiez et la supprimiez.",
    "googleDriveExportLocalBackup": "Exportez d'abord le JSON local",
    "googleDriveGoogleWindow": "Connect ouvre directement la fenêtre d'autorisation de Google ; aucune configuration manuelle de l'ID client n'est nécessaire dans Aura Start.",
    "googleDriveKeepCloud": "Conservez le cloud et remplacez le local",
    "googleDriveKeepLocal": "Restez local et téléchargez",
    "googleDriveLastCloudUpdate": "Nuage mis à jour : {time}",
    "googleDriveLastSynced": "Dernière synchronisation : {time}",
    "googleDriveLocalUploaded": "Version locale téléchargée sur Google Drive.",
    "googleDriveManualExportStillWorks": "L'exportation et l'importation manuelles de JSON fonctionnent toujours indépendamment.",
    "googleDriveMinimalScope": "L'autorisation Google demande uniquement l'autorisation des données de l'application Drive nécessaire à la synchronisation Aura Start.",
    "googleDriveNoFileUploadedLocal": "Aucun fichier de synchronisation n'existait, Aura Start a donc téléchargé la copie locale.",
    "googleDriveNoFullDrive": "Aura Start ne demande pas l'accès à votre Google Drive complet ou à vos fichiers Drive visibles.",
    "googleDriveNoBackupFoundAccountDisconnectedDescription": "Aucun fichier de synchronisation Google Drive masqué n'a été trouvé. Aura Start a déconnecté le compte Google et conservé les données locales sur cet appareil.",
    "googleDriveNoTracking": "Aura Start ne suit, n'analyse ni ne profile quoi que ce soit dans votre Google Drive.",
    "googleDriveNoSyncFileFound": "Aucun fichier de synchronisation Google Drive trouvé.",
    "googleDriveNotConnected": "Non connecté",
    "googleDriveNeedsReconnect": "Google Drive doit être connecté pour continuer la synchronisation. Les modifications locales ont été enregistrées.",
    "googleDriveReconnect": "Reconnecter Google Drive",
    "googleDriveRestoreFromDrive": "Restaurer à partir de Google Drive",
    "googleDriveRestoreSuccess": "Données Google Drive restaurées",
    "googleDriveRestoreSuccessDescription": "Un point de restauration local a été créé avant de remplacer les données locales.",
    "googleDriveRestoring": "Restauration à partir de Google Drive...",
    "googleDriveSyncDescription": "Sauvegarde et synchronisation facultatives via vos données d'application privées cachées Google Drive.",
    "googleDriveSyncDisabled": "Synchronisation désactivée",
    "googleDriveSyncFailed": "Échec de la synchronisation Google Drive",
    "googleDriveSyncFileDeleted": "Fichier de synchronisation Google Drive supprimé",
    "googleDriveSyncFileDeletedDescription": "Seul le fichier Aura Start appDataFolder masqué a été supprimé. Les données locales sont restées sur cet appareil.",
    "googleDriveSyncFileFound": "Fichier de synchronisation Google Drive existant trouvé.",
    "googleDriveSyncing": "Synchronisation de Google Drive...",
    "googleDriveSyncMode": "Mode synchronisation",
    "googleDriveSyncMode_auto": "Auto",
    "googleDriveSyncMode_manual": "Manuel",
    "googleDriveSyncMode_off": "Désactivé",
    "googleDriveSyncModeUpdated": "Mode de synchronisation Google Drive mis à jour.",
    "googleDriveSyncOffByDefault": "La synchronisation est désactivée par défaut et Aura Start stocke d'abord les données localement.",
    "googleDriveSyncTitle": "Synchronisation Google Drive",
    "googleDriveSyncUsesAppData": "Le fichier de synchronisation est stocké uniquement dans le Google Drive appDataFolder caché.",
    "googleDriveTokenRevokeFailed": "Le jeton mis en cache a été supprimé, mais la révocation du jeton Google a été signalée : {message}",
    "description": "Description",
    "deleteRestorePointAria": "Supprimer le point de restauration {name}",
    "deleteRestorePointMessage": "Cela supprime le point de restauration sélectionné du stockage local.",
    "deleteAllOldRestorePoints": "Supprimez tous les anciens points de restauration",
    "deleteAllRestorePointsMessage": "Cela supprime tous les points de restauration locaux. Les groupes et liens actuels restent inchangés.",
    "deleteThisGroupMessage": 'Cela supprime "{title}" et ses liens après avoir créé un point de restauration.',
    "deleteThisGroupFallback": "ce groupe",
    "deleteThisLink": "Supprimer ce lien ?",
    "deleteThisLinkMessage": 'Cela supprime "{title}". Vous pouvez annuler la notification si la mise à jour du stockage réussit.',
    "deleteSelected": "Supprimer la sélection",
    "deleteGroupAria": "Supprimer {title}",
    "dragGroup": "Faites glisser le groupe {title}",
    "dragLink": "Faites glisser {title}",
    "editLink": "Modifier le lien",
    "editLinkAria": "Modifier {title}",
    "exportAFineStartDescription": "Revenez à un code d’importation compatible A Fine Start. Les descriptions et balises Aura Start ne sont pas incluses si ce format ne les prend pas en charge.",
    "exportAllData": "Exporter toutes les données",
    "exportBackupBeforeImport": "Le mode Remplacer crée un point de restauration avant de modifier les données locales. Exportez d’abord une sauvegarde si vous souhaitez une copie supplémentaire.",
    "exportBackupTitle": "Exportation/Sauvegarde",
    "exportCsvDescription": "Format de feuille de calcul et d'archive.",
    "exportFormatFailed": "L'exportation de {label} a échoué.",
    "exportHtmlDescription": "Importez dans les favoris du navigateur.",
    "exportJsonDescription": "Sauvegarde complète de restauration et de migration.",
    "exportMarkdownDescription": "Liste groupée lisible.",
    "exportRestorePoint": "Exporter le point de restauration",
    "exportTrustMessage": "Les exportations sont créées localement dans votre navigateur. Aura Start ne télécharge pas vos données sur un serveur.",
    "groupNotFound": "Le groupe n'a pas été trouvé.",
    "importBackupDescription": "Importez des sauvegardes Aura Start ou collez un code d'exportation A Fine Start. Les données sont validées avant de modifier le stockage local.",
    "importFailed": "L'importation a échoué.",
    "importPreviewGroupsLinks": "Groupes {groups}, liens {links}",
    "importPreviewMode": "Mode",
    "importPreviewPayload": "Données",
    "importPreviewPotentialDuplicates": "Doublons potentiels",
    "importPreviewRejected": "Rejeté",
    "importPreviewValid": "Importation valide",
    "importPreviewWillAdd": "Importera",
    "importReplaceConfirmAction": "Remplacer les données",
    "importReplaceConfirmMessage": "Cela remplacera les groupes, liens et paramètres actuels après que Aura Start aura d'abord créé un point de restauration. Exportez un Full Backup JSON si vous souhaitez une copie supplémentaire.",
    "importReplaceConfirmTitle": "Remplacer les données Aura Start actuelles ?",
    "invalidExportCode": "Code d'exportation invalide.",
    "keyboardShortcuts": "Raccourcis clavier",
    "keepThis": "Conserver celui-ci",
    "linkNotFound": "Le lien n'a pas été trouvé.",
    "localStorageCouldNotInitialize": "Le stockage local n'a pas pu être initialisé.",
    "markdown": "Markdown",
    "mergeDescription": "Ajoute des groupes importés et évite les conflits d'ID.",
    "merge": "Fusionner",
    "moreWarnings": "{count} autres avertissements.",
    "newGroupTitle": "Nouveau titre de groupe",
    "noAds": "Aucune publicité",
    "noAnalytics": "Aucune analyse",
    "noBackend": "Pas de back-end",
    "noBrowserBookmarksPermission": "Aucune autorisation de favoris du navigateur",
    "noBrowserHistoryPermission": "Aucune autorisation d'historique du navigateur",
    "noRestorePointsDescription": "Créez-en un manuellement, ou Aura Start en crée un avant d'importer, de supprimer, de réinitialiser, de restaurer et de dupliquer les actions de suppression.",
    "noRequiredAccount": "Aucun compte requis",
    "noResults": "Aucun résultat",
    "noTracking": "Pas de suivi",
    "noCommandsFound": "Aucune commande trouvée",
    "noValidLinksFound": "Aucun lien valide trouvé.",
    "noUploadHappens": "Seule la lecture de fichiers locaux est utilisée. Aucun téléchargement n'a lieu.",
    "driveSyncAppDataFolderOnly": "La synchronisation Drive utilise uniquement le champ d’application masqué appDataFolder",
    "driveSyncOptionalOffByDefault": "La synchronisation Google Drive est optionnelle et désactivée par défaut",
    "openLinksInNewTabDescription": "Lorsqu'ils sont activés, les cartes de liens et les résultats de recherche s'ouvrent dans un nouvel onglet. Lorsqu'ils sont désactivés, ils s'ouvrent dans l'onglet actuel.",
    "optionalNote": "Remarque facultative",
    "pasteAFineStartPlaceholder": "Collez le code depuis Paramètres A Fine Start -> Exporter les favoris",
    "pickImportData": "Choisissez un fichier ou collez d'abord des données d'importation valides.",
    "pressEscToClear": "Appuyez sur Échap pour effacer",
    "pressSlashToSearch": "Appuyez sur / pour rechercher",
    "privacyPolicy": "Politique de confidentialité",
    "privacyPromise": "Promesse de confidentialité",
    "recoveryDescription": "Les données stockées n'ont pas été validées. Aura Start ne l'écrasera pas silencieusement. Exportez la charge utile brute avant de la réinitialiser si vous souhaitez l'inspecter ou la récupérer manuellement.",
    "removedMessage": '"{title}" a été supprimé.',
    "renameGroupAria": "Renommer {title}",
    "replaceDescription": "Crée un point de restauration avant de tout remplacer.",
    "replace": "Remplacer",
    "reviewImport": "Vérifier l’import",
    "restoreCurrentDataFirst": "Un point de restauration des données actuelles a d'abord été créé.",
    "resetAllDataMessage": "Cela efface les groupes, les liens et les paramètres après la création d'un point de restauration.",
    "restorePointActionFailed": "L'action du point de restauration a échoué.",
    "restorePointFailed": "Le point de restauration a échoué.",
    "restorePointImported": "Point de restauration importé",
    "restorePointNotFound": "Le point de restauration n'a pas été trouvé.",
    "restorePointRestored": "Point de restauration restauré",
    "restorePointsDescription": "Aura Start conserve jusqu'à {count} points de restauration locaux avant les opérations destructrices. Exportez Full Backup JSON pour un historique de sauvegarde à long terme.",
    "restoreFromGoogleDriveOnboarding": "Restaurer à partir de Google Drive",
    "restoreReasonAuto": "auto",
    "restoreThisPoint": "Restaurer ce point ?",
    "restoreThisPointMessage": "Cela remplacera les groupes et paramètres actuels par le point de restauration local sélectionné.",
    "searchDescription": "La recherche vérifie les titres, les URL, les descriptions et les balises. Effacez la recherche pour revenir à tous les groupes.",
    "searchModifiers": "Modificateurs de recherche",
    "searchModifiersExamples": "Utilisez tag:work, group:tools, url:github ou title:docs.",
    "searchModifiersHint": "Modificateurs : tag:work, group:tools, url:github, title:docs",
    "searchPlaceholder": "Rechercher titre, URL, description et étiquettes",
    "searchShortcuts": "Raccourcis de recherche",
    "settingsDescription": "Ajustez la mise en page, exportez les données et gérez la récupération locale.",
    "shortcutClearSearch": "Effacer la recherche",
    "shortcutCreateNewGroup": "Créer un nouveau groupe",
    "shortcutCreateNewLink": "Créer un nouveau lien",
    "shortcutFocusSearch": "Mettre la recherche en focus",
    "shortcutOpenCommandPalette": "Ouvrir la palette de commandes",
    "shortcutOpenSelectedResult": "Ouvrir le résultat sélectionné",
    "shortcutToggleEditMode": "Basculer en mode édition",
    "storageCorrupt": "Les données stockées sont corrompues.",
    "storageFallbackNotice": "Le stockage de secours de développement est actif car chrome.storage.local n'est pas disponible.",
    "tools": "Outils",
    "typeACommand": "Tapez une commande",
    "unsafeUrlSkipped": "URL non sûre ignorée.",
    "updateAutomaticRestoreSafety": "Sécurité de restauration automatique",
    "url": "URL",
    "urlHostRequired": "L’URL doit inclure un hôte valide.",
    "urlHttpOnly": "Seuls les liens http et https sont autorisés.",
    "urlInvalidExample": "Saisissez une URL valide, par exemple https://example.com.",
    "urlRequired": "L’URL est obligatoire.",
    "groupTitleRequired": "Le titre du groupe est obligatoire.",
    "linkTitleRequired": "Le titre du lien est obligatoire.",
    "restorePointNameRequired": "Le nom du point de restauration est obligatoire.",
    "validImport": "Importation valide : groupes {groups}, liens {links}."
  },
  "pt": {
    "addLinkTo": "Adicionar link para {title}",
    "aFineStartImported": "Grupos {groups} importados e links {links} de A Fine Start",
    "aFineStartImportStepCopy": "Copie o código de exportação.",
    "aFineStartImportStepMode": "Escolha Mesclar ou Substituir.",
    "aFineStartImportStepOpen": "Abra A Fine Start.",
    "aFineStartImportStepPaste": "Cole aqui.",
    "aFineStartImportStepReview": "Revise a visualização e importe.",
    "aFineStartImportStepSettings": "Vá para Configurações -> Exportar favoritos.",
    "aFineStartImportStepsTitle": "Importar de A Fine Start",
    "aFineStartInternalUrlConverted": '"{title}" em "{groupTitle}" usava uma URL interna do A Fine Start, então foi convertido para https://afinestart.me/bookmarks/.',
    "aFineStartLinkSkipped": '"{title}" em "{groupTitle}" foi ignorado: {reason}',
    "allRestorePointsDeleted": "Todos os pontos de restauração excluídos",
    "auto": "Auto",
    "clearSearch": "Limpar pesquisa",
    "closeDialog": "Fechar caixa de diálogo",
    "commandConnectGoogleDrive": "Conecte Google Drive",
    "commandCreateNewGroup": "Criar novo grupo",
    "commandCreateNewLink": "Criar novo link",
    "commandDisconnectGoogleDrive": "Desconecte Google Drive / exclua backup",
    "commandExportBackup": "Exportar backup",
    "commandFailed": "Comando falhou.",
    "commandImportBackup": "Importar backup",
    "commandImportFromAFineStart": "Importar de A Fine Start",
    "commandOpenKeyboardShortcuts": "Abrir atalhos de teclado",
    "commandOpenPrivacyPromise": "Abrir promessa de privacidade",
    "commandOpenRestorePoints": "Abrir pontos de restauração",
    "commandOpenSettings": "Abrir configurações",
    "commandOpensSettingsSection": "Abre Configurações para que você possa revisar e confirmar.",
    "commandPalette": "Paleta de comandos",
    "commandPaletteShortcutNote": "Ctrl+K/Cmd+K abre a paleta de comandos quando o navegador atribui esse atalho a Aura Start. Se não funcionar, marque chrome://extensions/shortcuts ou use este botão.",
    "commandSearchLinks": "Pesquisar links",
    "commandToggleEditMode": "Alternar modo de edição",
    "commandToggleTheme": "Alternar tema",
    "couldNotCompleteAction": "Não foi possível concluir esta ação.",
    "couldNotCreateGroupForLink": "Não foi possível criar um grupo para este link.",
    "couldNotCreateRestorePoint": "Não foi possível criar o ponto de restauração.",
    "couldNotDeleteLink": "Não foi possível excluir o link.",
    "couldNotExportBackup": "Não foi possível exportar o backup.",
    "couldNotLoadLocalData": "Não foi possível carregar os dados locais.",
    "couldNotMoveLink": "Não foi possível mover o link.",
    "couldNotParseImportData": "Não foi possível analisar estes dados de importação.",
    "couldNotReadImportFile": "Não foi possível ler este arquivo de importação.",
    "couldNotReorderGroups": "Não foi possível reordenar os grupos.",
    "couldNotResetLocalData": "Não foi possível redefinir os dados locais.",
    "couldNotSaveGroup": "Não foi possível salvar o grupo.",
    "couldNotSaveLink": "Não foi possível salvar o link.",
    "couldNotUpdateGroup": "Não foi possível atualizar o grupo.",
    "couldNotUpdateSettings": "Não foi possível atualizar as configurações.",
    "csv": "CSV",
    "googleDriveAccountDisconnected": "Conta do Google desconectada",
    "googleDriveAccountDisconnectedDescription": "Aura Start é apenas local novamente. Seus dados locais não foram excluídos.",
    "googleDriveAlreadySynced": "Os dados locais e Google Drive já estão sincronizados.",
    "googleDriveAutoSyncActive": "Após a conexão, as alterações locais são sincronizadas com Google Drive automaticamente.",
    "googleDriveBackingUp": "Fazendo backup em Google Drive...",
    "googleDriveBackupDeletedAndAccountDisconnected": "Google Drive backup excluído e conta desconectada",
    "googleDriveBackupDeletedAndAccountDisconnectedDescription": "Aura Start excluiu seu arquivo de sincronização Google Drive oculto e desconectou a Conta do Google. Os dados locais permaneceram neste dispositivo.",
    "googleDriveBackupDeleteFailedAccountDisconnected": "Aura Start desconectou-se localmente sem abrir o login do Google, mas não foi possível excluir o backup de Google Drive: {message}",
    "googleDriveBackupSuccess": "Google Drive backup salvo",
    "googleDriveBackupSuccessDescription": "Aura Start atualizou o arquivo de sincronização oculto nos dados do seu aplicativo Google Drive.",
    "googleDriveBackupToDrive": "Backup para Google Drive",
    "googleDriveCloudNewer": "A versão da nuvem é mais recente",
    "googleDriveCloudNewerDescription": "Revise a seção de sincronização Google Drive e escolha Restaurar de Google Drive se desejar substituir os dados locais.",
    "googleDriveConflictDescription": "Os dados locais e Google Drive foram alterados após a última sincronização. Escolha qual cópia deve vencer.",
    "googleDriveConflictDetected": "Conflito detectado",
    "googleDriveConflictTimes": "Local: {local}. Nuvem: {cloud}.",
    "googleDriveConnect": "Conecte Google Drive",
    "googleDriveConnected": "Google Drive conectado",
    "googleDriveConnectedNoFile": "Google Drive conectado. Nenhum arquivo de sincronização encontrado ainda.",
    "googleDriveConnectedShort": "Google Drive",
    "googleDriveConnecting": "Conectando Google Drive...",
    "googleDriveDeleteBackupAndDisconnect": "Excluir e desconectar",
    "googleDriveDeleteBackupAndDisconnectConfirm": "Excluir backup e desconectar",
    "googleDriveDeleteBackupAndDisconnectConfirmMessage": "Isso excluirá o backup Aura Start oculto dos dados do aplicativo Google Drive e desconectará a Conta do Google desta extensão. Seus dados Aura Start locais permanecerão neste dispositivo. Aura Start não abrirá o login do Google durante a desconexão; se a autorização não estiver mais disponível, ela será desconectada localmente e o backup do Drive poderá permanecer até você se reconectar.",
    "googleDriveDeleteBackupAndDisconnecting": "Excluindo backup de Google Drive e desconectando conta...",
    "googleDriveDeleteSyncFile": "Excluir arquivo de sincronização Google Drive",
    "googleDriveDeleteSyncFileConfirmMessage": "Isso excluirá o arquivo de sincronização Aura Start oculto dos dados do aplicativo Google Drive. Seus dados Aura Start locais permanecerão neste dispositivo.",
    "googleDriveDeletingSyncFile": "Excluindo arquivo de sincronização Google Drive...",
    "googleDriveDisconnectAccount": "Desconectar conta do Google",
    "googleDriveDisconnectConfirmMessage": "Isso desconectará o acesso à Conta do Google de Aura Start. Os dados locais permanecem neste dispositivo e o arquivo de sincronização Google Drive não é excluído.",
    "googleDriveDisconnecting": "Desconectando a Conta do Google...",
    "googleDriveDisconnectedWithoutGoogleWindow": "Aura Start desconectou-se localmente sem abrir o login do Google. A autorização do Google não estava disponível, portanto o backup do Drive pode permanecer até você reconectá-lo e excluí-lo.",
    "googleDriveExportLocalBackup": "Exporte JSON local primeiro",
    "googleDriveGoogleWindow": "O Connect abre diretamente a janela de autorização do Google; nenhuma configuração manual de ID do cliente é necessária em Aura Start.",
    "googleDriveKeepCloud": "Mantenha a nuvem e substitua o local",
    "googleDriveKeepLocal": "Mantenha-se local e faça upload",
    "googleDriveLastCloudUpdate": "Nuvem atualizada: {time}",
    "googleDriveLastSynced": "Última sincronização: {time}",
    "googleDriveLocalUploaded": "Versão local enviada para Google Drive.",
    "googleDriveManualExportStillWorks": "A exportação e importação manual de JSON ainda funcionam de forma independente.",
    "googleDriveMinimalScope": "A autorização do Google solicita apenas a permissão de dados do aplicativo Drive necessária para sincronização de Aura Start.",
    "googleDriveNoFileUploadedLocal": "Não existia nenhum arquivo de sincronização, então Aura Start carregou a cópia local.",
    "googleDriveNoFullDrive": "Aura Start não solicita acesso aos seus arquivos Google Drive completos ou visíveis do Drive.",
    "googleDriveNoBackupFoundAccountDisconnectedDescription": "Nenhum arquivo de sincronização Google Drive oculto foi encontrado. Aura Start desconectou a Conta do Google e manteve os dados locais neste dispositivo.",
    "googleDriveNoTracking": "Aura Start não rastreia, verifica ou cria perfil de nada em seu Google Drive.",
    "googleDriveNoSyncFileFound": "Nenhum arquivo de sincronização Google Drive encontrado.",
    "googleDriveNotConnected": "Não conectado",
    "googleDriveNeedsReconnect": "Google Drive precisa de login para continuar a sincronização. As alterações locais foram salvas.",
    "googleDriveReconnect": "Reconectar Google Drive",
    "googleDriveRestoreFromDrive": "Restaurar de Google Drive",
    "googleDriveRestoreSuccess": "Google Drive dados restaurados",
    "googleDriveRestoreSuccessDescription": "Um ponto de restauração local foi criado antes da substituição dos dados locais.",
    "googleDriveRestoring": "Restaurando de Google Drive...",
    "googleDriveSyncDescription": "Backup e sincronização opcionais por meio de dados privados e ocultos do aplicativo Google Drive.",
    "googleDriveSyncDisabled": "Sincronização desativada",
    "googleDriveSyncFailed": "Falha na sincronização de Google Drive",
    "googleDriveSyncFileDeleted": "Google Drive arquivo de sincronização excluído",
    "googleDriveSyncFileDeletedDescription": "Apenas o arquivo oculto Aura Start appDataFolder foi excluído. Os dados locais permaneceram neste dispositivo.",
    "googleDriveSyncFileFound": "Arquivo de sincronização Google Drive existente encontrado.",
    "googleDriveSyncing": "Sincronizando Google Drive...",
    "googleDriveSyncMode": "Modo de sincronização",
    "googleDriveSyncMode_auto": "Auto",
    "googleDriveSyncMode_manual": "Manual",
    "googleDriveSyncMode_off": "Desativado",
    "googleDriveSyncModeUpdated": "Google Drive modo de sincronização atualizado.",
    "googleDriveSyncOffByDefault": "A sincronização está desativada por padrão e Aura Start armazena os dados localmente primeiro.",
    "googleDriveSyncTitle": "Sincronização do Google Drive",
    "googleDriveSyncUsesAppData": "O arquivo de sincronização é armazenado apenas no Google Drive appDataFolder oculto.",
    "googleDriveTokenRevokeFailed": "O token armazenado em cache foi removido, mas a revogação do token do Google foi relatada: {message}",
    "deleteRestorePointAria": "Excluir ponto de restauração {name}",
    "deleteRestorePointMessage": "Isso remove o ponto de restauração selecionado do armazenamento local.",
    "deleteAllOldRestorePoints": "Exclua todos os pontos de restauração antigos",
    "deleteAllRestorePointsMessage": "Isso remove todos os pontos de restauração locais. Os grupos e links atuais permanecem inalterados.",
    "deleteThisGroupMessage": 'Isso exclui "{title}" e seus links após a criação de um ponto de restauração.',
    "deleteThisGroupFallback": "este grupo",
    "deleteThisLink": "Excluir este link?",
    "deleteThisLinkMessage": 'Isso exclui "{title}". Você poderá desfazer a notificação se o armazenamento for atualizado com sucesso.',
    "deleteSelected": "Excluir selecionado",
    "deleteGroupAria": "Excluir {title}",
    "dragGroup": "Arraste o grupo {title}",
    "dragLink": "Arraste {title}",
    "editLink": "Editar link",
    "editLinkAria": "Editar {title}",
    "exportAFineStartDescription": "Volte para um código de importação compatível com A Fine Start. Aura Start descrições e tags não serão incluídas se esse formato não for compatível.",
    "exportAllData": "Exportar todos os dados",
    "exportBackupBeforeImport": "O modo de substituição cria um ponto de restauração antes de alterar os dados locais. Exporte um backup primeiro se desejar uma cópia extra.",
    "exportBackupTitle": "Exportar/Backup",
    "exportCsvDescription": "Formato de planilha e arquivo.",
    "exportFormatFailed": "Falha na exportação de {label}.",
    "exportHtmlDescription": "Importe para os favoritos do navegador.",
    "exportJsonDescription": "Restauração completa e backup de migração.",
    "exportMarkdownDescription": "Lista agrupada legível.",
    "exportRestorePoint": "Exportar ponto de restauração",
    "exportTrustMessage": "As exportações são criadas localmente no seu navegador. Aura Start não carrega seus dados para um servidor.",
    "groupNotFound": "O grupo não foi encontrado.",
    "importBackupDescription": "Importe backups de Aura Start ou cole um código de exportação A Fine Start. Os dados são validados antes de alterarem o armazenamento local.",
    "importFailed": "Falha na importação.",
    "importPreviewGroupsLinks": "{groups} grupos, {links} links",
    "importPreviewMode": "Modo",
    "importPreviewPayload": "Dados",
    "importPreviewPotentialDuplicates": "Potenciais duplicatas",
    "importPreviewRejected": "Rejeitado",
    "importPreviewValid": "Importação válida",
    "importPreviewWillAdd": "Importará",
    "importReplaceConfirmAction": "Substituir dados",
    "importReplaceConfirmMessage": "Isso substituirá os grupos, links e configurações atuais depois que Aura Start criar primeiro um ponto de restauração. Exporte um Full Backup JSON se desejar uma cópia extra.",
    "importReplaceConfirmTitle": "Substituir os dados Aura Start atuais?",
    "invalidExportCode": "Código de exportação inválido.",
    "keyboardShortcuts": "Atalhos de teclado",
    "keepThis": "Manter este",
    "linksCount": "{count} links",
    "linkNotFound": "O link não foi encontrado.",
    "localStorageCouldNotInitialize": "O armazenamento local não pôde ser inicializado.",
    "markdown": "Markdown",
    "mergeDescription": "Adiciona grupos importados e evita conflitos de ID.",
    "merge": "Mesclar",
    "moreWarnings": "{count} mais avisos.",
    "newGroupTitle": "Novo título do grupo",
    "noAds": "Sem anúncios",
    "noAnalytics": "Sem análises",
    "noBackend": "Sem back-end",
    "noBrowserBookmarksPermission": "Sem permissão de favoritos do navegador",
    "noBrowserHistoryPermission": "Sem permissão de histórico do navegador",
    "noRestorePointsDescription": "Crie um manualmente ou Aura Start cria um antes de importar ações de substituição, exclusão, redefinição, restauração e exclusão duplicada.",
    "noRequiredAccount": "Nenhuma conta necessária",
    "noResults": "Nenhum resultado",
    "noTracking": "Sem rastreamento",
    "noCommandsFound": "Nenhum comando encontrado",
    "noValidLinksFound": "Nenhum link válido encontrado.",
    "noUploadHappens": "Somente leitura de arquivo local é usada. Nenhum upload acontece.",
    "driveSyncAppDataFolderOnly": "A sincronização do Drive usa apenas o escopo oculto appDataFolder",
    "driveSyncOptionalOffByDefault": "A sincronização do Google Drive é opcional e fica desativada por padrão",
    "openLinksInNewTabDescription": "Quando ativado, os cartões de link e os resultados da pesquisa são abertos em uma nova guia. Quando desativados, eles abrem na guia atual.",
    "optionalNote": "Nota opcional",
    "pasteAFineStartPlaceholder": "Cole o código de A Fine Start Configurações -> Exportar favoritos",
    "pickImportData": "Escolha um arquivo ou cole primeiro os dados de importação válidos.",
    "pressEscToClear": "Pressione Esc para limpar",
    "pressSlashToSearch": "Pressione / para pesquisar",
    "privacyPolicy": "Política de privacidade",
    "privacyPromise": "Promessa de privacidade",
    "recoveryDescription": "Os dados armazenados não passaram na validação. Aura Start não irá sobrescrevê-lo silenciosamente. Exporte a carga bruta antes de redefini-la se quiser inspecioná-la ou recuperá-la manualmente.",
    "removedMessage": '"{title}" foi removido.',
    "renameGroupAria": "Renomear {title}",
    "replaceDescription": "Cria um ponto de restauração antes de substituir tudo.",
    "replace": "Substituir",
    "reviewImport": "Revisar importação",
    "restoreCurrentDataFirst": "Um ponto de restauração dos dados atuais foi criado primeiro.",
    "resetAllDataMessage": "Isso limpa grupos, links e configurações após criar um ponto de restauração.",
    "restorePointActionFailed": "Falha na ação do ponto de restauração.",
    "restorePointFailed": "Falha no ponto de restauração.",
    "restorePointImported": "Ponto de restauração importado",
    "restorePointNotFound": "O ponto de restauração não foi encontrado.",
    "restorePointRestored": "Ponto de restauração restaurado",
    "restorePointsDescription": "Aura Start mantém até {count} pontos de restauração locais antes de operações destrutivas. Exporte Full Backup JSON para histórico de backup de longo prazo.",
    "restoreFromGoogleDriveOnboarding": "Restaurar de Google Drive",
    "restoreReasonAuto": "auto",
    "restoreReasonManual": "manual",
    "restoreThisPoint": "Restaurar este ponto?",
    "restoreThisPointMessage": "Isso substituirá os grupos e configurações atuais pelo ponto de restauração local selecionado.",
    "searchDescription": "A pesquisa verifica títulos, URLs, descrições e tags. Limpe a pesquisa para retornar a todos os grupos.",
    "searchModifiers": "Modificadores de pesquisa",
    "searchModifiersExamples": "Use tag:work, group:tools, url:github ou title:docs.",
    "searchModifiersHint": "Modificadores: tag:work, group:tools, url:github, title:docs",
    "searchPlaceholder": "Pesquisar título, URL, descrição e tags",
    "searchShortcuts": "Atalhos de pesquisa",
    "settingsDescription": "Ajuste o layout, exporte dados e gerencie a recuperação local.",
    "shortcutClearSearch": "Limpar pesquisa",
    "shortcutCreateNewGroup": "Criar novo grupo",
    "shortcutCreateNewLink": "Criar novo link",
    "shortcutFocusSearch": "Focar pesquisa",
    "shortcutOpenCommandPalette": "Abrir paleta de comandos",
    "shortcutOpenSelectedResult": "Abrir resultado selecionado",
    "shortcutToggleEditMode": "Alternar modo de edição",
    "storageCorrupt": "Os dados armazenados estão corrompidos.",
    "storageFallbackNotice": "O armazenamento substituto de desenvolvimento está ativo porque chrome.storage.local não está disponível.",
    "tags": "Tags",
    "tools": "Ferramentas",
    "typeACommand": "Digite um comando",
    "unsafeUrlSkipped": "URL inseguro ignorado.",
    "updateAutomaticRestoreSafety": "Segurança de restauração automática",
    "url": "URL",
    "urlHostRequired": "A URL deve incluir um host válido.",
    "urlHttpOnly": "Somente links http e https são permitidos.",
    "urlInvalidExample": "Digite uma URL válida, por exemplo https://example.com.",
    "urlRequired": "A URL é obrigatória.",
    "groupTitleRequired": "O título do grupo é obrigatório.",
    "linkTitleRequired": "O título do link é obrigatório.",
    "restorePointNameRequired": "O nome do ponto de restauração é obrigatório.",
    "validImport": "Importação válida: {groups} grupos, {links} links."
  },
  "uk": {
    "aFineStartImported": "Імпортовано {groups} груп і {links} посилань із A Fine Start",
    "aFineStartImportStepCopy": "Скопіюйте код експорту.",
    "aFineStartImportStepMode": "Виберіть «Об’єднати» або «Замінити».",
    "aFineStartImportStepOpen": "Відкрийте A Fine Start.",
    "aFineStartImportStepPaste": "Вставте його сюди.",
    "aFineStartImportStepReview": "Перегляньте попередній перегляд, а потім імпортуйте.",
    "aFineStartImportStepSettings": "Перейдіть до Налаштування -> Експортувати закладки.",
    "aFineStartImportStepsTitle": "Імпортувати з A Fine Start",
    "aFineStartInternalUrlConverted": '"{title}" у "{groupTitle}" використовувало внутрішню URL-адресу A Fine Start, тому її перетворено на https://afinestart.me/bookmarks/.',
    "aFineStartLinkSkipped": '"{title}" у "{groupTitle}" пропущено: {reason}',
    "allRestorePointsDeleted": "Усі точки відновлення видалено",
    "commandConnectGoogleDrive": "Підключити Google Drive",
    "commandCreateNewGroup": "Створити нову групу",
    "commandCreateNewLink": "Створити нове посилання",
    "commandDisconnectGoogleDrive": "Відключити Google Drive / видалити резервну копію",
    "commandExportBackup": "Експорт резервної копії",
    "commandFailed": "Помилка команди.",
    "commandImportBackup": "Імпорт резервної копії",
    "commandImportFromAFineStart": "Імпортувати з A Fine Start",
    "commandOpenKeyboardShortcuts": "Відкрити гарячі клавіші",
    "commandOpenPrivacyPromise": "Відкрити обіцянку приватності",
    "commandOpenRestorePoints": "Відкрийте точки відновлення",
    "commandOpenSettings": "Відкрийте налаштування",
    "commandOpensSettingsSection": "Відкриває налаштування, щоб ви могли переглянути та підтвердити.",
    "commandPalette": "Палітра команд",
    "commandPaletteShortcutNote": "Ctrl+K/Cmd+K відкриває палітру команд, коли браузер призначає цей ярлик для Aura Start. Якщо не працює, перевірте chrome://extensions/shortcuts або скористайтеся цією кнопкою.",
    "commandSearchLinks": "Пошук посилань",
    "commandToggleEditMode": "Перемкнути режим редагування",
    "commandToggleTheme": "Перемкнути тему",
    "couldNotCompleteAction": "Не вдалося завершити цю дію.",
    "couldNotCreateGroupForLink": "Не вдалося створити групу для цього посилання.",
    "couldNotCreateRestorePoint": "Не вдалося створити точку відновлення.",
    "couldNotDeleteLink": "Не вдалося видалити посилання.",
    "couldNotExportBackup": "Не вдалося експортувати резервну копію.",
    "couldNotLoadLocalData": "Не вдалося завантажити локальні дані.",
    "couldNotMoveLink": "Не вдалося перемістити посилання.",
    "couldNotParseImportData": "Не вдалося проаналізувати дані імпорту.",
    "couldNotReadImportFile": "Не вдалося прочитати цей імпортований файл.",
    "couldNotReorderGroups": "Не вдалося змінити порядок груп.",
    "couldNotResetLocalData": "Не вдалося скинути локальні дані.",
    "couldNotSaveGroup": "Не вдалося зберегти групу.",
    "couldNotSaveLink": "Не вдалося зберегти посилання.",
    "couldNotUpdateGroup": "Не вдалося оновити групу.",
    "couldNotUpdateSettings": "Не вдалося оновити налаштування.",
    "csv": "CSV",
    "googleDriveAccountDisconnected": "Обліковий запис Google відключено",
    "googleDriveAccountDisconnectedDescription": "Aura Start знову лише локальний. Ваші локальні дані не видалено.",
    "googleDriveAlreadySynced": "Локальні дані та дані Google Drive вже синхронізовано.",
    "googleDriveAutoSyncActive": "Після підключення локальні зміни автоматично синхронізуються з Google Drive.",
    "googleDriveBackingUp": "Резервне копіювання на Google Drive...",
    "googleDriveBackupDeletedAndAccountDisconnected": "Резервну копію Google Drive видалено, обліковий запис відключено",
    "googleDriveBackupDeletedAndAccountDisconnectedDescription": "Aura Start видалив свій прихований файл синхронізації Google Drive і від’єднав обліковий запис Google. Локальні дані залишилися на цьому пристрої.",
    "googleDriveBackupDeleteFailedAccountDisconnected": "Aura Start відключено локально, не ввійшовши в Google, але не вдалося видалити резервну копію Google Drive: {message}",
    "googleDriveBackupSuccess": "Резервну копію Google Drive збережено",
    "googleDriveBackupSuccessDescription": "Aura Start оновив прихований файл синхронізації в даних програми Google Drive.",
    "googleDriveBackupToDrive": "Резервне копіювання на Google Drive",
    "googleDriveCloudNewer": "Хмарна версія новіша",
    "googleDriveCloudNewerDescription": "Перегляньте розділ синхронізації Google Drive та виберіть «Відновити з Google Drive», якщо ви хочете замінити локальні дані.",
    "googleDriveConflictDescription": "Локальні дані та дані Google Drive змінилися після останньої синхронізації. Виберіть, яка копія виграє.",
    "googleDriveConflictDetected": "Виявлено конфлікт",
    "googleDriveConflictTimes": "Місцевий: {local}. Хмара: {cloud}.",
    "googleDriveConnect": "Підключити Google Drive",
    "googleDriveConnected": "Google Drive підключено",
    "googleDriveConnectedNoFile": "Google Drive підключено. Файл синхронізації ще не знайдено.",
    "googleDriveConnectedShort": "Google Drive",
    "googleDriveConnecting": "Підключення Google Drive...",
    "googleDriveDeleteBackupAndDisconnect": "Видалити та відключити",
    "googleDriveDeleteBackupAndDisconnectConfirm": "Видаліть резервну копію та відключіться",
    "googleDriveDeleteBackupAndDisconnectConfirmMessage": "Це призведе до видалення прихованої резервної копії Aura Start з даних програми Google Drive та від’єднання облікового запису Google від цього розширення. Ваші локальні дані Aura Start залишаться на цьому пристрої. Aura Start не відкриває вхід Google під час від’єднання; якщо авторизація більше не доступна, локально буде відключено, а резервна копія Диска може залишатися, доки ви не підключитесь знову.",
    "googleDriveDeleteBackupAndDisconnecting": "Видалення резервної копії Google Drive та відключення облікового запису...",
    "googleDriveDeleteSyncFile": "Видалити файл синхронізації Google Drive",
    "googleDriveDeleteSyncFileConfirmMessage": "Це видалить прихований файл синхронізації Aura Start з даних програми Google Drive. Ваші локальні дані Aura Start залишаться на цьому пристрої.",
    "googleDriveDeletingSyncFile": "Видалення файлу синхронізації Google Drive...",
    "googleDriveDisconnectAccount": "Відключити обліковий запис Google",
    "googleDriveDisconnectConfirmMessage": "Це призведе до відключення доступу до облікового запису Google від Aura Start. Локальні дані залишаються на цьому пристрої, а файл синхронізації Google Drive не видаляється.",
    "googleDriveDisconnecting": "Відключення облікового запису Google...",
    "googleDriveDisconnectedWithoutGoogleWindow": "Aura Start від’єднано локально без входу в Google. Авторизація Google була недоступна, тому резервна копія Диска може зберігатися, доки ви не підключитесь і не видалите її.",
    "googleDriveExportLocalBackup": "Спочатку експортуйте локальний JSON",
    "googleDriveGoogleWindow": "Connect безпосередньо відкриває вікно авторизації Google; у Aura Start не потрібно налаштовувати ідентифікатор клієнта вручну.",
    "googleDriveKeepCloud": "Зберегти хмару та замінити локальну",
    "googleDriveKeepLocal": "Зберігайте локальні та завантажуйте",
    "googleDriveLastCloudUpdate": "Хмара оновлено: {time}",
    "googleDriveLastSynced": "Остання синхронізація: {time}",
    "googleDriveLocalUploaded": "Локальну версію завантажено на Google Drive.",
    "googleDriveManualExportStillWorks": "Ручний експорт і імпорт JSON все ще працюють незалежно.",
    "googleDriveMinimalScope": "Авторизація Google вимагає лише дозволу на дані програми Диска, необхідного для синхронізації Aura Start.",
    "googleDriveNoFileUploadedLocal": "Файлу синхронізації не існувало, тому Aura Start завантажив локальну копію.",
    "googleDriveNoFullDrive": "Aura Start не запитує доступ до ваших повних Google Drive або видимих ​​файлів Диска.",
    "googleDriveNoBackupFoundAccountDisconnectedDescription": "Не знайдено прихованого файлу синхронізації Google Drive. Aura Start від’єднав обліковий запис Google і зберіг локальні дані на цьому пристрої.",
    "googleDriveNoTracking": "Aura Start не відстежує, не сканує та не профілює нічого у вашому Google Drive.",
    "googleDriveNoSyncFileFound": "Файл синхронізації Google Drive не знайдено.",
    "googleDriveNotConnected": "Не підключено",
    "googleDriveNeedsReconnect": "Google Drive потребує входу, щоб продовжити синхронізацію. Локальні зміни збережено.",
    "googleDriveReconnect": "Повторно підключити Google Drive",
    "googleDriveRestoreFromDrive": "Відновити з Google Drive",
    "googleDriveRestoreSuccess": "Дані Google Drive відновлено",
    "googleDriveRestoreSuccessDescription": "Локальну точку відновлення було створено перед заміною локальних даних.",
    "googleDriveRestoring": "Відновлення з Google Drive...",
    "googleDriveSyncDescription": "Додаткове резервне копіювання та синхронізація через особисті приховані дані програми Google Drive.",
    "googleDriveSyncDisabled": "Синхронізацію вимкнено",
    "googleDriveSyncFailed": "Помилка синхронізації Google Drive",
    "googleDriveSyncFileDeleted": "Файл синхронізації Google Drive видалено",
    "googleDriveSyncFileDeletedDescription": "Було видалено лише прихований файл Aura Start appDataFolder. Локальні дані залишилися на цьому пристрої.",
    "googleDriveSyncFileFound": "Знайдено наявний файл синхронізації Google Drive.",
    "googleDriveSyncing": "Синхронізація Google Drive...",
    "googleDriveSyncMode": "Режим синхронізації",
    "googleDriveSyncMode_auto": "Авто",
    "googleDriveSyncMode_manual": "Інструкція",
    "googleDriveSyncMode_off": "Вимкнено",
    "googleDriveSyncModeUpdated": "Режим синхронізації Google Drive оновлено.",
    "googleDriveSyncOffByDefault": "Синхронізацію вимкнено за умовчанням, і Aura Start спочатку зберігає дані локально.",
    "googleDriveSyncTitle": "Синхронізація Google Drive",
    "googleDriveSyncUsesAppData": "Файл синхронізації зберігається лише в прихованому Google Drive appDataFolder.",
    "googleDriveTokenRevokeFailed": "Кешований маркер видалено, але про відкликання маркера Google повідомлено: {message}",
    "deleteRestorePointAria": "Видалити точку відновлення {name}",
    "deleteRestorePointMessage": "Вибрану точку відновлення буде видалено з локального сховища.",
    "deleteAllOldRestorePoints": "Видаліть усі старі точки відновлення",
    "deleteAllRestorePointsMessage": "Це видаляє всі локальні точки відновлення. Поточні групи та посилання залишаються без змін.",
    "deleteThisGroupMessage": 'Це видаляє "{title}" та його посилання після створення точки відновлення.',
    "deleteThisGroupFallback": "ця група",
    "deleteThisLink": "Видалити це посилання?",
    "deleteThisLinkMessage": 'Це видаляє "{title}". Ви можете скасувати сповіщення, якщо сховище оновлено успішно.',
    "deleteSelected": "Видалити вибране",
    "deleteGroupAria": "Видалити {title}",
    "dragGroup": "Перетягніть групу {title}",
    "dragLink": "Перетягніть {title}",
    "editLink": "Редагувати посилання",
    "editLinkAria": "Редагувати {title}",
    "exportAFineStartDescription": "Поверніться до A Fine Start-сумісного коду імпорту. Описи та теги Aura Start не включені, якщо цей формат їх не підтримує.",
    "exportAllData": "Експортуйте всі дані",
    "exportBackupBeforeImport": "Режим заміни створює точку відновлення перед зміною локальних даних. Спершу експортуйте резервну копію, якщо вам потрібна додаткова копія.",
    "exportBackupTitle": "Експорт / резервне копіювання",
    "exportCsvDescription": "Формат електронної таблиці та архіву.",
    "exportFormatFailed": "Помилка експорту {label}.",
    "exportHtmlDescription": "Імпортувати в закладки браузера.",
    "exportJsonDescription": "Повне відновлення та резервне копіювання міграції.",
    "exportMarkdownDescription": "Читабельний згрупований список.",
    "exportRestorePoint": "Експорт точки відновлення",
    "exportTrustMessage": "Експорт створюється локально у вашому браузері. Aura Start не завантажує ваші дані на сервер.",
    "groupNotFound": "Групу не знайдено.",
    "importBackupDescription": "Імпортуйте резервні копії Aura Start або вставте код експорту A Fine Start. Дані перевіряються перед зміною локального сховища.",
    "importFailed": "Помилка імпорту.",
    "importPreviewGroupsLinks": "{groups} груп, {links} посилань",
    "importPreviewMode": "Режим",
    "importPreviewPayload": "Дані",
    "importPreviewPotentialDuplicates": "Потенційні дублікати",
    "importPreviewRejected": "Відхилено",
    "importPreviewValid": "Дійсний імпорт",
    "importPreviewWillAdd": "Імпортуватимуть",
    "importReplaceConfirmAction": "Замінити дані",
    "importReplaceConfirmMessage": "Це замінить поточні групи, посилання та налаштування після того, як Aura Start спочатку створить точку відновлення. Експортуйте Full Backup JSON, якщо вам потрібна додаткова копія.",
    "importReplaceConfirmTitle": "Замінити поточні дані Aura Start?",
    "invalidExportCode": "Недійсний код експорту.",
    "keyboardShortcuts": "Комбінації клавіш",
    "keepThis": "Залишити це",
    "linkNotFound": "Посилання не знайдено.",
    "localStorageCouldNotInitialize": "Не вдалося ініціалізувати локальне сховище.",
    "markdown": "Markdown",
    "merge": "Об’єднати",
    "moreWarnings": "Ще {count} попереджень.",
    "noAds": "Без реклами",
    "noAnalytics": "Ніякої аналітики",
    "noBackend": "Без бекенда",
    "noBrowserBookmarksPermission": "Немає дозволу на закладки браузера",
    "noBrowserHistoryPermission": "Немає дозволу на історію браузера",
    "noRestorePointsDescription": "Створіть його вручну або Aura Start створить його перед діями заміни імпорту, видалення, скидання, відновлення та видалення дублікатів.",
    "noRequiredAccount": "Обліковий запис не потрібен",
    "noResults": "Результатів немає",
    "noTracking": "Немає відстеження",
    "noCommandsFound": "Команди не знайдено",
    "noValidLinksFound": "Не знайдено дійсних посилань.",
    "noUploadHappens": "Використовується лише локальне читання файлів. Завантаження не відбувається.",
    "driveSyncAppDataFolderOnly": "Синхронізація Drive використовує лише приховану область appDataFolder",
    "driveSyncOptionalOffByDefault": "Синхронізація Google Drive необов’язкова й типово вимкнена",
    "openLinksInNewTabDescription": "Якщо ввімкнено, картки з посиланнями та результати пошуку відкриваються в новій вкладці. Якщо вимкнено, вони відкриваються в поточній вкладці.",
    "optionalNote": "Додаткова примітка",
    "pasteAFineStartPlaceholder": "Вставте код із A Fine Start Налаштування -> Експортувати закладки",
    "pickImportData": "Спочатку виберіть файл або вставте дійсні дані імпорту.",
    "pressEscToClear": "Натисніть Esc, щоб очистити",
    "pressSlashToSearch": "Натисніть / для пошуку",
    "privacyPolicy": "Політика приватності",
    "privacyPromise": "Обіцянка приватності",
    "recoveryDescription": "Збережені дані не пройшли перевірку. Aura Start не перезапише його мовчки. Експортуйте необроблене корисне навантаження перед скиданням, якщо ви хочете перевірити або відновити його вручну.",
    "removedMessage": '"{title}" видалено.',
    "renameGroupAria": "Перейменувати {title}",
    "replaceDescription": "Створює точку відновлення перед заміною всього.",
    "replace": "Замінити",
    "reviewImport": "Переглянути імпорт",
    "restoreCurrentDataFirst": "Спочатку була створена точка відновлення поточних даних.",
    "resetAllDataMessage": "Це очищає групи, посилання та налаштування після створення точки відновлення.",
    "restorePointActionFailed": "Помилка дії точки відновлення.",
    "restorePointFailed": "Помилка точки відновлення.",
    "restorePointImported": "Імпортована точка відновлення",
    "restorePointNotFound": "Точку відновлення не знайдено.",
    "restorePointRestored": "Точку відновлення відновлено",
    "restorePointsDescription": "Aura Start зберігає до {count} локальних точок відновлення перед руйнівними операціями. Експортуйте Full Backup JSON для тривалої історії резервного копіювання.",
    "restoreFromGoogleDriveOnboarding": "Відновити з Google Drive",
    "restoreThisPoint": "Відновити цю точку?",
    "restoreThisPointMessage": "Це замінить поточні групи та налаштування вибраною локальною точкою відновлення.",
    "searchDescription": "Пошук перевіряє заголовки, URL, описи та теги. Очистіть пошук, щоб повернутися до всіх груп.",
    "searchModifiers": "Модифікатори пошуку",
    "searchModifiersExamples": "Використовуйте tag:work, group:tools, url:github або title:docs.",
    "searchModifiersHint": "Модифікатори: tag:work, group:tools, url:github, title:docs",
    "searchPlaceholder": "Пошук за назвою, URL, описом і тегами",
    "searchShortcuts": "Швидкі клавіші пошуку",
    "shortcutClearSearch": "Очистити пошук",
    "shortcutCreateNewGroup": "Створити нову групу",
    "shortcutCreateNewLink": "Створити нове посилання",
    "shortcutFocusSearch": "Фокус на пошук",
    "shortcutOpenCommandPalette": "Відкрийте палітру команд",
    "shortcutOpenSelectedResult": "Відкрити вибраний результат",
    "shortcutToggleEditMode": "Перемкнути режим редагування",
    "storageCorrupt": "Збережені дані пошкоджені.",
    "storageFallbackNotice": "Резервне сховище розробки активне, оскільки chrome.storage.local недоступний.",
    "tools": "Інструменти",
    "typeACommand": "Введіть команду",
    "unsafeUrlSkipped": "Небезпечну URL-адресу пропущено.",
    "url": "URL",
    "urlHostRequired": "URL-адреса має містити дійсний хост.",
    "urlHttpOnly": "Дозволені лише http- та https-посилання.",
    "urlInvalidExample": "Введіть дійсну URL-адресу, наприклад https://example.com.",
    "urlRequired": "URL-адреса обов’язкова.",
    "groupTitleRequired": "Назва групи обов’язкова.",
    "linkTitleRequired": "Назва посилання обов’язкова.",
    "restorePointNameRequired": "Назва точки відновлення обов’язкова.",
    "validImport": "Дійсний імпорт: {groups} груп, {links} посилань."
  }
};
const languageOptions = [
  { code: "en", label: "English" },
  { code: "ru", label: "Русский" },
  { code: "es", label: "Español" },
  { code: "de", label: "Deutsch" },
  { code: "fr", label: "Français" },
  { code: "pt", label: "Português" },
  { code: "uk", label: "Українська" }
];
function isAuraLanguage(value) {
  return value === "en" || value === "ru" || value === "es" || value === "de" || value === "fr" || value === "pt" || value === "uk";
}
const en = {
  actionFailed: "Action failed",
  add: "Add",
  addGroup: "Add group",
  addLink: "Add link",
  addLinkTo: "Add link to {title}",
  aFineStartExportCode: "A Fine Start export code",
  aFineStartImported: "Imported {groups} groups and {links} links from A Fine Start",
  aFineStartImportStepCopy: "Copy the export code.",
  aFineStartImportStepMode: "Choose Merge or Replace.",
  aFineStartImportStepOpen: "Open A Fine Start.",
  aFineStartImportStepPaste: "Paste it here.",
  aFineStartImportStepReview: "Review the preview, then import.",
  aFineStartImportStepSettings: "Go to Settings -> Export bookmarks.",
  aFineStartImportStepsTitle: "Import from A Fine Start",
  aFineStartInternalUrlConverted: '"{title}" in "{groupTitle}" used an internal A Fine Start URL, so it was converted to https://afinestart.me/bookmarks/.',
  aFineStartLinkSkipped: '"{title}" in "{groupTitle}" was skipped: {reason}',
  allRestorePointsDeleted: "All restore points deleted",
  auto: "Auto",
  addDemoGroups: "Add demo groups",
  back: "Back",
  backupImported: "Backup imported",
  backupMerged: "Backup merged",
  auraStartBackupJson: "Aura Start Full Backup JSON",
  cancel: "Cancel",
  chooseImportFile: "Choose JSON/export-code file",
  chooseAppearance: "Choose appearance",
  chooseHowToStart: "Choose how to start",
  clearSearch: "Clear search",
  closeDialog: "Close dialog",
  collapseGroup: "Collapse {title}",
  comfortable: "Comfortable",
  compact: "Compact",
  columns: "Columns",
  commandConnectGoogleDrive: "Connect Google Drive",
  commandCreateNewGroup: "Create new group",
  commandCreateNewLink: "Create new link",
  commandDisconnectGoogleDrive: "Disconnect Google Drive / delete backup",
  commandExportBackup: "Export backup",
  commandFailed: "Command failed.",
  commandImportBackup: "Import backup",
  commandImportFromAFineStart: "Import from A Fine Start",
  commandOpenDuplicateFinder: "Open Duplicate Finder",
  commandOpenKeyboardShortcuts: "Open Keyboard Shortcuts",
  commandOpenPrivacyPromise: "Open Privacy Promise",
  commandOpenRestorePoints: "Open restore points",
  commandOpenSettings: "Open settings",
  commandOpensSettingsSection: "Opens Settings so you can review and confirm.",
  commandPalette: "Command Palette",
  commandPaletteShortcutNote: "Ctrl+K/Cmd+K opens the Command Palette when the browser assigns that shortcut to Aura Start. If it does not work, check chrome://extensions/shortcuts or use this button.",
  commandSearchLinks: "Search links",
  commandToggleEditMode: "Toggle edit mode",
  commandToggleTheme: "Toggle theme",
  compactMode: "Compact mode",
  couldNotCompleteAction: "Could not complete this action.",
  couldNotCreateGroupForLink: "Could not create a group for this link.",
  couldNotCreateRestorePoint: "Could not create restore point.",
  couldNotDeleteLink: "Could not delete link.",
  couldNotExportBackup: "Could not export backup.",
  couldNotLoadLocalData: "Local data could not be loaded.",
  couldNotMoveLink: "Could not move link.",
  couldNotParseImportData: "Could not parse this import data.",
  couldNotReadImportFile: "Could not read this import file.",
  couldNotReorderGroups: "Could not reorder groups.",
  couldNotResetLocalData: "Could not reset local data.",
  couldNotSaveGroup: "Could not save group.",
  couldNotSaveLink: "Could not save link.",
  couldNotUpdateGroup: "Could not update group.",
  couldNotUpdateSettings: "Could not update settings.",
  create: "Create",
  createYourFirstGroup: "Create your first group",
  csv: "CSV",
  dark: "Dark",
  dataOwnership: "Data ownership",
  dataOwnershipDescription: "Everything is stored in Chromium local extension storage. Export any time before changing browsers or profiles.",
  googleDriveAccountDisconnected: "Google Account disconnected",
  googleDriveAccountDisconnectedDescription: "Aura Start is local-only again. Your local data was not deleted.",
  googleDriveAlreadySynced: "Local and Google Drive data are already in sync.",
  googleDriveAutoSyncActive: "After connection, local changes are synced to Google Drive automatically.",
  googleDriveBackingUp: "Backing up to Google Drive...",
  googleDriveBackupDeletedAndAccountDisconnected: "Google Drive backup deleted and account disconnected",
  googleDriveBackupDeletedAndAccountDisconnectedDescription: "Aura Start deleted its hidden Google Drive sync file and disconnected the Google Account. Local data stayed on this device.",
  googleDriveBackupDeleteFailedAccountDisconnected: "Aura Start disconnected locally without opening Google sign-in, but could not delete the Google Drive backup: {message}",
  googleDriveBackupSuccess: "Google Drive backup saved",
  googleDriveBackupSuccessDescription: "Aura Start updated the hidden sync file in your Google Drive app data.",
  googleDriveBackupToDrive: "Backup to Google Drive",
  googleDriveCloudNewer: "Cloud version is newer",
  googleDriveCloudNewerDescription: "Review the Google Drive sync section and choose Restore from Google Drive if you want to replace local data.",
  googleDriveConflictDescription: "Local and Google Drive data both changed after the last sync. Choose which copy should win.",
  googleDriveConflictDetected: "Conflict detected",
  googleDriveConflictTimes: "Local: {local}. Cloud: {cloud}.",
  googleDriveConnect: "Connect Google Drive",
  googleDriveConnected: "Google Drive connected",
  googleDriveConnectedNoFile: "Google Drive connected. No sync file found yet.",
  googleDriveConnectedShort: "Google Drive",
  googleDriveConnecting: "Connecting Google Drive...",
  googleDriveDeleteBackupAndDisconnect: "Delete and disconnect",
  googleDriveDeleteBackupAndDisconnectConfirm: "Delete backup and disconnect",
  googleDriveDeleteBackupAndDisconnectConfirmMessage: "This will delete the hidden Aura Start backup from your Google Drive app data and disconnect the Google Account from this extension. Your local Aura Start data will stay on this device. Aura Start will not open Google sign-in while disconnecting; if authorization is no longer available, it will disconnect locally and the Drive backup may remain until you reconnect.",
  googleDriveDeleteBackupAndDisconnecting: "Deleting Google Drive backup and disconnecting account...",
  googleDriveDeleteSyncFile: "Delete Google Drive sync file",
  googleDriveDeleteSyncFileConfirmMessage: "This will delete the hidden Aura Start sync file from your Google Drive app data. Your local Aura Start data will stay on this device.",
  googleDriveDeletingSyncFile: "Deleting Google Drive sync file...",
  googleDriveDisconnectAccount: "Disconnect Google Account",
  googleDriveDisconnectConfirmMessage: "This will disconnect Google Account access from Aura Start. Local data stays on this device and the Google Drive sync file is not deleted.",
  googleDriveDisconnecting: "Disconnecting Google Account...",
  googleDriveDisconnectedWithoutGoogleWindow: "Aura Start disconnected locally without opening Google sign-in. Google authorization was not available, so the Drive backup may remain until you reconnect and delete it.",
  googleDriveExportLocalBackup: "Export local JSON first",
  googleDriveGoogleWindow: "Connect opens Google's authorization window directly; no manual client ID setup is needed in Aura Start.",
  googleDriveKeepCloud: "Keep cloud and replace local",
  googleDriveKeepLocal: "Keep local and upload",
  googleDriveLastCloudUpdate: "Cloud updated: {time}",
  googleDriveLastSynced: "Last synced: {time}",
  googleDriveLocalUploaded: "Local version uploaded to Google Drive.",
  googleDriveManualExportStillWorks: "Manual JSON export and import still work independently.",
  googleDriveMinimalScope: "Google authorization asks only for the Drive app data permission needed for Aura Start sync.",
  googleDriveNoFileUploadedLocal: "No sync file existed, so Aura Start uploaded the local copy.",
  googleDriveNoFullDrive: "Aura Start does not request access to your full Google Drive or visible Drive files.",
  googleDriveNoBackupFoundAccountDisconnectedDescription: "No hidden Google Drive sync file was found. Aura Start disconnected the Google Account and kept local data on this device.",
  googleDriveNoTracking: "Aura Start does not track, scan, or profile anything in your Google Drive.",
  googleDriveNoSyncFileCreated: "Google Drive sync file was not found and was created.",
  googleDriveNoSyncFileFound: "No Google Drive sync file found.",
  googleDriveNotConnected: "Not connected",
  googleDriveNeedsReconnect: "Google Drive needs sign-in to continue syncing. Local changes were saved.",
  googleDriveReconnect: "Reconnect Google Drive",
  googleDriveRestoreFromDrive: "Restore from Google Drive",
  googleDriveRestoreSuccess: "Google Drive data restored",
  googleDriveRestoreSuccessDescription: "A local restore point was created before replacing local data.",
  googleDriveRestoring: "Restoring from Google Drive...",
  googleDriveSyncDescription: "Optional backup and sync through your private hidden Google Drive app data.",
  googleDriveSyncDisabled: "Sync disabled",
  googleDriveSyncFailed: "Google Drive sync failed",
  googleDriveSyncFileDeleted: "Google Drive sync file deleted",
  googleDriveSyncFileDeletedDescription: "Only the hidden Aura Start appDataFolder file was deleted. Local data stayed on this device.",
  googleDriveSyncFileFound: "Existing Google Drive sync file found.",
  googleDriveSyncFileFoundAndRestored: "Google Drive sync file was found and restored.",
  googleDriveSyncing: "Syncing Google Drive...",
  googleDriveSyncMode: "Sync mode",
  googleDriveSyncMode_auto: "Auto",
  googleDriveSyncMode_manual: "Manual",
  googleDriveSyncMode_off: "Off",
  googleDriveSyncModeUpdated: "Google Drive sync mode updated.",
  googleDriveSyncOffByDefault: "Sync is off by default and Aura Start stores data locally first.",
  googleDriveSyncTitle: "Google Drive Sync",
  googleDriveSyncUsesAppData: "The sync file is stored only in the hidden Google Drive appDataFolder.",
  googleDriveTokenRevokeFailed: "The cached token was removed, but Google token revoke reported: {message}",
  delete: "Delete",
  deleteGroup: "Delete group",
  description: "Description",
  deleteRestorePoint: "Delete restore point?",
  deleteRestorePointAria: "Delete restore point {name}",
  deleteRestorePointMessage: "This removes the selected restore point from local storage.",
  deleteAllOldRestorePoints: "Delete all old restore points",
  deleteAllRestorePointsMessage: "This removes all local restore points. Current groups and links stay unchanged.",
  deleteThisGroup: "Delete this group?",
  deleteThisGroupMessage: 'This deletes "{title}" and its links after creating a restore point.',
  deleteThisGroupFallback: "this group",
  deleteThisLink: "Delete this link?",
  deleteThisLinkMessage: 'This deletes "{title}". You can undo from the notification if storage updates successfully.',
  deleteSelected: "Delete selected",
  deleteSelectedDuplicates: "Delete selected duplicates?",
  deleteSelectedDuplicatesMessage: "This will delete {count} selected duplicate links after creating a restore point.",
  deleteGroupAria: "Delete {title}",
  dismissNotification: "Dismiss notification",
  dragGroup: "Drag group {title}",
  dragLink: "Drag {title}",
  duplicateFinder: "Duplicate Finder",
  duplicateFinderDescription: "Scan local links for duplicates. Nothing is deleted unless you select links and confirm.",
  duplicateFinderNoMutation: "The scan is read-only and does not change local data.",
  duplicateFinderReadOnly: "Scan is read-only. Select links manually before deleting anything.",
  duplicateLinksDeleted: "{count} duplicate links deleted",
  duplicateReasonExactUrl: "Exact URL duplicate",
  duplicateReasonHostnameCase: "Same hostname with different casing",
  duplicateReasonHttpHttps: "Possible http/https duplicate",
  duplicateReasonTrailingSlash: "Duplicate after removing trailing slash",
  edit: "Edit",
  enableEditMode: "Enable edit mode",
  disableEditMode: "Disable edit mode",
  editLink: "Edit link",
  editLinkAria: "Edit {title}",
  emptyGroupButton: "Add the first link",
  export: "Export",
  exportAFineStartDescription: "Move back to an A Fine Start-compatible import code. Aura Start descriptions and tags are not included if that format does not support them.",
  exportAllData: "Export all data",
  exportBackupBeforeImport: "Replace mode creates a restore point before changing local data. Export a backup first if you want an extra copy.",
  exportBackupTitle: "Export / Backup",
  exportCsvDescription: "Spreadsheet and archive format.",
  expandGroup: "Expand {title}",
  exportFailed: "Export failed",
  exportFormatFailed: "{label} export failed.",
  exportHtmlDescription: "Import into browser bookmarks.",
  exportJsonDescription: "Full restore and migration backup.",
  exportMarkdownDescription: "Readable grouped list.",
  exportJsonBackup: "Export JSON backup",
  exportRawData: "Export raw data",
  exportRestorePoint: "Export restore point",
  exportTrustMessage: "Exports are created locally in your browser. Aura Start does not upload your data to a server.",
  exactDuplicates: "Exact duplicates",
  finish: "Finish",
  fullBackupJson: "Full Backup JSON",
  group: "Group",
  groupDeleted: "Group deleted",
  groupNotFound: "Group was not found.",
  groupsCount: "{count} groups",
  groupsLinksCount: "{groups} groups · {links} links",
  groupTitlePlaceholder: "Design, Work, Reading",
  hiThere: "Hi there!",
  htmlBookmarks: "Browser Bookmarks HTML",
  import: "Import",
  importBackup: "Import backup",
  importBackupDescription: "Import Aura Start backups or paste an A Fine Start export code. Data is validated before it changes local storage.",
  importBackupFile: "Import backup file",
  importFailed: "Import failed.",
  importFormat: "Import format",
  importFromAFineStart: "Import from A Fine Start",
  importMode: "Import mode",
  importPreviewGroupsLinks: "{groups} groups, {links} links",
  importPreviewMode: "Mode",
  importPreviewPayload: "Payload",
  importPreviewPotentialDuplicates: "Potential duplicates",
  importPreviewRejected: "Rejected",
  importPreviewValid: "Valid import",
  importPreviewWillAdd: "Will import",
  importReplaceConfirmAction: "Replace data",
  importReplaceConfirmMessage: "This will replace current groups, links, and settings after Aura Start creates a restore point first. Export a Full Backup JSON if you want an extra copy.",
  importReplaceConfirmTitle: "Replace current Aura Start data?",
  importRestorePointMessage: "A restore point was created before the import.",
  importWarnings: "Import warnings: {count}",
  invalidExportCode: "Invalid export code.",
  keyboardShortcuts: "Keyboard Shortcuts",
  keepThis: "Keep this",
  inspiredBy: "Inspired by A Fine Start",
  brandSlogan: "A private, local-first start page for your links - free, open-source, and easy to export",
  language: "Language",
  light: "Light",
  linkDeleted: "Link deleted",
  linksCount: "{count} links",
  linkNotFound: "Link was not found.",
  loadingAuraStart: "Loading Aura Start...",
  loadingLocalData: "Loading local data",
  localStorageCouldNotInitialize: "Local storage could not be initialized.",
  markdown: "Markdown",
  manualCheckpoint: "Manual checkpoint",
  mergeDescription: "Adds imported groups and avoids ID conflicts.",
  merge: "Merge",
  mergeWithCurrentData: "Merge with current data",
  moreWarnings: "{count} more warnings.",
  newGroup: "New group",
  newGroupTitle: "New group title",
  noMatchingLinks: "No matching links",
  noAds: "No ads",
  noAnalytics: "No analytics",
  noBackend: "No backend",
  noBrowserBookmarksPermission: "No browser bookmarks permission",
  noBrowserHistoryPermission: "No browser history permission",
  noRestorePoints: "No restore points yet",
  noRestorePointsDescription: "Create one manually, or Aura Start creates one before import replace, delete, reset, restore, and duplicate deletion actions.",
  noRequiredAccount: "No required account",
  noResults: "No results",
  noTracking: "No tracking",
  noCommandsFound: "No commands found",
  noDuplicateLinksSelected: "Select at least one duplicate link first.",
  noDuplicatesFound: "No duplicates found",
  noValidLinksFound: "No valid links found.",
  noUploadHappens: "Only local file reading is used. No upload happens.",
  driveSyncAppDataFolderOnly: "Drive sync uses only the hidden appDataFolder scope",
  driveSyncOptionalOffByDefault: "Google Drive sync is optional and off by default",
  onboardingDescription: "Aura Start keeps your groups and links local, editable, and exportable. Create your first group, add a link, or import an existing backup.",
  openLinksInNewTab: "Open links in new tab",
  openLinksInNewTabDescription: "When enabled, link cards and search results open in a new tab. When disabled, they open in the current tab.",
  openNewTab: "Open new tab",
  openOnboardingHelpAgain: "Open onboarding/help again",
  openSettings: "Open settings",
  optionalLayout: "Optional layout",
  optionalNote: "Optional note",
  pasteAFineStartCode: "Paste A Fine Start export code",
  pasteAFineStartPlaceholder: "Paste the code from A Fine Start Settings -> Export bookmarks",
  pasteAuraJson: "Paste Aura Start JSON",
  pasteFullBackupJson: "Paste a Full Backup JSON file here",
  pickImportData: "Choose a file or paste valid import data first.",
  pressEscToClear: "Press Esc to clear",
  pressSlashToSearch: "Press / to search",
  privacyPolicy: "Privacy Policy",
  privacyPromise: "Privacy Promise",
  possibleDuplicates: "Possible duplicates",
  projectDashboard: "Project dashboard",
  recoveryDescription: "The stored data did not pass validation. Aura Start will not overwrite it silently. Export the raw payload before resetting if you want to inspect or recover it manually.",
  recoveryTitle: "Aura Start could not load local data",
  removedMessage: '"{title}" was removed.',
  removeDemoData: "Remove demo data",
  removeDemoDataMessage: "This removes only demo groups and links tracked by Aura Start. User-created items with different IDs stay untouched.",
  renameGroup: "Rename group",
  renameGroupAria: "Rename {title}",
  replaceCurrentData: "Replace current data",
  replaceDescription: "Creates a restore point before replacing everything.",
  replace: "Replace",
  reviewImport: "Review import",
  restoreCurrentDataFirst: "A restore point of current data was created first.",
  resetAllData: "Reset all data",
  resetAllDataMessage: "This clears groups, links, and settings after creating a restore point.",
  resetAuraStart: "Reset Aura Start?",
  resetLocalData: "Reset local data",
  restore: "Restore",
  restorePointActionFailed: "Restore point action failed.",
  restorePointFailed: "Restore point failed.",
  restorePointImported: "Imported restore point",
  restorePointNotFound: "Restore point was not found.",
  restorePointRestored: "Restore point restored",
  restorePointCreatedBeforeDeletingDuplicates: "Restore point created before deleting duplicates",
  restorePoints: "Restore points",
  restorePointsDescription: "Aura Start keeps up to {count} local restore points before destructive operations. Export Full Backup JSON for long-term backup history.",
  restoreFromGoogleDriveOnboarding: "Restore from Google Drive",
  restoreReasonAuto: "auto",
  restoreReasonBeforeDelete: "before delete",
  restoreReasonBeforeImport: "before import",
  restoreReasonBeforeReset: "before reset",
  restoreReasonManual: "manual",
  restoreThisPoint: "Restore this point?",
  restoreThisPointMessage: "This will replace current groups and settings with the selected local restore point.",
  save: "Save",
  saveLink: "Save link",
  search: "Search",
  searchDescription: "Search checks titles, URLs, descriptions, and tags. Clear the search to return to all groups.",
  searchLinks: "Search links",
  searchModifiers: "Search modifiers",
  searchModifiersExamples: "Use tag:work, group:tools, url:github, or title:docs.",
  searchModifiersHint: "Modifiers: tag:work, group:tools, url:github, title:docs",
  searchMode: "Search mode",
  searchPlaceholder: "Search title, URL, description, tags",
  searchShortcuts: "Search shortcuts",
  selectedDuplicatesCount: "{count} selected",
  selectDuplicateLink: "Select duplicate link {title}",
  settings: "Settings",
  settingsDescription: "Tune layout, export data, and manage local recovery.",
  showDescriptions: "Show descriptions",
  showSearch: "Show search",
  shortcutClearSearch: "Clear search",
  shortcutCreateNewGroup: "Create new group",
  shortcutCreateNewLink: "Create new link",
  shortcutFocusSearch: "Focus search",
  shortcutOpenCommandPalette: "Open Command Palette",
  shortcutOpenSelectedResult: "Open selected result",
  shortcutToggleEditMode: "Toggle edit mode",
  startFresh: "Start fresh",
  startGroupTitle: "Start",
  storageCorrupt: "Stored data is corrupt.",
  storageFallbackNotice: "Development fallback storage is active because chrome.storage.local is unavailable.",
  storageNeedsRecovery: "Storage needs recovery",
  system: "System",
  tags: "Tags",
  tagsPlaceholder: "docs, work, design",
  theme: "Theme",
  title: "Title",
  tools: "Tools",
  typeACommand: "Type a command",
  undo: "Undo",
  unsafeUrlSkipped: "Unsafe URL skipped.",
  thisWouldRemoveAllCopies: "This would remove all copies in at least one duplicate set.",
  unavailableTitle: "Aura Start is unavailable",
  updateAutomaticRestoreSafety: "Automatic restore safety",
  url: "URL",
  urlHostRequired: "URL must include a valid host.",
  urlHttpOnly: "Only http and https links are allowed.",
  urlInvalidExample: "Enter a valid URL, for example https://example.com.",
  urlRequired: "URL is required.",
  groupTitleRequired: "Group title is required.",
  linkTitleRequired: "Link title is required.",
  restorePointNameRequired: "Restore point name is required.",
  validImport: "Valid import: {groups} groups, {links} links.",
  welcomeToAuraStart: "Welcome to Aura Start",
  onboardingFinishDescription: "You can change these choices later in Settings."
};
const translations = {
  en,
  ru: {
    ...en,
    actionFailed: "Действие не выполнено",
    add: "Добавить",
    addGroup: "Добавить группу",
    addLink: "Добавить ссылку",
    addLinkTo: "Добавить ссылку в {title}",
    aFineStartExportCode: "Код экспорта A Fine Start",
    aFineStartImported: "Импортировано из A Fine Start: {groups} групп, {links} ссылок",
    aFineStartImportStepCopy: "Скопируйте код экспорта.",
    aFineStartImportStepMode: "Выберите объединение или замену.",
    aFineStartImportStepOpen: "Откройте A Fine Start.",
    aFineStartImportStepPaste: "Вставьте код сюда.",
    aFineStartImportStepReview: "Проверьте preview, затем импортируйте.",
    aFineStartImportStepSettings: "Откройте Settings -> Export bookmarks.",
    aFineStartImportStepsTitle: "Импорт из A Fine Start",
    allRestorePointsDeleted: "Все точки восстановления удалены",
    auto: "Авто",
    auraStartBackupJson: "Полная JSON-резервная копия Aura Start",
    backupImported: "Резервная копия импортирована",
    backupMerged: "Резервная копия объединена",
    cancel: "Отмена",
    chooseImportFile: "Выберите JSON или файл с кодом экспорта",
    clearSearch: "Очистить поиск",
    closeDialog: "Закрыть окно",
    collapseGroup: "Свернуть {title}",
    columns: "Колонки",
    compactMode: "Компактный режим",
    couldNotCompleteAction: "Не удалось выполнить действие.",
    couldNotCreateGroupForLink: "Не удалось создать группу для этой ссылки.",
    couldNotCreateRestorePoint: "Не удалось создать точку восстановления.",
    couldNotDeleteLink: "Не удалось удалить ссылку.",
    couldNotExportBackup: "Не удалось экспортировать резервную копию.",
    couldNotLoadLocalData: "Не удалось загрузить локальные данные.",
    couldNotMoveLink: "Не удалось переместить ссылку.",
    couldNotParseImportData: "Не удалось разобрать данные импорта.",
    couldNotReadImportFile: "Не удалось прочитать файл импорта.",
    couldNotReorderGroups: "Не удалось изменить порядок групп.",
    couldNotResetLocalData: "Не удалось сбросить локальные данные.",
    couldNotSaveGroup: "Не удалось сохранить группу.",
    couldNotSaveLink: "Не удалось сохранить ссылку.",
    couldNotUpdateGroup: "Не удалось обновить группу.",
    couldNotUpdateSettings: "Не удалось обновить настройки.",
    create: "Создать",
    dark: "Тёмная",
    dataOwnership: "Владение данными",
    dataOwnershipDescription: "Всё хранится в локальном хранилище расширения Chromium. Экспортируйте данные в любой момент перед сменой браузера или профиля.",
    googleDriveAccountDisconnected: "Google-аккаунт отключён",
    googleDriveAccountDisconnectedDescription: "Aura Start снова работает только локально. Локальные данные не удалены.",
    googleDriveAlreadySynced: "Локальные данные и Google Drive уже синхронизированы.",
    googleDriveAutoSyncActive: "После подключения локальные изменения автоматически синхронизируются с Google Drive.",
    googleDriveBackingUp: "Создание копии в Google Drive...",
    googleDriveBackupDeletedAndAccountDisconnected: "Копия Google Drive удалена, аккаунт отключён",
    googleDriveBackupDeletedAndAccountDisconnectedDescription: "Aura Start удалил скрытый sync-файл в Google Drive и отключил Google-аккаунт. Локальные данные остались на этом устройстве.",
    googleDriveBackupDeleteFailedAccountDisconnected: "Aura Start отключил аккаунт локально без открытия окна входа Google, но не смог удалить копию Google Drive: {message}",
    googleDriveBackupSuccess: "Копия Google Drive сохранена",
    googleDriveBackupSuccessDescription: "Aura Start обновил скрытый sync-файл в данных приложения Google Drive.",
    googleDriveBackupToDrive: "Сохранить в Google Drive",
    googleDriveCloudNewer: "Облачная версия новее",
    googleDriveCloudNewerDescription: "Проверьте раздел синхронизации Google Drive и выберите восстановление из Google Drive, если хотите заменить локальные данные.",
    googleDriveConflictDescription: "Локальные данные и данные Google Drive изменились после последней синхронизации. Выберите, какая копия должна остаться.",
    googleDriveConflictDetected: "Обнаружен конфликт",
    googleDriveConflictTimes: "Локально: {local}. В облаке: {cloud}.",
    googleDriveConnect: "Подключить Google Drive",
    googleDriveConnected: "Google Drive подключён",
    googleDriveConnectedNoFile: "Google Drive подключён. Sync-файл пока не найден.",
    googleDriveConnectedShort: "Google Drive",
    googleDriveConnecting: "Подключение Google Drive...",
    googleDriveDeleteBackupAndDisconnect: "Удалить и отключить",
    googleDriveDeleteBackupAndDisconnectConfirm: "Удалить копию и отключить",
    googleDriveDeleteBackupAndDisconnectConfirmMessage: "Это удалит скрытую резервную копию Aura Start из данных приложения Google Drive и отключит Google-аккаунт от расширения. Локальные данные Aura Start останутся на этом устройстве. Aura Start не будет открывать окно входа Google при отключении; если авторизация уже недоступна, расширение отключится локально, а копия в Drive может остаться до повторного подключения.",
    googleDriveDeleteBackupAndDisconnecting: "Удаление копии Google Drive и отключение аккаунта...",
    googleDriveDeleteSyncFile: "Удалить sync-файл Google Drive",
    googleDriveDeleteSyncFileConfirmMessage: "Это удалит скрытый sync-файл Aura Start из данных приложения в Google Drive. Локальные данные Aura Start останутся на этом устройстве.",
    googleDriveDeletingSyncFile: "Удаление sync-файла Google Drive...",
    googleDriveDisconnectAccount: "Отключить Google-аккаунт",
    googleDriveDisconnectConfirmMessage: "Это отключит доступ Google-аккаунта от Aura Start. Локальные данные останутся на этом устройстве, а sync-файл Google Drive не будет удалён.",
    googleDriveDisconnecting: "Отключение Google-аккаунта...",
    googleDriveDisconnectedWithoutGoogleWindow: "Aura Start отключил аккаунт локально без открытия окна входа Google. Авторизация Google была недоступна, поэтому копия в Drive может остаться до повторного подключения и удаления.",
    googleDriveExportLocalBackup: "Сначала экспортировать локальный JSON",
    googleDriveGoogleWindow: "Подключение сразу открывает окно авторизации Google; вручную настраивать client ID в Aura Start не нужно.",
    googleDriveKeepCloud: "Оставить облако и заменить локальные данные",
    googleDriveKeepLocal: "Оставить локальные и загрузить в Drive",
    googleDriveLastCloudUpdate: "Облако обновлено: {time}",
    googleDriveLastSynced: "Последняя синхронизация: {time}",
    googleDriveLocalUploaded: "Локальная версия загружена в Google Drive.",
    googleDriveManualExportStillWorks: "Ручной JSON export/import продолжает работать независимо.",
    googleDriveMinimalScope: "Авторизация Google запрашивает только разрешение Drive app data, нужное для синхронизации Aura Start.",
    googleDriveNoFileUploadedLocal: "Sync-файла не было, поэтому Aura Start загрузил локальную копию.",
    googleDriveNoFullDrive: "Aura Start не запрашивает доступ ко всему Google Drive или видимым файлам Drive.",
    googleDriveNoBackupFoundAccountDisconnectedDescription: "Скрытый sync-файл Google Drive не найден. Aura Start отключил Google-аккаунт и оставил локальные данные на этом устройстве.",
    googleDriveNoTracking: "Aura Start не отслеживает, не сканирует и не профилирует ничего в вашем Google Drive.",
    googleDriveNoSyncFileCreated: "Sync-файл Google Drive не был найден и был создан",
    googleDriveNoSyncFileFound: "Sync-файл Google Drive не найден.",
    googleDriveNotConnected: "Не подключено",
    googleDriveNeedsReconnect: "Google Drive требует входа для продолжения синхронизации. Локальные изменения сохранены.",
    googleDriveReconnect: "Переподключить Google Drive",
    googleDriveRestoreFromDrive: "Восстановить из Google Drive",
    googleDriveRestoreSuccess: "Данные Google Drive восстановлены",
    googleDriveRestoreSuccessDescription: "Перед заменой локальных данных была создана локальная точка восстановления.",
    googleDriveRestoring: "Восстановление из Google Drive...",
    googleDriveSyncDescription: "Опциональная резервная копия и синхронизация через приватное скрытое хранилище данных приложения Google Drive.",
    googleDriveSyncDisabled: "Синхронизация выключена",
    googleDriveSyncFailed: "Синхронизация Google Drive не удалась",
    googleDriveSyncFileDeleted: "Sync-файл Google Drive удалён",
    googleDriveSyncFileDeletedDescription: "Удалён только скрытый файл Aura Start в appDataFolder. Локальные данные остались на этом устройстве.",
    googleDriveSyncFileFound: "Найден существующий sync-файл Google Drive.",
    googleDriveSyncFileFoundAndRestored: "Sync-файл Google Drive был найден и восстановлен.",
    googleDriveSyncing: "Синхронизация Google Drive...",
    googleDriveSyncMode: "Режим синхронизации",
    googleDriveSyncMode_auto: "Авто",
    googleDriveSyncMode_manual: "Вручную",
    googleDriveSyncMode_off: "Выключено",
    googleDriveSyncModeUpdated: "Режим синхронизации Google Drive обновлён.",
    googleDriveSyncOffByDefault: "Синхронизация выключена по умолчанию, а Aura Start сначала хранит данные локально.",
    googleDriveSyncTitle: "Синхронизация Google Drive",
    googleDriveSyncUsesAppData: "Sync-файл хранится только в скрытой Google Drive appDataFolder.",
    googleDriveTokenRevokeFailed: "Кэшированный токен удалён, но Google token revoke вернул ошибку: {message}",
    delete: "Удалить",
    deleteGroup: "Удалить группу",
    description: "Описание",
    deleteRestorePoint: "Удалить точку восстановления?",
    deleteRestorePointAria: "Удалить точку восстановления {name}",
    deleteRestorePointMessage: "Это удалит выбранную точку восстановления из локального хранилища.",
    deleteAllOldRestorePoints: "Удалить все старые точки восстановления",
    deleteAllRestorePointsMessage: "Это удалит все локальные точки восстановления. Текущие группы и ссылки не изменятся.",
    deleteThisGroup: "Удалить эту группу?",
    deleteThisGroupMessage: "Это удалит «{title}» и её ссылки после создания точки восстановления.",
    deleteThisGroupFallback: "эта группа",
    deleteThisLink: "Удалить эту ссылку?",
    deleteThisLinkMessage: "Это удалит «{title}». Если локальная запись пройдёт успешно, удаление можно будет отменить через уведомление.",
    deleteSelected: "Удалить выбранное",
    deleteSelectedDuplicates: "Удалить выбранные дубликаты?",
    deleteSelectedDuplicatesMessage: "Будет удалено выбранных ссылок-дубликатов: {count}. Перед удалением будет создана точка восстановления.",
    deleteGroupAria: "Удалить {title}",
    dismissNotification: "Закрыть уведомление",
    dragGroup: "Перетащить группу {title}",
    dragLink: "Перетащить {title}",
    duplicateFinder: "Поиск дубликатов",
    duplicateFinderDescription: "Сканирует локальные ссылки на дубликаты. Ничего не удаляется, пока вы не выберете ссылки и не подтвердите действие.",
    duplicateFinderNoMutation: "Сканирование read-only и не меняет локальные данные.",
    duplicateFinderReadOnly: "Сканирование read-only. Перед удалением выберите ссылки вручную.",
    duplicateLinksDeleted: "Удалено ссылок-дубликатов: {count}",
    duplicateReasonExactUrl: "Точный дубликат URL",
    duplicateReasonHostnameCase: "Тот же hostname с другим регистром",
    duplicateReasonHttpHttps: "Возможный http/https дубликат",
    duplicateReasonTrailingSlash: "Дубликат после удаления trailing slash",
    edit: "Правка",
    enableEditMode: "Включить режим правки",
    disableEditMode: "Выключить режим правки",
    editLink: "Редактировать ссылку",
    editLinkAria: "Редактировать {title}",
    emptyGroupButton: "Добавить первую ссылку",
    export: "Экспорт",
    exportAFineStartDescription: "Переход обратно в A Fine Start-compatible код импорта. Описания и теги Aura Start не включаются, если формат их не поддерживает.",
    exportAllData: "Экспортировать все данные",
    exportBackupBeforeImport: "Режим замены создаёт точку восстановления перед изменением локальных данных. Для дополнительной копии сначала экспортируйте backup.",
    exportBackupTitle: "Экспорт / Backup",
    exportCsvDescription: "Формат для таблиц и архива.",
    expandGroup: "Развернуть {title}",
    exportFailed: "Экспорт не удался",
    exportFormatFailed: "Экспорт {label} не удался.",
    exportHtmlDescription: "Импорт в закладки браузера.",
    exportJsonBackup: "Экспорт JSON-резервной копии",
    exportJsonDescription: "Полная резервная копия для восстановления и миграции.",
    exportMarkdownDescription: "Читаемый список по группам.",
    exportRawData: "Экспортировать сырые данные",
    exportRestorePoint: "Экспортировать точку восстановления",
    exportTrustMessage: "Экспорт создаётся локально в браузере. Aura Start не загружает ваши данные на сервер.",
    exactDuplicates: "Точные дубликаты",
    fullBackupJson: "Полная JSON-резервная копия",
    group: "Группа",
    groupDeleted: "Группа удалена",
    groupNotFound: "Группа не найдена.",
    groupsCount: "{count} групп",
    groupsLinksCount: "{groups} групп · {links} ссылок",
    groupTitlePlaceholder: "Дизайн, Работа, Чтение",
    hiThere: "Привет!",
    htmlBookmarks: "HTML закладок браузера",
    import: "Импорт",
    importBackup: "Импорт резервной копии",
    importBackupDescription: "Импортируйте резервные копии Aura Start или вставьте код экспорта A Fine Start. Данные проверяются до изменения локального хранилища.",
    importFailed: "Импорт не удался.",
    importFormat: "Формат импорта",
    importMode: "Режим импорта",
    importPreviewGroupsLinks: "{groups} групп, {links} ссылок",
    importPreviewMode: "Режим",
    importPreviewPayload: "Данные",
    importPreviewPotentialDuplicates: "Возможные дубликаты",
    importPreviewRejected: "Отклонено",
    importPreviewValid: "Валидный импорт",
    importPreviewWillAdd: "Будет импортировано",
    importReplaceConfirmAction: "Заменить данные",
    importReplaceConfirmMessage: "Это заменит текущие группы, ссылки и настройки после того, как Aura Start сначала создаст точку восстановления. Экспортируйте Full Backup JSON, если нужна дополнительная копия.",
    importReplaceConfirmTitle: "Заменить текущие данные Aura Start?",
    importRestorePointMessage: "Перед импортом была создана точка восстановления.",
    importWarnings: "Предупреждения импорта: {count}",
    invalidExportCode: "Некорректный код экспорта.",
    keyboardShortcuts: "Горячие клавиши",
    keepThis: "Оставить эту",
    inspiredBy: "Вдохновлено A Fine Start",
    brandSlogan: "Приватная local-first стартовая страница для ссылок - бесплатно, open-source и с простым экспортом",
    language: "Язык",
    light: "Светлая",
    linkDeleted: "Ссылка удалена",
    linksCount: "{count} ссылок",
    linkNotFound: "Ссылка не найдена.",
    loadingAuraStart: "Загрузка Aura Start...",
    loadingLocalData: "Загрузка локальных данных",
    localStorageCouldNotInitialize: "Не удалось инициализировать локальное хранилище.",
    manualCheckpoint: "Ручная точка",
    mergeDescription: "Добавляет импортированные группы и избегает конфликтов ID.",
    merge: "Объединить",
    mergeWithCurrentData: "Объединить с текущими данными",
    moreWarnings: "Ещё предупреждений: {count}.",
    newGroup: "Новая группа",
    newGroupTitle: "Название новой группы",
    noMatchingLinks: "Ничего не найдено",
    noAds: "Без рекламы",
    noAnalytics: "Без аналитики",
    noBackend: "Без серверной части",
    noBrowserBookmarksPermission: "Без разрешения на закладки браузера",
    noBrowserHistoryPermission: "Без разрешения на историю браузера",
    noRestorePoints: "Точек восстановления пока нет",
    noRestorePointsDescription: "Создайте её вручную, либо Aura Start создаст её перед импортом с заменой, удалением, сбросом, восстановлением и удалением дубликатов.",
    noRequiredAccount: "Аккаунт не требуется",
    noResults: "Нет результатов",
    noTracking: "Без отслеживания",
    noCommandsFound: "Команды не найдены",
    noDuplicateLinksSelected: "Сначала выберите хотя бы одну ссылку-дубликат.",
    noDuplicatesFound: "Дубликаты не найдены",
    noValidLinksFound: "Валидные ссылки не найдены.",
    noUploadHappens: "Используется только локальное чтение файла. Загрузки на сервер нет.",
    driveSyncAppDataFolderOnly: "Drive sync использует только скрытый appDataFolder scope",
    driveSyncOptionalOffByDefault: "Google Drive sync опционален и выключен по умолчанию",
    onboardingDescription: "Aura Start хранит группы и ссылки локально, позволяет редактировать их и экспортировать. Создайте первую группу, добавьте ссылку или импортируйте резервную копию.",
    openLinksInNewTab: "Открывать ссылки в новой вкладке",
    openLinksInNewTabDescription: "Если включено, карточки ссылок и результаты поиска открываются в новой вкладке. Если выключено, они открываются в текущей вкладке.",
    openNewTab: "Открыть новую вкладку",
    openSettings: "Открыть настройки",
    optionalNote: "Необязательная заметка",
    pasteAFineStartCode: "Вставьте код экспорта A Fine Start",
    pasteAFineStartPlaceholder: "Вставьте код из A Fine Start Settings -> Export bookmarks",
    pasteAuraJson: "Вставьте JSON Aura Start",
    pasteFullBackupJson: "Вставьте сюда полную JSON-резервную копию",
    pickImportData: "Сначала выберите файл или вставьте корректные данные импорта.",
    pressEscToClear: "Нажмите Esc, чтобы очистить",
    pressSlashToSearch: "Нажмите / для поиска",
    privacyPolicy: "Политика конфиденциальности",
    privacyPromise: "Обещание приватности",
    possibleDuplicates: "Возможные дубликаты",
    projectDashboard: "Панель проекта",
    recoveryDescription: "Сохранённые данные не прошли проверку. Aura Start не будет молча перезаписывать их. Экспортируйте сырые данные перед сбросом, если хотите изучить или восстановить их вручную.",
    recoveryTitle: "Aura Start не смог загрузить локальные данные",
    removedMessage: "«{title}» удалено.",
    renameGroup: "Переименовать группу",
    renameGroupAria: "Переименовать {title}",
    replaceCurrentData: "Заменить текущие данные",
    replaceDescription: "Создаёт точку восстановления перед полной заменой.",
    replace: "Заменить",
    reviewImport: "Проверить импорт",
    resetAllData: "Сбросить все данные",
    resetAllDataMessage: "Это очистит группы, ссылки и настройки после создания точки восстановления.",
    resetAuraStart: "Сбросить Aura Start?",
    resetLocalData: "Сбросить локальные данные",
    restore: "Восстановить",
    restoreCurrentDataFirst: "Сначала была создана точка восстановления текущих данных.",
    restorePointActionFailed: "Действие с точкой восстановления не удалось.",
    restorePointFailed: "Не удалось создать точку восстановления.",
    restorePointImported: "Импортированная точка восстановления",
    restorePointNotFound: "Точка восстановления не найдена.",
    restorePointRestored: "Точка восстановления применена",
    restorePointCreatedBeforeDeletingDuplicates: "Перед удалением дубликатов создана точка восстановления",
    restorePoints: "Точки восстановления",
    restorePointsDescription: "Aura Start хранит до {count} локальных точек восстановления перед опасными действиями. Для долгосрочной истории используйте экспорт Full Backup JSON.",
    restoreFromGoogleDriveOnboarding: "Загрузить из Google Drive",
    restoreReasonAuto: "авто",
    restoreReasonBeforeDelete: "перед удалением",
    restoreReasonBeforeImport: "перед импортом",
    restoreReasonBeforeReset: "перед сбросом",
    restoreReasonManual: "вручную",
    restoreThisPoint: "Восстановить эту точку?",
    restoreThisPointMessage: "Это заменит текущие группы и настройки выбранной локальной точкой восстановления.",
    save: "Сохранить",
    saveLink: "Сохранить ссылку",
    search: "Поиск",
    searchDescription: "Поиск проверяет названия, URL, описания и теги. Очистите поиск, чтобы вернуться ко всем группам.",
    searchLinks: "Поиск ссылок",
    searchModifiers: "Модификаторы поиска",
    searchModifiersExamples: "Используйте tag:work, group:tools, url:github или title:docs.",
    searchModifiersHint: "Модификаторы: tag:work, group:tools, url:github, title:docs",
    searchMode: "Режим поиска",
    searchPlaceholder: "Поиск по названию, URL, описанию, тегам",
    searchShortcuts: "Клавиши поиска",
    selectedDuplicatesCount: "Выбрано: {count}",
    selectDuplicateLink: "Выбрать дублирующуюся ссылку {title}",
    settings: "Настройки",
    settingsDescription: "Настройте вид, экспорт данных и локальное восстановление.",
    showDescriptions: "Показывать описания",
    showSearch: "Показывать поиск",
    shortcutClearSearch: "Очистить поиск",
    shortcutCreateNewGroup: "Создать группу",
    shortcutCreateNewLink: "Создать ссылку",
    shortcutFocusSearch: "Фокус на поиск",
    shortcutOpenCommandPalette: "Открыть палитру команд",
    shortcutOpenSelectedResult: "Открыть выбранный результат",
    shortcutToggleEditMode: "Переключить режим правки",
    startFresh: "Начать с нуля",
    startGroupTitle: "Старт",
    storageCorrupt: "Сохранённые данные повреждены.",
    storageFallbackNotice: "Активно fallback-хранилище для разработки, потому что chrome.storage.local недоступен.",
    storageNeedsRecovery: "Хранилище требует восстановления",
    system: "Системная",
    tags: "Теги",
    tagsPlaceholder: "документы, работа, дизайн",
    theme: "Тема",
    title: "Название",
    tools: "Инструменты",
    typeACommand: "Введите команду",
    undo: "Отменить",
    unsafeUrlSkipped: "Небезопасный URL пропущен.",
    thisWouldRemoveAllCopies: "Это удалит все копии как минимум в одном наборе дубликатов.",
    unavailableTitle: "Aura Start недоступен",
    updateAutomaticRestoreSafety: "Автоматические точки восстановления",
    addDemoGroups: "Добавить демо-группы",
    back: "Назад",
    chooseAppearance: "Выберите внешний вид",
    chooseHowToStart: "Выберите, как начать",
    comfortable: "Обычный",
    commandConnectGoogleDrive: "Подключить Google Drive",
    commandCreateNewGroup: "Создать группу",
    commandCreateNewLink: "Создать ссылку",
    commandDisconnectGoogleDrive: "Отключить Google Drive / удалить backup",
    commandExportBackup: "Экспортировать backup",
    commandFailed: "Команда не выполнена.",
    commandImportBackup: "Импортировать backup",
    commandImportFromAFineStart: "Импорт из A Fine Start",
    commandOpenDuplicateFinder: "Открыть поиск дубликатов",
    commandOpenKeyboardShortcuts: "Открыть горячие клавиши",
    commandOpenPrivacyPromise: "Открыть обещание приватности",
    commandOpenRestorePoints: "Открыть точки восстановления",
    commandOpenSettings: "Открыть настройки",
    commandOpensSettingsSection: "Открывает Settings, где можно проверить и подтвердить действие.",
    commandPalette: "Палитра команд",
    commandPaletteShortcutNote: "Ctrl+K/Cmd+K открывает палитру команд, если браузер назначил это сочетание Aura Start. Если оно не работает, проверьте chrome://extensions/shortcuts или используйте эту кнопку.",
    commandSearchLinks: "Искать ссылки",
    commandToggleEditMode: "Переключить режим правки",
    commandToggleTheme: "Переключить тему",
    compact: "Компактный",
    createYourFirstGroup: "Создать первую группу",
    finish: "Готово",
    importBackupFile: "Импортировать файл резервной копии",
    importFromAFineStart: "Импорт из A Fine Start",
    onboardingFinishDescription: "Эти настройки можно изменить позже.",
    openOnboardingHelpAgain: "Открыть onboarding/help снова",
    optionalLayout: "Дополнительная настройка вида",
    removeDemoData: "Удалить демо-данные",
    removeDemoDataMessage: "Будут удалены только демо-группы и ссылки, которые отслеживает Aura Start. Пользовательские элементы с другими ID останутся.",
    validImport: "Корректный импорт: {groups} групп, {links} ссылок.",
    welcomeToAuraStart: "Добро пожаловать в Aura Start",
    ...translationCompletions.ru
  },
  es: {
    ...en,
    actionFailed: "La acción falló",
    add: "Añadir",
    addGroup: "Añadir grupo",
    addLink: "Añadir enlace",
    addLinkTo: "Añadir enlace a {title}",
    aFineStartExportCode: "Código de exportación de A Fine Start",
    auto: "Auto",
    auraStartBackupJson: "Copia completa JSON de Aura Start",
    backupImported: "Copia importada",
    backupMerged: "Copia combinada",
    cancel: "Cancelar",
    chooseImportFile: "Elegir archivo JSON/código de exportación",
    clearSearch: "Borrar búsqueda",
    closeDialog: "Cerrar diálogo",
    collapseGroup: "Contraer {title}",
    columns: "Columnas",
    compactMode: "Modo compacto",
    couldNotCompleteAction: "No se pudo completar esta acción.",
    couldNotCreateGroupForLink: "No se pudo crear un grupo para este enlace.",
    couldNotCreateRestorePoint: "No se pudo crear el punto de restauración.",
    couldNotDeleteLink: "No se pudo eliminar el enlace.",
    couldNotExportBackup: "No se pudo exportar la copia.",
    couldNotLoadLocalData: "No se pudieron cargar los datos locales.",
    couldNotMoveLink: "No se pudo mover el enlace.",
    couldNotParseImportData: "No se pudieron leer estos datos de importación.",
    couldNotReadImportFile: "No se pudo leer este archivo de importación.",
    couldNotReorderGroups: "No se pudieron reordenar los grupos.",
    couldNotResetLocalData: "No se pudieron restablecer los datos locales.",
    couldNotSaveGroup: "No se pudo guardar el grupo.",
    couldNotSaveLink: "No se pudo guardar el enlace.",
    couldNotUpdateGroup: "No se pudo actualizar el grupo.",
    couldNotUpdateSettings: "No se pudieron actualizar los ajustes.",
    create: "Crear",
    dark: "Oscuro",
    dataOwnership: "Propiedad de los datos",
    dataOwnershipDescription: "Todo se guarda en el almacenamiento local de la extensión de Chromium. Exporta cuando quieras antes de cambiar de navegador o perfil.",
    googleDriveNoSyncFileCreated: "No se encontró el archivo de sincronización de Google Drive y se creó.",
    googleDriveSyncFileFoundAndRestored: "Se encontró el archivo de sincronización de Google Drive y se restauró.",
    delete: "Eliminar",
    deleteGroup: "Eliminar grupo",
    description: "Descripción",
    deleteRestorePoint: "¿Eliminar punto de restauración?",
    deleteRestorePointMessage: "Esto elimina el punto de restauración seleccionado del almacenamiento local.",
    deleteThisGroup: "¿Eliminar este grupo?",
    deleteThisGroupMessage: 'Esto elimina "{title}" y sus enlaces después de crear un punto de restauración.',
    deleteThisGroupFallback: "este grupo",
    deleteSelectedDuplicates: "¿Eliminar duplicados seleccionados?",
    deleteSelectedDuplicatesMessage: "Esto eliminará {count} enlaces duplicados seleccionados después de crear un punto de restauración.",
    dismissNotification: "Descartar notificación",
    dragGroup: "Arrastrar grupo {title}",
    dragLink: "Arrastrar {title}",
    duplicateFinder: "Buscador de duplicados",
    duplicateFinderDescription: "Escanea los enlaces locales en busca de duplicados. Nada se elimina hasta que selecciones enlaces y confirmes.",
    duplicateFinderNoMutation: "El escaneo es de solo lectura y no cambia los datos locales.",
    duplicateFinderReadOnly: "El escaneo es de solo lectura. Selecciona enlaces manualmente antes de eliminar algo.",
    duplicateLinksDeleted: "{count} enlaces duplicados eliminados",
    duplicateReasonExactUrl: "Duplicado exacto de URL",
    duplicateReasonHostnameCase: "Mismo nombre de host con mayúsculas/minúsculas diferentes",
    duplicateReasonHttpHttps: "Posible duplicado http/https",
    duplicateReasonTrailingSlash: "Duplicado tras quitar la barra final",
    edit: "Editar",
    enableEditMode: "Activar modo de edición",
    disableEditMode: "Desactivar modo de edición",
    editLink: "Editar enlace",
    editLinkAria: "Editar {title}",
    emptyGroupButton: "Añadir el primer enlace",
    export: "Exportar",
    expandGroup: "Expandir {title}",
    exportFailed: "La exportación falló",
    exportFormatFailed: "Falló la exportación de {label}.",
    exportJsonBackup: "Exportar copia JSON",
    exportRawData: "Exportar datos sin procesar",
    exactDuplicates: "Duplicados exactos",
    fullBackupJson: "Copia completa JSON",
    group: "Grupo",
    groupDeleted: "Grupo eliminado",
    groupsCount: "{count} grupos",
    groupsLinksCount: "{groups} grupos · {links} enlaces",
    groupTitlePlaceholder: "Diseño, Trabajo, Lectura",
    hiThere: "¡Hola!",
    htmlBookmarks: "HTML de marcadores del navegador",
    import: "Importar",
    importBackup: "Importar copia",
    importFormat: "Formato de importación",
    importMode: "Modo de importación",
    importRestorePointMessage: "Se creó un punto de restauración antes de importar.",
    importWarnings: "Advertencias de importación: {count}",
    inspiredBy: "Inspirado en A Fine Start",
    brandSlogan: "Una página de inicio privada y local-first para tus enlaces - gratis, open-source y fácil de exportar",
    language: "Idioma",
    light: "Claro",
    linkDeleted: "Enlace eliminado",
    linksCount: "{count} enlaces",
    loadingAuraStart: "Cargando Aura Start...",
    loadingLocalData: "Cargando datos locales",
    manualCheckpoint: "Punto manual",
    mergeDescription: "Añade los grupos importados y evita conflictos de ID.",
    mergeWithCurrentData: "Combinar con los datos actuales",
    moreWarnings: "{count} advertencias más.",
    newGroup: "Nuevo grupo",
    newGroupTitle: "Título del nuevo grupo",
    noDuplicateLinksSelected: "Selecciona primero al menos un enlace duplicado.",
    noDuplicatesFound: "No se encontraron duplicados",
    noMatchingLinks: "No hay enlaces coincidentes",
    noRestorePoints: "Aún no hay puntos de restauración",
    onboardingDescription: "Aura Start mantiene tus grupos y enlaces locales, editables y exportables. Crea tu primer grupo, añade un enlace o importa una copia existente.",
    openLinksInNewTab: "Abrir enlaces en una pestaña nueva",
    openNewTab: "Abrir nueva pestaña",
    openSettings: "Abrir ajustes",
    optionalNote: "Nota opcional",
    pasteAFineStartCode: "Pega el código de exportación de A Fine Start",
    pasteAuraJson: "Pega JSON de Aura Start",
    pasteFullBackupJson: "Pega aquí una copia completa JSON",
    pickImportData: "Primero elige un archivo o pega datos de importación válidos.",
    possibleDuplicates: "Posibles duplicados",
    projectDashboard: "Panel de proyecto",
    recoveryTitle: "Aura Start no pudo cargar los datos locales",
    removedMessage: '"{title}" se eliminó.',
    renameGroup: "Renombrar grupo",
    replaceCurrentData: "Reemplazar datos actuales",
    replaceDescription: "Crea un punto de restauración antes de reemplazar todo.",
    resetAllData: "Restablecer todos los datos",
    resetAuraStart: "¿Restablecer Aura Start?",
    resetLocalData: "Restablecer datos locales",
    restore: "Restaurar",
    restorePoints: "Puntos de restauración",
    restoreReasonAuto: "auto",
    restoreReasonBeforeDelete: "antes de eliminar",
    restoreReasonBeforeImport: "antes de importar",
    restoreReasonBeforeReset: "antes de restablecer",
    restoreReasonManual: "manual",
    restorePointCreatedBeforeDeletingDuplicates: "Punto de restauración creado antes de eliminar duplicados",
    save: "Guardar",
    saveLink: "Guardar enlace",
    search: "Buscar",
    searchDescription: "La búsqueda revisa títulos, URL, descripciones y etiquetas. Borra la búsqueda para volver a todos los grupos.",
    searchLinks: "Buscar enlaces",
    searchMode: "Modo de búsqueda",
    selectedDuplicatesCount: "{count} seleccionados",
    selectDuplicateLink: "Seleccionar enlace duplicado {title}",
    settings: "Ajustes",
    settingsDescription: "Ajusta el diseño, exporta datos y gestiona la recuperación local.",
    showDescriptions: "Mostrar descripciones",
    showSearch: "Mostrar búsqueda",
    startFresh: "Empezar desde cero",
    startGroupTitle: "Inicio",
    storageNeedsRecovery: "El almacenamiento necesita recuperación",
    system: "Sistema",
    tags: "Etiquetas",
    tagsPlaceholder: "documentos, trabajo, diseño",
    theme: "Tema",
    thisWouldRemoveAllCopies: "Esto eliminaría todas las copias en al menos un conjunto de duplicados.",
    title: "Título",
    undo: "Deshacer",
    unavailableTitle: "Aura Start no está disponible",
    updateAutomaticRestoreSafety: "Seguridad de restauración automática",
    addDemoGroups: "Añadir grupos de demo",
    back: "Atrás",
    chooseAppearance: "Elige apariencia",
    chooseHowToStart: "Elige cómo empezar",
    comfortable: "Cómodo",
    commandOpenDuplicateFinder: "Abrir buscador de duplicados",
    compact: "Compacto",
    createYourFirstGroup: "Crea tu primer grupo",
    finish: "Finalizar",
    importBackupFile: "Importar archivo de copia",
    importFromAFineStart: "Importar desde A Fine Start",
    onboardingFinishDescription: "Puedes cambiar estas opciones más tarde en Ajustes.",
    openOnboardingHelpAgain: "Abrir onboarding/ayuda otra vez",
    optionalLayout: "Diseño opcional",
    removeDemoData: "Eliminar datos de demo",
    removeDemoDataMessage: "Esto elimina solo grupos y enlaces de demo rastreados por Aura Start. Los elementos del usuario con otros ID no se tocan.",
    welcomeToAuraStart: "Bienvenido a Aura Start",
    ...translationCompletions.es
  },
  de: {
    ...en,
    actionFailed: "Aktion fehlgeschlagen",
    add: "Hinzufügen",
    addGroup: "Gruppe hinzufügen",
    addLink: "Link hinzufügen",
    aFineStartExportCode: "A Fine Start Exportcode",
    auto: "Auto",
    auraStartBackupJson: "Vollständiges Aura Start JSON-Backup",
    backupImported: "Backup importiert",
    backupMerged: "Backup zusammengeführt",
    cancel: "Abbrechen",
    chooseImportFile: "JSON-/Exportcode-Datei auswählen",
    collapseGroup: "{title} zuklappen",
    columns: "Spalten",
    compactMode: "Kompakter Modus",
    create: "Erstellen",
    dark: "Dunkel",
    dataOwnership: "Dateneigentum",
    dataOwnershipDescription: "Alles wird lokal im Chromium-Erweiterungsspeicher gespeichert. Exportiere jederzeit, bevor du Browser oder Profile wechselst.",
    googleDriveNoSyncFileCreated: "Die Google Drive-Sync-Datei wurde nicht gefunden und erstellt.",
    googleDriveSyncFileFoundAndRestored: "Die Google Drive-Sync-Datei wurde gefunden und wiederhergestellt.",
    delete: "Löschen",
    deleteGroup: "Gruppe löschen",
    description: "Beschreibung",
    deleteRestorePoint: "Wiederherstellungspunkt löschen?",
    deleteThisGroup: "Diese Gruppe löschen?",
    deleteSelectedDuplicates: "Ausgewählte Duplikate löschen?",
    deleteSelectedDuplicatesMessage: "Dies löscht {count} ausgewählte doppelte Links, nachdem ein Wiederherstellungspunkt erstellt wurde.",
    dismissNotification: "Benachrichtigung schließen",
    duplicateFinder: "Duplikatsuche",
    duplicateFinderDescription: "Durchsucht lokale Links nach Duplikaten. Nichts wird gelöscht, bis du Links auswählst und bestätigst.",
    duplicateFinderNoMutation: "Der Scan ist schreibgeschützt und ändert keine lokalen Daten.",
    duplicateFinderReadOnly: "Der Scan ist schreibgeschützt. Wähle Links vor dem Löschen manuell aus.",
    duplicateLinksDeleted: "{count} doppelte Links gelöscht",
    duplicateReasonExactUrl: "Exaktes URL-Duplikat",
    duplicateReasonHostnameCase: "Gleicher Hostname mit anderer Groß-/Kleinschreibung",
    duplicateReasonHttpHttps: "Mögliches http/https-Duplikat",
    duplicateReasonTrailingSlash: "Duplikat nach Entfernen des abschließenden Schrägstrichs",
    edit: "Bearbeiten",
    enableEditMode: "Bearbeitungsmodus aktivieren",
    disableEditMode: "Bearbeitungsmodus deaktivieren",
    emptyGroupButton: "Ersten Link hinzufügen",
    export: "Exportieren",
    expandGroup: "{title} aufklappen",
    exportFailed: "Export fehlgeschlagen",
    exportJsonBackup: "JSON-Backup exportieren",
    exportRawData: "Rohdaten exportieren",
    exactDuplicates: "Exakte Duplikate",
    fullBackupJson: "Vollständiges JSON-Backup",
    group: "Gruppe",
    groupDeleted: "Gruppe gelöscht",
    groupsCount: "{count} Gruppen",
    groupsLinksCount: "{groups} Gruppen · {links} Links",
    groupTitlePlaceholder: "Design, Arbeit, Lesen",
    hiThere: "Hallo!",
    htmlBookmarks: "Browser-Lesezeichen HTML",
    import: "Importieren",
    importBackup: "Backup importieren",
    importFormat: "Importformat",
    importMode: "Importmodus",
    importRestorePointMessage: "Vor dem Import wurde ein Wiederherstellungspunkt erstellt.",
    importWarnings: "Importwarnungen: {count}",
    inspiredBy: "Inspiriert von A Fine Start",
    brandSlogan: "Eine private, local-first Startseite für deine Links - kostenlos, open-source und leicht zu exportieren",
    language: "Sprache",
    light: "Hell",
    linkDeleted: "Link gelöscht",
    linksCount: "{count} Links",
    loadingAuraStart: "Aura Start wird geladen...",
    loadingLocalData: "Lokale Daten werden geladen",
    manualCheckpoint: "Manueller Prüfpunkt",
    mergeWithCurrentData: "Mit aktuellen Daten zusammenführen",
    newGroup: "Neue Gruppe",
    noDuplicateLinksSelected: "Wähle zuerst mindestens einen doppelten Link aus.",
    noDuplicatesFound: "Keine Duplikate gefunden",
    noMatchingLinks: "Keine passenden Links",
    noRestorePoints: "Noch keine Wiederherstellungspunkte",
    onboardingDescription: "Aura Start hält deine Gruppen und Links lokal, bearbeitbar und exportierbar. Erstelle deine erste Gruppe, füge einen Link hinzu oder importiere ein vorhandenes Backup.",
    openLinksInNewTab: "Links in neuem Tab öffnen",
    openNewTab: "Neuen Tab öffnen",
    openSettings: "Einstellungen öffnen",
    pasteAFineStartCode: "A Fine Start Exportcode einfügen",
    pasteAuraJson: "Aura Start JSON einfügen",
    pasteFullBackupJson: "Vollständiges JSON-Backup hier einfügen",
    possibleDuplicates: "Mögliche Duplikate",
    projectDashboard: "Projektübersicht",
    recoveryTitle: "Aura Start konnte lokale Daten nicht laden",
    renameGroup: "Gruppe umbenennen",
    replaceCurrentData: "Aktuelle Daten ersetzen",
    resetAllData: "Alle Daten zurücksetzen",
    resetAuraStart: "Aura Start zurücksetzen?",
    resetLocalData: "Lokale Daten zurücksetzen",
    restore: "Wiederherstellen",
    restorePoints: "Wiederherstellungspunkte",
    restoreReasonAuto: "automatisch",
    restoreReasonBeforeDelete: "vor dem Löschen",
    restoreReasonBeforeImport: "vor dem Import",
    restoreReasonBeforeReset: "vor dem Zurücksetzen",
    restoreReasonManual: "manuell",
    restorePointCreatedBeforeDeletingDuplicates: "Wiederherstellungspunkt vor dem Löschen von Duplikaten erstellt",
    save: "Speichern",
    saveLink: "Link speichern",
    search: "Suchen",
    searchLinks: "Links suchen",
    searchMode: "Suchmodus",
    selectedDuplicatesCount: "{count} ausgewählt",
    selectDuplicateLink: "Doppelten Link {title} auswählen",
    settings: "Einstellungen",
    showDescriptions: "Beschreibungen anzeigen",
    showSearch: "Suche anzeigen",
    startFresh: "Neu starten",
    startGroupTitle: "Start",
    storageNeedsRecovery: "Speicher muss wiederhergestellt werden",
    system: "System",
    tags: "Tags",
    tagsPlaceholder: "dokumente, arbeit, design",
    theme: "Design",
    thisWouldRemoveAllCopies: "Dies würde alle Kopien in mindestens einem Duplikatset entfernen.",
    title: "Titel",
    undo: "Rückgängig",
    unavailableTitle: "Aura Start ist nicht verfügbar",
    addDemoGroups: "Demo-Gruppen hinzufügen",
    back: "Zurück",
    chooseAppearance: "Darstellung wählen",
    chooseHowToStart: "Startoption wählen",
    comfortable: "Komfortabel",
    commandOpenDuplicateFinder: "Duplikatsuche öffnen",
    compact: "Kompakt",
    createYourFirstGroup: "Erste Gruppe erstellen",
    finish: "Fertig",
    importBackupFile: "Backup-Datei importieren",
    importFromAFineStart: "Aus A Fine Start importieren",
    onboardingFinishDescription: "Du kannst diese Auswahl später in den Einstellungen ändern.",
    openOnboardingHelpAgain: "Onboarding/Hilfe erneut öffnen",
    optionalLayout: "Optionales Layout",
    removeDemoData: "Demo-Daten entfernen",
    removeDemoDataMessage: "Es werden nur Demo-Gruppen und Links entfernt, die Aura Start verfolgt. Benutzerelemente mit anderen IDs bleiben erhalten.",
    welcomeToAuraStart: "Willkommen bei Aura Start",
    ...translationCompletions.de
  },
  fr: {
    ...en,
    actionFailed: "Action échouée",
    add: "Ajouter",
    addGroup: "Ajouter un groupe",
    addLink: "Ajouter un lien",
    aFineStartExportCode: "Code d’export A Fine Start",
    auto: "Auto",
    auraStartBackupJson: "Sauvegarde JSON complète Aura Start",
    backupImported: "Sauvegarde importée",
    backupMerged: "Sauvegarde fusionnée",
    cancel: "Annuler",
    chooseImportFile: "Choisir un fichier JSON/code d’export",
    collapseGroup: "Replier {title}",
    columns: "Colonnes",
    compactMode: "Mode compact",
    create: "Créer",
    dark: "Sombre",
    dataOwnership: "Propriété des données",
    dataOwnershipDescription: "Tout est stocké localement dans le stockage de l’extension Chromium. Exportez quand vous voulez avant de changer de navigateur ou de profil.",
    googleDriveNoSyncFileCreated: "Le fichier de synchronisation Google Drive était introuvable et a été créé.",
    googleDriveSyncFileFoundAndRestored: "Le fichier de synchronisation Google Drive a été trouvé et restauré.",
    delete: "Supprimer",
    deleteGroup: "Supprimer le groupe",
    description: "Description",
    deleteRestorePoint: "Supprimer le point de restauration ?",
    deleteThisGroup: "Supprimer ce groupe ?",
    deleteSelectedDuplicates: "Supprimer les doublons sélectionnés ?",
    deleteSelectedDuplicatesMessage: "Cela supprimera {count} liens en double sélectionnés après la création d’un point de restauration.",
    dismissNotification: "Fermer la notification",
    duplicateFinder: "Recherche de doublons",
    duplicateFinderDescription: "Analyse les liens locaux pour trouver les doublons. Rien n’est supprimé tant que vous ne sélectionnez pas de liens et ne confirmez pas.",
    duplicateFinderNoMutation: "L’analyse est en lecture seule et ne modifie pas les données locales.",
    duplicateFinderReadOnly: "L’analyse est en lecture seule. Sélectionnez les liens manuellement avant de supprimer quoi que ce soit.",
    duplicateLinksDeleted: "{count} liens en double supprimés",
    duplicateReasonExactUrl: "Doublon exact d’URL",
    duplicateReasonHostnameCase: "Même nom d’hôte avec une casse différente",
    duplicateReasonHttpHttps: "Doublon http/https possible",
    duplicateReasonTrailingSlash: "Doublon après suppression de la barre oblique finale",
    edit: "Modifier",
    enableEditMode: "Activer le mode édition",
    disableEditMode: "Désactiver le mode édition",
    emptyGroupButton: "Ajouter le premier lien",
    export: "Exporter",
    expandGroup: "Développer {title}",
    exportFailed: "Échec de l’export",
    exportJsonBackup: "Exporter la sauvegarde JSON",
    exportRawData: "Exporter les données brutes",
    exactDuplicates: "Doublons exacts",
    fullBackupJson: "Sauvegarde JSON complète",
    group: "Groupe",
    groupDeleted: "Groupe supprimé",
    groupsCount: "{count} groupes",
    groupsLinksCount: "{groups} groupes · {links} liens",
    groupTitlePlaceholder: "Design, Travail, Lecture",
    hiThere: "Bonjour !",
    htmlBookmarks: "HTML des favoris du navigateur",
    import: "Importer",
    importBackup: "Importer une sauvegarde",
    importFormat: "Format d’import",
    importMode: "Mode d’import",
    importRestorePointMessage: "Un point de restauration a été créé avant l’import.",
    importWarnings: "Avertissements d’import : {count}",
    inspiredBy: "Inspiré par A Fine Start",
    brandSlogan: "Une page de démarrage privée et local-first pour vos liens - gratuite, open-source et facile à exporter",
    language: "Langue",
    light: "Clair",
    linkDeleted: "Lien supprimé",
    linksCount: "{count} liens",
    loadingAuraStart: "Chargement d’Aura Start...",
    loadingLocalData: "Chargement des données locales",
    manualCheckpoint: "Point manuel",
    mergeWithCurrentData: "Fusionner avec les données actuelles",
    newGroup: "Nouveau groupe",
    noDuplicateLinksSelected: "Sélectionnez d’abord au moins un lien en double.",
    noDuplicatesFound: "Aucun doublon trouvé",
    noMatchingLinks: "Aucun lien correspondant",
    noRestorePoints: "Aucun point de restauration pour le moment",
    onboardingDescription: "Aura Start garde vos groupes et liens en local, modifiables et exportables. Créez votre premier groupe, ajoutez un lien ou importez une sauvegarde existante.",
    openLinksInNewTab: "Ouvrir les liens dans un nouvel onglet",
    openNewTab: "Ouvrir un nouvel onglet",
    openSettings: "Ouvrir les paramètres",
    pasteAFineStartCode: "Coller le code d’export A Fine Start",
    pasteAuraJson: "Coller le JSON Aura Start",
    pasteFullBackupJson: "Collez ici une sauvegarde JSON complète",
    possibleDuplicates: "Doublons possibles",
    projectDashboard: "Tableau de bord du projet",
    recoveryTitle: "Aura Start n’a pas pu charger les données locales",
    renameGroup: "Renommer le groupe",
    replaceCurrentData: "Remplacer les données actuelles",
    resetAllData: "Réinitialiser toutes les données",
    resetAuraStart: "Réinitialiser Aura Start ?",
    resetLocalData: "Réinitialiser les données locales",
    restore: "Restaurer",
    restorePoints: "Points de restauration",
    restoreReasonAuto: "auto",
    restoreReasonBeforeDelete: "avant suppression",
    restoreReasonBeforeImport: "avant import",
    restoreReasonBeforeReset: "avant réinitialisation",
    restoreReasonManual: "manuel",
    restorePointCreatedBeforeDeletingDuplicates: "Point de restauration créé avant la suppression des doublons",
    save: "Enregistrer",
    saveLink: "Enregistrer le lien",
    search: "Rechercher",
    searchLinks: "Rechercher des liens",
    searchMode: "Mode recherche",
    selectedDuplicatesCount: "{count} sélectionnés",
    selectDuplicateLink: "Sélectionner le lien en double {title}",
    settings: "Paramètres",
    showDescriptions: "Afficher les descriptions",
    showSearch: "Afficher la recherche",
    startFresh: "Commencer à zéro",
    startGroupTitle: "Départ",
    storageNeedsRecovery: "Le stockage doit être récupéré",
    system: "Système",
    tags: "Étiquettes",
    tagsPlaceholder: "docs, travail, design",
    theme: "Thème",
    thisWouldRemoveAllCopies: "Cela supprimerait toutes les copies dans au moins un ensemble de doublons.",
    title: "Titre",
    undo: "Annuler",
    unavailableTitle: "Aura Start est indisponible",
    addDemoGroups: "Ajouter des groupes de démonstration",
    back: "Retour",
    chooseAppearance: "Choisir l’apparence",
    chooseHowToStart: "Choisir comment commencer",
    comfortable: "Confortable",
    commandOpenDuplicateFinder: "Ouvrir la recherche de doublons",
    compact: "Compact",
    createYourFirstGroup: "Créer votre premier groupe",
    finish: "Terminer",
    importBackupFile: "Importer un fichier de sauvegarde",
    importFromAFineStart: "Importer depuis A Fine Start",
    onboardingFinishDescription: "Vous pouvez modifier ces choix plus tard dans les paramètres.",
    openOnboardingHelpAgain: "Rouvrir l’onboarding/l’aide",
    optionalLayout: "Disposition optionnelle",
    removeDemoData: "Supprimer les données de démonstration",
    removeDemoDataMessage: "Cela supprime uniquement les groupes et liens de démonstration suivis par Aura Start. Les éléments utilisateur avec d’autres ID restent intacts.",
    welcomeToAuraStart: "Bienvenue dans Aura Start",
    ...translationCompletions.fr
  },
  pt: {
    ...en,
    actionFailed: "Ação falhou",
    add: "Adicionar",
    addGroup: "Adicionar grupo",
    addLink: "Adicionar link",
    aFineStartExportCode: "Código de exportação do A Fine Start",
    auto: "Auto",
    auraStartBackupJson: "Backup JSON completo do Aura Start",
    backupImported: "Backup importado",
    backupMerged: "Backup mesclado",
    cancel: "Cancelar",
    chooseImportFile: "Escolher arquivo JSON/código de exportação",
    collapseGroup: "Recolher {title}",
    columns: "Colunas",
    compactMode: "Modo compacto",
    create: "Criar",
    dark: "Escuro",
    dataOwnership: "Propriedade dos dados",
    dataOwnershipDescription: "Tudo fica armazenado no armazenamento local da extensão Chromium. Exporte a qualquer momento antes de trocar de navegador ou perfil.",
    googleDriveNoSyncFileCreated: "O arquivo de sincronização do Google Drive não foi encontrado e foi criado.",
    googleDriveSyncFileFoundAndRestored: "O arquivo de sincronização do Google Drive foi encontrado e restaurado.",
    delete: "Excluir",
    deleteGroup: "Excluir grupo",
    description: "Descrição",
    deleteRestorePoint: "Excluir ponto de restauração?",
    deleteThisGroup: "Excluir este grupo?",
    deleteSelectedDuplicates: "Excluir duplicados selecionados?",
    deleteSelectedDuplicatesMessage: "Isso excluirá {count} links duplicados selecionados depois de criar um ponto de restauração.",
    dismissNotification: "Dispensar notificação",
    duplicateFinder: "Busca de duplicados",
    duplicateFinderDescription: "Verifica links locais em busca de duplicados. Nada é excluído até você selecionar links e confirmar.",
    duplicateFinderNoMutation: "A verificação é somente leitura e não altera os dados locais.",
    duplicateFinderReadOnly: "A verificação é somente leitura. Selecione links manualmente antes de excluir qualquer coisa.",
    duplicateLinksDeleted: "{count} links duplicados excluídos",
    duplicateReasonExactUrl: "Duplicado exato de URL",
    duplicateReasonHostnameCase: "Mesmo nome de host com maiúsculas/minúsculas diferentes",
    duplicateReasonHttpHttps: "Possível duplicado http/https",
    duplicateReasonTrailingSlash: "Duplicado após remover a barra final",
    edit: "Editar",
    enableEditMode: "Ativar modo de edição",
    disableEditMode: "Desativar modo de edição",
    emptyGroupButton: "Adicionar o primeiro link",
    export: "Exportar",
    expandGroup: "Expandir {title}",
    exportFailed: "Falha na exportação",
    exportJsonBackup: "Exportar backup JSON",
    exportRawData: "Exportar dados brutos",
    exactDuplicates: "Duplicados exatos",
    fullBackupJson: "Backup JSON completo",
    group: "Grupo",
    groupDeleted: "Grupo excluído",
    groupsCount: "{count} grupos",
    groupsLinksCount: "{groups} grupos · {links} links",
    groupTitlePlaceholder: "Design, Trabalho, Leitura",
    hiThere: "Olá!",
    htmlBookmarks: "HTML de favoritos do navegador",
    import: "Importar",
    importBackup: "Importar backup",
    importFormat: "Formato de importação",
    importMode: "Modo de importação",
    importRestorePointMessage: "Um ponto de restauração foi criado antes da importação.",
    importWarnings: "Avisos de importação: {count}",
    inspiredBy: "Inspirado por A Fine Start",
    brandSlogan: "Uma página inicial privada e local-first para seus links - grátis, open-source e fácil de exportar",
    language: "Idioma",
    light: "Claro",
    linkDeleted: "Link excluído",
    linksCount: "{count} links",
    loadingAuraStart: "Carregando Aura Start...",
    loadingLocalData: "Carregando dados locais",
    manualCheckpoint: "Ponto manual",
    mergeWithCurrentData: "Mesclar com os dados atuais",
    newGroup: "Novo grupo",
    noDuplicateLinksSelected: "Selecione pelo menos um link duplicado primeiro.",
    noDuplicatesFound: "Nenhum duplicado encontrado",
    noMatchingLinks: "Nenhum link encontrado",
    noRestorePoints: "Ainda não há pontos de restauração",
    onboardingDescription: "Aura Start mantém seus grupos e links locais, editáveis e exportáveis. Crie seu primeiro grupo, adicione um link ou importe um backup existente.",
    openLinksInNewTab: "Abrir links em nova guia",
    openNewTab: "Abrir nova guia",
    openSettings: "Abrir configurações",
    pasteAFineStartCode: "Cole o código de exportação do A Fine Start",
    pasteAuraJson: "Cole o JSON do Aura Start",
    pasteFullBackupJson: "Cole aqui um backup JSON completo",
    possibleDuplicates: "Possíveis duplicados",
    projectDashboard: "Painel do projeto",
    recoveryTitle: "Aura Start não conseguiu carregar os dados locais",
    renameGroup: "Renomear grupo",
    replaceCurrentData: "Substituir dados atuais",
    resetAllData: "Redefinir todos os dados",
    resetAuraStart: "Redefinir Aura Start?",
    resetLocalData: "Redefinir dados locais",
    restore: "Restaurar",
    restorePoints: "Pontos de restauração",
    restoreReasonAuto: "auto",
    restoreReasonBeforeDelete: "antes de excluir",
    restoreReasonBeforeImport: "antes de importar",
    restoreReasonBeforeReset: "antes de redefinir",
    restoreReasonManual: "manual",
    restorePointCreatedBeforeDeletingDuplicates: "Ponto de restauração criado antes de excluir duplicados",
    save: "Salvar",
    saveLink: "Salvar link",
    search: "Pesquisar",
    searchLinks: "Pesquisar links",
    searchMode: "Modo de pesquisa",
    selectedDuplicatesCount: "{count} selecionados",
    selectDuplicateLink: "Selecionar link duplicado {title}",
    settings: "Configurações",
    showDescriptions: "Mostrar descrições",
    showSearch: "Mostrar pesquisa",
    startFresh: "Começar do zero",
    startGroupTitle: "Início",
    storageNeedsRecovery: "O armazenamento precisa de recuperação",
    system: "Sistema",
    tags: "Tags",
    tagsPlaceholder: "documentos, trabalho, design",
    theme: "Tema",
    thisWouldRemoveAllCopies: "Isso removeria todas as cópias em pelo menos um conjunto de duplicados.",
    title: "Título",
    undo: "Desfazer",
    unavailableTitle: "Aura Start está indisponível",
    addDemoGroups: "Adicionar grupos de demonstração",
    back: "Voltar",
    chooseAppearance: "Escolha a aparência",
    chooseHowToStart: "Escolha como começar",
    comfortable: "Confortável",
    commandOpenDuplicateFinder: "Abrir busca de duplicados",
    compact: "Compacto",
    createYourFirstGroup: "Crie seu primeiro grupo",
    finish: "Concluir",
    importBackupFile: "Importar arquivo de backup",
    importFromAFineStart: "Importar do A Fine Start",
    onboardingFinishDescription: "Você pode alterar essas escolhas depois nas configurações.",
    openOnboardingHelpAgain: "Abrir onboarding/ajuda novamente",
    optionalLayout: "Layout opcional",
    removeDemoData: "Remover dados de demonstração",
    removeDemoDataMessage: "Isso remove apenas grupos e links de demonstração rastreados pelo Aura Start. Itens do usuário com outros IDs permanecem.",
    welcomeToAuraStart: "Bem-vindo ao Aura Start",
    ...translationCompletions.pt
  },
  uk: {
    ...en,
    actionFailed: "Дію не виконано",
    add: "Додати",
    addGroup: "Додати групу",
    addLink: "Додати посилання",
    addLinkTo: "Додати посилання до {title}",
    aFineStartExportCode: "Код експорту A Fine Start",
    auto: "Авто",
    auraStartBackupJson: "Повна JSON-резервна копія Aura Start",
    backupImported: "Резервну копію імпортовано",
    backupMerged: "Резервну копію об’єднано",
    cancel: "Скасувати",
    chooseImportFile: "Виберіть JSON або файл з кодом експорту",
    clearSearch: "Очистити пошук",
    closeDialog: "Закрити вікно",
    collapseGroup: "Згорнути {title}",
    columns: "Колонки",
    compactMode: "Компактний режим",
    create: "Створити",
    dark: "Темна",
    dataOwnership: "Власність даних",
    dataOwnershipDescription: "Усе зберігається в локальному сховищі розширення Chromium. Експортуйте будь-коли перед зміною браузера або профілю.",
    googleDriveNoSyncFileCreated: "Sync-файл Google Drive не було знайдено, тому його створено.",
    googleDriveSyncFileFoundAndRestored: "Sync-файл Google Drive знайдено та відновлено.",
    delete: "Видалити",
    deleteGroup: "Видалити групу",
    description: "Опис",
    deleteRestorePoint: "Видалити точку відновлення?",
    deleteThisGroup: "Видалити цю групу?",
    deleteSelectedDuplicates: "Видалити вибрані дублікати?",
    deleteSelectedDuplicatesMessage: "Буде видалено вибраних посилань-дублікатів: {count}. Перед видаленням буде створено точку відновлення.",
    dismissNotification: "Закрити сповіщення",
    duplicateFinder: "Пошук дублікатів",
    duplicateFinderDescription: "Сканує локальні посилання на дублікати. Нічого не видаляється, доки ви не виберете посилання й не підтвердите дію.",
    duplicateFinderNoMutation: "Сканування лише для читання й не змінює локальні дані.",
    duplicateFinderReadOnly: "Сканування лише для читання. Перед видаленням виберіть посилання вручну.",
    duplicateLinksDeleted: "Видалено посилань-дублікатів: {count}",
    duplicateReasonExactUrl: "Точний дублікат URL",
    duplicateReasonHostnameCase: "Той самий hostname з іншим регістром",
    duplicateReasonHttpHttps: "Можливий http/https дублікат",
    duplicateReasonTrailingSlash: "Дублікат після видалення кінцевої косої риски",
    edit: "Правка",
    enableEditMode: "Увімкнути режим правки",
    disableEditMode: "Вимкнути режим правки",
    emptyGroupButton: "Додати перше посилання",
    export: "Експорт",
    expandGroup: "Розгорнути {title}",
    exportFailed: "Експорт не вдався",
    exportJsonBackup: "Експорт JSON-резервної копії",
    exportRawData: "Експортувати сирі дані",
    exactDuplicates: "Точні дублікати",
    fullBackupJson: "Повна JSON-резервна копія",
    group: "Група",
    groupDeleted: "Групу видалено",
    groupsCount: "{count} груп",
    groupsLinksCount: "{groups} груп · {links} посилань",
    groupTitlePlaceholder: "Дизайн, Робота, Читання",
    hiThere: "Привіт!",
    htmlBookmarks: "HTML закладок браузера",
    import: "Імпорт",
    importBackup: "Імпорт резервної копії",
    importFormat: "Формат імпорту",
    importMode: "Режим імпорту",
    importRestorePointMessage: "Перед імпортом було створено точку відновлення.",
    importWarnings: "Попередження імпорту: {count}",
    inspiredBy: "Натхнено A Fine Start",
    brandSlogan: "Приватна local-first стартова сторінка для посилань - безкоштовна, open-source і з простим експортом",
    language: "Мова",
    light: "Світла",
    linkDeleted: "Посилання видалено",
    linksCount: "{count} посилань",
    loadingAuraStart: "Завантаження Aura Start...",
    loadingLocalData: "Завантаження локальних даних",
    manualCheckpoint: "Ручна точка",
    mergeDescription: "Додає імпортовані групи й уникає конфліктів ID.",
    mergeWithCurrentData: "Об’єднати з поточними даними",
    newGroup: "Нова група",
    newGroupTitle: "Назва нової групи",
    noDuplicateLinksSelected: "Спочатку виберіть хоча б одне посилання-дублікат.",
    noDuplicatesFound: "Дублікатів не знайдено",
    noMatchingLinks: "Нічого не знайдено",
    noRestorePoints: "Точок відновлення ще немає",
    onboardingDescription: "Aura Start зберігає групи й посилання локально, дозволяє редагувати їх і експортувати. Створіть першу групу, додайте посилання або імпортуйте резервну копію.",
    openLinksInNewTab: "Відкривати посилання в новій вкладці",
    openNewTab: "Відкрити нову вкладку",
    openSettings: "Відкрити налаштування",
    pasteAFineStartCode: "Вставте код експорту A Fine Start",
    pasteAuraJson: "Вставте JSON Aura Start",
    pasteFullBackupJson: "Вставте сюди повну JSON-резервну копію",
    possibleDuplicates: "Можливі дублікати",
    projectDashboard: "Панель проєкту",
    recoveryTitle: "Aura Start не зміг завантажити локальні дані",
    renameGroup: "Перейменувати групу",
    replaceCurrentData: "Замінити поточні дані",
    resetAllData: "Скинути всі дані",
    resetAuraStart: "Скинути Aura Start?",
    resetLocalData: "Скинути локальні дані",
    restore: "Відновити",
    restorePoints: "Точки відновлення",
    restoreReasonAuto: "авто",
    restoreReasonBeforeDelete: "перед видаленням",
    restoreReasonBeforeImport: "перед імпортом",
    restoreReasonBeforeReset: "перед скиданням",
    restoreReasonManual: "вручну",
    restorePointCreatedBeforeDeletingDuplicates: "Перед видаленням дублікатів створено точку відновлення",
    save: "Зберегти",
    saveLink: "Зберегти посилання",
    search: "Пошук",
    searchLinks: "Пошук посилань",
    searchMode: "Режим пошуку",
    selectedDuplicatesCount: "Вибрано: {count}",
    selectDuplicateLink: "Вибрати посилання-дублікат {title}",
    settings: "Налаштування",
    settingsDescription: "Налаштуйте вигляд, експорт даних і локальне відновлення.",
    showDescriptions: "Показувати описи",
    showSearch: "Показувати пошук",
    startFresh: "Почати з нуля",
    startGroupTitle: "Старт",
    storageNeedsRecovery: "Сховище потребує відновлення",
    system: "Системна",
    tags: "Теги",
    tagsPlaceholder: "документи, робота, дизайн",
    theme: "Тема",
    thisWouldRemoveAllCopies: "Це видалить усі копії принаймні в одному наборі дублікатів.",
    title: "Назва",
    undo: "Скасувати",
    unavailableTitle: "Aura Start недоступний",
    updateAutomaticRestoreSafety: "Автоматичні точки відновлення",
    addDemoGroups: "Додати демо-групи",
    back: "Назад",
    chooseAppearance: "Виберіть вигляд",
    chooseHowToStart: "Виберіть, як почати",
    comfortable: "Зручний",
    commandOpenDuplicateFinder: "Відкрити пошук дублікатів",
    compact: "Компактний",
    createYourFirstGroup: "Створити першу групу",
    finish: "Готово",
    importBackupFile: "Імпортувати файл резервної копії",
    importFromAFineStart: "Імпорт з A Fine Start",
    onboardingFinishDescription: "Ці налаштування можна змінити пізніше.",
    openOnboardingHelpAgain: "Відкрити onboarding/help знову",
    optionalLayout: "Додатковий макет",
    removeDemoData: "Видалити демо-дані",
    removeDemoDataMessage: "Буде видалено лише демо-групи й посилання, які відстежує Aura Start. Користувацькі елементи з іншими ID залишаться.",
    welcomeToAuraStart: "Ласкаво просимо до Aura Start",
    ...translationCompletions.uk
  }
};
function t(language, key, values = {}) {
  var _a;
  const template = ((_a = translations[language]) == null ? void 0 : _a[key]) ?? translations.en[key] ?? key;
  return Object.entries(values).reduce((text2, [name, value]) => text2.replaceAll(`{${name}}`, String(value)), template);
}
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const mergeClasses = (...classes) => classes.filter((className, index, array) => {
  return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
}).join(" ").trim();
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Icon = reactExports.forwardRef(
  ({
    color = "currentColor",
    size = 24,
    strokeWidth = 2,
    absoluteStrokeWidth,
    className = "",
    children,
    iconNode,
    ...rest
  }, ref) => {
    return reactExports.createElement(
      "svg",
      {
        ref,
        ...defaultAttributes,
        width: size,
        height: size,
        stroke: color,
        strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
        className: mergeClasses("lucide", className),
        ...rest
      },
      [
        ...iconNode.map(([tag, attrs]) => reactExports.createElement(tag, attrs)),
        ...Array.isArray(children) ? children : [children]
      ]
    );
  }
);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const createLucideIcon = (iconName, iconNode) => {
  const Component = reactExports.forwardRef(
    ({ className, ...props }, ref) => reactExports.createElement(Icon, {
      ref,
      iconNode,
      className: mergeClasses(`lucide-${toKebabCase(iconName)}`, className),
      ...props
    })
  );
  Component.displayName = `${iconName}`;
  return Component;
};
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Download = createLucideIcon("Download", [
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
  ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ExternalLink = createLucideIcon("ExternalLink", [
  ["path", { d: "M15 3h6v6", key: "1q9fwt" }],
  ["path", { d: "M10 14 21 3", key: "gplh6r" }],
  ["path", { d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6", key: "a6xqqp" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Settings = createLucideIcon("Settings", [
  [
    "path",
    {
      d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",
      key: "1qme2f"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
]);
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function dateForFile(date = /* @__PURE__ */ new Date()) {
  return date.toISOString().slice(0, 10);
}
function toUnixSeconds(isoDate) {
  const time = new Date(isoDate).getTime();
  return Number.isFinite(time) ? Math.floor(time / 1e3) : Math.floor(Date.now() / 1e3);
}
function formatDateTime(isoDate) {
  const date = new Date(isoDate);
  if (Number.isNaN(date.getTime())) {
    return isoDate;
  }
  return new Intl.DateTimeFormat(void 0, {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(date);
}
function downloadTextFile(filename, content, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.rel = "noopener";
  document.body.append(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
function createJsonBackup(data) {
  return JSON.stringify(data, null, 2);
}
function exportJsonBackup(data) {
  downloadTextFile(
    `aura-start-backup-${dateForFile()}.json`,
    createJsonBackup(data),
    "application/json;charset=utf-8"
  );
}
const DATA_VERSION = 1;
const STORAGE_KEY = "aura-start-data-v1";
const UI_STATE_STORAGE_KEY = "aura-start-ui-state-v1";
const MAX_RESTORE_POINTS = 20;
const DEFAULT_SETTINGS = {
  theme: "system",
  language: "en",
  columns: "auto",
  compactMode: false,
  openLinksInNewTab: false,
  showDescriptions: true,
  showSearch: true,
  autoRestorePoints: true,
  sync: {
    mode: "off",
    deviceId: "",
    connected: false
  }
};
function createId(prefix) {
  const cryptoApi = globalThis.crypto;
  const unique = typeof (cryptoApi == null ? void 0 : cryptoApi.randomUUID) === "function" ? cryptoApi.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  return `${prefix}_${unique}`;
}
const ALLOWED_URL_PROTOCOLS = /* @__PURE__ */ new Set(["http:", "https:"]);
function normalizeUrl(input) {
  const trimmed = input.trim();
  if (!trimmed) {
    return { ok: false, code: "required", message: "URL is required." };
  }
  const hasProtocol = /^[a-zA-Z][a-zA-Z\d+\-.]*:/.test(trimmed);
  const candidate = hasProtocol ? trimmed : `https://${trimmed}`;
  try {
    const url = new URL(candidate);
    if (!ALLOWED_URL_PROTOCOLS.has(url.protocol)) {
      return { ok: false, code: "unsupported_protocol", message: "Only http and https links are allowed." };
    }
    if (!url.hostname) {
      return { ok: false, code: "missing_host", message: "URL must include a valid host." };
    }
    return { ok: true, url: url.toString() };
  } catch {
    return { ok: false, code: "invalid", message: "Enter a valid URL, for example https://example.com." };
  }
}
function parseTags(input) {
  const tags = input.split(",").map((tag) => tag.trim()).filter(Boolean);
  return tags.length > 0 ? Array.from(new Set(tags)) : void 0;
}
function isRecord$2(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function asString(value, field) {
  if (typeof value !== "string") {
    throw new Error(`${field} must be a string.`);
  }
  return value;
}
function asOptionalString(value, field) {
  if (value === void 0 || value === null || value === "") {
    return void 0;
  }
  return asString(value, field);
}
function asNumber(value, fallback) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}
function asBoolean(value, fallback) {
  return typeof value === "boolean" ? value : fallback;
}
function normalizeIso(value, fallback = nowIso()) {
  if (typeof value !== "string") {
    return fallback;
  }
  const time = new Date(value).getTime();
  return Number.isFinite(time) ? new Date(time).toISOString() : fallback;
}
function normalizeOptionalIso(value) {
  if (typeof value !== "string") {
    return void 0;
  }
  const time = new Date(value).getTime();
  return Number.isFinite(time) ? new Date(time).toISOString() : void 0;
}
function normalizeTheme(value) {
  return value === "light" || value === "dark" || value === "system" ? value : DEFAULT_SETTINGS.theme;
}
function normalizeLanguage(value) {
  return isAuraLanguage(value) ? value : DEFAULT_SETTINGS.language;
}
function normalizeColumns(value) {
  if (value === "auto" || value === 1 || value === 2 || value === 3 || value === 4 || value === 5 || value === 6) {
    return value;
  }
  return DEFAULT_SETTINGS.columns;
}
function normalizeSyncMode(value) {
  if (value === "manual") return "auto";
  return value === "auto" || value === "off" ? value : "off";
}
function optionalTrimmedString(value) {
  return typeof value === "string" && value.trim() ? value.trim() : void 0;
}
function normalizeSyncSettings(value) {
  const sync = isRecord$2(value) ? value : {};
  const mode = normalizeSyncMode(sync.mode);
  const deviceId = optionalTrimmedString(sync.deviceId) ?? createId("device");
  return {
    mode,
    deviceId,
    lastSyncedAt: normalizeOptionalIso(sync.lastSyncedAt),
    lastCloudUpdatedAt: normalizeOptionalIso(sync.lastCloudUpdatedAt),
    accountEmail: optionalTrimmedString(sync.accountEmail),
    accountName: optionalTrimmedString(sync.accountName),
    accountAvatarUrl: optionalTrimmedString(sync.accountAvatarUrl),
    cloudFileId: optionalTrimmedString(sync.cloudFileId),
    connected: mode !== "off" && asBoolean(sync.connected, false)
  };
}
function normalizeSettings(value) {
  if (!isRecord$2(value)) {
    return {
      ...DEFAULT_SETTINGS,
      sync: normalizeSyncSettings(void 0)
    };
  }
  return {
    theme: normalizeTheme(value.theme),
    language: normalizeLanguage(value.language),
    columns: normalizeColumns(value.columns),
    compactMode: asBoolean(value.compactMode, DEFAULT_SETTINGS.compactMode),
    openLinksInNewTab: asBoolean(value.openLinksInNewTab, DEFAULT_SETTINGS.openLinksInNewTab),
    showDescriptions: asBoolean(value.showDescriptions, DEFAULT_SETTINGS.showDescriptions),
    showSearch: asBoolean(value.showSearch, DEFAULT_SETTINGS.showSearch),
    autoRestorePoints: asBoolean(value.autoRestorePoints, DEFAULT_SETTINGS.autoRestorePoints),
    sync: normalizeSyncSettings(value.sync)
  };
}
function normalizeTags(value) {
  if (!Array.isArray(value)) {
    return void 0;
  }
  const tags = value.filter((tag) => typeof tag === "string").map((tag) => tag.trim()).filter(Boolean);
  return tags.length ? Array.from(new Set(tags)) : void 0;
}
function normalizeLink(value, fallbackOrder, usedIds) {
  var _a;
  if (!isRecord$2(value)) {
    throw new Error("Every link must be an object.");
  }
  const title = asString(value.title, "Link title").trim();
  if (!title) {
    throw new Error("Link title is required.");
  }
  const normalizedUrl = normalizeUrl(asString(value.url, "Link URL"));
  if (!normalizedUrl.ok) {
    throw new Error(`Invalid link URL for "${title}": ${normalizedUrl.message}`);
  }
  const rawId = typeof value.id === "string" && value.id.trim() ? value.id.trim() : createId("link");
  const id = usedIds.has(rawId) ? createId("link") : rawId;
  usedIds.add(id);
  return {
    id,
    title,
    url: normalizedUrl.url,
    description: (_a = asOptionalString(value.description, "Link description")) == null ? void 0 : _a.trim(),
    tags: normalizeTags(value.tags),
    order: asNumber(value.order, fallbackOrder),
    createdAt: normalizeIso(value.createdAt),
    updatedAt: normalizeIso(value.updatedAt)
  };
}
function normalizeGroup(value, fallbackOrder, usedIds) {
  if (!isRecord$2(value)) {
    throw new Error("Every group must be an object.");
  }
  const title = asString(value.title, "Group title").trim();
  if (!title) {
    throw new Error("Group title is required.");
  }
  const rawId = typeof value.id === "string" && value.id.trim() ? value.id.trim() : createId("group");
  const id = usedIds.has(rawId) ? createId("group") : rawId;
  usedIds.add(id);
  const linkIds = /* @__PURE__ */ new Set();
  const links = Array.isArray(value.links) ? value.links.map((link, index) => normalizeLink(link, index, linkIds)) : [];
  return {
    id,
    title,
    collapsed: asBoolean(value.collapsed, false),
    order: asNumber(value.order, fallbackOrder),
    links: links.slice().sort((a, b) => a.order - b.order).map((link, index) => ({ ...link, order: index }))
  };
}
function normalizeCoreData(value) {
  if (!isRecord$2(value)) {
    throw new Error("Backup root must be an object.");
  }
  if (value.version !== DATA_VERSION) {
    throw new Error("This backup version is not supported by this version of Aura Start.");
  }
  const groupIds = /* @__PURE__ */ new Set();
  const groups = Array.isArray(value.groups) ? value.groups.map((group, index) => normalizeGroup(group, index, groupIds)) : [];
  return {
    version: DATA_VERSION,
    updatedAt: normalizeIso(value.updatedAt),
    settings: normalizeSettings(value.settings),
    groups: groups.slice().sort((a, b) => a.order - b.order).map((group, index) => ({ ...group, order: index }))
  };
}
function normalizeReason(value) {
  if (value === "manual" || value === "before_import" || value === "before_delete" || value === "before_reset" || value === "auto") {
    return value;
  }
  return "manual";
}
function normalizeRestorePoint(value) {
  if (!isRecord$2(value) || !("data" in value)) {
    return void 0;
  }
  try {
    return {
      id: typeof value.id === "string" && value.id.trim() ? value.id.trim() : createId("restore"),
      name: typeof value.name === "string" && value.name.trim() ? value.name.trim() : "Imported restore point",
      createdAt: normalizeIso(value.createdAt),
      reason: normalizeReason(value.reason),
      data: normalizeCoreData(value.data)
    };
  } catch {
    return void 0;
  }
}
function validateAuraData(value) {
  const core = normalizeCoreData(value);
  const restorePoints = isRecord$2(value) && Array.isArray(value.restorePoints) ? value.restorePoints.map(normalizeRestorePoint).filter((point) => point !== void 0).slice(0, MAX_RESTORE_POINTS) : [];
  return {
    ...core,
    restorePoints
  };
}
function parseJsonBackup(text2) {
  let parsed;
  try {
    parsed = JSON.parse(text2);
  } catch {
    throw new Error("The selected file is not valid JSON.");
  }
  return validateAuraData(parsed);
}
function mergeImportedData(current, imported) {
  const now = nowIso();
  const existingGroupIds = new Set(current.groups.map((group) => group.id));
  const existingLinkIds = new Set(current.groups.flatMap((group) => group.links.map((link) => link.id)));
  const appendedGroups = imported.groups.map((group, groupIndex) => {
    const groupId = existingGroupIds.has(group.id) ? createId("group") : group.id;
    existingGroupIds.add(groupId);
    return {
      ...group,
      id: groupId,
      order: current.groups.length + groupIndex,
      links: group.links.map((link, linkIndex) => {
        const linkId = existingLinkIds.has(link.id) ? createId("link") : link.id;
        existingLinkIds.add(linkId);
        return {
          ...link,
          id: linkId,
          order: linkIndex
        };
      })
    };
  });
  return {
    ...current,
    updatedAt: now,
    groups: [...current.groups, ...appendedGroups].map((group, index) => ({ ...group, order: index }))
  };
}
const DRIVE_API_BASE = "https://www.googleapis.com/drive/v3";
const DRIVE_UPLOAD_BASE = "https://www.googleapis.com/upload/drive/v3";
const GOOGLE_OAUTH_AUTHORIZE_URL = "https://accounts.google.com/o/oauth2/v2/auth";
const OAUTH_REVOKE_URL = "https://oauth2.googleapis.com/revoke";
const DRIVE_APPDATA_SCOPE = "https://www.googleapis.com/auth/drive.appdata";
const SYNC_FILE_NAME = "aura-start-sync.json";
const CLOUD_SCHEMA_VERSION = 1;
const CLOUD_APP_NAME = "Aura Start";
const PUBLISHED_CHROME_WEB_STORE_EXTENSION_ID = "pdhhnnmcampmmklkbbtfbmnijmgjliabi";
const TOKEN_EXPIRY_SAFETY_MS = 6e4;
const WEB_AUTH_TOKEN_STORAGE_KEY = "aura-start-google-web-auth-token";
const OAUTH_CLIENT_ID_PATTERN = /^[a-z0-9-]+\.apps\.googleusercontent\.com$/i;
const WEB_OAUTH_CLIENT_ID = "391557451047-rdtft86g9hcbst7mcs38h6t2jgkvrnm3.apps.googleusercontent.com".trim();
const WEB_OAUTH_REDIRECT_PATH = "".trim();
class GoogleDriveSyncError extends Error {
  constructor(code, message, status, reason) {
    super(message);
    __publicField(this, "code");
    __publicField(this, "reason");
    __publicField(this, "status");
    this.name = "GoogleDriveSyncError";
    this.code = code;
    this.reason = reason;
    this.status = status;
  }
}
let webAuthTokenCache;
function isRecord$1(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function getChromeLastErrorMessage() {
  var _a, _b, _c;
  return (_c = (_b = (_a = globalThis.chrome) == null ? void 0 : _a.runtime) == null ? void 0 : _b.lastError) == null ? void 0 : _c.message;
}
function requireIdentityApi() {
  var _a;
  if (!((_a = globalThis.chrome) == null ? void 0 : _a.identity)) {
    throw new GoogleDriveSyncError(
      "identity_unavailable",
      "Google Drive sync is available only inside the installed Chromium extension."
    );
  }
  return chrome.identity;
}
function appVersion() {
  var _a, _b, _c;
  return ((_c = (_b = (_a = globalThis.chrome) == null ? void 0 : _a.runtime) == null ? void 0 : _b.getManifest) == null ? void 0 : _c.call(_b).version) ?? "1.2.2";
}
function looksLikeExampleOAuthClientId(clientId) {
  const normalized = clientId.toLowerCase();
  return normalized.includes("your_google_oauth_client_id") || normalized.includes("your-real-client-id") || normalized.includes("paste_real_client_id_here") || normalized.includes("placeholder") || normalized.includes("example") || /^123(?:4567890)?-[a-z]+\.apps\.googleusercontent\.com$/i.test(normalized);
}
function isUsableOAuthClientId(clientId) {
  return Boolean(
    clientId && OAUTH_CLIENT_ID_PATTERN.test(clientId) && !looksLikeExampleOAuthClientId(clientId)
  );
}
function hasExactDriveAppDataScope(scopes) {
  return Array.isArray(scopes) && scopes.length === 1 && scopes[0] === DRIVE_APPDATA_SCOPE;
}
function selectGoogleDriveAuthFlow(input) {
  const canUseWebOAuth = input.hasIdentityApi && isUsableOAuthClientId(input.webOAuthClientId);
  if (input.installSource === "chrome_web_store") {
    if (input.chromeIdentityUnsupported || !input.hasGetAuthToken) {
      return canUseWebOAuth ? "web_oauth" : "unavailable";
    }
    return input.hasIdentityApi && input.hasGetAuthToken && isUsableOAuthClientId(input.manifestClientId) && hasExactDriveAppDataScope(input.manifestScopes) ? "chrome_identity" : "unavailable";
  }
  if (input.chromeIdentityUnsupported) {
    return canUseWebOAuth ? "web_oauth" : "unavailable";
  }
  if (input.hasIdentityApi && input.hasGetAuthToken) {
    return isUsableOAuthClientId(input.manifestClientId) && hasExactDriveAppDataScope(input.manifestScopes) ? "chrome_identity" : "unavailable";
  }
  return canUseWebOAuth ? "web_oauth" : "unavailable";
}
function detectGoogleDriveInstallSource() {
  var _a, _b;
  const runtime = (_a = globalThis.chrome) == null ? void 0 : _a.runtime;
  if (!runtime) {
    return "unknown";
  }
  const extensionId = runtime.id;
  const manifest = (_b = runtime.getManifest) == null ? void 0 : _b.call(runtime);
  const updateUrl = (manifest == null ? void 0 : manifest.update_url) ?? "";
  if (extensionId === PUBLISHED_CHROME_WEB_STORE_EXTENSION_ID || /clients2\.google\.com\/service\/update2\/crx/i.test(updateUrl)) {
    return "chrome_web_store";
  }
  return updateUrl ? "unknown" : "unpacked";
}
async function isKnownNonChromeChromiumBrowser() {
  var _a, _b, _c, _d;
  const userAgent = ((_a = globalThis.navigator) == null ? void 0 : _a.userAgent) ?? "";
  const brands = ((_c = (_b = globalThis.navigator) == null ? void 0 : _b.userAgentData) == null ? void 0 : _c.brands) ?? [];
  const brandText = brands.map((brand) => brand.brand ?? "").join(" ");
  const browserText = `${userAgent} ${brandText}`;
  if (/\b(Helium|Edg|OPR|Opera|Vivaldi)\b/i.test(browserText)) {
    return true;
  }
  const brave = (_d = globalThis.navigator) == null ? void 0 : _d.brave;
  if (typeof (brave == null ? void 0 : brave.isBrave) === "function" && await brave.isBrave().catch(() => false)) {
    return true;
  }
  return false;
}
function webOAuthRedirectPath(installSource) {
  if (WEB_OAUTH_REDIRECT_PATH) {
    return WEB_OAUTH_REDIRECT_PATH;
  }
  return installSource === "chrome_web_store" ? "" : "oauth2";
}
function oauthClientConfigurationError(clientId) {
  if (!clientId) {
    return "Google Drive sync is not configured in this build. Rebuild Aura Start so the generated manifest contains a real Chrome Extension OAuth Client ID.";
  }
  if (!OAUTH_CLIENT_ID_PATTERN.test(clientId)) {
    return "Google Drive sync is not configured correctly. The OAuth Client ID in the generated manifest must end with .apps.googleusercontent.com.";
  }
  if (looksLikeExampleOAuthClientId(clientId)) {
    return "Google Drive sync is using an example OAuth Client ID, so Google rejects it with invalid_client. Rebuild Aura Start with a real Chrome Extension OAuth Client ID from Google Cloud Console.";
  }
  return "Google Drive sync is not configured correctly. Rebuild Aura Start with a real Google OAuth Client ID.";
}
function manifestOAuthConfig() {
  var _a, _b, _c, _d, _e, _f, _g;
  const manifest = (_c = (_b = (_a = globalThis.chrome) == null ? void 0 : _a.runtime) == null ? void 0 : _b.getManifest) == null ? void 0 : _c.call(_b);
  return {
    clientId: (_e = (_d = manifest == null ? void 0 : manifest.oauth2) == null ? void 0 : _d.client_id) == null ? void 0 : _e.trim(),
    scopes: (_g = (_f = manifest == null ? void 0 : manifest.oauth2) == null ? void 0 : _f.scopes) == null ? void 0 : _g.filter((scope) => typeof scope === "string" && scope.trim())
  };
}
function manifestOAuthConfigurationError(config) {
  if (!isUsableOAuthClientId(config.clientId)) {
    return oauthClientConfigurationError(config.clientId);
  }
  if (!hasExactDriveAppDataScope(config.scopes)) {
    return "Google Drive sync is not configured correctly. The extension manifest must request only the Google Drive appDataFolder OAuth scope.";
  }
  return "Google Drive sync is not configured correctly. Rebuild Aura Start with a valid Google OAuth manifest configuration.";
}
function configuredWebOAuthClientId() {
  return WEB_OAUTH_CLIENT_ID && OAUTH_CLIENT_ID_PATTERN.test(WEB_OAUTH_CLIENT_ID) && !looksLikeExampleOAuthClientId(WEB_OAUTH_CLIENT_ID) ? WEB_OAUTH_CLIENT_ID : void 0;
}
function oauthScopes() {
  var _a, _b, _c, _d, _e;
  const manifest = (_c = (_b = (_a = globalThis.chrome) == null ? void 0 : _a.runtime) == null ? void 0 : _b.getManifest) == null ? void 0 : _c.call(_b);
  const scopes = (_e = (_d = manifest == null ? void 0 : manifest.oauth2) == null ? void 0 : _d.scopes) == null ? void 0 : _e.filter((scope) => typeof scope === "string" && scope.trim());
  return (scopes == null ? void 0 : scopes.length) ? scopes : [DRIVE_APPDATA_SCOPE];
}
function cachedWebAuthToken() {
  if (!webAuthTokenCache) return void 0;
  if (Date.now() + TOKEN_EXPIRY_SAFETY_MS >= webAuthTokenCache.expiresAt) {
    webAuthTokenCache = void 0;
    return void 0;
  }
  return webAuthTokenCache.token;
}
function normalizeCachedToken(value) {
  if (!isRecord$1(value) || typeof value.token !== "string" || typeof value.expiresAt !== "number") {
    return void 0;
  }
  if (Date.now() + TOKEN_EXPIRY_SAFETY_MS >= value.expiresAt) {
    return void 0;
  }
  return {
    token: value.token,
    expiresAt: value.expiresAt
  };
}
function webAuthTokenStorageAreas() {
  var _a;
  const storage = (_a = globalThis.chrome) == null ? void 0 : _a.storage;
  const areas = [];
  if (storage == null ? void 0 : storage.local) {
    areas.push(storage.local);
  }
  if (storage == null ? void 0 : storage.session) {
    areas.push(storage.session);
  }
  return areas;
}
async function readStoredWebAuthToken() {
  for (const area of webAuthTokenStorageAreas()) {
    const result = await area.get(WEB_AUTH_TOKEN_STORAGE_KEY).catch(() => void 0);
    const cached = result ? normalizeCachedToken(result[WEB_AUTH_TOKEN_STORAGE_KEY]) : void 0;
    if (!cached) {
      await area.remove(WEB_AUTH_TOKEN_STORAGE_KEY).catch(() => void 0);
      continue;
    }
    webAuthTokenCache = cached;
    return cached.token;
  }
  return void 0;
}
async function writeStoredWebAuthToken(token) {
  await Promise.all(
    webAuthTokenStorageAreas().map((area) => area.set({ [WEB_AUTH_TOKEN_STORAGE_KEY]: token }).catch(() => void 0))
  );
}
async function removeStoredWebAuthToken() {
  await Promise.all(webAuthTokenStorageAreas().map((area) => area.remove(WEB_AUTH_TOKEN_STORAGE_KEY).catch(() => void 0)));
}
async function getCachedWebAuthToken() {
  return cachedWebAuthToken() ?? await readStoredWebAuthToken();
}
async function getNonInteractiveCachedToken() {
  var _a;
  const installSource = detectGoogleDriveInstallSource();
  if (installSource !== "chrome_web_store") {
    const cachedWebToken = await getCachedWebAuthToken();
    if (cachedWebToken) {
      return cachedWebToken;
    }
  }
  const manifestConfig = manifestOAuthConfig();
  const identity2 = (_a = globalThis.chrome) == null ? void 0 : _a.identity;
  const flow = selectGoogleDriveAuthFlow({
    hasIdentityApi: Boolean(identity2),
    hasGetAuthToken: typeof (identity2 == null ? void 0 : identity2.getAuthToken) === "function",
    manifestClientId: manifestConfig.clientId,
    manifestScopes: manifestConfig.scopes,
    installSource,
    webOAuthClientId: configuredWebOAuthClientId()
  });
  if (flow === "web_oauth") {
    return await getCachedWebAuthToken();
  }
  if (flow === "chrome_identity") {
    return await getChromeAuthToken(false).catch(() => void 0);
  }
  return void 0;
}
function randomState() {
  var _a, _b;
  const randomUUID = (_a = globalThis.crypto) == null ? void 0 : _a.randomUUID;
  if (typeof randomUUID === "function") {
    return randomUUID.call(globalThis.crypto);
  }
  const values = new Uint32Array(4);
  (_b = globalThis.crypto) == null ? void 0 : _b.getRandomValues(values);
  return Array.from(values, (value) => value.toString(36)).join("");
}
function authResultToken(value) {
  if (typeof value === "string") {
    return value;
  }
  if (isRecord$1(value) && typeof value.token === "string") {
    return value.token;
  }
  return void 0;
}
function isBrowserSigninDisabledError(error) {
  const message = error instanceof Error ? error.message.toLowerCase() : "";
  return message.includes("browser signin") || message.includes("browser sign-in");
}
function isChromeIdentityUnsupportedError(error) {
  const message = error instanceof Error ? error.message.toLowerCase() : "";
  return isBrowserSigninDisabledError(error) || message.includes("custom uri scheme") || message.includes("not supported on chrome apps") || message.includes("oauth2 request failed: invalid_request");
}
async function getChromeAuthToken(interactive) {
  const identity2 = requireIdentityApi();
  return await new Promise((resolve, reject) => {
    identity2.getAuthToken({ interactive }, (token) => {
      const lastError = getChromeLastErrorMessage();
      if (lastError) {
        reject(new GoogleDriveSyncError("auth_cancelled", lastError));
        return;
      }
      const resolvedToken = authResultToken(token);
      if (!resolvedToken) {
        reject(new GoogleDriveSyncError("auth_cancelled", "Google authorization did not return a token."));
        return;
      }
      resolve(resolvedToken);
    });
  });
}
async function launchGoogleWebAuthFlow(interactive) {
  const clientId = configuredWebOAuthClientId();
  if (!clientId) {
    throw new GoogleDriveSyncError(
      "identity_unavailable",
      "This build uses Chrome's built-in Google sign-in for Drive sync. The Web OAuth fallback is not configured."
    );
  }
  const cached = await getCachedWebAuthToken();
  if (cached) {
    return cached;
  }
  const identity2 = requireIdentityApi();
  if (!identity2.launchWebAuthFlow || !identity2.getRedirectURL) {
    throw new GoogleDriveSyncError(
      "identity_unavailable",
      "This browser does not support the Google OAuth web auth flow required for Drive sync."
    );
  }
  const redirectUri = identity2.getRedirectURL(webOAuthRedirectPath(detectGoogleDriveInstallSource()));
  const state = randomState();
  const authUrl = new URL(GOOGLE_OAUTH_AUTHORIZE_URL);
  authUrl.searchParams.set("client_id", clientId);
  authUrl.searchParams.set("redirect_uri", redirectUri);
  authUrl.searchParams.set("response_type", "token");
  authUrl.searchParams.set("scope", oauthScopes().join(" "));
  authUrl.searchParams.set("include_granted_scopes", "true");
  authUrl.searchParams.set("state", state);
  if (interactive) {
    authUrl.searchParams.set("prompt", "select_account consent");
  }
  const redirectResult = await new Promise((resolve, reject) => {
    identity2.launchWebAuthFlow({ interactive, url: authUrl.toString() }, (redirectedTo) => {
      const lastError = getChromeLastErrorMessage();
      if (lastError) {
        reject(new GoogleDriveSyncError("auth_cancelled", lastError));
        return;
      }
      if (!redirectedTo) {
        reject(new GoogleDriveSyncError("auth_cancelled", "Google authorization did not complete."));
        return;
      }
      resolve(redirectedTo);
    });
  });
  const redirectedUrl = new URL(redirectResult);
  const fragmentParams = new URLSearchParams(redirectedUrl.hash.startsWith("#") ? redirectedUrl.hash.slice(1) : "");
  const queryParams = redirectedUrl.searchParams;
  const params = fragmentParams.size ? fragmentParams : queryParams;
  const error = params.get("error");
  if (error) {
    throw new GoogleDriveSyncError("auth_cancelled", params.get("error_description") ?? error);
  }
  if (params.get("state") !== state) {
    throw new GoogleDriveSyncError("auth_cancelled", "Google authorization returned an invalid state.");
  }
  const token = params.get("access_token");
  if (!token) {
    throw new GoogleDriveSyncError("auth_cancelled", "Google authorization did not return an access token.");
  }
  const expiresInSeconds = Number(params.get("expires_in") ?? "3600");
  const expiresIn = Number.isFinite(expiresInSeconds) && expiresInSeconds > 0 ? expiresInSeconds : 3600;
  const cachedToken = {
    token,
    expiresAt: Date.now() + expiresIn * 1e3
  };
  webAuthTokenCache = cachedToken;
  await writeStoredWebAuthToken(cachedToken);
  return token;
}
function driveHeaders(token, extra) {
  return {
    Authorization: `Bearer ${token}`,
    ...extra
  };
}
function statusCodeToErrorCode(status) {
  if (status === 401) return "unauthorized";
  if (status === 403) return "forbidden";
  if (status === 404) return "not_found";
  if (status === 429) return "rate_limited";
  return "unknown";
}
async function errorFromResponse(response) {
  var _a, _b, _c, _d, _e;
  let message = response.statusText || "Google Drive request failed.";
  let reason;
  try {
    const body = await response.json();
    message = ((_a = body.error) == null ? void 0 : _a.message) ?? message;
    reason = ((_d = (_c = (_b = body.error) == null ? void 0 : _b.errors) == null ? void 0 : _c.find((item) => item.reason)) == null ? void 0 : _d.reason) ?? ((_e = body.error) == null ? void 0 : _e.status);
  } catch {
  }
  return new GoogleDriveSyncError(statusCodeToErrorCode(response.status), message, response.status, reason);
}
async function driveFetch(token, url, init = {}) {
  let response;
  try {
    response = await fetch(url, {
      ...init,
      headers: driveHeaders(token, init.headers)
    });
  } catch (error) {
    throw new GoogleDriveSyncError(
      "network",
      error instanceof Error ? error.message : "Network connection failed."
    );
  }
  if (!response.ok) {
    throw await errorFromResponse(response);
  }
  if (response.status === 204) {
    return void 0;
  }
  return await response.json();
}
function createMultipartBody(metadata, payload) {
  const boundary = `aura_start_${Math.random().toString(36).slice(2)}`;
  const body = [
    `--${boundary}`,
    "Content-Type: application/json; charset=UTF-8",
    "",
    JSON.stringify(metadata),
    `--${boundary}`,
    "Content-Type: application/json; charset=UTF-8",
    "",
    JSON.stringify(payload, null, 2),
    `--${boundary}--`,
    ""
  ].join("\r\n");
  return {
    body,
    contentType: `multipart/related; boundary=${boundary}`
  };
}
function cloudPayload(data, deviceId) {
  return {
    schemaVersion: CLOUD_SCHEMA_VERSION,
    app: CLOUD_APP_NAME,
    appVersion: appVersion(),
    updatedAt: nowIso(),
    deviceId,
    data
  };
}
function normalizeCloudUpdatedAt(payload) {
  const dataTime = new Date(payload.data.updatedAt).getTime();
  if (Number.isFinite(dataTime)) {
    return new Date(dataTime).toISOString();
  }
  const payloadTime = new Date(payload.updatedAt).getTime();
  return Number.isFinite(payloadTime) ? new Date(payloadTime).toISOString() : nowIso();
}
function validateCloudPayload(value) {
  if (!isRecord$1(value)) {
    throw new GoogleDriveSyncError("invalid_cloud_file", "Google Drive sync file must be a JSON object.");
  }
  if (value.schemaVersion !== CLOUD_SCHEMA_VERSION) {
    throw new GoogleDriveSyncError("invalid_cloud_file", "This Google Drive sync file version is not supported.");
  }
  if (value.app !== CLOUD_APP_NAME) {
    throw new GoogleDriveSyncError("invalid_cloud_file", "This is not an Aura Start Google Drive sync file.");
  }
  if (typeof value.appVersion !== "string" || !value.appVersion.trim()) {
    throw new GoogleDriveSyncError("invalid_cloud_file", "Google Drive sync file is missing appVersion.");
  }
  if (typeof value.updatedAt !== "string" || Number.isNaN(new Date(value.updatedAt).getTime())) {
    throw new GoogleDriveSyncError("invalid_cloud_file", "Google Drive sync file has an invalid updatedAt value.");
  }
  if (typeof value.deviceId !== "string" || !value.deviceId.trim()) {
    throw new GoogleDriveSyncError("invalid_cloud_file", "Google Drive sync file is missing deviceId.");
  }
  try {
    return {
      schemaVersion: CLOUD_SCHEMA_VERSION,
      app: CLOUD_APP_NAME,
      appVersion: value.appVersion,
      updatedAt: new Date(value.updatedAt).toISOString(),
      deviceId: value.deviceId,
      data: validateAuraData(value.data)
    };
  } catch (error) {
    if (error instanceof GoogleDriveSyncError) {
      throw error;
    }
    throw new GoogleDriveSyncError(
      "invalid_cloud_file",
      error instanceof Error ? error.message : "Google Drive sync file contains invalid Aura Start data."
    );
  }
}
async function getAuthToken(interactive) {
  var _a, _b, _c;
  const installSource = detectGoogleDriveInstallSource();
  if (!interactive && installSource !== "chrome_web_store") {
    const cachedWebToken = await getCachedWebAuthToken();
    if (cachedWebToken) {
      return cachedWebToken;
    }
  }
  const manifestConfig = manifestOAuthConfig();
  const identity2 = (_a = globalThis.chrome) == null ? void 0 : _a.identity;
  const webOAuthClientId = configuredWebOAuthClientId();
  const chromeIdentityUnsupported = interactive && await isKnownNonChromeChromiumBrowser();
  const flow = selectGoogleDriveAuthFlow({
    hasIdentityApi: Boolean(identity2),
    hasGetAuthToken: typeof (identity2 == null ? void 0 : identity2.getAuthToken) === "function",
    manifestClientId: manifestConfig.clientId,
    manifestScopes: manifestConfig.scopes,
    chromeIdentityUnsupported,
    installSource,
    webOAuthClientId
  });
  if (flow === "chrome_identity") {
    (_b = console.debug) == null ? void 0 : _b.call(console, "Aura Start Google Drive sync: using chrome.identity.getAuthToken.");
    return await getChromeAuthToken(interactive).catch(async (error) => {
      var _a2;
      if (isChromeIdentityUnsupportedError(error) && webOAuthClientId) {
        (_a2 = console.debug) == null ? void 0 : _a2.call(console, "Aura Start Google Drive sync: chrome.identity.getAuthToken is unsupported here; using Web OAuth fallback.");
        return await launchGoogleWebAuthFlow(interactive);
      }
      if (isChromeIdentityUnsupportedError(error)) {
        throw new GoogleDriveSyncError(
          "identity_unavailable",
          "This browser rejected Chrome's built-in Google sign-in for Drive sync. Use Google Chrome, or rebuild Aura Start with the explicit Web OAuth fallback enabled and configured for this extension ID."
        );
      }
      throw error;
    });
  }
  if (flow === "web_oauth") {
    (_c = console.debug) == null ? void 0 : _c.call(console, "Aura Start Google Drive sync: using Web OAuth fallback.");
    return await launchGoogleWebAuthFlow(interactive);
  }
  if (chromeIdentityUnsupported && !webOAuthClientId) {
    throw new GoogleDriveSyncError(
      "identity_unavailable",
      "This browser does not support Chrome's built-in Google sign-in for Drive sync. Use Google Chrome, or build Aura Start with a Web OAuth fallback client authorized for this extension redirect URL."
    );
  }
  throw new GoogleDriveSyncError("identity_unavailable", manifestOAuthConfigurationError(manifestConfig));
}
async function getCachedAuthToken() {
  return await getNonInteractiveCachedToken();
}
async function clearAuthToken(token) {
  const identity2 = requireIdentityApi();
  const tokenToClear = token ?? await getNonInteractiveCachedToken();
  if (!tokenToClear) return;
  if ((webAuthTokenCache == null ? void 0 : webAuthTokenCache.token) === tokenToClear) {
    webAuthTokenCache = void 0;
  }
  await removeStoredWebAuthToken();
  await new Promise((resolve, reject) => {
    identity2.removeCachedAuthToken({ token: tokenToClear }, () => {
      const lastError = getChromeLastErrorMessage();
      if (lastError) {
        reject(new GoogleDriveSyncError("unknown", lastError));
        return;
      }
      resolve();
    });
  });
}
async function revokeAuthToken(token) {
  let response;
  try {
    response = await fetch(`${OAUTH_REVOKE_URL}?token=${encodeURIComponent(token)}`, {
      method: "POST"
    });
  } catch (error) {
    throw new GoogleDriveSyncError(
      "network",
      error instanceof Error ? error.message : "Google OAuth token revoke failed."
    );
  }
  if (!response.ok) {
    throw await errorFromResponse(response);
  }
}
async function disconnectGoogleAccount(token) {
  const tokenToDisconnect = token ?? await getNonInteractiveCachedToken();
  if (!tokenToDisconnect) {
    return {};
  }
  let revokeError;
  try {
    await revokeAuthToken(tokenToDisconnect);
  } catch (error) {
    revokeError = mapDriveError(error);
  }
  try {
    await clearAuthToken(tokenToDisconnect);
  } catch (error) {
    const clearError = mapDriveError(error);
    revokeError = revokeError ? `${revokeError}; ${clearError}` : clearError;
  }
  return { revokeError };
}
async function getConnectedAccountInfo() {
  const identity2 = requireIdentityApi();
  if (!identity2.getProfileUserInfo) {
    return void 0;
  }
  return await new Promise((resolve) => {
    identity2.getProfileUserInfo((info) => {
      const email = typeof info.email === "string" && info.email ? info.email : void 0;
      resolve(email ? { email } : void 0);
    });
  });
}
async function findSyncFile(token) {
  var _a;
  const authToken = token ?? await getAuthToken(false);
  const query = `name = '${SYNC_FILE_NAME}' and 'appDataFolder' in parents and trashed = false`;
  const params = new URLSearchParams({
    spaces: "appDataFolder",
    q: query,
    fields: "files(id,name,modifiedTime,size)",
    pageSize: "10"
  });
  const result = await driveFetch(
    authToken,
    `${DRIVE_API_BASE}/files?${params.toString()}`
  );
  return (_a = result.files) == null ? void 0 : _a[0];
}
async function createSyncFile(data, deviceId, token) {
  const authToken = token ?? await getAuthToken(false);
  const payload = cloudPayload(data, deviceId);
  const multipart = createMultipartBody(
    {
      name: SYNC_FILE_NAME,
      parents: ["appDataFolder"],
      mimeType: "application/json"
    },
    payload
  );
  const params = new URLSearchParams({
    uploadType: "multipart",
    fields: "id,name,modifiedTime,size"
  });
  return await driveFetch(authToken, `${DRIVE_UPLOAD_BASE}/files?${params.toString()}`, {
    method: "POST",
    body: multipart.body,
    headers: {
      "Content-Type": multipart.contentType
    }
  });
}
async function uploadSyncFile(data, options) {
  var _a;
  const token = options.token ?? await getAuthToken(false);
  const payload = cloudPayload(data, options.deviceId);
  const metadata = {
    name: SYNC_FILE_NAME,
    mimeType: "application/json"
  };
  const multipart = createMultipartBody(metadata, payload);
  const params = new URLSearchParams({
    uploadType: "multipart",
    fields: "id,name,modifiedTime,size"
  });
  const currentFileId = options.fileId ?? ((_a = await findSyncFile(token)) == null ? void 0 : _a.id);
  if (!currentFileId) {
    return await createSyncFile(data, options.deviceId, token);
  }
  try {
    return await driveFetch(
      token,
      `${DRIVE_UPLOAD_BASE}/files/${encodeURIComponent(currentFileId)}?${params.toString()}`,
      {
        method: "PATCH",
        body: multipart.body,
        headers: {
          "Content-Type": multipart.contentType
        }
      }
    );
  } catch (error) {
    if (error instanceof GoogleDriveSyncError && error.code === "not_found") {
      return await createSyncFile(data, options.deviceId, token);
    }
    throw error;
  }
}
async function backupToDrive(data, options) {
  return await uploadSyncFile(data, options);
}
async function downloadSyncFile(fileId, token) {
  const authToken = token ?? await getAuthToken(false);
  const metadata = fileId ? await driveFetch(
    authToken,
    `${DRIVE_API_BASE}/files/${encodeURIComponent(fileId)}?fields=id,name,modifiedTime,size`
  ).catch(async (error) => {
    if (error instanceof GoogleDriveSyncError && error.code === "not_found") {
      return await findSyncFile(authToken);
    }
    throw error;
  }) : await findSyncFile(authToken);
  if (!metadata) {
    return void 0;
  }
  const rawPayload = await driveFetch(
    authToken,
    `${DRIVE_API_BASE}/files/${encodeURIComponent(metadata.id)}?alt=media`
  );
  const payload = validateCloudPayload(rawPayload);
  return {
    metadata,
    payload,
    data: payload.data,
    cloudUpdatedAt: normalizeCloudUpdatedAt(payload)
  };
}
async function restoreFromDrive(token) {
  return await downloadSyncFile(void 0, token);
}
function compareLocalAndCloud(localData, cloud, syncSettings) {
  if (!cloud) {
    return "no_cloud_file";
  }
  const lastSyncedTime = syncSettings.lastSyncedAt ? new Date(syncSettings.lastSyncedAt).getTime() : 0;
  const localTime = new Date(localData.updatedAt).getTime();
  const cloudTime = new Date(cloud.cloudUpdatedAt).getTime();
  if (!Number.isFinite(localTime) || !Number.isFinite(cloudTime)) {
    return "conflict";
  }
  const localChanged = lastSyncedTime > 0 ? localTime > lastSyncedTime : false;
  const cloudChanged = lastSyncedTime > 0 ? cloudTime > lastSyncedTime : false;
  if (localChanged && cloudChanged && Math.abs(localTime - cloudTime) > 1e3) {
    return "conflict";
  }
  if (Math.abs(localTime - cloudTime) <= 1e3) {
    return "in_sync";
  }
  return localTime > cloudTime ? "local_newer" : "cloud_newer";
}
async function deleteSyncFile(token) {
  const authToken = token ?? await getAuthToken(false);
  const metadata = await findSyncFile(authToken);
  if (!metadata) {
    return false;
  }
  await driveFetch(authToken, `${DRIVE_API_BASE}/files/${encodeURIComponent(metadata.id)}`, {
    method: "DELETE"
  });
  return true;
}
function mapDriveError(error) {
  var _a;
  if (error instanceof GoogleDriveSyncError) {
    const message = error.message.toLowerCase();
    const reason = ((_a = error.reason) == null ? void 0 : _a.toLowerCase()) ?? "";
    if (isGoogleDriveAuthorizationUnavailable(error)) {
      return "Google authorization expired or was revoked. Reconnect Google Drive to resume sync.";
    }
    if (error.code === "auth_cancelled") {
      return error.message || "Google authorization was cancelled or did not complete.";
    }
    if (error.code === "identity_unavailable") {
      return error.message;
    }
    if (error.code === "unauthorized") {
      return "Google authorization expired. Reconnect Google Drive and try again.";
    }
    if (error.code === "forbidden") {
      if (reason === "accessnotconfigured" || message.includes("api has not been used") || message.includes("api has not been enabled") || message.includes("it is disabled")) {
        return "Google Drive API is disabled for this OAuth project. Enable Google Drive API in Google Cloud Console, wait a few minutes, then reconnect Google Drive.";
      }
      if (reason === "insufficientpermissions" || message.includes("insufficient authentication scopes") || message.includes("insufficient permission")) {
        return "Google authorized Aura Start without the required drive.appdata permission. Disconnect Google Account, connect again, and make sure the OAuth consent screen includes the Google Drive appdata scope.";
      }
      return `Google Drive denied access: ${error.message}`;
    }
    if (error.code === "not_found") {
      return "No Google Drive sync file found.";
    }
    if (error.code === "rate_limited") {
      return "Google Drive rate limit reached. Try again later.";
    }
    if (error.code === "network") {
      return `Network error: ${error.message}`;
    }
    if (error.code === "invalid_cloud_file") {
      return error.message;
    }
    return error.message;
  }
  return error instanceof Error ? error.message : "Google Drive sync failed.";
}
function isGoogleDriveAuthorizationUnavailable(error) {
  var _a;
  if (!(error instanceof GoogleDriveSyncError)) {
    return false;
  }
  if (error.code === "unauthorized") {
    return true;
  }
  if (error.code !== "auth_cancelled") {
    return false;
  }
  const message = error.message.toLowerCase();
  const reason = ((_a = error.reason) == null ? void 0 : _a.toLowerCase()) ?? "";
  return reason.includes("invalid_grant") || message.includes("invalid_grant") || message.includes("oauth2 not granted") || message.includes("not granted or revoked") || message.includes("token has been revoked") || message.includes("authorization has been revoked");
}
const createStoreImpl = (createState) => {
  let state;
  const listeners = /* @__PURE__ */ new Set();
  const setState = (partial, replace) => {
    const nextState = typeof partial === "function" ? partial(state) : partial;
    if (!Object.is(nextState, state)) {
      const previousState = state;
      state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
      listeners.forEach((listener) => listener(state, previousState));
    }
  };
  const getState = () => state;
  const getInitialState = () => initialState;
  const subscribe = (listener) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  };
  const api = { setState, getState, getInitialState, subscribe };
  const initialState = state = createState(setState, getState, api);
  return api;
};
const createStore = ((createState) => createState ? createStoreImpl(createState) : createStoreImpl);
const identity = (arg) => arg;
function useStore(api, selector = identity) {
  const slice = React.useSyncExternalStore(
    api.subscribe,
    React.useCallback(() => selector(api.getState()), [api, selector]),
    React.useCallback(() => selector(api.getInitialState()), [api, selector])
  );
  React.useDebugValue(slice);
  return slice;
}
const createImpl = (createState) => {
  const api = createStore(createState);
  const useBoundStore = (selector) => useStore(api, selector);
  Object.assign(useBoundStore, api);
  return useBoundStore;
};
const create = ((createState) => createState ? createImpl(createState) : createImpl);
function detectDefaultLanguage() {
  var _a;
  if (typeof navigator === "undefined") {
    return DEFAULT_SETTINGS.language;
  }
  const candidates = ((_a = navigator.languages) == null ? void 0 : _a.length) ? navigator.languages : [navigator.language];
  for (const candidate of candidates) {
    const code = candidate.toLowerCase().split("-")[0];
    if (isAuraLanguage(code)) {
      return code;
    }
  }
  return DEFAULT_SETTINGS.language;
}
function createEmptyData() {
  return {
    version: DATA_VERSION,
    updatedAt: nowIso(),
    settings: {
      ...DEFAULT_SETTINGS,
      language: detectDefaultLanguage(),
      sync: {
        ...DEFAULT_SETTINGS.sync,
        deviceId: createId("device")
      }
    },
    groups: [],
    restorePoints: []
  };
}
function hasChromeStorage$1() {
  var _a, _b;
  return Boolean((_b = (_a = globalThis.chrome) == null ? void 0 : _a.storage) == null ? void 0 : _b.local);
}
async function chromeGet$1(key) {
  const result = await chrome.storage.local.get(key);
  return result[key];
}
async function chromeSet$1(key, value) {
  await chrome.storage.local.set({ [key]: value });
}
async function chromeRemove(key) {
  await chrome.storage.local.remove(key);
}
function localGet$1(key) {
  const value = localStorage.getItem(key);
  return value ? JSON.parse(value) : void 0;
}
function localSet$1(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}
function localRemove(key) {
  localStorage.removeItem(key);
}
async function loadAuraData() {
  const fallback = !hasChromeStorage$1();
  try {
    const rawValue = fallback ? localGet$1(STORAGE_KEY) : await chromeGet$1(STORAGE_KEY);
    if (rawValue === void 0) {
      return { status: "missing", fallback };
    }
    try {
      return { status: "ready", data: validateAuraData(rawValue), fallback };
    } catch (error) {
      return {
        status: "corrupt",
        raw: JSON.stringify(rawValue, null, 2),
        message: error instanceof Error ? error.message : "Stored data could not be validated.",
        fallback
      };
    }
  } catch (error) {
    return {
      status: "corrupt",
      raw: "",
      message: error instanceof Error ? error.message : "Stored data could not be loaded.",
      fallback
    };
  }
}
async function saveAuraData(data) {
  const validated = validateAuraData(data);
  if (hasChromeStorage$1()) {
    await chromeSet$1(STORAGE_KEY, validated);
  } else {
    localSet$1(STORAGE_KEY, validated);
  }
}
async function clearAuraData() {
  if (hasChromeStorage$1()) {
    await chromeRemove(STORAGE_KEY);
  } else {
    localRemove(STORAGE_KEY);
  }
}
const EMPTY_DEMO_DATA$1 = {
  groupIds: [],
  linkIds: []
};
const DEFAULT_UI_STATE = {
  onboardingCompleted: false,
  demoData: EMPTY_DEMO_DATA$1
};
function hasChromeStorage() {
  var _a, _b;
  return Boolean((_b = (_a = globalThis.chrome) == null ? void 0 : _a.storage) == null ? void 0 : _b.local);
}
async function chromeGet(key) {
  const result = await chrome.storage.local.get(key);
  return result[key];
}
async function chromeSet(key, value) {
  await chrome.storage.local.set({ [key]: value });
}
function localGet(key) {
  const value = localStorage.getItem(key);
  return value ? JSON.parse(value) : void 0;
}
function localSet(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function normalizeStringList(value) {
  if (!Array.isArray(value)) {
    return [];
  }
  return Array.from(new Set(value.filter((item) => typeof item === "string" && item.trim().length > 0)));
}
function normalizeDemoData(value) {
  if (!isRecord(value)) {
    return EMPTY_DEMO_DATA$1;
  }
  return {
    groupIds: normalizeStringList(value.groupIds),
    linkIds: normalizeStringList(value.linkIds)
  };
}
function normalizeUiState(value) {
  if (!isRecord(value)) {
    return DEFAULT_UI_STATE;
  }
  return {
    onboardingCompleted: value.onboardingCompleted === true,
    demoData: normalizeDemoData(value.demoData)
  };
}
async function loadAuraUiState() {
  try {
    const rawValue = hasChromeStorage() ? await chromeGet(UI_STATE_STORAGE_KEY) : localGet(UI_STATE_STORAGE_KEY);
    return normalizeUiState(rawValue);
  } catch {
    return DEFAULT_UI_STATE;
  }
}
async function saveAuraUiState(state) {
  const normalized = normalizeUiState(state);
  if (hasChromeStorage()) {
    await chromeSet(UI_STATE_STORAGE_KEY, normalized);
  } else {
    localSet(UI_STATE_STORAGE_KEY, normalized);
  }
}
const EMPTY_DEMO_DATA = {
  groupIds: [],
  linkIds: []
};
const AUTO_SYNC_DELAY_MS = 2e3;
let autoSyncTimer;
let autoSyncDirty = false;
function cloneData(data) {
  return JSON.parse(JSON.stringify(data));
}
function text(data, key, values) {
  return t((data == null ? void 0 : data.settings.language) ?? "en", key, values);
}
function snapshot(data) {
  return {
    version: data.version,
    updatedAt: data.updatedAt,
    settings: data.settings,
    groups: data.groups
  };
}
function isActiveSyncStatus(status) {
  return status === "connecting" || status === "syncing";
}
function ensureSyncDevice(sync) {
  return sync.deviceId ? sync : { ...sync, deviceId: createId("device") };
}
function mergeSyncSettings(data, patch) {
  const current = ensureSyncDevice(data.settings.sync);
  return {
    ...current,
    ...patch,
    deviceId: patch.deviceId ?? current.deviceId
  };
}
function syncStatusFromData(data) {
  return data.settings.sync.mode !== "off" && data.settings.sync.connected ? "connected" : "idle";
}
async function getTokenForSync(sync, allowInteractive = true) {
  try {
    return await getAuthToken(!sync.connected && allowInteractive);
  } catch (error) {
    if (sync.connected && allowInteractive) {
      return await getAuthToken(true);
    }
    throw error;
  }
}
function normalizeOrders(groups) {
  return groups.map((group, groupIndex) => ({
    ...group,
    order: groupIndex,
    links: group.links.map((link, linkIndex) => ({ ...link, order: linkIndex }))
  }));
}
function touch(data) {
  return {
    ...data,
    updatedAt: nowIso(),
    groups: normalizeOrders(data.groups)
  };
}
function createRestorePoint(data, name, reason) {
  return {
    id: createId("restore"),
    name,
    createdAt: nowIso(),
    reason,
    data: snapshot(data)
  };
}
function createDemoGroups(startOrder) {
  const createdAt = nowIso();
  const specs = [
    {
      title: "Work",
      links: [
        ["GitHub", "https://github.com"],
        ["Chrome Developers", "https://developer.chrome.com"]
      ]
    },
    {
      title: "Social",
      links: [["Hacker News", "https://news.ycombinator.com"]]
    },
    {
      title: "Tools",
      links: [
        ["MDN Web Docs", "https://developer.mozilla.org"],
        ["web.dev", "https://web.dev"]
      ]
    },
    {
      title: "Reading",
      links: [["Wikipedia", "https://wikipedia.org"]]
    }
  ];
  const marker = {
    groupIds: [],
    linkIds: []
  };
  const groups = specs.map((groupSpec, groupIndex) => {
    const groupId = createId("demo_group");
    marker.groupIds.push(groupId);
    return {
      id: groupId,
      title: groupSpec.title,
      collapsed: false,
      order: startOrder + groupIndex,
      links: groupSpec.links.map(([title, url], linkIndex) => {
        const linkId = createId("demo_link");
        marker.linkIds.push(linkId);
        return {
          id: linkId,
          title,
          url,
          order: linkIndex,
          createdAt,
          updatedAt: createdAt
        };
      })
    };
  });
  return { groups, marker };
}
function mergeDemoDataMarker(current, added) {
  return {
    groupIds: Array.from(/* @__PURE__ */ new Set([...current.groupIds, ...added.groupIds])),
    linkIds: Array.from(/* @__PURE__ */ new Set([...current.linkIds, ...added.linkIds]))
  };
}
function hasMatchingDemoData(data, marker) {
  const groupIds = new Set(marker.groupIds);
  const linkIds = new Set(marker.linkIds);
  return data.groups.some((group) => groupIds.has(group.id) || group.links.some((link) => linkIds.has(link.id)));
}
function withRestorePoint(data, name, reason) {
  const point = createRestorePoint(data, name, reason);
  return {
    ...data,
    restorePoints: [point, ...data.restorePoints].slice(0, MAX_RESTORE_POINTS)
  };
}
function keepLocalSyncSettings(data, current) {
  return {
    ...data,
    settings: {
      ...data.settings,
      sync: ensureSyncDevice(current.settings.sync)
    }
  };
}
function findGroup(data, groupId) {
  const group = data.groups.find((item) => item.id === groupId);
  if (!group) {
    throw new Error(text(data, "groupNotFound"));
  }
  return group;
}
function urlValidationMessage(data, result) {
  switch (result.code) {
    case "required":
      return text(data, "urlRequired");
    case "unsupported_protocol":
      return text(data, "urlHttpOnly");
    case "missing_host":
      return text(data, "urlHostRequired");
    case "invalid":
      return text(data, "urlInvalidExample");
  }
}
function requireTitle(data, input, key) {
  const title = input.trim();
  if (!title) {
    throw new Error(text(data, key));
  }
  return title;
}
function prepareLinkInput(data, input) {
  var _a;
  const normalizedUrl = normalizeUrl(input.url);
  if (!normalizedUrl.ok) {
    throw new Error(urlValidationMessage(data, normalizedUrl));
  }
  const description = (_a = input.description) == null ? void 0 : _a.trim();
  return {
    title: requireTitle(data, input.title, "linkTitleRequired"),
    url: normalizedUrl.url,
    description: description ? description : void 0,
    tags: input.tags ? parseTags(input.tags) : void 0
  };
}
function clearAutoSyncQueue() {
  autoSyncDirty = false;
  if (typeof window !== "undefined" && autoSyncTimer) {
    window.clearTimeout(autoSyncTimer);
  }
  autoSyncTimer = void 0;
}
function scheduleAutoSync(data) {
  if (typeof window === "undefined") return;
  const sync = data.settings.sync;
  if (sync.mode !== "auto" || !sync.connected) return;
  autoSyncDirty = true;
  if (autoSyncTimer) {
    window.clearTimeout(autoSyncTimer);
  }
  autoSyncTimer = window.setTimeout(() => {
    autoSyncTimer = void 0;
    const state = useAuraStore.getState();
    const current = state.data;
    if (!autoSyncDirty || !current || current.settings.sync.mode !== "auto" || !current.settings.sync.connected) {
      autoSyncDirty = false;
      return;
    }
    if (isActiveSyncStatus(state.syncStatus)) {
      scheduleAutoSync(current);
      return;
    }
    autoSyncDirty = false;
    void state.syncNow({ silent: true }).catch(() => {
    });
  }, AUTO_SYNC_DELAY_MS);
}
async function safeCommit(set, data, options = {}) {
  const next = touch(data);
  await saveAuraData(next);
  set({ data: next, status: "ready", error: null });
  if (!options.skipAutoSync) {
    scheduleAutoSync(next);
  }
}
async function optimisticCommit(set, previous, data, options = {}) {
  const next = touch(data);
  set({ data: next, status: "ready", error: null });
  try {
    await saveAuraData(next);
    if (!options.skipAutoSync) {
      scheduleAutoSync(next);
    }
  } catch (error) {
    set({
      data: previous,
      status: "ready",
      error: error instanceof Error ? error.message : "Local storage could not be updated."
    });
    throw error;
  }
}
async function commitSyncMetadata(set, data, patch, syncStatus, syncMessage, syncConflict = null) {
  const current = useAuraStore.getState().data;
  const base = current && current.updatedAt !== data.updatedAt ? current : data;
  const next = {
    ...base,
    settings: {
      ...base.settings,
      sync: mergeSyncSettings(base, patch)
    }
  };
  await saveAuraData(next);
  set({
    data: next,
    status: "ready",
    error: null,
    syncStatus,
    syncMessage,
    syncConflict
  });
  return next;
}
function driveFailure(set, get, error) {
  const data = get().data;
  const message = mapDriveError(error);
  set({ syncStatus: "error", syncMessage: message });
  get().addToast({
    type: "error",
    title: text(data, "googleDriveSyncFailed"),
    message
  });
  return message;
}
async function markGoogleDriveSyncNeedsReconnect(set, get, error) {
  clearAutoSyncQueue();
  await clearAuthToken().catch(() => void 0);
  const data = get().data;
  if (!data) {
    set({ syncStatus: "connected", syncMessage: mapDriveError(error), syncConflict: null });
    return;
  }
  set({
    syncStatus: "connected",
    syncMessage: text(data, "googleDriveNeedsReconnect"),
    syncConflict: null
  });
}
async function applyCloudDownload(set, get, download, syncPatch = {}) {
  const current = get().data;
  if (!current) return;
  const point = createRestorePoint(current, "Before Google Drive restore", "before_import");
  const syncedAt = nowIso();
  const currentSync = ensureSyncDevice(current.settings.sync);
  const nextSync = {
    ...currentSync,
    ...syncPatch,
    mode: "auto",
    connected: true,
    cloudFileId: download.metadata.id,
    lastSyncedAt: syncedAt,
    lastCloudUpdatedAt: download.cloudUpdatedAt
  };
  const next = {
    ...download.data,
    settings: {
      ...download.data.settings,
      sync: nextSync
    },
    restorePoints: [point, ...download.data.restorePoints].slice(0, MAX_RESTORE_POINTS)
  };
  await saveAuraData(next);
  set({
    data: next,
    status: "ready",
    error: null,
    syncStatus: "connected",
    syncMessage: text(next, "googleDriveRestoreSuccess"),
    syncConflict: null
  });
}
const useAuraStore = create((set, get) => ({
  data: null,
  status: "idle",
  error: null,
  corruptRaw: null,
  usingFallbackStorage: false,
  syncStatus: "idle",
  syncMessage: null,
  syncConflict: null,
  onboardingCompleted: false,
  demoData: EMPTY_DEMO_DATA,
  toasts: [],
  async load() {
    set({ status: "loading", error: null, corruptRaw: null });
    try {
      const uiState = await loadAuraUiState();
      const result = await loadAuraData();
      if (result.status === "missing") {
        const empty = createEmptyData();
        await saveAuraData(empty);
        set({
          data: empty,
          status: "ready",
          usingFallbackStorage: result.fallback,
          syncStatus: "idle",
          syncMessage: null,
          syncConflict: null,
          onboardingCompleted: uiState.onboardingCompleted,
          demoData: uiState.demoData
        });
        return;
      }
      if (result.status === "corrupt") {
        set({
          data: null,
          status: "corrupt",
          error: result.message,
          corruptRaw: result.raw,
          usingFallbackStorage: result.fallback,
          syncStatus: "idle",
          syncMessage: null,
          syncConflict: null,
          onboardingCompleted: uiState.onboardingCompleted,
          demoData: uiState.demoData
        });
        return;
      }
      set({
        data: result.data,
        status: "ready",
        usingFallbackStorage: result.fallback,
        syncStatus: syncStatusFromData(result.data),
        syncMessage: null,
        syncConflict: null,
        onboardingCompleted: uiState.onboardingCompleted,
        demoData: uiState.demoData
      });
    } catch (caught) {
      set({
        status: "error",
        error: caught instanceof Error ? caught.message : "Local storage could not be initialized.",
        syncStatus: "idle",
        syncMessage: null,
        syncConflict: null
      });
    }
  },
  async completeOnboarding() {
    const next = {
      onboardingCompleted: true,
      demoData: get().demoData
    };
    await saveAuraUiState(next);
    set({ onboardingCompleted: true });
  },
  async resetCorruptData() {
    const empty = createEmptyData();
    await clearAuraData();
    await saveAuraData(empty);
    set({
      data: empty,
      status: "ready",
      error: null,
      corruptRaw: null,
      syncStatus: "idle",
      syncMessage: null,
      syncConflict: null
    });
  },
  async updateSettings(settings) {
    const data = get().data;
    if (!data) return;
    await safeCommit(set, {
      ...data,
      settings: { ...data.settings, ...settings }
    });
  },
  async addGroup(title) {
    const data = get().data;
    if (!data) return void 0;
    const now = nowIso();
    const group = {
      id: createId("group"),
      title: requireTitle(data, title, "groupTitleRequired"),
      collapsed: false,
      order: data.groups.length,
      links: []
    };
    await safeCommit(set, {
      ...data,
      updatedAt: now,
      groups: [...data.groups, group]
    });
    return group.id;
  },
  async updateGroupTitle(groupId, title) {
    const data = get().data;
    if (!data) return;
    const nextTitle = requireTitle(data, title, "groupTitleRequired");
    await safeCommit(set, {
      ...data,
      groups: data.groups.map((group) => group.id === groupId ? { ...group, title: nextTitle } : group)
    });
  },
  async toggleGroupCollapsed(groupId) {
    const data = get().data;
    if (!data) return;
    await safeCommit(set, {
      ...data,
      groups: data.groups.map(
        (group) => group.id === groupId ? { ...group, collapsed: !group.collapsed } : group
      )
    });
  },
  async deleteGroup(groupId) {
    const data = get().data;
    if (!data) return;
    const previous = cloneData(data);
    const group = findGroup(data, groupId);
    const withSafety = withRestorePoint(data, `Before deleting "${group.title}"`, "before_delete");
    await safeCommit(set, {
      ...withSafety,
      groups: withSafety.groups.filter((item) => item.id !== groupId)
    });
    get().addToast({
      type: "info",
      title: text(data, "groupDeleted"),
      message: text(data, "removedMessage", { title: group.title }),
      actionLabel: text(data, "undo"),
      onAction: async () => {
        const current = get().data;
        await safeCommit(set, current ? { ...previous, restorePoints: current.restorePoints } : previous);
      }
    });
  },
  async addLink(groupId, input) {
    const data = get().data;
    if (!data) return;
    const normalized = prepareLinkInput(data, input);
    const now = nowIso();
    await safeCommit(set, {
      ...data,
      groups: data.groups.map(
        (group) => group.id === groupId ? {
          ...group,
          collapsed: false,
          links: [
            ...group.links,
            {
              id: createId("link"),
              ...normalized,
              order: group.links.length,
              createdAt: now,
              updatedAt: now
            }
          ]
        } : group
      )
    });
  },
  async updateLink(groupId, linkId, input) {
    const data = get().data;
    if (!data) return;
    const normalized = prepareLinkInput(data, input);
    await safeCommit(set, {
      ...data,
      groups: data.groups.map(
        (group) => group.id === groupId ? {
          ...group,
          links: group.links.map(
            (link) => link.id === linkId ? { ...link, ...normalized, updatedAt: nowIso() } : link
          )
        } : group
      )
    });
  },
  async deleteLink(groupId, linkId) {
    const data = get().data;
    if (!data) return;
    const previous = cloneData(data);
    const group = findGroup(data, groupId);
    const link = group.links.find((item) => item.id === linkId);
    if (!link) {
      throw new Error(text(data, "linkNotFound"));
    }
    await safeCommit(set, {
      ...data,
      groups: data.groups.map(
        (item) => item.id === groupId ? { ...item, links: item.links.filter((candidate) => candidate.id !== linkId) } : item
      )
    });
    get().addToast({
      type: "info",
      title: text(data, "linkDeleted"),
      message: text(data, "removedMessage", { title: link.title }),
      actionLabel: text(data, "undo"),
      onAction: async () => {
        await safeCommit(set, previous);
      }
    });
  },
  async deleteLinksWithRestorePoint(targets) {
    const data = get().data;
    if (!data) return;
    const uniqueTargets = Array.from(new Set(targets.map((target) => `${target.groupId}::${target.linkId}`)));
    if (!uniqueTargets.length) {
      throw new Error(text(data, "noDuplicateLinksSelected"));
    }
    const previous = cloneData(data);
    const targetIds = new Set(uniqueTargets);
    let deletedCount = 0;
    const withSafety = withRestorePoint(data, "Before deleting duplicate links", "before_delete");
    const groups = withSafety.groups.map((group) => ({
      ...group,
      links: group.links.filter((link) => {
        const deleteLink = targetIds.has(`${group.id}::${link.id}`);
        if (deleteLink) {
          deletedCount += 1;
        }
        return !deleteLink;
      })
    }));
    if (!deletedCount) {
      throw new Error(text(data, "noDuplicateLinksSelected"));
    }
    await safeCommit(set, {
      ...withSafety,
      groups
    });
    get().addToast({
      type: "info",
      title: text(data, "duplicateLinksDeleted", { count: deletedCount }),
      message: text(data, "restorePointCreatedBeforeDeletingDuplicates"),
      actionLabel: text(data, "undo"),
      onAction: async () => {
        const current = get().data;
        await safeCommit(set, current ? { ...previous, restorePoints: current.restorePoints } : previous);
      }
    });
  },
  async reorderGroups(orderedGroupIds) {
    const data = get().data;
    if (!data) return;
    const groupsById = new Map(data.groups.map((group) => [group.id, group]));
    const orderedIdSet = new Set(orderedGroupIds);
    const nextGroups = orderedGroupIds.map((groupId) => groupsById.get(groupId)).filter((group) => Boolean(group));
    const missingGroups = data.groups.filter((group) => !orderedIdSet.has(group.id));
    if (!nextGroups.length || nextGroups.length + missingGroups.length !== data.groups.length) {
      return;
    }
    const nextOrder = [...nextGroups, ...missingGroups];
    const changed = nextOrder.some((group, index) => {
      var _a;
      return group.id !== ((_a = data.groups[index]) == null ? void 0 : _a.id);
    });
    if (!changed) return;
    await optimisticCommit(set, data, { ...data, groups: nextOrder });
  },
  async moveLink(linkId, targetGroupId, overLinkId) {
    const data = get().data;
    if (!data) return;
    const sourceGroup = data.groups.find((group) => group.links.some((link2) => link2.id === linkId));
    const targetGroup = data.groups.find((group) => group.id === targetGroupId);
    if (!sourceGroup || !targetGroup) return;
    const link = sourceGroup.links.find((item) => item.id === linkId);
    if (!link) return;
    const sourceLinks = sourceGroup.links.filter((item) => item.id !== linkId);
    const targetWithoutMoved = sourceGroup.id === targetGroup.id ? sourceLinks : targetGroup.links.filter((item) => item.id !== linkId);
    const foundOverIndex = overLinkId ? targetWithoutMoved.findIndex((item) => item.id === overLinkId) : -1;
    const insertIndex = foundOverIndex >= 0 ? foundOverIndex : targetWithoutMoved.length;
    const nextTargetLinks = targetWithoutMoved.slice();
    nextTargetLinks.splice(insertIndex, 0, link);
    await optimisticCommit(set, data, {
      ...data,
      groups: data.groups.map((group) => {
        if (group.id === sourceGroup.id && group.id === targetGroup.id) {
          return { ...group, links: nextTargetLinks };
        }
        if (group.id === sourceGroup.id) {
          return { ...group, links: sourceLinks };
        }
        if (group.id === targetGroup.id) {
          return { ...group, links: nextTargetLinks };
        }
        return group;
      })
    });
  },
  async addDemoData() {
    const data = get().data;
    if (!data) return;
    const demo = createDemoGroups(data.groups.length);
    const nextMarker = mergeDemoDataMarker(get().demoData, demo.marker);
    await safeCommit(set, {
      ...data,
      groups: [...data.groups, ...demo.groups]
    });
    await saveAuraUiState({
      onboardingCompleted: get().onboardingCompleted,
      demoData: nextMarker
    });
    set({ demoData: nextMarker });
  },
  async removeDemoData() {
    const data = get().data;
    if (!data) return;
    const marker = get().demoData;
    const groupIds = new Set(marker.groupIds);
    const linkIds = new Set(marker.linkIds);
    if (!hasMatchingDemoData(data, marker)) {
      await saveAuraUiState({
        onboardingCompleted: get().onboardingCompleted,
        demoData: EMPTY_DEMO_DATA
      });
      set({ demoData: EMPTY_DEMO_DATA });
      return;
    }
    const withSafety = withRestorePoint(data, "Before removing demo data", "before_delete");
    const nextGroups = withSafety.groups.map((group) => {
      const links = group.links.filter((link) => !linkIds.has(link.id));
      if (groupIds.has(group.id) && links.length === 0) {
        return null;
      }
      return { ...group, links };
    }).filter((group) => group !== null);
    const nextMarker = {
      groupIds: nextGroups.filter((group) => groupIds.has(group.id)).map((group) => group.id),
      linkIds: nextGroups.flatMap((group) => group.links.filter((link) => linkIds.has(link.id)).map((link) => link.id))
    };
    await safeCommit(set, {
      ...withSafety,
      groups: nextGroups
    });
    await saveAuraUiState({
      onboardingCompleted: get().onboardingCompleted,
      demoData: nextMarker
    });
    set({ demoData: nextMarker });
  },
  async importBackup(imported, mode, source = "aura_json") {
    const data = get().data;
    if (!data) return;
    const withSafety = withRestorePoint(data, "Before import", "before_import");
    const next = mode === "replace" ? keepLocalSyncSettings(
      {
        ...imported,
        restorePoints: [withSafety.restorePoints[0], ...imported.restorePoints].slice(0, MAX_RESTORE_POINTS)
      },
      data
    ) : mergeImportedData(withSafety, imported);
    await safeCommit(set, next);
    const importedLinkCount = imported.groups.reduce((count, group) => count + group.links.length, 0);
    get().addToast({
      type: "success",
      title: source === "a_fine_start" ? text(data, "aFineStartImported", { groups: imported.groups.length, links: importedLinkCount }) : mode === "replace" ? text(data, "backupImported") : text(data, "backupMerged"),
      message: text(data, "importRestorePointMessage")
    });
  },
  async resetAllData() {
    const data = get().data;
    if (!data) return;
    const point = createRestorePoint(data, "Before reset", "before_reset");
    const empty = createEmptyData();
    await safeCommit(set, {
      ...empty,
      restorePoints: [point]
    });
  },
  async createManualRestorePoint(name) {
    const data = get().data;
    if (!data) return;
    await safeCommit(set, withRestorePoint(data, requireTitle(data, name, "restorePointNameRequired"), "manual"));
  },
  async restoreRestorePoint(restorePointId) {
    const data = get().data;
    if (!data) return;
    const point = data.restorePoints.find((item) => item.id === restorePointId);
    if (!point) {
      throw new Error(text(data, "restorePointNotFound"));
    }
    const withSafety = withRestorePoint(data, "Before restore", "auto");
    await safeCommit(set, {
      ...point.data,
      restorePoints: withSafety.restorePoints
    });
    get().addToast({
      type: "success",
      title: text(data, "restorePointRestored"),
      message: text(data, "restoreCurrentDataFirst")
    });
  },
  async deleteRestorePoint(restorePointId) {
    const data = get().data;
    if (!data) return;
    await safeCommit(set, {
      ...data,
      restorePoints: data.restorePoints.filter((point) => point.id !== restorePointId)
    });
  },
  async deleteAllRestorePoints() {
    const data = get().data;
    if (!data) return;
    await safeCommit(set, {
      ...data,
      restorePoints: []
    });
    get().addToast({
      type: "success",
      title: text(data, "allRestorePointsDeleted")
    });
  },
  async connectGoogleDrive() {
    const data = get().data;
    if (!data) return;
    set({ syncStatus: "connecting", syncMessage: text(data, "googleDriveConnecting"), syncConflict: null });
    try {
      const sync = ensureSyncDevice(data.settings.sync);
      const token = await getAuthToken(true);
      const metadata = await findSyncFile(token);
      const account = await getConnectedAccountInfo().catch(() => void 0);
      const accountPatch = {
        accountEmail: account == null ? void 0 : account.email,
        accountName: account == null ? void 0 : account.name,
        accountAvatarUrl: account == null ? void 0 : account.avatarUrl
      };
      if (metadata) {
        const download = await downloadSyncFile(metadata.id, token);
        if (download) {
          await applyCloudDownload(set, get, download, accountPatch);
          get().addToast({
            type: "success",
            title: text(get().data, "googleDriveConnected"),
            message: text(get().data, "googleDriveSyncFileFoundAndRestored")
          });
          return;
        }
      }
      const nextSync = mergeSyncSettings(data, {
        ...accountPatch,
        mode: "auto",
        connected: true
      });
      const uploadData = {
        ...data,
        settings: {
          ...data.settings,
          sync: nextSync
        }
      };
      const createdMetadata = await backupToDrive(uploadData, {
        deviceId: nextSync.deviceId,
        token
      });
      const next = await commitSyncMetadata(
        set,
        data,
        {
          ...accountPatch,
          mode: "auto",
          connected: true,
          cloudFileId: createdMetadata.id,
          lastSyncedAt: nowIso(),
          lastCloudUpdatedAt: data.updatedAt
        },
        "connected",
        text(data, "googleDriveNoSyncFileCreated")
      );
      get().addToast({
        type: "success",
        title: text(next, "googleDriveConnected"),
        message: text(next, "googleDriveNoSyncFileCreated")
      });
    } catch (error) {
      driveFailure(set, get, error);
      throw error;
    }
  },
  async disconnectGoogleDrive() {
    const data = get().data;
    if (!data) return;
    clearAutoSyncQueue();
    set({ syncStatus: "syncing", syncMessage: text(data, "googleDriveDisconnecting"), syncConflict: null });
    try {
      const result = await disconnectGoogleAccount();
      const next = await commitSyncMetadata(
        set,
        data,
        {
          mode: "off",
          connected: false,
          accountEmail: void 0,
          accountName: void 0,
          accountAvatarUrl: void 0,
          cloudFileId: void 0,
          lastSyncedAt: void 0,
          lastCloudUpdatedAt: void 0
        },
        "idle",
        text(data, "googleDriveAccountDisconnected")
      );
      get().addToast({
        type: result.revokeError ? "info" : "success",
        title: text(next, "googleDriveAccountDisconnected"),
        message: result.revokeError ? text(next, "googleDriveTokenRevokeFailed", { message: result.revokeError }) : text(next, "googleDriveAccountDisconnectedDescription")
      });
    } catch (error) {
      driveFailure(set, get, error);
      throw error;
    }
  },
  async backupToGoogleDrive(options = {}) {
    const data = get().data;
    if (!data) return;
    set({ syncStatus: "syncing", syncMessage: text(data, "googleDriveBackingUp"), syncConflict: null });
    try {
      const sync = ensureSyncDevice(data.settings.sync);
      const token = options.token ?? await getTokenForSync(sync, !options.silent);
      const metadata = await backupToDrive(data, {
        deviceId: sync.deviceId,
        fileId: sync.cloudFileId,
        token
      });
      const syncedAt = nowIso();
      const next = await commitSyncMetadata(
        set,
        data,
        {
          mode: "auto",
          connected: true,
          cloudFileId: metadata.id,
          lastSyncedAt: syncedAt,
          lastCloudUpdatedAt: data.updatedAt
        },
        "connected",
        text(data, "googleDriveBackupSuccess")
      );
      if (!options.silent) {
        get().addToast({
          type: "success",
          title: text(next, "googleDriveBackupSuccess"),
          message: text(next, "googleDriveBackupSuccessDescription")
        });
      }
    } catch (error) {
      if (options.silent && isGoogleDriveAuthorizationUnavailable(error)) {
        await markGoogleDriveSyncNeedsReconnect(set, get, error);
        return;
      }
      driveFailure(set, get, error);
      throw error;
    }
  },
  async restoreFromGoogleDrive(options = {}) {
    const data = get().data;
    if (!data) return false;
    set({ syncStatus: "syncing", syncMessage: text(data, "googleDriveRestoring"), syncConflict: null });
    try {
      const token = await getTokenForSync(data.settings.sync);
      const download = await restoreFromDrive(token);
      if (!download) {
        if (options.requireExistingFile) {
          set({ syncStatus: "idle", syncMessage: text(data, "googleDriveNoSyncFileFound"), syncConflict: null });
          return false;
        }
        await commitSyncMetadata(
          set,
          data,
          {
            connected: true,
            cloudFileId: void 0,
            lastCloudUpdatedAt: void 0
          },
          "connected",
          text(data, "googleDriveNoSyncFileFound")
        );
        get().addToast({
          type: "info",
          title: text(data, "googleDriveNoSyncFileFound")
        });
        return false;
      }
      await applyCloudDownload(set, get, download);
      get().addToast({
        type: "success",
        title: text(get().data, "googleDriveRestoreSuccess"),
        message: text(get().data, "googleDriveRestoreSuccessDescription")
      });
      return true;
    } catch (error) {
      driveFailure(set, get, error);
      throw error;
    }
  },
  async syncNow(options = {}) {
    const data = get().data;
    if (!data) return;
    set({ syncStatus: "syncing", syncMessage: text(data, "googleDriveSyncing"), syncConflict: null });
    try {
      const sync = ensureSyncDevice(data.settings.sync);
      const token = await getTokenForSync(sync, !options.silent);
      const download = await downloadSyncFile(sync.cloudFileId, token);
      const comparison = compareLocalAndCloud(data, download, sync);
      if (comparison === "no_cloud_file") {
        await get().backupToGoogleDrive({ silent: true, token });
        if (!options.silent) {
          get().addToast({
            type: "success",
            title: text(get().data, "googleDriveBackupSuccess"),
            message: text(get().data, "googleDriveNoFileUploadedLocal")
          });
        }
        return;
      }
      if (!download) return;
      if (comparison === "in_sync") {
        const next = await commitSyncMetadata(
          set,
          data,
          {
            mode: "auto",
            connected: true,
            cloudFileId: download.metadata.id,
            lastSyncedAt: nowIso(),
            lastCloudUpdatedAt: download.cloudUpdatedAt
          },
          "connected",
          text(data, "googleDriveAlreadySynced")
        );
        if (!options.silent) {
          get().addToast({ type: "success", title: text(next, "googleDriveAlreadySynced") });
        }
        return;
      }
      if (comparison === "local_newer") {
        await get().backupToGoogleDrive({ silent: true, token });
        if (!options.silent) {
          get().addToast({
            type: "success",
            title: text(get().data, "googleDriveBackupSuccess"),
            message: text(get().data, "googleDriveLocalUploaded")
          });
        }
        return;
      }
      if (comparison === "cloud_newer") {
        await commitSyncMetadata(
          set,
          data,
          {
            mode: "auto",
            connected: true,
            cloudFileId: download.metadata.id,
            lastCloudUpdatedAt: download.cloudUpdatedAt
          },
          "connected",
          text(data, "googleDriveCloudNewer")
        );
        get().addToast({
          type: "info",
          title: text(data, "googleDriveCloudNewer"),
          message: text(data, "googleDriveCloudNewerDescription")
        });
        return;
      }
      set({
        syncStatus: "conflict",
        syncMessage: text(data, "googleDriveConflictDetected"),
        syncConflict: {
          detectedAt: nowIso(),
          localUpdatedAt: data.updatedAt,
          cloudUpdatedAt: download.cloudUpdatedAt,
          cloudFileId: download.metadata.id,
          cloudData: download.data
        }
      });
      get().addToast({
        type: "error",
        title: text(data, "googleDriveConflictDetected"),
        message: text(data, "googleDriveConflictDescription")
      });
    } catch (error) {
      if (options.silent && isGoogleDriveAuthorizationUnavailable(error)) {
        await markGoogleDriveSyncNeedsReconnect(set, get, error);
        return;
      }
      driveFailure(set, get, error);
      throw error;
    }
  },
  async setSyncMode(mode) {
    const data = get().data;
    if (!data) return;
    const nextMode = mode === "off" ? "off" : "auto";
    if (nextMode === "off") {
      clearAutoSyncQueue();
    }
    const patch = { mode: nextMode };
    await commitSyncMetadata(
      set,
      data,
      patch,
      nextMode === "off" ? "idle" : syncStatusFromData({ ...data, settings: { ...data.settings, sync: mergeSyncSettings(data, patch) } }),
      nextMode === "off" ? text(data, "googleDriveSyncDisabled") : text(data, "googleDriveSyncModeUpdated")
    );
  },
  async deleteGoogleDriveSyncFile() {
    const data = get().data;
    if (!data) return;
    set({ syncStatus: "syncing", syncMessage: text(data, "googleDriveDeletingSyncFile"), syncConflict: null });
    try {
      const token = await getTokenForSync(data.settings.sync);
      const deleted = await deleteSyncFile(token);
      const next = await commitSyncMetadata(
        set,
        data,
        {
          connected: true,
          cloudFileId: void 0,
          lastCloudUpdatedAt: void 0,
          lastSyncedAt: void 0
        },
        "connected",
        deleted ? text(data, "googleDriveSyncFileDeleted") : text(data, "googleDriveNoSyncFileFound")
      );
      get().addToast({
        type: deleted ? "success" : "info",
        title: deleted ? text(next, "googleDriveSyncFileDeleted") : text(next, "googleDriveNoSyncFileFound"),
        message: deleted ? text(next, "googleDriveSyncFileDeletedDescription") : void 0
      });
    } catch (error) {
      driveFailure(set, get, error);
      throw error;
    }
  },
  async deleteGoogleDriveBackupAndDisconnect() {
    const data = get().data;
    if (!data) return;
    clearAutoSyncQueue();
    set({ syncStatus: "syncing", syncMessage: text(data, "googleDriveDeleteBackupAndDisconnecting"), syncConflict: null });
    try {
      const token = await getCachedAuthToken();
      let deleted = false;
      let deleteError;
      if (token) {
        try {
          deleted = await deleteSyncFile(token);
        } catch (error) {
          deleteError = mapDriveError(error);
        }
      }
      const result = await disconnectGoogleAccount(token);
      const next = await commitSyncMetadata(
        set,
        data,
        {
          mode: "off",
          connected: false,
          accountEmail: void 0,
          accountName: void 0,
          accountAvatarUrl: void 0,
          cloudFileId: void 0,
          lastSyncedAt: void 0,
          lastCloudUpdatedAt: void 0
        },
        "idle",
        text(data, "googleDriveBackupDeletedAndAccountDisconnected")
      );
      let toastMessage;
      if (deleteError) {
        toastMessage = text(next, "googleDriveBackupDeleteFailedAccountDisconnected", { message: deleteError });
      } else if (result.revokeError) {
        toastMessage = text(next, "googleDriveTokenRevokeFailed", { message: result.revokeError });
      } else if (!token) {
        toastMessage = text(next, "googleDriveDisconnectedWithoutGoogleWindow");
      } else if (deleted) {
        toastMessage = text(next, "googleDriveBackupDeletedAndAccountDisconnectedDescription");
      } else {
        toastMessage = text(next, "googleDriveNoBackupFoundAccountDisconnectedDescription");
      }
      get().addToast({
        type: deleteError || result.revokeError || !token ? "info" : "success",
        title: text(next, "googleDriveBackupDeletedAndAccountDisconnected"),
        message: toastMessage
      });
    } catch (error) {
      driveFailure(set, get, error);
      throw error;
    }
  },
  async resolveSyncConflict(choice) {
    const conflict = get().syncConflict;
    if (!conflict) return;
    if (choice === "keep_local") {
      await get().backupToGoogleDrive();
      set({ syncConflict: null, syncStatus: "connected", syncMessage: text(get().data, "googleDriveLocalUploaded") });
      return;
    }
    await applyCloudDownload(set, get, {
      metadata: {
        id: conflict.cloudFileId ?? "",
        name: "aura-start-sync.json"
      },
      payload: {
        updatedAt: conflict.cloudUpdatedAt,
        deviceId: conflict.cloudData.settings.sync.deviceId,
        data: conflict.cloudData
      },
      data: conflict.cloudData,
      cloudUpdatedAt: conflict.cloudUpdatedAt
    });
    get().addToast({
      type: "success",
      title: text(get().data, "googleDriveRestoreSuccess"),
      message: text(get().data, "googleDriveRestoreSuccessDescription")
    });
  },
  addToast(toast) {
    const id = createId("toast");
    set((state) => ({ toasts: [...state.toasts, { ...toast, id }] }));
    window.setTimeout(() => {
      get().removeToast(id);
    }, toast.type === "error" ? 8e3 : 5e3);
  },
  removeToast(toastId) {
    set((state) => ({ toasts: state.toasts.filter((toast) => toast.id !== toastId) }));
  }
}));
export {
  DEFAULT_SETTINGS as D,
  ExternalLink as E,
  GoogleDriveSyncError as G,
  MAX_RESTORE_POINTS as M,
  React as R,
  Settings as S,
  Download as a,
  createLucideIcon as b,
  clientExports as c,
  requireReactDom as d,
  exportJsonBackup as e,
  downloadTextFile as f,
  dateForFile as g,
  toUnixSeconds as h,
  formatDateTime as i,
  jsxRuntimeExports as j,
  createId as k,
  DATA_VERSION as l,
  normalizeUrl as m,
  nowIso as n,
  createJsonBackup as o,
  parseJsonBackup as p,
  languageOptions as q,
  reactExports as r,
  t,
  useAuraStore as u
};
