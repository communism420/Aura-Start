import { b as createLucideIcon, r as reactExports, j as jsxRuntimeExports, t, a as Download, d as requireReactDom, R as React, f as downloadTextFile, g as dateForFile, h as toUnixSeconds, e as exportJsonBackup, i as formatDateTime, S as Settings, n as nowIso, k as createId, D as DEFAULT_SETTINGS, l as DATA_VERSION, m as normalizeUrl, p as parseJsonBackup, M as MAX_RESTORE_POINTS, o as createJsonBackup, G as GoogleDriveSyncError, q as languageOptions, E as ExternalLink, u as useAuraStore } from "./styles-Bx0ca_OT.js";
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Check = createLucideIcon("Check", [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ChevronDown = createLucideIcon("ChevronDown", [
  ["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ChevronRight = createLucideIcon("ChevronRight", [
  ["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const CircleAlert = createLucideIcon("CircleAlert", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "12", key: "1pkeuh" }],
  ["line", { x1: "12", x2: "12.01", y1: "16", y2: "16", key: "4dfq90" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const CircleCheck = createLucideIcon("CircleCheck", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const CircleHelp = createLucideIcon("CircleHelp", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3", key: "1u773s" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Cloud = createLucideIcon("Cloud", [
  ["path", { d: "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z", key: "p7xjir" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Command = createLucideIcon("Command", [
  [
    "path",
    { d: "M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3", key: "11bfej" }
  ]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Database = createLucideIcon("Database", [
  ["ellipse", { cx: "12", cy: "5", rx: "9", ry: "3", key: "msslwz" }],
  ["path", { d: "M3 5V19A9 3 0 0 0 21 19V5", key: "1wlel7" }],
  ["path", { d: "M3 12A9 3 0 0 0 21 12", key: "mv7ke4" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const FileUp = createLucideIcon("FileUp", [
  ["path", { d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z", key: "1rqfz7" }],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M12 12v6", key: "3ahymv" }],
  ["path", { d: "m15 15-3-3-3 3", key: "15xj92" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const FolderPlus = createLucideIcon("FolderPlus", [
  ["path", { d: "M12 10v6", key: "1bos4e" }],
  ["path", { d: "M9 13h6", key: "1uhe8q" }],
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const GripVertical = createLucideIcon("GripVertical", [
  ["circle", { cx: "9", cy: "12", r: "1", key: "1vctgf" }],
  ["circle", { cx: "9", cy: "5", r: "1", key: "hp0tcf" }],
  ["circle", { cx: "9", cy: "19", r: "1", key: "fkjjf6" }],
  ["circle", { cx: "15", cy: "12", r: "1", key: "1tmaij" }],
  ["circle", { cx: "15", cy: "5", r: "1", key: "19l28e" }],
  ["circle", { cx: "15", cy: "19", r: "1", key: "f4zoj3" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Info = createLucideIcon("Info", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 16v-4", key: "1dtifu" }],
  ["path", { d: "M12 8h.01", key: "e9boi3" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Keyboard = createLucideIcon("Keyboard", [
  ["path", { d: "M10 8h.01", key: "1r9ogq" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M14 8h.01", key: "1primd" }],
  ["path", { d: "M16 12h.01", key: "1l6xoz" }],
  ["path", { d: "M18 8h.01", key: "emo2bl" }],
  ["path", { d: "M6 8h.01", key: "x9i8wu" }],
  ["path", { d: "M7 16h10", key: "wp8him" }],
  ["path", { d: "M8 12h.01", key: "czm47f" }],
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Link = createLucideIcon("Link", [
  ["path", { d: "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71", key: "1cjeqo" }],
  ["path", { d: "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71", key: "19qd67" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Palette = createLucideIcon("Palette", [
  ["circle", { cx: "13.5", cy: "6.5", r: ".5", fill: "currentColor", key: "1okk4w" }],
  ["circle", { cx: "17.5", cy: "10.5", r: ".5", fill: "currentColor", key: "f64h9f" }],
  ["circle", { cx: "8.5", cy: "7.5", r: ".5", fill: "currentColor", key: "fotxhn" }],
  ["circle", { cx: "6.5", cy: "12.5", r: ".5", fill: "currentColor", key: "qy21gx" }],
  [
    "path",
    {
      d: "M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z",
      key: "12rzf8"
    }
  ]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Pencil = createLucideIcon("Pencil", [
  [
    "path",
    {
      d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
      key: "1a8usu"
    }
  ],
  ["path", { d: "m15 5 4 4", key: "1mk7zo" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const RefreshCw = createLucideIcon("RefreshCw", [
  ["path", { d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8", key: "v9h5vc" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }],
  ["path", { d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16", key: "3uifl3" }],
  ["path", { d: "M8 16H3v5", key: "1cv678" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const RotateCcw = createLucideIcon("RotateCcw", [
  ["path", { d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "1357e3" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const SearchCheck = createLucideIcon("SearchCheck", [
  ["path", { d: "m8 11 2 2 4-4", key: "1sed1v" }],
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["path", { d: "m21 21-4.3-4.3", key: "1qie3q" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Search = createLucideIcon("Search", [
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["path", { d: "m21 21-4.3-4.3", key: "1qie3q" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ShieldCheck = createLucideIcon("ShieldCheck", [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ShieldPlus = createLucideIcon("ShieldPlus", [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "M9 12h6", key: "1c52cq" }],
  ["path", { d: "M12 9v6", key: "199k2o" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Sparkles = createLucideIcon("Sparkles", [
  [
    "path",
    {
      d: "M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",
      key: "4pj2yx"
    }
  ],
  ["path", { d: "M20 3v4", key: "1olli1" }],
  ["path", { d: "M22 5h-4", key: "1gvqau" }],
  ["path", { d: "M4 17v2", key: "vumght" }],
  ["path", { d: "M5 18H3", key: "zchphs" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Trash2 = createLucideIcon("Trash2", [
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", key: "4alrt4" }],
  ["path", { d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", key: "v07s0e" }],
  ["line", { x1: "10", x2: "10", y1: "11", y2: "17", key: "1uufr5" }],
  ["line", { x1: "14", x2: "14", y1: "11", y2: "17", key: "xtxkd" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const TriangleAlert = createLucideIcon("TriangleAlert", [
  [
    "path",
    {
      d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
      key: "wmoenq"
    }
  ],
  ["path", { d: "M12 9v4", key: "juzpu7" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Upload = createLucideIcon("Upload", [
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["polyline", { points: "17 8 12 3 7 8", key: "t8dd8p" }],
  ["line", { x1: "12", x2: "12", y1: "3", y2: "15", key: "widbto" }]
]);
/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const X = createLucideIcon("X", [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
]);
const sizeClass = {
  sm: "max-w-md",
  md: "max-w-xl",
  lg: "max-w-3xl",
  xl: "max-w-6xl"
};
function Modal({ open, title, description, children, closeLabel = "Close dialog", onClose, size = "md" }) {
  reactExports.useEffect(() => {
    if (!open) return;
    function handleKeyDown(event) {
      if (event.key === "Escape") {
        onClose();
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [onClose, open]);
  if (!open) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: "fixed inset-0 z-40 flex items-start justify-center overflow-y-auto bg-black/34 px-4 py-8 backdrop-blur-sm",
      role: "presentation",
      onMouseDown: (event) => {
        if (event.target === event.currentTarget) {
          onClose();
        }
      },
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "section",
        {
          "aria-modal": "true",
          "aria-labelledby": "modal-title",
          className: `surface w-full ${sizeClass[size]} rounded-xl p-5`,
          role: "dialog",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-5 flex items-start justify-between gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-semibold", id: "modal-title", children: title }),
                description ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted mt-1 text-sm", children: description }) : null
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-ghost h-9 w-9 p-0", type: "button", onClick: onClose, "aria-label": closeLabel, children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 18 }) })
            ] }),
            children
          ]
        }
      )
    }
  );
}
function AddEditGroupDialog({ language, open, group, onClose, onSubmit, onError }) {
  const [title, setTitle] = reactExports.useState("");
  reactExports.useEffect(() => {
    if (open) {
      setTitle((group == null ? void 0 : group.title) ?? "");
    }
  }, [group, open]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Modal, { open, title: group ? t(language, "renameGroup") : t(language, "addGroup"), closeLabel: t(language, "closeDialog"), onClose, size: "sm", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "form",
    {
      className: "space-y-4",
      onSubmit: (event) => {
        event.preventDefault();
        void onSubmit(title).then(onClose).catch((error) => onError(error instanceof Error ? error.message : t(language, "couldNotSaveGroup")));
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-sm font-semibold", children: t(language, "title") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              autoFocus: true,
              className: "field",
              maxLength: 80,
              placeholder: t(language, "groupTitlePlaceholder"),
              value: title,
              onChange: (event) => setTitle(event.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", type: "button", onClick: onClose, children: t(language, "cancel") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-primary", type: "submit", children: group ? t(language, "save") : t(language, "addGroup") })
        ] })
      ]
    }
  ) });
}
function AddEditLinkDialog({
  language,
  open,
  groups,
  initialGroupId,
  editing,
  onClose,
  onCreateGroup,
  onAdd,
  onUpdate,
  onError
}) {
  const sortedGroups = reactExports.useMemo(() => groups.slice().sort((a, b) => a.order - b.order), [groups]);
  const [groupId, setGroupId] = reactExports.useState("");
  const [newGroupTitle, setNewGroupTitle] = reactExports.useState(t(language, "startGroupTitle"));
  const [form, setForm] = reactExports.useState({ title: "", url: "", description: "", tags: "" });
  reactExports.useEffect(() => {
    var _a, _b;
    if (!open) return;
    const targetGroupId = (editing == null ? void 0 : editing.groupId) ?? initialGroupId ?? ((_a = sortedGroups[0]) == null ? void 0 : _a.id) ?? "";
    setGroupId(targetGroupId);
    setNewGroupTitle(t(language, "startGroupTitle"));
    setForm({
      title: (editing == null ? void 0 : editing.link.title) ?? "",
      url: (editing == null ? void 0 : editing.link.url) ?? "",
      description: (editing == null ? void 0 : editing.link.description) ?? "",
      tags: ((_b = editing == null ? void 0 : editing.link.tags) == null ? void 0 : _b.join(", ")) ?? ""
    });
  }, [editing, initialGroupId, language, open, sortedGroups]);
  const updateField = (field, value) => {
    setForm((current) => ({ ...current, [field]: value }));
  };
  async function handleSubmit() {
    let targetGroupId = groupId;
    if (!editing && !targetGroupId) {
      const createdId = await onCreateGroup(newGroupTitle);
      if (!createdId) {
        throw new Error(t(language, "couldNotCreateGroupForLink"));
      }
      targetGroupId = createdId;
    }
    if (editing) {
      await onUpdate(editing.groupId, editing.link.id, form);
    } else {
      await onAdd(targetGroupId, form);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Modal, { open, title: editing ? t(language, "editLink") : t(language, "addLink"), closeLabel: t(language, "closeDialog"), onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "form",
    {
      className: "space-y-4",
      onSubmit: (event) => {
        event.preventDefault();
        void handleSubmit().then(onClose).catch((error) => onError(error instanceof Error ? error.message : t(language, "couldNotSaveLink")));
      },
      children: [
        !editing && sortedGroups.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-sm font-semibold", children: t(language, "group") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("select", { className: "field", value: groupId, onChange: (event) => setGroupId(event.target.value), children: sortedGroups.map((group) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: group.id, children: group.title }, group.id)) })
        ] }) : null,
        !editing && sortedGroups.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-sm font-semibold", children: t(language, "newGroupTitle") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "field",
              maxLength: 80,
              value: newGroupTitle,
              onChange: (event) => setNewGroupTitle(event.target.value)
            }
          )
        ] }) : null,
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-sm font-semibold", children: t(language, "title") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                autoFocus: true,
                className: "field",
                maxLength: 120,
                placeholder: t(language, "projectDashboard"),
                value: form.title,
                onChange: (event) => updateField("title", event.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-sm font-semibold", children: t(language, "url") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                className: "field",
                placeholder: "example.com",
                value: form.url,
                onChange: (event) => updateField("url", event.target.value)
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-sm font-semibold", children: t(language, "description") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "textarea",
            {
              className: "field min-h-24 resize-y",
              maxLength: 260,
              placeholder: t(language, "optionalNote"),
              value: form.description,
              onChange: (event) => updateField("description", event.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-sm font-semibold", children: t(language, "tags") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "field",
              placeholder: t(language, "tagsPlaceholder"),
              value: form.tags,
              onChange: (event) => updateField("tags", event.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", type: "button", onClick: onClose, children: t(language, "cancel") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-primary", type: "submit", children: editing ? t(language, "saveLink") : t(language, "addLink") })
        ] })
      ]
    }
  ) });
}
function commandMatches(command, query) {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return true;
  const haystack = [command.title, command.description ?? "", ...command.keywords ?? []].join(" ").toLowerCase();
  return haystack.includes(normalized);
}
function CommandPalette({ language, open, commands, onClose, onError }) {
  const [query, setQuery] = reactExports.useState("");
  const [selectedIndex, setSelectedIndex] = reactExports.useState(0);
  const inputRef = reactExports.useRef(null);
  const filteredCommands = reactExports.useMemo(
    () => commands.filter((command) => commandMatches(command, query)),
    [commands, query]
  );
  const selectedCommand = filteredCommands[selectedIndex];
  reactExports.useEffect(() => {
    if (!open) return;
    setQuery("");
    setSelectedIndex(0);
    window.requestAnimationFrame(() => {
      var _a;
      return (_a = inputRef.current) == null ? void 0 : _a.focus();
    });
  }, [open]);
  reactExports.useEffect(() => {
    if (selectedIndex >= filteredCommands.length) {
      setSelectedIndex(Math.max(0, filteredCommands.length - 1));
    }
  }, [filteredCommands.length, selectedIndex]);
  if (!open) return null;
  const runCommand = async (command) => {
    if (!command) return;
    onClose();
    try {
      await command.action();
    } catch (error) {
      onError(error instanceof Error ? error.message : t(language, "commandFailed"));
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      "aria-label": t(language, "commandPalette"),
      "aria-modal": "true",
      className: "fixed inset-0 z-50 flex items-start justify-center bg-black/34 px-4 py-20 backdrop-blur-sm",
      role: "dialog",
      onMouseDown: (event) => {
        if (event.target === event.currentTarget) {
          onClose();
        }
      },
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "command-palette surface w-full max-w-2xl rounded-xl p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 border-b border-[var(--border)] pb-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { "aria-hidden": "true", className: "text-[var(--muted)]", size: 18 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              "aria-label": t(language, "typeACommand"),
              "aria-activedescendant": selectedCommand ? `command-palette-${selectedCommand.id}` : void 0,
              "aria-controls": "command-palette-listbox",
              className: "command-palette-input",
              placeholder: t(language, "typeACommand"),
              ref: inputRef,
              value: query,
              onChange: (event) => {
                setQuery(event.target.value);
                setSelectedIndex(0);
              },
              onKeyDown: (event) => {
                if (event.key === "Escape") {
                  event.preventDefault();
                  onClose();
                  return;
                }
                if (event.key === "ArrowDown" || event.key === "ArrowUp") {
                  event.preventDefault();
                  const direction = event.key === "ArrowDown" ? 1 : -1;
                  setSelectedIndex(
                    (current) => filteredCommands.length ? (current + direction + filteredCommands.length) % filteredCommands.length : 0
                  );
                  return;
                }
                if (event.key === "Enter") {
                  event.preventDefault();
                  void runCommand(filteredCommands[selectedIndex]);
                }
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-ghost h-9 w-9 p-0", type: "button", "aria-label": t(language, "closeDialog"), onClick: onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 17 }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 max-h-[min(28rem,60vh)] overflow-y-auto", id: "command-palette-listbox", role: "listbox", children: filteredCommands.length ? filteredCommands.map((command, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            "aria-selected": index === selectedIndex,
            className: `command-palette-item ${index === selectedIndex ? "command-palette-item-selected" : ""}`,
            id: `command-palette-${command.id}`,
            role: "option",
            type: "button",
            onMouseEnter: () => setSelectedIndex(index),
            onClick: () => void runCommand(command),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold", children: command.title }),
              command.description ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "muted text-sm", children: command.description }) : null
            ]
          },
          command.id
        )) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "muted p-4 text-center text-sm", children: t(language, "noCommandsFound") }) })
      ] })
    }
  );
}
function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel,
  cancelLabel = "Cancel",
  tone = "danger",
  onConfirm,
  onCancel
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Modal, { open, title, closeLabel: cancelLabel, onClose: onCancel, size: "sm", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: `flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${tone === "danger" ? "bg-[var(--danger-soft)] text-[var(--danger)]" : "bg-[var(--accent-soft)]"}`,
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { size: 20 })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted text-sm leading-6", children: message })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex justify-end gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", type: "button", onClick: onCancel, children: cancelLabel }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: tone === "danger" ? "btn btn-danger" : "btn btn-primary",
          type: "button",
          onClick: () => {
            void onConfirm();
          },
          children: confirmLabel
        }
      )
    ] })
  ] });
}
function trimTrailingSlash(pathname) {
  if (pathname === "/") return "";
  return pathname.endsWith("/") ? pathname.slice(0, -1) : pathname;
}
function parseUrl(rawUrl) {
  try {
    return new URL(rawUrl);
  } catch {
    return void 0;
  }
}
function originalHost(rawUrl) {
  var _a;
  return (_a = rawUrl.match(/^[a-z][a-z\d+.-]*:\/\/([^/?#]*)/i)) == null ? void 0 : _a[1];
}
function isWebUrl(url) {
  return (url == null ? void 0 : url.protocol) === "http:" || (url == null ? void 0 : url.protocol) === "https:";
}
function exactKey(item) {
  if (!isWebUrl(item.parsed)) {
    return `raw:${item.rawUrl}`;
  }
  const url = item.parsed;
  return [
    url.protocol,
    url.hostname.toLowerCase(),
    url.port,
    trimTrailingSlash(url.pathname),
    url.search,
    url.hash
  ].join("|");
}
function possibleHttpHttpsKey(item) {
  if (!isWebUrl(item.parsed)) return void 0;
  const url = item.parsed;
  return [url.hostname.toLowerCase(), url.port, trimTrailingSlash(url.pathname), url.search, url.hash].join("|");
}
function exactReason(items) {
  const hostVariants = new Set(
    items.map((item) => originalHost(item.rawUrl)).filter((host) => Boolean(host))
  );
  if (hostVariants.size > 1) {
    return "hostname_case";
  }
  const pathVariants = new Set(items.map((item) => isWebUrl(item.parsed) ? item.parsed.pathname : item.rawUrl));
  if (pathVariants.size > 1) {
    return "trailing_slash";
  }
  return "exact_url";
}
function addToBucket(map, key2, item, reason) {
  const bucket = map.get(key2);
  if (bucket) {
    bucket.items.push(item);
    return;
  }
  map.set(key2, { reason, items: [item] });
}
function toDuplicateGroups(kind, buckets) {
  return Array.from(buckets.entries()).filter(([, bucket]) => bucket.items.length > 1).map(([key2, bucket]) => ({
    id: `${kind}:${key2}`,
    kind,
    reason: kind === "exact" ? exactReason(bucket.items) : bucket.reason,
    items: bucket.items.map(({ groupId, groupTitle, link }) => ({ groupId, groupTitle, link }))
  }));
}
function findDuplicateLinks(data) {
  const indexed = data.groups.flatMap(
    (group) => group.links.map((link) => {
      const rawUrl = link.url.trim();
      return {
        groupId: group.id,
        groupTitle: group.title,
        link,
        rawUrl,
        parsed: parseUrl(rawUrl)
      };
    })
  );
  const exactBuckets = /* @__PURE__ */ new Map();
  const possibleBuckets = /* @__PURE__ */ new Map();
  indexed.forEach((item) => {
    addToBucket(exactBuckets, exactKey(item), item, "exact_url");
    const possibleKey = possibleHttpHttpsKey(item);
    if (possibleKey) {
      addToBucket(possibleBuckets, possibleKey, item, "http_https");
    }
  });
  return [
    ...toDuplicateGroups("exact", exactBuckets),
    ...toDuplicateGroups("possible", possibleBuckets).filter((group) => {
      const protocols = new Set(group.items.map((item) => {
        var _a;
        return (_a = parseUrl(item.link.url)) == null ? void 0 : _a.protocol;
      }).filter(Boolean));
      return protocols.has("http:") && protocols.has("https:");
    })
  ];
}
function itemId(item) {
  return `${item.groupId}::${item.link.id}`;
}
function reasonLabel(language, reason) {
  switch (reason) {
    case "exact_url":
      return t(language, "duplicateReasonExactUrl");
    case "hostname_case":
      return t(language, "duplicateReasonHostnameCase");
    case "trailing_slash":
      return t(language, "duplicateReasonTrailingSlash");
    case "http_https":
      return t(language, "duplicateReasonHttpHttps");
  }
}
function selectedTargets(selected) {
  return Array.from(selected).map((id) => {
    const [groupId, linkId] = id.split("::");
    return { groupId, linkId };
  });
}
function willRemoveAllCopies(groups, selected) {
  return groups.some((group) => group.items.every((item) => selected.has(itemId(item))));
}
function DuplicateFinderDialog({
  language,
  open,
  data,
  onClose,
  onDeleteSelected,
  onError
}) {
  const duplicateGroups = reactExports.useMemo(() => findDuplicateLinks(data), [data]);
  const exactGroups = duplicateGroups.filter((group) => group.kind === "exact");
  const possibleGroups = duplicateGroups.filter((group) => group.kind === "possible");
  const [selected, setSelected] = reactExports.useState(/* @__PURE__ */ new Set());
  const [confirmOpen, setConfirmOpen] = reactExports.useState(false);
  const selectedCount = selected.size;
  const removesAllCopies = willRemoveAllCopies(duplicateGroups, selected);
  reactExports.useEffect(() => {
    if (open) {
      setSelected(/* @__PURE__ */ new Set());
      setConfirmOpen(false);
    }
  }, [open, data.updatedAt]);
  function toggleItem(id) {
    setSelected((current) => {
      const next = new Set(current);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }
  function keepOnly(group, keepId) {
    setSelected((current) => {
      const next = new Set(current);
      group.items.forEach((item) => {
        const id = itemId(item);
        if (id === keepId) {
          next.delete(id);
        } else {
          next.add(id);
        }
      });
      return next;
    });
  }
  const renderGroup = (group) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-[var(--border)] p-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-3 flex flex-wrap items-center justify-between gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: reasonLabel(language, group.reason) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "muted text-sm", children: t(language, "linksCount", { count: group.items.length }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: group.items.map((item) => {
      const id = itemId(item);
      const checked = selected.has(id);
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "duplicate-row", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex min-w-0 flex-1 items-start gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              "aria-label": t(language, "selectDuplicateLink", { title: item.link.title }),
              checked,
              className: "mt-1",
              type: "checkbox",
              onChange: () => toggleItem(id)
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block truncate font-semibold", children: item.link.title }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "muted block truncate text-sm", children: item.link.url }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "muted block text-xs", children: item.groupTitle })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            "aria-label": `${t(language, "keepThis")}: ${item.link.title}`,
            className: "btn btn-secondary shrink-0",
            type: "button",
            onClick: () => keepOnly(group, id),
            children: t(language, "keepThis")
          }
        )
      ] }, id);
    }) })
  ] }, group.id);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Modal,
      {
        open,
        title: t(language, "duplicateFinder"),
        description: t(language, "duplicateFinderDescription"),
        closeLabel: t(language, "closeDialog"),
        onClose,
        size: "xl",
        children: duplicateGroups.length ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-lg bg-[var(--accent-soft)] p-3 text-sm text-[var(--accent-strong)]", children: t(language, "duplicateFinderReadOnly") }),
          exactGroups.length ? /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold", children: t(language, "exactDuplicates") }),
            exactGroups.map(renderGroup)
          ] }) : null,
          possibleGroups.length ? /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold", children: t(language, "possibleDuplicates") }),
            possibleGroups.map(renderGroup)
          ] }) : null,
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sticky bottom-0 flex flex-wrap items-center justify-between gap-3 border-t border-[var(--border)] bg-[var(--surface)] pt-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "muted text-sm", children: t(language, "selectedDuplicatesCount", { count: selectedCount }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-danger", disabled: !selectedCount, type: "button", onClick: () => setConfirmOpen(true), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { size: 16 }),
              t(language, "deleteSelected")
            ] })
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "surface-flat rounded-xl p-8 text-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SearchCheck, { className: "mx-auto text-[var(--accent)]", size: 32 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 font-semibold", children: t(language, "noDuplicatesFound") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted mt-1 text-sm", children: t(language, "duplicateFinderNoMutation") })
        ] })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      ConfirmDialog,
      {
        cancelLabel: t(language, "cancel"),
        confirmLabel: t(language, "deleteSelected"),
        message: removesAllCopies ? `${t(language, "deleteSelectedDuplicatesMessage", { count: selectedCount })} ${t(language, "thisWouldRemoveAllCopies")}` : t(language, "deleteSelectedDuplicatesMessage", { count: selectedCount }),
        open: confirmOpen,
        title: t(language, "deleteSelectedDuplicates"),
        onCancel: () => setConfirmOpen(false),
        onConfirm: async () => {
          try {
            await onDeleteSelected(selectedTargets(selected));
            setConfirmOpen(false);
            setSelected(/* @__PURE__ */ new Set());
          } catch (error) {
            onError(error instanceof Error ? error.message : t(language, "couldNotCompleteAction"));
          }
        }
      }
    )
  ] });
}
function EmptyState({
  language,
  mode,
  onAddGroup,
  onAddDemoData,
  onImportAFineStart,
  onImportBackup
}) {
  if (mode === "search") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "initial-view", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { children: t(language, "noResults") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted", children: t(language, "searchDescription") })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "initial-view", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { children: t(language, "hiThere") }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: t(language, "onboardingDescription") }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "initial-actions", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-primary", type: "button", onClick: onAddGroup, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(FolderPlus, { size: 17 }),
        t(language, "createYourFirstGroup")
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary", type: "button", onClick: onImportAFineStart, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(FileUp, { size: 17 }),
        t(language, "importFromAFineStart")
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary", type: "button", onClick: onImportBackup, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { size: 17 }),
        t(language, "importBackupFile")
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary", type: "button", onClick: onAddDemoData, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { size: 17 }),
        t(language, "addDemoGroups")
      ] })
    ] })
  ] });
}
var reactDomExports = requireReactDom();
function useCombinedRefs() {
  for (var _len = arguments.length, refs = new Array(_len), _key = 0; _key < _len; _key++) {
    refs[_key] = arguments[_key];
  }
  return reactExports.useMemo(
    () => (node) => {
      refs.forEach((ref) => ref(node));
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    refs
  );
}
const canUseDOM = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
function isWindow(element) {
  const elementString = Object.prototype.toString.call(element);
  return elementString === "[object Window]" || // In Electron context the Window object serializes to [object global]
  elementString === "[object global]";
}
function isNode(node) {
  return "nodeType" in node;
}
function getWindow(target) {
  var _target$ownerDocument, _target$ownerDocument2;
  if (!target) {
    return window;
  }
  if (isWindow(target)) {
    return target;
  }
  if (!isNode(target)) {
    return window;
  }
  return (_target$ownerDocument = (_target$ownerDocument2 = target.ownerDocument) == null ? void 0 : _target$ownerDocument2.defaultView) != null ? _target$ownerDocument : window;
}
function isDocument(node) {
  const {
    Document
  } = getWindow(node);
  return node instanceof Document;
}
function isHTMLElement(node) {
  if (isWindow(node)) {
    return false;
  }
  return node instanceof getWindow(node).HTMLElement;
}
function isSVGElement(node) {
  return node instanceof getWindow(node).SVGElement;
}
function getOwnerDocument(target) {
  if (!target) {
    return document;
  }
  if (isWindow(target)) {
    return target.document;
  }
  if (!isNode(target)) {
    return document;
  }
  if (isDocument(target)) {
    return target;
  }
  if (isHTMLElement(target) || isSVGElement(target)) {
    return target.ownerDocument;
  }
  return document;
}
const useIsomorphicLayoutEffect = canUseDOM ? reactExports.useLayoutEffect : reactExports.useEffect;
function useEvent(handler) {
  const handlerRef = reactExports.useRef(handler);
  useIsomorphicLayoutEffect(() => {
    handlerRef.current = handler;
  });
  return reactExports.useCallback(function() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return handlerRef.current == null ? void 0 : handlerRef.current(...args);
  }, []);
}
function useInterval() {
  const intervalRef = reactExports.useRef(null);
  const set = reactExports.useCallback((listener, duration) => {
    intervalRef.current = setInterval(listener, duration);
  }, []);
  const clear = reactExports.useCallback(() => {
    if (intervalRef.current !== null) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);
  return [set, clear];
}
function useLatestValue(value, dependencies) {
  if (dependencies === void 0) {
    dependencies = [value];
  }
  const valueRef = reactExports.useRef(value);
  useIsomorphicLayoutEffect(() => {
    if (valueRef.current !== value) {
      valueRef.current = value;
    }
  }, dependencies);
  return valueRef;
}
function useLazyMemo(callback, dependencies) {
  const valueRef = reactExports.useRef();
  return reactExports.useMemo(
    () => {
      const newValue = callback(valueRef.current);
      valueRef.current = newValue;
      return newValue;
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [...dependencies]
  );
}
function useNodeRef(onChange) {
  const onChangeHandler = useEvent(onChange);
  const node = reactExports.useRef(null);
  const setNodeRef = reactExports.useCallback(
    (element) => {
      if (element !== node.current) {
        onChangeHandler == null ? void 0 : onChangeHandler(element, node.current);
      }
      node.current = element;
    },
    //eslint-disable-next-line
    []
  );
  return [node, setNodeRef];
}
function usePrevious(value) {
  const ref = reactExports.useRef();
  reactExports.useEffect(() => {
    ref.current = value;
  }, [value]);
  return ref.current;
}
let ids = {};
function useUniqueId(prefix, value) {
  return reactExports.useMemo(() => {
    if (value) {
      return value;
    }
    const id = ids[prefix] == null ? 0 : ids[prefix] + 1;
    ids[prefix] = id;
    return prefix + "-" + id;
  }, [prefix, value]);
}
function createAdjustmentFn(modifier) {
  return function(object) {
    for (var _len = arguments.length, adjustments = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      adjustments[_key - 1] = arguments[_key];
    }
    return adjustments.reduce((accumulator, adjustment) => {
      const entries = Object.entries(adjustment);
      for (const [key2, valueAdjustment] of entries) {
        const value = accumulator[key2];
        if (value != null) {
          accumulator[key2] = value + modifier * valueAdjustment;
        }
      }
      return accumulator;
    }, {
      ...object
    });
  };
}
const add = /* @__PURE__ */ createAdjustmentFn(1);
const subtract = /* @__PURE__ */ createAdjustmentFn(-1);
function hasViewportRelativeCoordinates(event) {
  return "clientX" in event && "clientY" in event;
}
function isKeyboardEvent(event) {
  if (!event) {
    return false;
  }
  const {
    KeyboardEvent
  } = getWindow(event.target);
  return KeyboardEvent && event instanceof KeyboardEvent;
}
function isTouchEvent(event) {
  if (!event) {
    return false;
  }
  const {
    TouchEvent
  } = getWindow(event.target);
  return TouchEvent && event instanceof TouchEvent;
}
function getEventCoordinates(event) {
  if (isTouchEvent(event)) {
    if (event.touches && event.touches.length) {
      const {
        clientX: x,
        clientY: y
      } = event.touches[0];
      return {
        x,
        y
      };
    } else if (event.changedTouches && event.changedTouches.length) {
      const {
        clientX: x,
        clientY: y
      } = event.changedTouches[0];
      return {
        x,
        y
      };
    }
  }
  if (hasViewportRelativeCoordinates(event)) {
    return {
      x: event.clientX,
      y: event.clientY
    };
  }
  return null;
}
const CSS = /* @__PURE__ */ Object.freeze({
  Translate: {
    toString(transform) {
      if (!transform) {
        return;
      }
      const {
        x,
        y
      } = transform;
      return "translate3d(" + (x ? Math.round(x) : 0) + "px, " + (y ? Math.round(y) : 0) + "px, 0)";
    }
  },
  Scale: {
    toString(transform) {
      if (!transform) {
        return;
      }
      const {
        scaleX,
        scaleY
      } = transform;
      return "scaleX(" + scaleX + ") scaleY(" + scaleY + ")";
    }
  },
  Transform: {
    toString(transform) {
      if (!transform) {
        return;
      }
      return [CSS.Translate.toString(transform), CSS.Scale.toString(transform)].join(" ");
    }
  },
  Transition: {
    toString(_ref) {
      let {
        property,
        duration,
        easing
      } = _ref;
      return property + " " + duration + "ms " + easing;
    }
  }
});
const SELECTOR = "a,frame,iframe,input:not([type=hidden]):not(:disabled),select:not(:disabled),textarea:not(:disabled),button:not(:disabled),*[tabindex]";
function findFirstFocusableNode(element) {
  if (element.matches(SELECTOR)) {
    return element;
  }
  return element.querySelector(SELECTOR);
}
const hiddenStyles = {
  display: "none"
};
function HiddenText(_ref) {
  let {
    id,
    value
  } = _ref;
  return React.createElement("div", {
    id,
    style: hiddenStyles
  }, value);
}
function LiveRegion(_ref) {
  let {
    id,
    announcement,
    ariaLiveType = "assertive"
  } = _ref;
  const visuallyHidden = {
    position: "fixed",
    top: 0,
    left: 0,
    width: 1,
    height: 1,
    margin: -1,
    border: 0,
    padding: 0,
    overflow: "hidden",
    clip: "rect(0 0 0 0)",
    clipPath: "inset(100%)",
    whiteSpace: "nowrap"
  };
  return React.createElement("div", {
    id,
    style: visuallyHidden,
    role: "status",
    "aria-live": ariaLiveType,
    "aria-atomic": true
  }, announcement);
}
function useAnnouncement() {
  const [announcement, setAnnouncement] = reactExports.useState("");
  const announce = reactExports.useCallback((value) => {
    if (value != null) {
      setAnnouncement(value);
    }
  }, []);
  return {
    announce,
    announcement
  };
}
const DndMonitorContext = /* @__PURE__ */ reactExports.createContext(null);
function useDndMonitor(listener) {
  const registerListener = reactExports.useContext(DndMonitorContext);
  reactExports.useEffect(() => {
    if (!registerListener) {
      throw new Error("useDndMonitor must be used within a children of <DndContext>");
    }
    const unsubscribe = registerListener(listener);
    return unsubscribe;
  }, [listener, registerListener]);
}
function useDndMonitorProvider() {
  const [listeners] = reactExports.useState(() => /* @__PURE__ */ new Set());
  const registerListener = reactExports.useCallback((listener) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  }, [listeners]);
  const dispatch = reactExports.useCallback((_ref) => {
    let {
      type,
      event
    } = _ref;
    listeners.forEach((listener) => {
      var _listener$type;
      return (_listener$type = listener[type]) == null ? void 0 : _listener$type.call(listener, event);
    });
  }, [listeners]);
  return [dispatch, registerListener];
}
const defaultScreenReaderInstructions = {
  draggable: "\n    To pick up a draggable item, press the space bar.\n    While dragging, use the arrow keys to move the item.\n    Press space again to drop the item in its new position, or press escape to cancel.\n  "
};
const defaultAnnouncements = {
  onDragStart(_ref) {
    let {
      active
    } = _ref;
    return "Picked up draggable item " + active.id + ".";
  },
  onDragOver(_ref2) {
    let {
      active,
      over
    } = _ref2;
    if (over) {
      return "Draggable item " + active.id + " was moved over droppable area " + over.id + ".";
    }
    return "Draggable item " + active.id + " is no longer over a droppable area.";
  },
  onDragEnd(_ref3) {
    let {
      active,
      over
    } = _ref3;
    if (over) {
      return "Draggable item " + active.id + " was dropped over droppable area " + over.id;
    }
    return "Draggable item " + active.id + " was dropped.";
  },
  onDragCancel(_ref4) {
    let {
      active
    } = _ref4;
    return "Dragging was cancelled. Draggable item " + active.id + " was dropped.";
  }
};
function Accessibility(_ref) {
  let {
    announcements = defaultAnnouncements,
    container,
    hiddenTextDescribedById,
    screenReaderInstructions = defaultScreenReaderInstructions
  } = _ref;
  const {
    announce,
    announcement
  } = useAnnouncement();
  const liveRegionId = useUniqueId("DndLiveRegion");
  const [mounted, setMounted] = reactExports.useState(false);
  reactExports.useEffect(() => {
    setMounted(true);
  }, []);
  useDndMonitor(reactExports.useMemo(() => ({
    onDragStart(_ref2) {
      let {
        active
      } = _ref2;
      announce(announcements.onDragStart({
        active
      }));
    },
    onDragMove(_ref3) {
      let {
        active,
        over
      } = _ref3;
      if (announcements.onDragMove) {
        announce(announcements.onDragMove({
          active,
          over
        }));
      }
    },
    onDragOver(_ref4) {
      let {
        active,
        over
      } = _ref4;
      announce(announcements.onDragOver({
        active,
        over
      }));
    },
    onDragEnd(_ref5) {
      let {
        active,
        over
      } = _ref5;
      announce(announcements.onDragEnd({
        active,
        over
      }));
    },
    onDragCancel(_ref6) {
      let {
        active,
        over
      } = _ref6;
      announce(announcements.onDragCancel({
        active,
        over
      }));
    }
  }), [announce, announcements]));
  if (!mounted) {
    return null;
  }
  const markup = React.createElement(React.Fragment, null, React.createElement(HiddenText, {
    id: hiddenTextDescribedById,
    value: screenReaderInstructions.draggable
  }), React.createElement(LiveRegion, {
    id: liveRegionId,
    announcement
  }));
  return container ? reactDomExports.createPortal(markup, container) : markup;
}
var Action;
(function(Action2) {
  Action2["DragStart"] = "dragStart";
  Action2["DragMove"] = "dragMove";
  Action2["DragEnd"] = "dragEnd";
  Action2["DragCancel"] = "dragCancel";
  Action2["DragOver"] = "dragOver";
  Action2["RegisterDroppable"] = "registerDroppable";
  Action2["SetDroppableDisabled"] = "setDroppableDisabled";
  Action2["UnregisterDroppable"] = "unregisterDroppable";
})(Action || (Action = {}));
function noop() {
}
function useSensor(sensor, options) {
  return reactExports.useMemo(
    () => ({
      sensor,
      options: options != null ? options : {}
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [sensor, options]
  );
}
function useSensors() {
  for (var _len = arguments.length, sensors = new Array(_len), _key = 0; _key < _len; _key++) {
    sensors[_key] = arguments[_key];
  }
  return reactExports.useMemo(
    () => [...sensors].filter((sensor) => sensor != null),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [...sensors]
  );
}
const defaultCoordinates = /* @__PURE__ */ Object.freeze({
  x: 0,
  y: 0
});
function distanceBetween(p1, p2) {
  return Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
}
function getRelativeTransformOrigin(event, rect) {
  const eventCoordinates = getEventCoordinates(event);
  if (!eventCoordinates) {
    return "0 0";
  }
  const transformOrigin = {
    x: (eventCoordinates.x - rect.left) / rect.width * 100,
    y: (eventCoordinates.y - rect.top) / rect.height * 100
  };
  return transformOrigin.x + "% " + transformOrigin.y + "%";
}
function sortCollisionsAsc(_ref, _ref2) {
  let {
    data: {
      value: a
    }
  } = _ref;
  let {
    data: {
      value: b
    }
  } = _ref2;
  return a - b;
}
function sortCollisionsDesc(_ref3, _ref4) {
  let {
    data: {
      value: a
    }
  } = _ref3;
  let {
    data: {
      value: b
    }
  } = _ref4;
  return b - a;
}
function cornersOfRectangle(_ref5) {
  let {
    left,
    top,
    height,
    width
  } = _ref5;
  return [{
    x: left,
    y: top
  }, {
    x: left + width,
    y: top
  }, {
    x: left,
    y: top + height
  }, {
    x: left + width,
    y: top + height
  }];
}
function getFirstCollision(collisions, property) {
  if (!collisions || collisions.length === 0) {
    return null;
  }
  const [firstCollision] = collisions;
  return firstCollision[property];
}
function centerOfRectangle(rect, left, top) {
  if (left === void 0) {
    left = rect.left;
  }
  if (top === void 0) {
    top = rect.top;
  }
  return {
    x: left + rect.width * 0.5,
    y: top + rect.height * 0.5
  };
}
const closestCenter = (_ref) => {
  let {
    collisionRect,
    droppableRects,
    droppableContainers
  } = _ref;
  const centerRect = centerOfRectangle(collisionRect, collisionRect.left, collisionRect.top);
  const collisions = [];
  for (const droppableContainer of droppableContainers) {
    const {
      id
    } = droppableContainer;
    const rect = droppableRects.get(id);
    if (rect) {
      const distBetween = distanceBetween(centerOfRectangle(rect), centerRect);
      collisions.push({
        id,
        data: {
          droppableContainer,
          value: distBetween
        }
      });
    }
  }
  return collisions.sort(sortCollisionsAsc);
};
const closestCorners = (_ref) => {
  let {
    collisionRect,
    droppableRects,
    droppableContainers
  } = _ref;
  const corners = cornersOfRectangle(collisionRect);
  const collisions = [];
  for (const droppableContainer of droppableContainers) {
    const {
      id
    } = droppableContainer;
    const rect = droppableRects.get(id);
    if (rect) {
      const rectCorners = cornersOfRectangle(rect);
      const distances = corners.reduce((accumulator, corner, index) => {
        return accumulator + distanceBetween(rectCorners[index], corner);
      }, 0);
      const effectiveDistance = Number((distances / 4).toFixed(4));
      collisions.push({
        id,
        data: {
          droppableContainer,
          value: effectiveDistance
        }
      });
    }
  }
  return collisions.sort(sortCollisionsAsc);
};
function getIntersectionRatio(entry, target) {
  const top = Math.max(target.top, entry.top);
  const left = Math.max(target.left, entry.left);
  const right = Math.min(target.left + target.width, entry.left + entry.width);
  const bottom = Math.min(target.top + target.height, entry.top + entry.height);
  const width = right - left;
  const height = bottom - top;
  if (left < right && top < bottom) {
    const targetArea = target.width * target.height;
    const entryArea = entry.width * entry.height;
    const intersectionArea = width * height;
    const intersectionRatio = intersectionArea / (targetArea + entryArea - intersectionArea);
    return Number(intersectionRatio.toFixed(4));
  }
  return 0;
}
const rectIntersection = (_ref) => {
  let {
    collisionRect,
    droppableRects,
    droppableContainers
  } = _ref;
  const collisions = [];
  for (const droppableContainer of droppableContainers) {
    const {
      id
    } = droppableContainer;
    const rect = droppableRects.get(id);
    if (rect) {
      const intersectionRatio = getIntersectionRatio(rect, collisionRect);
      if (intersectionRatio > 0) {
        collisions.push({
          id,
          data: {
            droppableContainer,
            value: intersectionRatio
          }
        });
      }
    }
  }
  return collisions.sort(sortCollisionsDesc);
};
function isPointWithinRect(point, rect) {
  const {
    top,
    left,
    bottom,
    right
  } = rect;
  return top <= point.y && point.y <= bottom && left <= point.x && point.x <= right;
}
const pointerWithin = (_ref) => {
  let {
    droppableContainers,
    droppableRects,
    pointerCoordinates
  } = _ref;
  if (!pointerCoordinates) {
    return [];
  }
  const collisions = [];
  for (const droppableContainer of droppableContainers) {
    const {
      id
    } = droppableContainer;
    const rect = droppableRects.get(id);
    if (rect && isPointWithinRect(pointerCoordinates, rect)) {
      const corners = cornersOfRectangle(rect);
      const distances = corners.reduce((accumulator, corner) => {
        return accumulator + distanceBetween(pointerCoordinates, corner);
      }, 0);
      const effectiveDistance = Number((distances / 4).toFixed(4));
      collisions.push({
        id,
        data: {
          droppableContainer,
          value: effectiveDistance
        }
      });
    }
  }
  return collisions.sort(sortCollisionsAsc);
};
function adjustScale(transform, rect1, rect2) {
  return {
    ...transform,
    scaleX: rect1 && rect2 ? rect1.width / rect2.width : 1,
    scaleY: rect1 && rect2 ? rect1.height / rect2.height : 1
  };
}
function getRectDelta(rect1, rect2) {
  return rect1 && rect2 ? {
    x: rect1.left - rect2.left,
    y: rect1.top - rect2.top
  } : defaultCoordinates;
}
function createRectAdjustmentFn(modifier) {
  return function adjustClientRect(rect) {
    for (var _len = arguments.length, adjustments = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      adjustments[_key - 1] = arguments[_key];
    }
    return adjustments.reduce((acc, adjustment) => ({
      ...acc,
      top: acc.top + modifier * adjustment.y,
      bottom: acc.bottom + modifier * adjustment.y,
      left: acc.left + modifier * adjustment.x,
      right: acc.right + modifier * adjustment.x
    }), {
      ...rect
    });
  };
}
const getAdjustedRect = /* @__PURE__ */ createRectAdjustmentFn(1);
function parseTransform(transform) {
  if (transform.startsWith("matrix3d(")) {
    const transformArray = transform.slice(9, -1).split(/, /);
    return {
      x: +transformArray[12],
      y: +transformArray[13],
      scaleX: +transformArray[0],
      scaleY: +transformArray[5]
    };
  } else if (transform.startsWith("matrix(")) {
    const transformArray = transform.slice(7, -1).split(/, /);
    return {
      x: +transformArray[4],
      y: +transformArray[5],
      scaleX: +transformArray[0],
      scaleY: +transformArray[3]
    };
  }
  return null;
}
function inverseTransform(rect, transform, transformOrigin) {
  const parsedTransform = parseTransform(transform);
  if (!parsedTransform) {
    return rect;
  }
  const {
    scaleX,
    scaleY,
    x: translateX,
    y: translateY
  } = parsedTransform;
  const x = rect.left - translateX - (1 - scaleX) * parseFloat(transformOrigin);
  const y = rect.top - translateY - (1 - scaleY) * parseFloat(transformOrigin.slice(transformOrigin.indexOf(" ") + 1));
  const w = scaleX ? rect.width / scaleX : rect.width;
  const h = scaleY ? rect.height / scaleY : rect.height;
  return {
    width: w,
    height: h,
    top: y,
    right: x + w,
    bottom: y + h,
    left: x
  };
}
const defaultOptions = {
  ignoreTransform: false
};
function getClientRect(element, options) {
  if (options === void 0) {
    options = defaultOptions;
  }
  let rect = element.getBoundingClientRect();
  if (options.ignoreTransform) {
    const {
      transform,
      transformOrigin
    } = getWindow(element).getComputedStyle(element);
    if (transform) {
      rect = inverseTransform(rect, transform, transformOrigin);
    }
  }
  const {
    top,
    left,
    width,
    height,
    bottom,
    right
  } = rect;
  return {
    top,
    left,
    width,
    height,
    bottom,
    right
  };
}
function getTransformAgnosticClientRect(element) {
  return getClientRect(element, {
    ignoreTransform: true
  });
}
function getWindowClientRect(element) {
  const width = element.innerWidth;
  const height = element.innerHeight;
  return {
    top: 0,
    left: 0,
    right: width,
    bottom: height,
    width,
    height
  };
}
function isFixed(node, computedStyle) {
  if (computedStyle === void 0) {
    computedStyle = getWindow(node).getComputedStyle(node);
  }
  return computedStyle.position === "fixed";
}
function isScrollable(element, computedStyle) {
  if (computedStyle === void 0) {
    computedStyle = getWindow(element).getComputedStyle(element);
  }
  const overflowRegex = /(auto|scroll|overlay)/;
  const properties2 = ["overflow", "overflowX", "overflowY"];
  return properties2.some((property) => {
    const value = computedStyle[property];
    return typeof value === "string" ? overflowRegex.test(value) : false;
  });
}
function getScrollableAncestors(element, limit) {
  const scrollParents = [];
  function findScrollableAncestors(node) {
    if (limit != null && scrollParents.length >= limit) {
      return scrollParents;
    }
    if (!node) {
      return scrollParents;
    }
    if (isDocument(node) && node.scrollingElement != null && !scrollParents.includes(node.scrollingElement)) {
      scrollParents.push(node.scrollingElement);
      return scrollParents;
    }
    if (!isHTMLElement(node) || isSVGElement(node)) {
      return scrollParents;
    }
    if (scrollParents.includes(node)) {
      return scrollParents;
    }
    const computedStyle = getWindow(element).getComputedStyle(node);
    if (node !== element) {
      if (isScrollable(node, computedStyle)) {
        scrollParents.push(node);
      }
    }
    if (isFixed(node, computedStyle)) {
      return scrollParents;
    }
    return findScrollableAncestors(node.parentNode);
  }
  if (!element) {
    return scrollParents;
  }
  return findScrollableAncestors(element);
}
function getFirstScrollableAncestor(node) {
  const [firstScrollableAncestor] = getScrollableAncestors(node, 1);
  return firstScrollableAncestor != null ? firstScrollableAncestor : null;
}
function getScrollableElement(element) {
  if (!canUseDOM || !element) {
    return null;
  }
  if (isWindow(element)) {
    return element;
  }
  if (!isNode(element)) {
    return null;
  }
  if (isDocument(element) || element === getOwnerDocument(element).scrollingElement) {
    return window;
  }
  if (isHTMLElement(element)) {
    return element;
  }
  return null;
}
function getScrollXCoordinate(element) {
  if (isWindow(element)) {
    return element.scrollX;
  }
  return element.scrollLeft;
}
function getScrollYCoordinate(element) {
  if (isWindow(element)) {
    return element.scrollY;
  }
  return element.scrollTop;
}
function getScrollCoordinates(element) {
  return {
    x: getScrollXCoordinate(element),
    y: getScrollYCoordinate(element)
  };
}
var Direction;
(function(Direction2) {
  Direction2[Direction2["Forward"] = 1] = "Forward";
  Direction2[Direction2["Backward"] = -1] = "Backward";
})(Direction || (Direction = {}));
function isDocumentScrollingElement(element) {
  if (!canUseDOM || !element) {
    return false;
  }
  return element === document.scrollingElement;
}
function getScrollPosition(scrollingContainer) {
  const minScroll = {
    x: 0,
    y: 0
  };
  const dimensions = isDocumentScrollingElement(scrollingContainer) ? {
    height: window.innerHeight,
    width: window.innerWidth
  } : {
    height: scrollingContainer.clientHeight,
    width: scrollingContainer.clientWidth
  };
  const maxScroll = {
    x: scrollingContainer.scrollWidth - dimensions.width,
    y: scrollingContainer.scrollHeight - dimensions.height
  };
  const isTop = scrollingContainer.scrollTop <= minScroll.y;
  const isLeft = scrollingContainer.scrollLeft <= minScroll.x;
  const isBottom = scrollingContainer.scrollTop >= maxScroll.y;
  const isRight = scrollingContainer.scrollLeft >= maxScroll.x;
  return {
    isTop,
    isLeft,
    isBottom,
    isRight,
    maxScroll,
    minScroll
  };
}
const defaultThreshold = {
  x: 0.2,
  y: 0.2
};
function getScrollDirectionAndSpeed(scrollContainer, scrollContainerRect, _ref, acceleration, thresholdPercentage) {
  let {
    top,
    left,
    right,
    bottom
  } = _ref;
  if (acceleration === void 0) {
    acceleration = 10;
  }
  if (thresholdPercentage === void 0) {
    thresholdPercentage = defaultThreshold;
  }
  const {
    isTop,
    isBottom,
    isLeft,
    isRight
  } = getScrollPosition(scrollContainer);
  const direction = {
    x: 0,
    y: 0
  };
  const speed = {
    x: 0,
    y: 0
  };
  const threshold = {
    height: scrollContainerRect.height * thresholdPercentage.y,
    width: scrollContainerRect.width * thresholdPercentage.x
  };
  if (!isTop && top <= scrollContainerRect.top + threshold.height) {
    direction.y = Direction.Backward;
    speed.y = acceleration * Math.abs((scrollContainerRect.top + threshold.height - top) / threshold.height);
  } else if (!isBottom && bottom >= scrollContainerRect.bottom - threshold.height) {
    direction.y = Direction.Forward;
    speed.y = acceleration * Math.abs((scrollContainerRect.bottom - threshold.height - bottom) / threshold.height);
  }
  if (!isRight && right >= scrollContainerRect.right - threshold.width) {
    direction.x = Direction.Forward;
    speed.x = acceleration * Math.abs((scrollContainerRect.right - threshold.width - right) / threshold.width);
  } else if (!isLeft && left <= scrollContainerRect.left + threshold.width) {
    direction.x = Direction.Backward;
    speed.x = acceleration * Math.abs((scrollContainerRect.left + threshold.width - left) / threshold.width);
  }
  return {
    direction,
    speed
  };
}
function getScrollElementRect(element) {
  if (element === document.scrollingElement) {
    const {
      innerWidth,
      innerHeight
    } = window;
    return {
      top: 0,
      left: 0,
      right: innerWidth,
      bottom: innerHeight,
      width: innerWidth,
      height: innerHeight
    };
  }
  const {
    top,
    left,
    right,
    bottom
  } = element.getBoundingClientRect();
  return {
    top,
    left,
    right,
    bottom,
    width: element.clientWidth,
    height: element.clientHeight
  };
}
function getScrollOffsets(scrollableAncestors) {
  return scrollableAncestors.reduce((acc, node) => {
    return add(acc, getScrollCoordinates(node));
  }, defaultCoordinates);
}
function getScrollXOffset(scrollableAncestors) {
  return scrollableAncestors.reduce((acc, node) => {
    return acc + getScrollXCoordinate(node);
  }, 0);
}
function getScrollYOffset(scrollableAncestors) {
  return scrollableAncestors.reduce((acc, node) => {
    return acc + getScrollYCoordinate(node);
  }, 0);
}
function scrollIntoViewIfNeeded(element, measure) {
  if (measure === void 0) {
    measure = getClientRect;
  }
  if (!element) {
    return;
  }
  const {
    top,
    left,
    bottom,
    right
  } = measure(element);
  const firstScrollableAncestor = getFirstScrollableAncestor(element);
  if (!firstScrollableAncestor) {
    return;
  }
  if (bottom <= 0 || right <= 0 || top >= window.innerHeight || left >= window.innerWidth) {
    element.scrollIntoView({
      block: "center",
      inline: "center"
    });
  }
}
const properties = [["x", ["left", "right"], getScrollXOffset], ["y", ["top", "bottom"], getScrollYOffset]];
class Rect {
  constructor(rect, element) {
    this.rect = void 0;
    this.width = void 0;
    this.height = void 0;
    this.top = void 0;
    this.bottom = void 0;
    this.right = void 0;
    this.left = void 0;
    const scrollableAncestors = getScrollableAncestors(element);
    const scrollOffsets = getScrollOffsets(scrollableAncestors);
    this.rect = {
      ...rect
    };
    this.width = rect.width;
    this.height = rect.height;
    for (const [axis, keys, getScrollOffset] of properties) {
      for (const key2 of keys) {
        Object.defineProperty(this, key2, {
          get: () => {
            const currentOffsets = getScrollOffset(scrollableAncestors);
            const scrollOffsetsDeltla = scrollOffsets[axis] - currentOffsets;
            return this.rect[key2] + scrollOffsetsDeltla;
          },
          enumerable: true
        });
      }
    }
    Object.defineProperty(this, "rect", {
      enumerable: false
    });
  }
}
class Listeners {
  constructor(target) {
    this.target = void 0;
    this.listeners = [];
    this.removeAll = () => {
      this.listeners.forEach((listener) => {
        var _this$target;
        return (_this$target = this.target) == null ? void 0 : _this$target.removeEventListener(...listener);
      });
    };
    this.target = target;
  }
  add(eventName, handler, options) {
    var _this$target2;
    (_this$target2 = this.target) == null ? void 0 : _this$target2.addEventListener(eventName, handler, options);
    this.listeners.push([eventName, handler, options]);
  }
}
function getEventListenerTarget(target) {
  const {
    EventTarget
  } = getWindow(target);
  return target instanceof EventTarget ? target : getOwnerDocument(target);
}
function hasExceededDistance(delta, measurement) {
  const dx = Math.abs(delta.x);
  const dy = Math.abs(delta.y);
  if (typeof measurement === "number") {
    return Math.sqrt(dx ** 2 + dy ** 2) > measurement;
  }
  if ("x" in measurement && "y" in measurement) {
    return dx > measurement.x && dy > measurement.y;
  }
  if ("x" in measurement) {
    return dx > measurement.x;
  }
  if ("y" in measurement) {
    return dy > measurement.y;
  }
  return false;
}
var EventName;
(function(EventName2) {
  EventName2["Click"] = "click";
  EventName2["DragStart"] = "dragstart";
  EventName2["Keydown"] = "keydown";
  EventName2["ContextMenu"] = "contextmenu";
  EventName2["Resize"] = "resize";
  EventName2["SelectionChange"] = "selectionchange";
  EventName2["VisibilityChange"] = "visibilitychange";
})(EventName || (EventName = {}));
function preventDefault(event) {
  event.preventDefault();
}
function stopPropagation(event) {
  event.stopPropagation();
}
var KeyboardCode;
(function(KeyboardCode2) {
  KeyboardCode2["Space"] = "Space";
  KeyboardCode2["Down"] = "ArrowDown";
  KeyboardCode2["Right"] = "ArrowRight";
  KeyboardCode2["Left"] = "ArrowLeft";
  KeyboardCode2["Up"] = "ArrowUp";
  KeyboardCode2["Esc"] = "Escape";
  KeyboardCode2["Enter"] = "Enter";
  KeyboardCode2["Tab"] = "Tab";
})(KeyboardCode || (KeyboardCode = {}));
const defaultKeyboardCodes = {
  start: [KeyboardCode.Space, KeyboardCode.Enter],
  cancel: [KeyboardCode.Esc],
  end: [KeyboardCode.Space, KeyboardCode.Enter, KeyboardCode.Tab]
};
const defaultKeyboardCoordinateGetter = (event, _ref) => {
  let {
    currentCoordinates
  } = _ref;
  switch (event.code) {
    case KeyboardCode.Right:
      return {
        ...currentCoordinates,
        x: currentCoordinates.x + 25
      };
    case KeyboardCode.Left:
      return {
        ...currentCoordinates,
        x: currentCoordinates.x - 25
      };
    case KeyboardCode.Down:
      return {
        ...currentCoordinates,
        y: currentCoordinates.y + 25
      };
    case KeyboardCode.Up:
      return {
        ...currentCoordinates,
        y: currentCoordinates.y - 25
      };
  }
  return void 0;
};
class KeyboardSensor {
  constructor(props) {
    this.props = void 0;
    this.autoScrollEnabled = false;
    this.referenceCoordinates = void 0;
    this.listeners = void 0;
    this.windowListeners = void 0;
    this.props = props;
    const {
      event: {
        target
      }
    } = props;
    this.props = props;
    this.listeners = new Listeners(getOwnerDocument(target));
    this.windowListeners = new Listeners(getWindow(target));
    this.handleKeyDown = this.handleKeyDown.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.attach();
  }
  attach() {
    this.handleStart();
    this.windowListeners.add(EventName.Resize, this.handleCancel);
    this.windowListeners.add(EventName.VisibilityChange, this.handleCancel);
    setTimeout(() => this.listeners.add(EventName.Keydown, this.handleKeyDown));
  }
  handleStart() {
    const {
      activeNode,
      onStart
    } = this.props;
    const node = activeNode.node.current;
    if (node) {
      scrollIntoViewIfNeeded(node);
    }
    onStart(defaultCoordinates);
  }
  handleKeyDown(event) {
    if (isKeyboardEvent(event)) {
      const {
        active,
        context,
        options
      } = this.props;
      const {
        keyboardCodes = defaultKeyboardCodes,
        coordinateGetter = defaultKeyboardCoordinateGetter,
        scrollBehavior = "smooth"
      } = options;
      const {
        code
      } = event;
      if (keyboardCodes.end.includes(code)) {
        this.handleEnd(event);
        return;
      }
      if (keyboardCodes.cancel.includes(code)) {
        this.handleCancel(event);
        return;
      }
      const {
        collisionRect
      } = context.current;
      const currentCoordinates = collisionRect ? {
        x: collisionRect.left,
        y: collisionRect.top
      } : defaultCoordinates;
      if (!this.referenceCoordinates) {
        this.referenceCoordinates = currentCoordinates;
      }
      const newCoordinates = coordinateGetter(event, {
        active,
        context: context.current,
        currentCoordinates
      });
      if (newCoordinates) {
        const coordinatesDelta = subtract(newCoordinates, currentCoordinates);
        const scrollDelta = {
          x: 0,
          y: 0
        };
        const {
          scrollableAncestors
        } = context.current;
        for (const scrollContainer of scrollableAncestors) {
          const direction = event.code;
          const {
            isTop,
            isRight,
            isLeft,
            isBottom,
            maxScroll,
            minScroll
          } = getScrollPosition(scrollContainer);
          const scrollElementRect = getScrollElementRect(scrollContainer);
          const clampedCoordinates = {
            x: Math.min(direction === KeyboardCode.Right ? scrollElementRect.right - scrollElementRect.width / 2 : scrollElementRect.right, Math.max(direction === KeyboardCode.Right ? scrollElementRect.left : scrollElementRect.left + scrollElementRect.width / 2, newCoordinates.x)),
            y: Math.min(direction === KeyboardCode.Down ? scrollElementRect.bottom - scrollElementRect.height / 2 : scrollElementRect.bottom, Math.max(direction === KeyboardCode.Down ? scrollElementRect.top : scrollElementRect.top + scrollElementRect.height / 2, newCoordinates.y))
          };
          const canScrollX = direction === KeyboardCode.Right && !isRight || direction === KeyboardCode.Left && !isLeft;
          const canScrollY = direction === KeyboardCode.Down && !isBottom || direction === KeyboardCode.Up && !isTop;
          if (canScrollX && clampedCoordinates.x !== newCoordinates.x) {
            const newScrollCoordinates = scrollContainer.scrollLeft + coordinatesDelta.x;
            const canScrollToNewCoordinates = direction === KeyboardCode.Right && newScrollCoordinates <= maxScroll.x || direction === KeyboardCode.Left && newScrollCoordinates >= minScroll.x;
            if (canScrollToNewCoordinates && !coordinatesDelta.y) {
              scrollContainer.scrollTo({
                left: newScrollCoordinates,
                behavior: scrollBehavior
              });
              return;
            }
            if (canScrollToNewCoordinates) {
              scrollDelta.x = scrollContainer.scrollLeft - newScrollCoordinates;
            } else {
              scrollDelta.x = direction === KeyboardCode.Right ? scrollContainer.scrollLeft - maxScroll.x : scrollContainer.scrollLeft - minScroll.x;
            }
            if (scrollDelta.x) {
              scrollContainer.scrollBy({
                left: -scrollDelta.x,
                behavior: scrollBehavior
              });
            }
            break;
          } else if (canScrollY && clampedCoordinates.y !== newCoordinates.y) {
            const newScrollCoordinates = scrollContainer.scrollTop + coordinatesDelta.y;
            const canScrollToNewCoordinates = direction === KeyboardCode.Down && newScrollCoordinates <= maxScroll.y || direction === KeyboardCode.Up && newScrollCoordinates >= minScroll.y;
            if (canScrollToNewCoordinates && !coordinatesDelta.x) {
              scrollContainer.scrollTo({
                top: newScrollCoordinates,
                behavior: scrollBehavior
              });
              return;
            }
            if (canScrollToNewCoordinates) {
              scrollDelta.y = scrollContainer.scrollTop - newScrollCoordinates;
            } else {
              scrollDelta.y = direction === KeyboardCode.Down ? scrollContainer.scrollTop - maxScroll.y : scrollContainer.scrollTop - minScroll.y;
            }
            if (scrollDelta.y) {
              scrollContainer.scrollBy({
                top: -scrollDelta.y,
                behavior: scrollBehavior
              });
            }
            break;
          }
        }
        this.handleMove(event, add(subtract(newCoordinates, this.referenceCoordinates), scrollDelta));
      }
    }
  }
  handleMove(event, coordinates) {
    const {
      onMove
    } = this.props;
    event.preventDefault();
    onMove(coordinates);
  }
  handleEnd(event) {
    const {
      onEnd
    } = this.props;
    event.preventDefault();
    this.detach();
    onEnd();
  }
  handleCancel(event) {
    const {
      onCancel
    } = this.props;
    event.preventDefault();
    this.detach();
    onCancel();
  }
  detach() {
    this.listeners.removeAll();
    this.windowListeners.removeAll();
  }
}
KeyboardSensor.activators = [{
  eventName: "onKeyDown",
  handler: (event, _ref, _ref2) => {
    let {
      keyboardCodes = defaultKeyboardCodes,
      onActivation
    } = _ref;
    let {
      active
    } = _ref2;
    const {
      code
    } = event.nativeEvent;
    if (keyboardCodes.start.includes(code)) {
      const activator = active.activatorNode.current;
      if (activator && event.target !== activator) {
        return false;
      }
      event.preventDefault();
      onActivation == null ? void 0 : onActivation({
        event: event.nativeEvent
      });
      return true;
    }
    return false;
  }
}];
function isDistanceConstraint(constraint) {
  return Boolean(constraint && "distance" in constraint);
}
function isDelayConstraint(constraint) {
  return Boolean(constraint && "delay" in constraint);
}
class AbstractPointerSensor {
  constructor(props, events2, listenerTarget) {
    var _getEventCoordinates;
    if (listenerTarget === void 0) {
      listenerTarget = getEventListenerTarget(props.event.target);
    }
    this.props = void 0;
    this.events = void 0;
    this.autoScrollEnabled = true;
    this.document = void 0;
    this.activated = false;
    this.initialCoordinates = void 0;
    this.timeoutId = null;
    this.listeners = void 0;
    this.documentListeners = void 0;
    this.windowListeners = void 0;
    this.props = props;
    this.events = events2;
    const {
      event
    } = props;
    const {
      target
    } = event;
    this.props = props;
    this.events = events2;
    this.document = getOwnerDocument(target);
    this.documentListeners = new Listeners(this.document);
    this.listeners = new Listeners(listenerTarget);
    this.windowListeners = new Listeners(getWindow(target));
    this.initialCoordinates = (_getEventCoordinates = getEventCoordinates(event)) != null ? _getEventCoordinates : defaultCoordinates;
    this.handleStart = this.handleStart.bind(this);
    this.handleMove = this.handleMove.bind(this);
    this.handleEnd = this.handleEnd.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleKeydown = this.handleKeydown.bind(this);
    this.removeTextSelection = this.removeTextSelection.bind(this);
    this.attach();
  }
  attach() {
    const {
      events: events2,
      props: {
        options: {
          activationConstraint,
          bypassActivationConstraint
        }
      }
    } = this;
    this.listeners.add(events2.move.name, this.handleMove, {
      passive: false
    });
    this.listeners.add(events2.end.name, this.handleEnd);
    if (events2.cancel) {
      this.listeners.add(events2.cancel.name, this.handleCancel);
    }
    this.windowListeners.add(EventName.Resize, this.handleCancel);
    this.windowListeners.add(EventName.DragStart, preventDefault);
    this.windowListeners.add(EventName.VisibilityChange, this.handleCancel);
    this.windowListeners.add(EventName.ContextMenu, preventDefault);
    this.documentListeners.add(EventName.Keydown, this.handleKeydown);
    if (activationConstraint) {
      if (bypassActivationConstraint != null && bypassActivationConstraint({
        event: this.props.event,
        activeNode: this.props.activeNode,
        options: this.props.options
      })) {
        return this.handleStart();
      }
      if (isDelayConstraint(activationConstraint)) {
        this.timeoutId = setTimeout(this.handleStart, activationConstraint.delay);
        this.handlePending(activationConstraint);
        return;
      }
      if (isDistanceConstraint(activationConstraint)) {
        this.handlePending(activationConstraint);
        return;
      }
    }
    this.handleStart();
  }
  detach() {
    this.listeners.removeAll();
    this.windowListeners.removeAll();
    setTimeout(this.documentListeners.removeAll, 50);
    if (this.timeoutId !== null) {
      clearTimeout(this.timeoutId);
      this.timeoutId = null;
    }
  }
  handlePending(constraint, offset) {
    const {
      active,
      onPending
    } = this.props;
    onPending(active, constraint, this.initialCoordinates, offset);
  }
  handleStart() {
    const {
      initialCoordinates
    } = this;
    const {
      onStart
    } = this.props;
    if (initialCoordinates) {
      this.activated = true;
      this.documentListeners.add(EventName.Click, stopPropagation, {
        capture: true
      });
      this.removeTextSelection();
      this.documentListeners.add(EventName.SelectionChange, this.removeTextSelection);
      onStart(initialCoordinates);
    }
  }
  handleMove(event) {
    var _getEventCoordinates2;
    const {
      activated,
      initialCoordinates,
      props
    } = this;
    const {
      onMove,
      options: {
        activationConstraint
      }
    } = props;
    if (!initialCoordinates) {
      return;
    }
    const coordinates = (_getEventCoordinates2 = getEventCoordinates(event)) != null ? _getEventCoordinates2 : defaultCoordinates;
    const delta = subtract(initialCoordinates, coordinates);
    if (!activated && activationConstraint) {
      if (isDistanceConstraint(activationConstraint)) {
        if (activationConstraint.tolerance != null && hasExceededDistance(delta, activationConstraint.tolerance)) {
          return this.handleCancel();
        }
        if (hasExceededDistance(delta, activationConstraint.distance)) {
          return this.handleStart();
        }
      }
      if (isDelayConstraint(activationConstraint)) {
        if (hasExceededDistance(delta, activationConstraint.tolerance)) {
          return this.handleCancel();
        }
      }
      this.handlePending(activationConstraint, delta);
      return;
    }
    if (event.cancelable) {
      event.preventDefault();
    }
    onMove(coordinates);
  }
  handleEnd() {
    const {
      onAbort,
      onEnd
    } = this.props;
    this.detach();
    if (!this.activated) {
      onAbort(this.props.active);
    }
    onEnd();
  }
  handleCancel() {
    const {
      onAbort,
      onCancel
    } = this.props;
    this.detach();
    if (!this.activated) {
      onAbort(this.props.active);
    }
    onCancel();
  }
  handleKeydown(event) {
    if (event.code === KeyboardCode.Esc) {
      this.handleCancel();
    }
  }
  removeTextSelection() {
    var _this$document$getSel;
    (_this$document$getSel = this.document.getSelection()) == null ? void 0 : _this$document$getSel.removeAllRanges();
  }
}
const events = {
  cancel: {
    name: "pointercancel"
  },
  move: {
    name: "pointermove"
  },
  end: {
    name: "pointerup"
  }
};
class PointerSensor extends AbstractPointerSensor {
  constructor(props) {
    const {
      event
    } = props;
    const listenerTarget = getOwnerDocument(event.target);
    super(props, events, listenerTarget);
  }
}
PointerSensor.activators = [{
  eventName: "onPointerDown",
  handler: (_ref, _ref2) => {
    let {
      nativeEvent: event
    } = _ref;
    let {
      onActivation
    } = _ref2;
    if (!event.isPrimary || event.button !== 0) {
      return false;
    }
    onActivation == null ? void 0 : onActivation({
      event
    });
    return true;
  }
}];
const events$1 = {
  move: {
    name: "mousemove"
  },
  end: {
    name: "mouseup"
  }
};
var MouseButton;
(function(MouseButton2) {
  MouseButton2[MouseButton2["RightClick"] = 2] = "RightClick";
})(MouseButton || (MouseButton = {}));
class MouseSensor extends AbstractPointerSensor {
  constructor(props) {
    super(props, events$1, getOwnerDocument(props.event.target));
  }
}
MouseSensor.activators = [{
  eventName: "onMouseDown",
  handler: (_ref, _ref2) => {
    let {
      nativeEvent: event
    } = _ref;
    let {
      onActivation
    } = _ref2;
    if (event.button === MouseButton.RightClick) {
      return false;
    }
    onActivation == null ? void 0 : onActivation({
      event
    });
    return true;
  }
}];
const events$2 = {
  cancel: {
    name: "touchcancel"
  },
  move: {
    name: "touchmove"
  },
  end: {
    name: "touchend"
  }
};
class TouchSensor extends AbstractPointerSensor {
  constructor(props) {
    super(props, events$2);
  }
  static setup() {
    window.addEventListener(events$2.move.name, noop2, {
      capture: false,
      passive: false
    });
    return function teardown() {
      window.removeEventListener(events$2.move.name, noop2);
    };
    function noop2() {
    }
  }
}
TouchSensor.activators = [{
  eventName: "onTouchStart",
  handler: (_ref, _ref2) => {
    let {
      nativeEvent: event
    } = _ref;
    let {
      onActivation
    } = _ref2;
    const {
      touches
    } = event;
    if (touches.length > 1) {
      return false;
    }
    onActivation == null ? void 0 : onActivation({
      event
    });
    return true;
  }
}];
var AutoScrollActivator;
(function(AutoScrollActivator2) {
  AutoScrollActivator2[AutoScrollActivator2["Pointer"] = 0] = "Pointer";
  AutoScrollActivator2[AutoScrollActivator2["DraggableRect"] = 1] = "DraggableRect";
})(AutoScrollActivator || (AutoScrollActivator = {}));
var TraversalOrder;
(function(TraversalOrder2) {
  TraversalOrder2[TraversalOrder2["TreeOrder"] = 0] = "TreeOrder";
  TraversalOrder2[TraversalOrder2["ReversedTreeOrder"] = 1] = "ReversedTreeOrder";
})(TraversalOrder || (TraversalOrder = {}));
function useAutoScroller(_ref) {
  let {
    acceleration,
    activator = AutoScrollActivator.Pointer,
    canScroll,
    draggingRect,
    enabled,
    interval = 5,
    order = TraversalOrder.TreeOrder,
    pointerCoordinates,
    scrollableAncestors,
    scrollableAncestorRects,
    delta,
    threshold
  } = _ref;
  const scrollIntent = useScrollIntent({
    delta,
    disabled: !enabled
  });
  const [setAutoScrollInterval, clearAutoScrollInterval] = useInterval();
  const scrollSpeed = reactExports.useRef({
    x: 0,
    y: 0
  });
  const scrollDirection = reactExports.useRef({
    x: 0,
    y: 0
  });
  const rect = reactExports.useMemo(() => {
    switch (activator) {
      case AutoScrollActivator.Pointer:
        return pointerCoordinates ? {
          top: pointerCoordinates.y,
          bottom: pointerCoordinates.y,
          left: pointerCoordinates.x,
          right: pointerCoordinates.x
        } : null;
      case AutoScrollActivator.DraggableRect:
        return draggingRect;
    }
  }, [activator, draggingRect, pointerCoordinates]);
  const scrollContainerRef = reactExports.useRef(null);
  const autoScroll = reactExports.useCallback(() => {
    const scrollContainer = scrollContainerRef.current;
    if (!scrollContainer) {
      return;
    }
    const scrollLeft = scrollSpeed.current.x * scrollDirection.current.x;
    const scrollTop = scrollSpeed.current.y * scrollDirection.current.y;
    scrollContainer.scrollBy(scrollLeft, scrollTop);
  }, []);
  const sortedScrollableAncestors = reactExports.useMemo(() => order === TraversalOrder.TreeOrder ? [...scrollableAncestors].reverse() : scrollableAncestors, [order, scrollableAncestors]);
  reactExports.useEffect(
    () => {
      if (!enabled || !scrollableAncestors.length || !rect) {
        clearAutoScrollInterval();
        return;
      }
      for (const scrollContainer of sortedScrollableAncestors) {
        if ((canScroll == null ? void 0 : canScroll(scrollContainer)) === false) {
          continue;
        }
        const index = scrollableAncestors.indexOf(scrollContainer);
        const scrollContainerRect = scrollableAncestorRects[index];
        if (!scrollContainerRect) {
          continue;
        }
        const {
          direction,
          speed
        } = getScrollDirectionAndSpeed(scrollContainer, scrollContainerRect, rect, acceleration, threshold);
        for (const axis of ["x", "y"]) {
          if (!scrollIntent[axis][direction[axis]]) {
            speed[axis] = 0;
            direction[axis] = 0;
          }
        }
        if (speed.x > 0 || speed.y > 0) {
          clearAutoScrollInterval();
          scrollContainerRef.current = scrollContainer;
          setAutoScrollInterval(autoScroll, interval);
          scrollSpeed.current = speed;
          scrollDirection.current = direction;
          return;
        }
      }
      scrollSpeed.current = {
        x: 0,
        y: 0
      };
      scrollDirection.current = {
        x: 0,
        y: 0
      };
      clearAutoScrollInterval();
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      acceleration,
      autoScroll,
      canScroll,
      clearAutoScrollInterval,
      enabled,
      interval,
      // eslint-disable-next-line react-hooks/exhaustive-deps
      JSON.stringify(rect),
      // eslint-disable-next-line react-hooks/exhaustive-deps
      JSON.stringify(scrollIntent),
      setAutoScrollInterval,
      scrollableAncestors,
      sortedScrollableAncestors,
      scrollableAncestorRects,
      // eslint-disable-next-line react-hooks/exhaustive-deps
      JSON.stringify(threshold)
    ]
  );
}
const defaultScrollIntent = {
  x: {
    [Direction.Backward]: false,
    [Direction.Forward]: false
  },
  y: {
    [Direction.Backward]: false,
    [Direction.Forward]: false
  }
};
function useScrollIntent(_ref2) {
  let {
    delta,
    disabled
  } = _ref2;
  const previousDelta = usePrevious(delta);
  return useLazyMemo((previousIntent) => {
    if (disabled || !previousDelta || !previousIntent) {
      return defaultScrollIntent;
    }
    const direction = {
      x: Math.sign(delta.x - previousDelta.x),
      y: Math.sign(delta.y - previousDelta.y)
    };
    return {
      x: {
        [Direction.Backward]: previousIntent.x[Direction.Backward] || direction.x === -1,
        [Direction.Forward]: previousIntent.x[Direction.Forward] || direction.x === 1
      },
      y: {
        [Direction.Backward]: previousIntent.y[Direction.Backward] || direction.y === -1,
        [Direction.Forward]: previousIntent.y[Direction.Forward] || direction.y === 1
      }
    };
  }, [disabled, delta, previousDelta]);
}
function useCachedNode(draggableNodes, id) {
  const draggableNode = id != null ? draggableNodes.get(id) : void 0;
  const node = draggableNode ? draggableNode.node.current : null;
  return useLazyMemo((cachedNode) => {
    var _ref;
    if (id == null) {
      return null;
    }
    return (_ref = node != null ? node : cachedNode) != null ? _ref : null;
  }, [node, id]);
}
function useCombineActivators(sensors, getSyntheticHandler) {
  return reactExports.useMemo(() => sensors.reduce((accumulator, sensor) => {
    const {
      sensor: Sensor
    } = sensor;
    const sensorActivators = Sensor.activators.map((activator) => ({
      eventName: activator.eventName,
      handler: getSyntheticHandler(activator.handler, sensor)
    }));
    return [...accumulator, ...sensorActivators];
  }, []), [sensors, getSyntheticHandler]);
}
var MeasuringStrategy;
(function(MeasuringStrategy2) {
  MeasuringStrategy2[MeasuringStrategy2["Always"] = 0] = "Always";
  MeasuringStrategy2[MeasuringStrategy2["BeforeDragging"] = 1] = "BeforeDragging";
  MeasuringStrategy2[MeasuringStrategy2["WhileDragging"] = 2] = "WhileDragging";
})(MeasuringStrategy || (MeasuringStrategy = {}));
var MeasuringFrequency;
(function(MeasuringFrequency2) {
  MeasuringFrequency2["Optimized"] = "optimized";
})(MeasuringFrequency || (MeasuringFrequency = {}));
const defaultValue = /* @__PURE__ */ new Map();
function useDroppableMeasuring(containers, _ref) {
  let {
    dragging,
    dependencies,
    config
  } = _ref;
  const [queue, setQueue] = reactExports.useState(null);
  const {
    frequency,
    measure,
    strategy
  } = config;
  const containersRef = reactExports.useRef(containers);
  const disabled = isDisabled();
  const disabledRef = useLatestValue(disabled);
  const measureDroppableContainers = reactExports.useCallback(function(ids2) {
    if (ids2 === void 0) {
      ids2 = [];
    }
    if (disabledRef.current) {
      return;
    }
    setQueue((value) => {
      if (value === null) {
        return ids2;
      }
      return value.concat(ids2.filter((id) => !value.includes(id)));
    });
  }, [disabledRef]);
  const timeoutId = reactExports.useRef(null);
  const droppableRects = useLazyMemo((previousValue) => {
    if (disabled && !dragging) {
      return defaultValue;
    }
    if (!previousValue || previousValue === defaultValue || containersRef.current !== containers || queue != null) {
      const map = /* @__PURE__ */ new Map();
      for (let container of containers) {
        if (!container) {
          continue;
        }
        if (queue && queue.length > 0 && !queue.includes(container.id) && container.rect.current) {
          map.set(container.id, container.rect.current);
          continue;
        }
        const node = container.node.current;
        const rect = node ? new Rect(measure(node), node) : null;
        container.rect.current = rect;
        if (rect) {
          map.set(container.id, rect);
        }
      }
      return map;
    }
    return previousValue;
  }, [containers, queue, dragging, disabled, measure]);
  reactExports.useEffect(() => {
    containersRef.current = containers;
  }, [containers]);
  reactExports.useEffect(
    () => {
      if (disabled) {
        return;
      }
      measureDroppableContainers();
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [dragging, disabled]
  );
  reactExports.useEffect(
    () => {
      if (queue && queue.length > 0) {
        setQueue(null);
      }
    },
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [JSON.stringify(queue)]
  );
  reactExports.useEffect(
    () => {
      if (disabled || typeof frequency !== "number" || timeoutId.current !== null) {
        return;
      }
      timeoutId.current = setTimeout(() => {
        measureDroppableContainers();
        timeoutId.current = null;
      }, frequency);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [frequency, disabled, measureDroppableContainers, ...dependencies]
  );
  return {
    droppableRects,
    measureDroppableContainers,
    measuringScheduled: queue != null
  };
  function isDisabled() {
    switch (strategy) {
      case MeasuringStrategy.Always:
        return false;
      case MeasuringStrategy.BeforeDragging:
        return dragging;
      default:
        return !dragging;
    }
  }
}
function useInitialValue(value, computeFn) {
  return useLazyMemo((previousValue) => {
    if (!value) {
      return null;
    }
    if (previousValue) {
      return previousValue;
    }
    return typeof computeFn === "function" ? computeFn(value) : value;
  }, [computeFn, value]);
}
function useInitialRect(node, measure) {
  return useInitialValue(node, measure);
}
function useMutationObserver(_ref) {
  let {
    callback,
    disabled
  } = _ref;
  const handleMutations = useEvent(callback);
  const mutationObserver = reactExports.useMemo(() => {
    if (disabled || typeof window === "undefined" || typeof window.MutationObserver === "undefined") {
      return void 0;
    }
    const {
      MutationObserver
    } = window;
    return new MutationObserver(handleMutations);
  }, [handleMutations, disabled]);
  reactExports.useEffect(() => {
    return () => mutationObserver == null ? void 0 : mutationObserver.disconnect();
  }, [mutationObserver]);
  return mutationObserver;
}
function useResizeObserver(_ref) {
  let {
    callback,
    disabled
  } = _ref;
  const handleResize = useEvent(callback);
  const resizeObserver = reactExports.useMemo(
    () => {
      if (disabled || typeof window === "undefined" || typeof window.ResizeObserver === "undefined") {
        return void 0;
      }
      const {
        ResizeObserver
      } = window;
      return new ResizeObserver(handleResize);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [disabled]
  );
  reactExports.useEffect(() => {
    return () => resizeObserver == null ? void 0 : resizeObserver.disconnect();
  }, [resizeObserver]);
  return resizeObserver;
}
function defaultMeasure(element) {
  return new Rect(getClientRect(element), element);
}
function useRect(element, measure, fallbackRect) {
  if (measure === void 0) {
    measure = defaultMeasure;
  }
  const [rect, setRect] = reactExports.useState(null);
  function measureRect() {
    setRect((currentRect) => {
      if (!element) {
        return null;
      }
      if (element.isConnected === false) {
        var _ref;
        return (_ref = currentRect != null ? currentRect : fallbackRect) != null ? _ref : null;
      }
      const newRect = measure(element);
      if (JSON.stringify(currentRect) === JSON.stringify(newRect)) {
        return currentRect;
      }
      return newRect;
    });
  }
  const mutationObserver = useMutationObserver({
    callback(records) {
      if (!element) {
        return;
      }
      for (const record of records) {
        const {
          type,
          target
        } = record;
        if (type === "childList" && target instanceof HTMLElement && target.contains(element)) {
          measureRect();
          break;
        }
      }
    }
  });
  const resizeObserver = useResizeObserver({
    callback: measureRect
  });
  useIsomorphicLayoutEffect(() => {
    measureRect();
    if (element) {
      resizeObserver == null ? void 0 : resizeObserver.observe(element);
      mutationObserver == null ? void 0 : mutationObserver.observe(document.body, {
        childList: true,
        subtree: true
      });
    } else {
      resizeObserver == null ? void 0 : resizeObserver.disconnect();
      mutationObserver == null ? void 0 : mutationObserver.disconnect();
    }
  }, [element]);
  return rect;
}
function useRectDelta(rect) {
  const initialRect = useInitialValue(rect);
  return getRectDelta(rect, initialRect);
}
const defaultValue$1 = [];
function useScrollableAncestors(node) {
  const previousNode = reactExports.useRef(node);
  const ancestors = useLazyMemo((previousValue) => {
    if (!node) {
      return defaultValue$1;
    }
    if (previousValue && previousValue !== defaultValue$1 && node && previousNode.current && node.parentNode === previousNode.current.parentNode) {
      return previousValue;
    }
    return getScrollableAncestors(node);
  }, [node]);
  reactExports.useEffect(() => {
    previousNode.current = node;
  }, [node]);
  return ancestors;
}
function useScrollOffsets(elements) {
  const [scrollCoordinates, setScrollCoordinates] = reactExports.useState(null);
  const prevElements = reactExports.useRef(elements);
  const handleScroll = reactExports.useCallback((event) => {
    const scrollingElement = getScrollableElement(event.target);
    if (!scrollingElement) {
      return;
    }
    setScrollCoordinates((scrollCoordinates2) => {
      if (!scrollCoordinates2) {
        return null;
      }
      scrollCoordinates2.set(scrollingElement, getScrollCoordinates(scrollingElement));
      return new Map(scrollCoordinates2);
    });
  }, []);
  reactExports.useEffect(() => {
    const previousElements = prevElements.current;
    if (elements !== previousElements) {
      cleanup(previousElements);
      const entries = elements.map((element) => {
        const scrollableElement = getScrollableElement(element);
        if (scrollableElement) {
          scrollableElement.addEventListener("scroll", handleScroll, {
            passive: true
          });
          return [scrollableElement, getScrollCoordinates(scrollableElement)];
        }
        return null;
      }).filter((entry) => entry != null);
      setScrollCoordinates(entries.length ? new Map(entries) : null);
      prevElements.current = elements;
    }
    return () => {
      cleanup(elements);
      cleanup(previousElements);
    };
    function cleanup(elements2) {
      elements2.forEach((element) => {
        const scrollableElement = getScrollableElement(element);
        scrollableElement == null ? void 0 : scrollableElement.removeEventListener("scroll", handleScroll);
      });
    }
  }, [handleScroll, elements]);
  return reactExports.useMemo(() => {
    if (elements.length) {
      return scrollCoordinates ? Array.from(scrollCoordinates.values()).reduce((acc, coordinates) => add(acc, coordinates), defaultCoordinates) : getScrollOffsets(elements);
    }
    return defaultCoordinates;
  }, [elements, scrollCoordinates]);
}
function useScrollOffsetsDelta(scrollOffsets, dependencies) {
  if (dependencies === void 0) {
    dependencies = [];
  }
  const initialScrollOffsets = reactExports.useRef(null);
  reactExports.useEffect(
    () => {
      initialScrollOffsets.current = null;
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    dependencies
  );
  reactExports.useEffect(() => {
    const hasScrollOffsets = scrollOffsets !== defaultCoordinates;
    if (hasScrollOffsets && !initialScrollOffsets.current) {
      initialScrollOffsets.current = scrollOffsets;
    }
    if (!hasScrollOffsets && initialScrollOffsets.current) {
      initialScrollOffsets.current = null;
    }
  }, [scrollOffsets]);
  return initialScrollOffsets.current ? subtract(scrollOffsets, initialScrollOffsets.current) : defaultCoordinates;
}
function useSensorSetup(sensors) {
  reactExports.useEffect(
    () => {
      if (!canUseDOM) {
        return;
      }
      const teardownFns = sensors.map((_ref) => {
        let {
          sensor
        } = _ref;
        return sensor.setup == null ? void 0 : sensor.setup();
      });
      return () => {
        for (const teardown of teardownFns) {
          teardown == null ? void 0 : teardown();
        }
      };
    },
    // TO-DO: Sensors length could theoretically change which would not be a valid dependency
    // eslint-disable-next-line react-hooks/exhaustive-deps
    sensors.map((_ref2) => {
      let {
        sensor
      } = _ref2;
      return sensor;
    })
  );
}
function useSyntheticListeners(listeners, id) {
  return reactExports.useMemo(() => {
    return listeners.reduce((acc, _ref) => {
      let {
        eventName,
        handler
      } = _ref;
      acc[eventName] = (event) => {
        handler(event, id);
      };
      return acc;
    }, {});
  }, [listeners, id]);
}
function useWindowRect(element) {
  return reactExports.useMemo(() => element ? getWindowClientRect(element) : null, [element]);
}
const defaultValue$2 = [];
function useRects(elements, measure) {
  if (measure === void 0) {
    measure = getClientRect;
  }
  const [firstElement] = elements;
  const windowRect = useWindowRect(firstElement ? getWindow(firstElement) : null);
  const [rects, setRects] = reactExports.useState(defaultValue$2);
  function measureRects() {
    setRects(() => {
      if (!elements.length) {
        return defaultValue$2;
      }
      return elements.map((element) => isDocumentScrollingElement(element) ? windowRect : new Rect(measure(element), element));
    });
  }
  const resizeObserver = useResizeObserver({
    callback: measureRects
  });
  useIsomorphicLayoutEffect(() => {
    resizeObserver == null ? void 0 : resizeObserver.disconnect();
    measureRects();
    elements.forEach((element) => resizeObserver == null ? void 0 : resizeObserver.observe(element));
  }, [elements]);
  return rects;
}
function getMeasurableNode(node) {
  if (!node) {
    return null;
  }
  if (node.children.length > 1) {
    return node;
  }
  const firstChild = node.children[0];
  return isHTMLElement(firstChild) ? firstChild : node;
}
function useDragOverlayMeasuring(_ref) {
  let {
    measure
  } = _ref;
  const [rect, setRect] = reactExports.useState(null);
  const handleResize = reactExports.useCallback((entries) => {
    for (const {
      target
    } of entries) {
      if (isHTMLElement(target)) {
        setRect((rect2) => {
          const newRect = measure(target);
          return rect2 ? {
            ...rect2,
            width: newRect.width,
            height: newRect.height
          } : newRect;
        });
        break;
      }
    }
  }, [measure]);
  const resizeObserver = useResizeObserver({
    callback: handleResize
  });
  const handleNodeChange = reactExports.useCallback((element) => {
    const node = getMeasurableNode(element);
    resizeObserver == null ? void 0 : resizeObserver.disconnect();
    if (node) {
      resizeObserver == null ? void 0 : resizeObserver.observe(node);
    }
    setRect(node ? measure(node) : null);
  }, [measure, resizeObserver]);
  const [nodeRef, setRef] = useNodeRef(handleNodeChange);
  return reactExports.useMemo(() => ({
    nodeRef,
    rect,
    setRef
  }), [rect, nodeRef, setRef]);
}
const defaultSensors = [{
  sensor: PointerSensor,
  options: {}
}, {
  sensor: KeyboardSensor,
  options: {}
}];
const defaultData = {
  current: {}
};
const defaultMeasuringConfiguration = {
  draggable: {
    measure: getTransformAgnosticClientRect
  },
  droppable: {
    measure: getTransformAgnosticClientRect,
    strategy: MeasuringStrategy.WhileDragging,
    frequency: MeasuringFrequency.Optimized
  },
  dragOverlay: {
    measure: getClientRect
  }
};
class DroppableContainersMap extends Map {
  get(id) {
    var _super$get;
    return id != null ? (_super$get = super.get(id)) != null ? _super$get : void 0 : void 0;
  }
  toArray() {
    return Array.from(this.values());
  }
  getEnabled() {
    return this.toArray().filter((_ref) => {
      let {
        disabled
      } = _ref;
      return !disabled;
    });
  }
  getNodeFor(id) {
    var _this$get$node$curren, _this$get;
    return (_this$get$node$curren = (_this$get = this.get(id)) == null ? void 0 : _this$get.node.current) != null ? _this$get$node$curren : void 0;
  }
}
const defaultPublicContext = {
  activatorEvent: null,
  active: null,
  activeNode: null,
  activeNodeRect: null,
  collisions: null,
  containerNodeRect: null,
  draggableNodes: /* @__PURE__ */ new Map(),
  droppableRects: /* @__PURE__ */ new Map(),
  droppableContainers: /* @__PURE__ */ new DroppableContainersMap(),
  over: null,
  dragOverlay: {
    nodeRef: {
      current: null
    },
    rect: null,
    setRef: noop
  },
  scrollableAncestors: [],
  scrollableAncestorRects: [],
  measuringConfiguration: defaultMeasuringConfiguration,
  measureDroppableContainers: noop,
  windowRect: null,
  measuringScheduled: false
};
const defaultInternalContext = {
  activatorEvent: null,
  activators: [],
  active: null,
  activeNodeRect: null,
  ariaDescribedById: {
    draggable: ""
  },
  dispatch: noop,
  draggableNodes: /* @__PURE__ */ new Map(),
  over: null,
  measureDroppableContainers: noop
};
const InternalContext = /* @__PURE__ */ reactExports.createContext(defaultInternalContext);
const PublicContext = /* @__PURE__ */ reactExports.createContext(defaultPublicContext);
function getInitialState() {
  return {
    draggable: {
      active: null,
      initialCoordinates: {
        x: 0,
        y: 0
      },
      nodes: /* @__PURE__ */ new Map(),
      translate: {
        x: 0,
        y: 0
      }
    },
    droppable: {
      containers: new DroppableContainersMap()
    }
  };
}
function reducer(state, action) {
  switch (action.type) {
    case Action.DragStart:
      return {
        ...state,
        draggable: {
          ...state.draggable,
          initialCoordinates: action.initialCoordinates,
          active: action.active
        }
      };
    case Action.DragMove:
      if (state.draggable.active == null) {
        return state;
      }
      return {
        ...state,
        draggable: {
          ...state.draggable,
          translate: {
            x: action.coordinates.x - state.draggable.initialCoordinates.x,
            y: action.coordinates.y - state.draggable.initialCoordinates.y
          }
        }
      };
    case Action.DragEnd:
    case Action.DragCancel:
      return {
        ...state,
        draggable: {
          ...state.draggable,
          active: null,
          initialCoordinates: {
            x: 0,
            y: 0
          },
          translate: {
            x: 0,
            y: 0
          }
        }
      };
    case Action.RegisterDroppable: {
      const {
        element
      } = action;
      const {
        id
      } = element;
      const containers = new DroppableContainersMap(state.droppable.containers);
      containers.set(id, element);
      return {
        ...state,
        droppable: {
          ...state.droppable,
          containers
        }
      };
    }
    case Action.SetDroppableDisabled: {
      const {
        id,
        key: key2,
        disabled
      } = action;
      const element = state.droppable.containers.get(id);
      if (!element || key2 !== element.key) {
        return state;
      }
      const containers = new DroppableContainersMap(state.droppable.containers);
      containers.set(id, {
        ...element,
        disabled
      });
      return {
        ...state,
        droppable: {
          ...state.droppable,
          containers
        }
      };
    }
    case Action.UnregisterDroppable: {
      const {
        id,
        key: key2
      } = action;
      const element = state.droppable.containers.get(id);
      if (!element || key2 !== element.key) {
        return state;
      }
      const containers = new DroppableContainersMap(state.droppable.containers);
      containers.delete(id);
      return {
        ...state,
        droppable: {
          ...state.droppable,
          containers
        }
      };
    }
    default: {
      return state;
    }
  }
}
function RestoreFocus(_ref) {
  let {
    disabled
  } = _ref;
  const {
    active,
    activatorEvent,
    draggableNodes
  } = reactExports.useContext(InternalContext);
  const previousActivatorEvent = usePrevious(activatorEvent);
  const previousActiveId = usePrevious(active == null ? void 0 : active.id);
  reactExports.useEffect(() => {
    if (disabled) {
      return;
    }
    if (!activatorEvent && previousActivatorEvent && previousActiveId != null) {
      if (!isKeyboardEvent(previousActivatorEvent)) {
        return;
      }
      if (document.activeElement === previousActivatorEvent.target) {
        return;
      }
      const draggableNode = draggableNodes.get(previousActiveId);
      if (!draggableNode) {
        return;
      }
      const {
        activatorNode,
        node
      } = draggableNode;
      if (!activatorNode.current && !node.current) {
        return;
      }
      requestAnimationFrame(() => {
        for (const element of [activatorNode.current, node.current]) {
          if (!element) {
            continue;
          }
          const focusableNode = findFirstFocusableNode(element);
          if (focusableNode) {
            focusableNode.focus();
            break;
          }
        }
      });
    }
  }, [activatorEvent, disabled, draggableNodes, previousActiveId, previousActivatorEvent]);
  return null;
}
function applyModifiers(modifiers, _ref) {
  let {
    transform,
    ...args
  } = _ref;
  return modifiers != null && modifiers.length ? modifiers.reduce((accumulator, modifier) => {
    return modifier({
      transform: accumulator,
      ...args
    });
  }, transform) : transform;
}
function useMeasuringConfiguration(config) {
  return reactExports.useMemo(
    () => ({
      draggable: {
        ...defaultMeasuringConfiguration.draggable,
        ...config == null ? void 0 : config.draggable
      },
      droppable: {
        ...defaultMeasuringConfiguration.droppable,
        ...config == null ? void 0 : config.droppable
      },
      dragOverlay: {
        ...defaultMeasuringConfiguration.dragOverlay,
        ...config == null ? void 0 : config.dragOverlay
      }
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [config == null ? void 0 : config.draggable, config == null ? void 0 : config.droppable, config == null ? void 0 : config.dragOverlay]
  );
}
function useLayoutShiftScrollCompensation(_ref) {
  let {
    activeNode,
    measure,
    initialRect,
    config = true
  } = _ref;
  const initialized = reactExports.useRef(false);
  const {
    x,
    y
  } = typeof config === "boolean" ? {
    x: config,
    y: config
  } : config;
  useIsomorphicLayoutEffect(() => {
    const disabled = !x && !y;
    if (disabled || !activeNode) {
      initialized.current = false;
      return;
    }
    if (initialized.current || !initialRect) {
      return;
    }
    const node = activeNode == null ? void 0 : activeNode.node.current;
    if (!node || node.isConnected === false) {
      return;
    }
    const rect = measure(node);
    const rectDelta = getRectDelta(rect, initialRect);
    if (!x) {
      rectDelta.x = 0;
    }
    if (!y) {
      rectDelta.y = 0;
    }
    initialized.current = true;
    if (Math.abs(rectDelta.x) > 0 || Math.abs(rectDelta.y) > 0) {
      const firstScrollableAncestor = getFirstScrollableAncestor(node);
      if (firstScrollableAncestor) {
        firstScrollableAncestor.scrollBy({
          top: rectDelta.y,
          left: rectDelta.x
        });
      }
    }
  }, [activeNode, x, y, initialRect, measure]);
}
const ActiveDraggableContext = /* @__PURE__ */ reactExports.createContext({
  ...defaultCoordinates,
  scaleX: 1,
  scaleY: 1
});
var Status;
(function(Status2) {
  Status2[Status2["Uninitialized"] = 0] = "Uninitialized";
  Status2[Status2["Initializing"] = 1] = "Initializing";
  Status2[Status2["Initialized"] = 2] = "Initialized";
})(Status || (Status = {}));
const DndContext = /* @__PURE__ */ reactExports.memo(function DndContext2(_ref) {
  var _sensorContext$curren, _dragOverlay$nodeRef$, _dragOverlay$rect, _over$rect;
  let {
    id,
    accessibility,
    autoScroll = true,
    children,
    sensors = defaultSensors,
    collisionDetection = rectIntersection,
    measuring,
    modifiers,
    ...props
  } = _ref;
  const store = reactExports.useReducer(reducer, void 0, getInitialState);
  const [state, dispatch] = store;
  const [dispatchMonitorEvent, registerMonitorListener] = useDndMonitorProvider();
  const [status, setStatus] = reactExports.useState(Status.Uninitialized);
  const isInitialized = status === Status.Initialized;
  const {
    draggable: {
      active: activeId,
      nodes: draggableNodes,
      translate
    },
    droppable: {
      containers: droppableContainers
    }
  } = state;
  const node = activeId != null ? draggableNodes.get(activeId) : null;
  const activeRects = reactExports.useRef({
    initial: null,
    translated: null
  });
  const active = reactExports.useMemo(() => {
    var _node$data;
    return activeId != null ? {
      id: activeId,
      // It's possible for the active node to unmount while dragging
      data: (_node$data = node == null ? void 0 : node.data) != null ? _node$data : defaultData,
      rect: activeRects
    } : null;
  }, [activeId, node]);
  const activeRef = reactExports.useRef(null);
  const [activeSensor, setActiveSensor] = reactExports.useState(null);
  const [activatorEvent, setActivatorEvent] = reactExports.useState(null);
  const latestProps = useLatestValue(props, Object.values(props));
  const draggableDescribedById = useUniqueId("DndDescribedBy", id);
  const enabledDroppableContainers = reactExports.useMemo(() => droppableContainers.getEnabled(), [droppableContainers]);
  const measuringConfiguration = useMeasuringConfiguration(measuring);
  const {
    droppableRects,
    measureDroppableContainers,
    measuringScheduled
  } = useDroppableMeasuring(enabledDroppableContainers, {
    dragging: isInitialized,
    dependencies: [translate.x, translate.y],
    config: measuringConfiguration.droppable
  });
  const activeNode = useCachedNode(draggableNodes, activeId);
  const activationCoordinates = reactExports.useMemo(() => activatorEvent ? getEventCoordinates(activatorEvent) : null, [activatorEvent]);
  const autoScrollOptions = getAutoScrollerOptions();
  const initialActiveNodeRect = useInitialRect(activeNode, measuringConfiguration.draggable.measure);
  useLayoutShiftScrollCompensation({
    activeNode: activeId != null ? draggableNodes.get(activeId) : null,
    config: autoScrollOptions.layoutShiftCompensation,
    initialRect: initialActiveNodeRect,
    measure: measuringConfiguration.draggable.measure
  });
  const activeNodeRect = useRect(activeNode, measuringConfiguration.draggable.measure, initialActiveNodeRect);
  const containerNodeRect = useRect(activeNode ? activeNode.parentElement : null);
  const sensorContext = reactExports.useRef({
    activatorEvent: null,
    active: null,
    activeNode,
    collisionRect: null,
    collisions: null,
    droppableRects,
    draggableNodes,
    draggingNode: null,
    draggingNodeRect: null,
    droppableContainers,
    over: null,
    scrollableAncestors: [],
    scrollAdjustedTranslate: null
  });
  const overNode = droppableContainers.getNodeFor((_sensorContext$curren = sensorContext.current.over) == null ? void 0 : _sensorContext$curren.id);
  const dragOverlay = useDragOverlayMeasuring({
    measure: measuringConfiguration.dragOverlay.measure
  });
  const draggingNode = (_dragOverlay$nodeRef$ = dragOverlay.nodeRef.current) != null ? _dragOverlay$nodeRef$ : activeNode;
  const draggingNodeRect = isInitialized ? (_dragOverlay$rect = dragOverlay.rect) != null ? _dragOverlay$rect : activeNodeRect : null;
  const usesDragOverlay = Boolean(dragOverlay.nodeRef.current && dragOverlay.rect);
  const nodeRectDelta = useRectDelta(usesDragOverlay ? null : activeNodeRect);
  const windowRect = useWindowRect(draggingNode ? getWindow(draggingNode) : null);
  const scrollableAncestors = useScrollableAncestors(isInitialized ? overNode != null ? overNode : activeNode : null);
  const scrollableAncestorRects = useRects(scrollableAncestors);
  const modifiedTranslate = applyModifiers(modifiers, {
    transform: {
      x: translate.x - nodeRectDelta.x,
      y: translate.y - nodeRectDelta.y,
      scaleX: 1,
      scaleY: 1
    },
    activatorEvent,
    active,
    activeNodeRect,
    containerNodeRect,
    draggingNodeRect,
    over: sensorContext.current.over,
    overlayNodeRect: dragOverlay.rect,
    scrollableAncestors,
    scrollableAncestorRects,
    windowRect
  });
  const pointerCoordinates = activationCoordinates ? add(activationCoordinates, translate) : null;
  const scrollOffsets = useScrollOffsets(scrollableAncestors);
  const scrollAdjustment = useScrollOffsetsDelta(scrollOffsets);
  const activeNodeScrollDelta = useScrollOffsetsDelta(scrollOffsets, [activeNodeRect]);
  const scrollAdjustedTranslate = add(modifiedTranslate, scrollAdjustment);
  const collisionRect = draggingNodeRect ? getAdjustedRect(draggingNodeRect, modifiedTranslate) : null;
  const collisions = active && collisionRect ? collisionDetection({
    active,
    collisionRect,
    droppableRects,
    droppableContainers: enabledDroppableContainers,
    pointerCoordinates
  }) : null;
  const overId = getFirstCollision(collisions, "id");
  const [over, setOver] = reactExports.useState(null);
  const appliedTranslate = usesDragOverlay ? modifiedTranslate : add(modifiedTranslate, activeNodeScrollDelta);
  const transform = adjustScale(appliedTranslate, (_over$rect = over == null ? void 0 : over.rect) != null ? _over$rect : null, activeNodeRect);
  const activeSensorRef = reactExports.useRef(null);
  const instantiateSensor = reactExports.useCallback(
    (event, _ref2) => {
      let {
        sensor: Sensor,
        options
      } = _ref2;
      if (activeRef.current == null) {
        return;
      }
      const activeNode2 = draggableNodes.get(activeRef.current);
      if (!activeNode2) {
        return;
      }
      const activatorEvent2 = event.nativeEvent;
      const sensorInstance = new Sensor({
        active: activeRef.current,
        activeNode: activeNode2,
        event: activatorEvent2,
        options,
        // Sensors need to be instantiated with refs for arguments that change over time
        // otherwise they are frozen in time with the stale arguments
        context: sensorContext,
        onAbort(id2) {
          const draggableNode = draggableNodes.get(id2);
          if (!draggableNode) {
            return;
          }
          const {
            onDragAbort
          } = latestProps.current;
          const event2 = {
            id: id2
          };
          onDragAbort == null ? void 0 : onDragAbort(event2);
          dispatchMonitorEvent({
            type: "onDragAbort",
            event: event2
          });
        },
        onPending(id2, constraint, initialCoordinates, offset) {
          const draggableNode = draggableNodes.get(id2);
          if (!draggableNode) {
            return;
          }
          const {
            onDragPending
          } = latestProps.current;
          const event2 = {
            id: id2,
            constraint,
            initialCoordinates,
            offset
          };
          onDragPending == null ? void 0 : onDragPending(event2);
          dispatchMonitorEvent({
            type: "onDragPending",
            event: event2
          });
        },
        onStart(initialCoordinates) {
          const id2 = activeRef.current;
          if (id2 == null) {
            return;
          }
          const draggableNode = draggableNodes.get(id2);
          if (!draggableNode) {
            return;
          }
          const {
            onDragStart
          } = latestProps.current;
          const event2 = {
            activatorEvent: activatorEvent2,
            active: {
              id: id2,
              data: draggableNode.data,
              rect: activeRects
            }
          };
          reactDomExports.unstable_batchedUpdates(() => {
            onDragStart == null ? void 0 : onDragStart(event2);
            setStatus(Status.Initializing);
            dispatch({
              type: Action.DragStart,
              initialCoordinates,
              active: id2
            });
            dispatchMonitorEvent({
              type: "onDragStart",
              event: event2
            });
            setActiveSensor(activeSensorRef.current);
            setActivatorEvent(activatorEvent2);
          });
        },
        onMove(coordinates) {
          dispatch({
            type: Action.DragMove,
            coordinates
          });
        },
        onEnd: createHandler(Action.DragEnd),
        onCancel: createHandler(Action.DragCancel)
      });
      activeSensorRef.current = sensorInstance;
      function createHandler(type) {
        return async function handler() {
          const {
            active: active2,
            collisions: collisions2,
            over: over2,
            scrollAdjustedTranslate: scrollAdjustedTranslate2
          } = sensorContext.current;
          let event2 = null;
          if (active2 && scrollAdjustedTranslate2) {
            const {
              cancelDrop
            } = latestProps.current;
            event2 = {
              activatorEvent: activatorEvent2,
              active: active2,
              collisions: collisions2,
              delta: scrollAdjustedTranslate2,
              over: over2
            };
            if (type === Action.DragEnd && typeof cancelDrop === "function") {
              const shouldCancel = await Promise.resolve(cancelDrop(event2));
              if (shouldCancel) {
                type = Action.DragCancel;
              }
            }
          }
          activeRef.current = null;
          reactDomExports.unstable_batchedUpdates(() => {
            dispatch({
              type
            });
            setStatus(Status.Uninitialized);
            setOver(null);
            setActiveSensor(null);
            setActivatorEvent(null);
            activeSensorRef.current = null;
            const eventName = type === Action.DragEnd ? "onDragEnd" : "onDragCancel";
            if (event2) {
              const handler2 = latestProps.current[eventName];
              handler2 == null ? void 0 : handler2(event2);
              dispatchMonitorEvent({
                type: eventName,
                event: event2
              });
            }
          });
        };
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [draggableNodes]
  );
  const bindActivatorToSensorInstantiator = reactExports.useCallback((handler, sensor) => {
    return (event, active2) => {
      const nativeEvent = event.nativeEvent;
      const activeDraggableNode = draggableNodes.get(active2);
      if (
        // Another sensor is already instantiating
        activeRef.current !== null || // No active draggable
        !activeDraggableNode || // Event has already been captured
        nativeEvent.dndKit || nativeEvent.defaultPrevented
      ) {
        return;
      }
      const activationContext = {
        active: activeDraggableNode
      };
      const shouldActivate = handler(event, sensor.options, activationContext);
      if (shouldActivate === true) {
        nativeEvent.dndKit = {
          capturedBy: sensor.sensor
        };
        activeRef.current = active2;
        instantiateSensor(event, sensor);
      }
    };
  }, [draggableNodes, instantiateSensor]);
  const activators = useCombineActivators(sensors, bindActivatorToSensorInstantiator);
  useSensorSetup(sensors);
  useIsomorphicLayoutEffect(() => {
    if (activeNodeRect && status === Status.Initializing) {
      setStatus(Status.Initialized);
    }
  }, [activeNodeRect, status]);
  reactExports.useEffect(
    () => {
      const {
        onDragMove
      } = latestProps.current;
      const {
        active: active2,
        activatorEvent: activatorEvent2,
        collisions: collisions2,
        over: over2
      } = sensorContext.current;
      if (!active2 || !activatorEvent2) {
        return;
      }
      const event = {
        active: active2,
        activatorEvent: activatorEvent2,
        collisions: collisions2,
        delta: {
          x: scrollAdjustedTranslate.x,
          y: scrollAdjustedTranslate.y
        },
        over: over2
      };
      reactDomExports.unstable_batchedUpdates(() => {
        onDragMove == null ? void 0 : onDragMove(event);
        dispatchMonitorEvent({
          type: "onDragMove",
          event
        });
      });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [scrollAdjustedTranslate.x, scrollAdjustedTranslate.y]
  );
  reactExports.useEffect(
    () => {
      const {
        active: active2,
        activatorEvent: activatorEvent2,
        collisions: collisions2,
        droppableContainers: droppableContainers2,
        scrollAdjustedTranslate: scrollAdjustedTranslate2
      } = sensorContext.current;
      if (!active2 || activeRef.current == null || !activatorEvent2 || !scrollAdjustedTranslate2) {
        return;
      }
      const {
        onDragOver
      } = latestProps.current;
      const overContainer = droppableContainers2.get(overId);
      const over2 = overContainer && overContainer.rect.current ? {
        id: overContainer.id,
        rect: overContainer.rect.current,
        data: overContainer.data,
        disabled: overContainer.disabled
      } : null;
      const event = {
        active: active2,
        activatorEvent: activatorEvent2,
        collisions: collisions2,
        delta: {
          x: scrollAdjustedTranslate2.x,
          y: scrollAdjustedTranslate2.y
        },
        over: over2
      };
      reactDomExports.unstable_batchedUpdates(() => {
        setOver(over2);
        onDragOver == null ? void 0 : onDragOver(event);
        dispatchMonitorEvent({
          type: "onDragOver",
          event
        });
      });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [overId]
  );
  useIsomorphicLayoutEffect(() => {
    sensorContext.current = {
      activatorEvent,
      active,
      activeNode,
      collisionRect,
      collisions,
      droppableRects,
      draggableNodes,
      draggingNode,
      draggingNodeRect,
      droppableContainers,
      over,
      scrollableAncestors,
      scrollAdjustedTranslate
    };
    activeRects.current = {
      initial: draggingNodeRect,
      translated: collisionRect
    };
  }, [active, activeNode, collisions, collisionRect, draggableNodes, draggingNode, draggingNodeRect, droppableRects, droppableContainers, over, scrollableAncestors, scrollAdjustedTranslate]);
  useAutoScroller({
    ...autoScrollOptions,
    delta: translate,
    draggingRect: collisionRect,
    pointerCoordinates,
    scrollableAncestors,
    scrollableAncestorRects
  });
  const publicContext = reactExports.useMemo(() => {
    const context = {
      active,
      activeNode,
      activeNodeRect,
      activatorEvent,
      collisions,
      containerNodeRect,
      dragOverlay,
      draggableNodes,
      droppableContainers,
      droppableRects,
      over,
      measureDroppableContainers,
      scrollableAncestors,
      scrollableAncestorRects,
      measuringConfiguration,
      measuringScheduled,
      windowRect
    };
    return context;
  }, [active, activeNode, activeNodeRect, activatorEvent, collisions, containerNodeRect, dragOverlay, draggableNodes, droppableContainers, droppableRects, over, measureDroppableContainers, scrollableAncestors, scrollableAncestorRects, measuringConfiguration, measuringScheduled, windowRect]);
  const internalContext = reactExports.useMemo(() => {
    const context = {
      activatorEvent,
      activators,
      active,
      activeNodeRect,
      ariaDescribedById: {
        draggable: draggableDescribedById
      },
      dispatch,
      draggableNodes,
      over,
      measureDroppableContainers
    };
    return context;
  }, [activatorEvent, activators, active, activeNodeRect, dispatch, draggableDescribedById, draggableNodes, over, measureDroppableContainers]);
  return React.createElement(DndMonitorContext.Provider, {
    value: registerMonitorListener
  }, React.createElement(InternalContext.Provider, {
    value: internalContext
  }, React.createElement(PublicContext.Provider, {
    value: publicContext
  }, React.createElement(ActiveDraggableContext.Provider, {
    value: transform
  }, children)), React.createElement(RestoreFocus, {
    disabled: (accessibility == null ? void 0 : accessibility.restoreFocus) === false
  })), React.createElement(Accessibility, {
    ...accessibility,
    hiddenTextDescribedById: draggableDescribedById
  }));
  function getAutoScrollerOptions() {
    const activeSensorDisablesAutoscroll = (activeSensor == null ? void 0 : activeSensor.autoScrollEnabled) === false;
    const autoScrollGloballyDisabled = typeof autoScroll === "object" ? autoScroll.enabled === false : autoScroll === false;
    const enabled = isInitialized && !activeSensorDisablesAutoscroll && !autoScrollGloballyDisabled;
    if (typeof autoScroll === "object") {
      return {
        ...autoScroll,
        enabled
      };
    }
    return {
      enabled
    };
  }
});
const NullContext = /* @__PURE__ */ reactExports.createContext(null);
const defaultRole = "button";
const ID_PREFIX$1 = "Draggable";
function useDraggable(_ref) {
  let {
    id,
    data,
    disabled = false,
    attributes
  } = _ref;
  const key2 = useUniqueId(ID_PREFIX$1);
  const {
    activators,
    activatorEvent,
    active,
    activeNodeRect,
    ariaDescribedById,
    draggableNodes,
    over
  } = reactExports.useContext(InternalContext);
  const {
    role = defaultRole,
    roleDescription = "draggable",
    tabIndex = 0
  } = attributes != null ? attributes : {};
  const isDragging = (active == null ? void 0 : active.id) === id;
  const transform = reactExports.useContext(isDragging ? ActiveDraggableContext : NullContext);
  const [node, setNodeRef] = useNodeRef();
  const [activatorNode, setActivatorNodeRef] = useNodeRef();
  const listeners = useSyntheticListeners(activators, id);
  const dataRef = useLatestValue(data);
  useIsomorphicLayoutEffect(
    () => {
      draggableNodes.set(id, {
        id,
        key: key2,
        node,
        activatorNode,
        data: dataRef
      });
      return () => {
        const node2 = draggableNodes.get(id);
        if (node2 && node2.key === key2) {
          draggableNodes.delete(id);
        }
      };
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [draggableNodes, id]
  );
  const memoizedAttributes = reactExports.useMemo(() => ({
    role,
    tabIndex,
    "aria-disabled": disabled,
    "aria-pressed": isDragging && role === defaultRole ? true : void 0,
    "aria-roledescription": roleDescription,
    "aria-describedby": ariaDescribedById.draggable
  }), [disabled, role, tabIndex, isDragging, roleDescription, ariaDescribedById.draggable]);
  return {
    active,
    activatorEvent,
    activeNodeRect,
    attributes: memoizedAttributes,
    isDragging,
    listeners: disabled ? void 0 : listeners,
    node,
    over,
    setNodeRef,
    setActivatorNodeRef,
    transform
  };
}
function useDndContext() {
  return reactExports.useContext(PublicContext);
}
const ID_PREFIX$1$1 = "Droppable";
const defaultResizeObserverConfig = {
  timeout: 25
};
function useDroppable(_ref) {
  let {
    data,
    disabled = false,
    id,
    resizeObserverConfig
  } = _ref;
  const key2 = useUniqueId(ID_PREFIX$1$1);
  const {
    active,
    dispatch,
    over,
    measureDroppableContainers
  } = reactExports.useContext(InternalContext);
  const previous = reactExports.useRef({
    disabled
  });
  const resizeObserverConnected = reactExports.useRef(false);
  const rect = reactExports.useRef(null);
  const callbackId = reactExports.useRef(null);
  const {
    disabled: resizeObserverDisabled,
    updateMeasurementsFor,
    timeout: resizeObserverTimeout
  } = {
    ...defaultResizeObserverConfig,
    ...resizeObserverConfig
  };
  const ids2 = useLatestValue(updateMeasurementsFor != null ? updateMeasurementsFor : id);
  const handleResize = reactExports.useCallback(
    () => {
      if (!resizeObserverConnected.current) {
        resizeObserverConnected.current = true;
        return;
      }
      if (callbackId.current != null) {
        clearTimeout(callbackId.current);
      }
      callbackId.current = setTimeout(() => {
        measureDroppableContainers(Array.isArray(ids2.current) ? ids2.current : [ids2.current]);
        callbackId.current = null;
      }, resizeObserverTimeout);
    },
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [resizeObserverTimeout]
  );
  const resizeObserver = useResizeObserver({
    callback: handleResize,
    disabled: resizeObserverDisabled || !active
  });
  const handleNodeChange = reactExports.useCallback((newElement, previousElement) => {
    if (!resizeObserver) {
      return;
    }
    if (previousElement) {
      resizeObserver.unobserve(previousElement);
      resizeObserverConnected.current = false;
    }
    if (newElement) {
      resizeObserver.observe(newElement);
    }
  }, [resizeObserver]);
  const [nodeRef, setNodeRef] = useNodeRef(handleNodeChange);
  const dataRef = useLatestValue(data);
  reactExports.useEffect(() => {
    if (!resizeObserver || !nodeRef.current) {
      return;
    }
    resizeObserver.disconnect();
    resizeObserverConnected.current = false;
    resizeObserver.observe(nodeRef.current);
  }, [nodeRef, resizeObserver]);
  reactExports.useEffect(
    () => {
      dispatch({
        type: Action.RegisterDroppable,
        element: {
          id,
          key: key2,
          disabled,
          node: nodeRef,
          rect,
          data: dataRef
        }
      });
      return () => dispatch({
        type: Action.UnregisterDroppable,
        key: key2,
        id
      });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [id]
  );
  reactExports.useEffect(() => {
    if (disabled !== previous.current.disabled) {
      dispatch({
        type: Action.SetDroppableDisabled,
        id,
        key: key2,
        disabled
      });
      previous.current.disabled = disabled;
    }
  }, [id, key2, disabled, dispatch]);
  return {
    active,
    rect,
    isOver: (over == null ? void 0 : over.id) === id,
    node: nodeRef,
    over,
    setNodeRef
  };
}
function AnimationManager(_ref) {
  let {
    animation,
    children
  } = _ref;
  const [clonedChildren, setClonedChildren] = reactExports.useState(null);
  const [element, setElement] = reactExports.useState(null);
  const previousChildren = usePrevious(children);
  if (!children && !clonedChildren && previousChildren) {
    setClonedChildren(previousChildren);
  }
  useIsomorphicLayoutEffect(() => {
    if (!element) {
      return;
    }
    const key2 = clonedChildren == null ? void 0 : clonedChildren.key;
    const id = clonedChildren == null ? void 0 : clonedChildren.props.id;
    if (key2 == null || id == null) {
      setClonedChildren(null);
      return;
    }
    Promise.resolve(animation(id, element)).then(() => {
      setClonedChildren(null);
    });
  }, [animation, clonedChildren, element]);
  return React.createElement(React.Fragment, null, children, clonedChildren ? reactExports.cloneElement(clonedChildren, {
    ref: setElement
  }) : null);
}
const defaultTransform = {
  x: 0,
  y: 0,
  scaleX: 1,
  scaleY: 1
};
function NullifiedContextProvider(_ref) {
  let {
    children
  } = _ref;
  return React.createElement(InternalContext.Provider, {
    value: defaultInternalContext
  }, React.createElement(ActiveDraggableContext.Provider, {
    value: defaultTransform
  }, children));
}
const baseStyles = {
  position: "fixed",
  touchAction: "none"
};
const defaultTransition$1 = (activatorEvent) => {
  const isKeyboardActivator = isKeyboardEvent(activatorEvent);
  return isKeyboardActivator ? "transform 250ms ease" : void 0;
};
const PositionedOverlay = /* @__PURE__ */ reactExports.forwardRef((_ref, ref) => {
  let {
    as,
    activatorEvent,
    adjustScale: adjustScale2,
    children,
    className,
    rect,
    style,
    transform,
    transition = defaultTransition$1
  } = _ref;
  if (!rect) {
    return null;
  }
  const scaleAdjustedTransform = adjustScale2 ? transform : {
    ...transform,
    scaleX: 1,
    scaleY: 1
  };
  const styles = {
    ...baseStyles,
    width: rect.width,
    height: rect.height,
    top: rect.top,
    left: rect.left,
    transform: CSS.Transform.toString(scaleAdjustedTransform),
    transformOrigin: adjustScale2 && activatorEvent ? getRelativeTransformOrigin(activatorEvent, rect) : void 0,
    transition: typeof transition === "function" ? transition(activatorEvent) : transition,
    ...style
  };
  return React.createElement(as, {
    className,
    style: styles,
    ref
  }, children);
});
const defaultDropAnimationSideEffects = (options) => (_ref) => {
  let {
    active,
    dragOverlay
  } = _ref;
  const originalStyles = {};
  const {
    styles,
    className
  } = options;
  if (styles != null && styles.active) {
    for (const [key2, value] of Object.entries(styles.active)) {
      if (value === void 0) {
        continue;
      }
      originalStyles[key2] = active.node.style.getPropertyValue(key2);
      active.node.style.setProperty(key2, value);
    }
  }
  if (styles != null && styles.dragOverlay) {
    for (const [key2, value] of Object.entries(styles.dragOverlay)) {
      if (value === void 0) {
        continue;
      }
      dragOverlay.node.style.setProperty(key2, value);
    }
  }
  if (className != null && className.active) {
    active.node.classList.add(className.active);
  }
  if (className != null && className.dragOverlay) {
    dragOverlay.node.classList.add(className.dragOverlay);
  }
  return function cleanup() {
    for (const [key2, value] of Object.entries(originalStyles)) {
      active.node.style.setProperty(key2, value);
    }
    if (className != null && className.active) {
      active.node.classList.remove(className.active);
    }
  };
};
const defaultKeyframeResolver = (_ref2) => {
  let {
    transform: {
      initial,
      final
    }
  } = _ref2;
  return [{
    transform: CSS.Transform.toString(initial)
  }, {
    transform: CSS.Transform.toString(final)
  }];
};
const defaultDropAnimationConfiguration = {
  duration: 250,
  easing: "ease",
  keyframes: defaultKeyframeResolver,
  sideEffects: /* @__PURE__ */ defaultDropAnimationSideEffects({
    styles: {
      active: {
        opacity: "0"
      }
    }
  })
};
function useDropAnimation(_ref3) {
  let {
    config,
    draggableNodes,
    droppableContainers,
    measuringConfiguration
  } = _ref3;
  return useEvent((id, node) => {
    if (config === null) {
      return;
    }
    const activeDraggable = draggableNodes.get(id);
    if (!activeDraggable) {
      return;
    }
    const activeNode = activeDraggable.node.current;
    if (!activeNode) {
      return;
    }
    const measurableNode = getMeasurableNode(node);
    if (!measurableNode) {
      return;
    }
    const {
      transform
    } = getWindow(node).getComputedStyle(node);
    const parsedTransform = parseTransform(transform);
    if (!parsedTransform) {
      return;
    }
    const animation = typeof config === "function" ? config : createDefaultDropAnimation(config);
    scrollIntoViewIfNeeded(activeNode, measuringConfiguration.draggable.measure);
    return animation({
      active: {
        id,
        data: activeDraggable.data,
        node: activeNode,
        rect: measuringConfiguration.draggable.measure(activeNode)
      },
      draggableNodes,
      dragOverlay: {
        node,
        rect: measuringConfiguration.dragOverlay.measure(measurableNode)
      },
      droppableContainers,
      measuringConfiguration,
      transform: parsedTransform
    });
  });
}
function createDefaultDropAnimation(options) {
  const {
    duration,
    easing,
    sideEffects,
    keyframes
  } = {
    ...defaultDropAnimationConfiguration,
    ...options
  };
  return (_ref4) => {
    let {
      active,
      dragOverlay,
      transform,
      ...rest
    } = _ref4;
    if (!duration) {
      return;
    }
    const delta = {
      x: dragOverlay.rect.left - active.rect.left,
      y: dragOverlay.rect.top - active.rect.top
    };
    const scale = {
      scaleX: transform.scaleX !== 1 ? active.rect.width * transform.scaleX / dragOverlay.rect.width : 1,
      scaleY: transform.scaleY !== 1 ? active.rect.height * transform.scaleY / dragOverlay.rect.height : 1
    };
    const finalTransform = {
      x: transform.x - delta.x,
      y: transform.y - delta.y,
      ...scale
    };
    const animationKeyframes = keyframes({
      ...rest,
      active,
      dragOverlay,
      transform: {
        initial: transform,
        final: finalTransform
      }
    });
    const [firstKeyframe] = animationKeyframes;
    const lastKeyframe = animationKeyframes[animationKeyframes.length - 1];
    if (JSON.stringify(firstKeyframe) === JSON.stringify(lastKeyframe)) {
      return;
    }
    const cleanup = sideEffects == null ? void 0 : sideEffects({
      active,
      dragOverlay,
      ...rest
    });
    const animation = dragOverlay.node.animate(animationKeyframes, {
      duration,
      easing,
      fill: "forwards"
    });
    return new Promise((resolve) => {
      animation.onfinish = () => {
        cleanup == null ? void 0 : cleanup();
        resolve();
      };
    });
  };
}
let key = 0;
function useKey(id) {
  return reactExports.useMemo(() => {
    if (id == null) {
      return;
    }
    key++;
    return key;
  }, [id]);
}
const DragOverlay = /* @__PURE__ */ React.memo((_ref) => {
  let {
    adjustScale: adjustScale2 = false,
    children,
    dropAnimation: dropAnimationConfig,
    style,
    transition,
    modifiers,
    wrapperElement = "div",
    className,
    zIndex = 999
  } = _ref;
  const {
    activatorEvent,
    active,
    activeNodeRect,
    containerNodeRect,
    draggableNodes,
    droppableContainers,
    dragOverlay,
    over,
    measuringConfiguration,
    scrollableAncestors,
    scrollableAncestorRects,
    windowRect
  } = useDndContext();
  const transform = reactExports.useContext(ActiveDraggableContext);
  const key2 = useKey(active == null ? void 0 : active.id);
  const modifiedTransform = applyModifiers(modifiers, {
    activatorEvent,
    active,
    activeNodeRect,
    containerNodeRect,
    draggingNodeRect: dragOverlay.rect,
    over,
    overlayNodeRect: dragOverlay.rect,
    scrollableAncestors,
    scrollableAncestorRects,
    transform,
    windowRect
  });
  const initialRect = useInitialValue(activeNodeRect);
  const dropAnimation = useDropAnimation({
    config: dropAnimationConfig,
    draggableNodes,
    droppableContainers,
    measuringConfiguration
  });
  const ref = initialRect ? dragOverlay.setRef : void 0;
  return React.createElement(NullifiedContextProvider, null, React.createElement(AnimationManager, {
    animation: dropAnimation
  }, active && key2 ? React.createElement(PositionedOverlay, {
    key: key2,
    id: active.id,
    ref,
    as: wrapperElement,
    activatorEvent,
    adjustScale: adjustScale2,
    className,
    transition,
    rect: initialRect,
    style: {
      zIndex,
      ...style
    },
    transform: modifiedTransform
  }, children) : null));
});
function arrayMove(array, from, to) {
  const newArray = array.slice();
  newArray.splice(to < 0 ? newArray.length + to : to, 0, newArray.splice(from, 1)[0]);
  return newArray;
}
function getSortedRects(items, rects) {
  return items.reduce((accumulator, id, index) => {
    const rect = rects.get(id);
    if (rect) {
      accumulator[index] = rect;
    }
    return accumulator;
  }, Array(items.length));
}
function isValidIndex(index) {
  return index !== null && index >= 0;
}
function itemsEqual(a, b) {
  if (a === b) {
    return true;
  }
  if (a.length !== b.length) {
    return false;
  }
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) {
      return false;
    }
  }
  return true;
}
function normalizeDisabled(disabled) {
  if (typeof disabled === "boolean") {
    return {
      draggable: disabled,
      droppable: disabled
    };
  }
  return disabled;
}
const rectSortingStrategy = (_ref) => {
  let {
    rects,
    activeIndex,
    overIndex,
    index
  } = _ref;
  const newRects = arrayMove(rects, overIndex, activeIndex);
  const oldRect = rects[index];
  const newRect = newRects[index];
  if (!newRect || !oldRect) {
    return null;
  }
  return {
    x: newRect.left - oldRect.left,
    y: newRect.top - oldRect.top,
    scaleX: newRect.width / oldRect.width,
    scaleY: newRect.height / oldRect.height
  };
};
const defaultScale$1 = {
  scaleX: 1,
  scaleY: 1
};
const verticalListSortingStrategy = (_ref) => {
  var _rects$activeIndex;
  let {
    activeIndex,
    activeNodeRect: fallbackActiveRect,
    index,
    rects,
    overIndex
  } = _ref;
  const activeNodeRect = (_rects$activeIndex = rects[activeIndex]) != null ? _rects$activeIndex : fallbackActiveRect;
  if (!activeNodeRect) {
    return null;
  }
  if (index === activeIndex) {
    const overIndexRect = rects[overIndex];
    if (!overIndexRect) {
      return null;
    }
    return {
      x: 0,
      y: activeIndex < overIndex ? overIndexRect.top + overIndexRect.height - (activeNodeRect.top + activeNodeRect.height) : overIndexRect.top - activeNodeRect.top,
      ...defaultScale$1
    };
  }
  const itemGap = getItemGap$1(rects, index, activeIndex);
  if (index > activeIndex && index <= overIndex) {
    return {
      x: 0,
      y: -activeNodeRect.height - itemGap,
      ...defaultScale$1
    };
  }
  if (index < activeIndex && index >= overIndex) {
    return {
      x: 0,
      y: activeNodeRect.height + itemGap,
      ...defaultScale$1
    };
  }
  return {
    x: 0,
    y: 0,
    ...defaultScale$1
  };
};
function getItemGap$1(clientRects, index, activeIndex) {
  const currentRect = clientRects[index];
  const previousRect = clientRects[index - 1];
  const nextRect = clientRects[index + 1];
  if (!currentRect) {
    return 0;
  }
  if (activeIndex < index) {
    return previousRect ? currentRect.top - (previousRect.top + previousRect.height) : nextRect ? nextRect.top - (currentRect.top + currentRect.height) : 0;
  }
  return nextRect ? nextRect.top - (currentRect.top + currentRect.height) : previousRect ? currentRect.top - (previousRect.top + previousRect.height) : 0;
}
const ID_PREFIX = "Sortable";
const Context = /* @__PURE__ */ React.createContext({
  activeIndex: -1,
  containerId: ID_PREFIX,
  disableTransforms: false,
  items: [],
  overIndex: -1,
  useDragOverlay: false,
  sortedRects: [],
  strategy: rectSortingStrategy,
  disabled: {
    draggable: false,
    droppable: false
  }
});
function SortableContext(_ref) {
  let {
    children,
    id,
    items: userDefinedItems,
    strategy = rectSortingStrategy,
    disabled: disabledProp = false
  } = _ref;
  const {
    active,
    dragOverlay,
    droppableRects,
    over,
    measureDroppableContainers
  } = useDndContext();
  const containerId = useUniqueId(ID_PREFIX, id);
  const useDragOverlay = Boolean(dragOverlay.rect !== null);
  const items = reactExports.useMemo(() => userDefinedItems.map((item) => typeof item === "object" && "id" in item ? item.id : item), [userDefinedItems]);
  const isDragging = active != null;
  const activeIndex = active ? items.indexOf(active.id) : -1;
  const overIndex = over ? items.indexOf(over.id) : -1;
  const previousItemsRef = reactExports.useRef(items);
  const itemsHaveChanged = !itemsEqual(items, previousItemsRef.current);
  const disableTransforms = overIndex !== -1 && activeIndex === -1 || itemsHaveChanged;
  const disabled = normalizeDisabled(disabledProp);
  useIsomorphicLayoutEffect(() => {
    if (itemsHaveChanged && isDragging) {
      measureDroppableContainers(items);
    }
  }, [itemsHaveChanged, items, isDragging, measureDroppableContainers]);
  reactExports.useEffect(() => {
    previousItemsRef.current = items;
  }, [items]);
  const contextValue = reactExports.useMemo(
    () => ({
      activeIndex,
      containerId,
      disabled,
      disableTransforms,
      items,
      overIndex,
      useDragOverlay,
      sortedRects: getSortedRects(items, droppableRects),
      strategy
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [activeIndex, containerId, disabled.draggable, disabled.droppable, disableTransforms, items, overIndex, droppableRects, useDragOverlay, strategy]
  );
  return React.createElement(Context.Provider, {
    value: contextValue
  }, children);
}
const defaultNewIndexGetter = (_ref) => {
  let {
    id,
    items,
    activeIndex,
    overIndex
  } = _ref;
  return arrayMove(items, activeIndex, overIndex).indexOf(id);
};
const defaultAnimateLayoutChanges = (_ref2) => {
  let {
    containerId,
    isSorting,
    wasDragging,
    index,
    items,
    newIndex,
    previousItems,
    previousContainerId,
    transition
  } = _ref2;
  if (!transition || !wasDragging) {
    return false;
  }
  if (previousItems !== items && index === newIndex) {
    return false;
  }
  if (isSorting) {
    return true;
  }
  return newIndex !== index && containerId === previousContainerId;
};
const defaultTransition = {
  duration: 200,
  easing: "ease"
};
const transitionProperty = "transform";
const disabledTransition = /* @__PURE__ */ CSS.Transition.toString({
  property: transitionProperty,
  duration: 0,
  easing: "linear"
});
const defaultAttributes = {
  roleDescription: "sortable"
};
function useDerivedTransform(_ref) {
  let {
    disabled,
    index,
    node,
    rect
  } = _ref;
  const [derivedTransform, setDerivedtransform] = reactExports.useState(null);
  const previousIndex = reactExports.useRef(index);
  useIsomorphicLayoutEffect(() => {
    if (!disabled && index !== previousIndex.current && node.current) {
      const initial = rect.current;
      if (initial) {
        const current = getClientRect(node.current, {
          ignoreTransform: true
        });
        const delta = {
          x: initial.left - current.left,
          y: initial.top - current.top,
          scaleX: initial.width / current.width,
          scaleY: initial.height / current.height
        };
        if (delta.x || delta.y) {
          setDerivedtransform(delta);
        }
      }
    }
    if (index !== previousIndex.current) {
      previousIndex.current = index;
    }
  }, [disabled, index, node, rect]);
  reactExports.useEffect(() => {
    if (derivedTransform) {
      setDerivedtransform(null);
    }
  }, [derivedTransform]);
  return derivedTransform;
}
function useSortable(_ref) {
  let {
    animateLayoutChanges = defaultAnimateLayoutChanges,
    attributes: userDefinedAttributes,
    disabled: localDisabled,
    data: customData,
    getNewIndex = defaultNewIndexGetter,
    id,
    strategy: localStrategy,
    resizeObserverConfig,
    transition = defaultTransition
  } = _ref;
  const {
    items,
    containerId,
    activeIndex,
    disabled: globalDisabled,
    disableTransforms,
    sortedRects,
    overIndex,
    useDragOverlay,
    strategy: globalStrategy
  } = reactExports.useContext(Context);
  const disabled = normalizeLocalDisabled(localDisabled, globalDisabled);
  const index = items.indexOf(id);
  const data = reactExports.useMemo(() => ({
    sortable: {
      containerId,
      index,
      items
    },
    ...customData
  }), [containerId, customData, index, items]);
  const itemsAfterCurrentSortable = reactExports.useMemo(() => items.slice(items.indexOf(id)), [items, id]);
  const {
    rect,
    node,
    isOver,
    setNodeRef: setDroppableNodeRef
  } = useDroppable({
    id,
    data,
    disabled: disabled.droppable,
    resizeObserverConfig: {
      updateMeasurementsFor: itemsAfterCurrentSortable,
      ...resizeObserverConfig
    }
  });
  const {
    active,
    activatorEvent,
    activeNodeRect,
    attributes,
    setNodeRef: setDraggableNodeRef,
    listeners,
    isDragging,
    over,
    setActivatorNodeRef,
    transform
  } = useDraggable({
    id,
    data,
    attributes: {
      ...defaultAttributes,
      ...userDefinedAttributes
    },
    disabled: disabled.draggable
  });
  const setNodeRef = useCombinedRefs(setDroppableNodeRef, setDraggableNodeRef);
  const isSorting = Boolean(active);
  const displaceItem = isSorting && !disableTransforms && isValidIndex(activeIndex) && isValidIndex(overIndex);
  const shouldDisplaceDragSource = !useDragOverlay && isDragging;
  const dragSourceDisplacement = shouldDisplaceDragSource && displaceItem ? transform : null;
  const strategy = localStrategy != null ? localStrategy : globalStrategy;
  const finalTransform = displaceItem ? dragSourceDisplacement != null ? dragSourceDisplacement : strategy({
    rects: sortedRects,
    activeNodeRect,
    activeIndex,
    overIndex,
    index
  }) : null;
  const newIndex = isValidIndex(activeIndex) && isValidIndex(overIndex) ? getNewIndex({
    id,
    items,
    activeIndex,
    overIndex
  }) : index;
  const activeId = active == null ? void 0 : active.id;
  const previous = reactExports.useRef({
    activeId,
    items,
    newIndex,
    containerId
  });
  const itemsHaveChanged = items !== previous.current.items;
  const shouldAnimateLayoutChanges = animateLayoutChanges({
    active,
    containerId,
    isDragging,
    isSorting,
    id,
    index,
    items,
    newIndex: previous.current.newIndex,
    previousItems: previous.current.items,
    previousContainerId: previous.current.containerId,
    transition,
    wasDragging: previous.current.activeId != null
  });
  const derivedTransform = useDerivedTransform({
    disabled: !shouldAnimateLayoutChanges,
    index,
    node,
    rect
  });
  reactExports.useEffect(() => {
    if (isSorting && previous.current.newIndex !== newIndex) {
      previous.current.newIndex = newIndex;
    }
    if (containerId !== previous.current.containerId) {
      previous.current.containerId = containerId;
    }
    if (items !== previous.current.items) {
      previous.current.items = items;
    }
  }, [isSorting, newIndex, containerId, items]);
  reactExports.useEffect(() => {
    if (activeId === previous.current.activeId) {
      return;
    }
    if (activeId != null && previous.current.activeId == null) {
      previous.current.activeId = activeId;
      return;
    }
    const timeoutId = setTimeout(() => {
      previous.current.activeId = activeId;
    }, 50);
    return () => clearTimeout(timeoutId);
  }, [activeId]);
  return {
    active,
    activeIndex,
    attributes,
    data,
    rect,
    index,
    newIndex,
    items,
    isOver,
    isSorting,
    isDragging,
    listeners,
    node,
    overIndex,
    over,
    setNodeRef,
    setActivatorNodeRef,
    setDroppableNodeRef,
    setDraggableNodeRef,
    transform: derivedTransform != null ? derivedTransform : finalTransform,
    transition: getTransition()
  };
  function getTransition() {
    if (
      // Temporarily disable transitions for a single frame to set up derived transforms
      derivedTransform || // Or to prevent items jumping to back to their "new" position when items change
      itemsHaveChanged && previous.current.newIndex === index
    ) {
      return disabledTransition;
    }
    if (shouldDisplaceDragSource && !isKeyboardEvent(activatorEvent) || !transition) {
      return void 0;
    }
    if (isSorting || shouldAnimateLayoutChanges) {
      return CSS.Transition.toString({
        ...transition,
        property: transitionProperty
      });
    }
    return void 0;
  }
}
function normalizeLocalDisabled(localDisabled, globalDisabled) {
  var _localDisabled$dragga, _localDisabled$droppa;
  if (typeof localDisabled === "boolean") {
    return {
      draggable: localDisabled,
      // Backwards compatibility
      droppable: false
    };
  }
  return {
    draggable: (_localDisabled$dragga = localDisabled == null ? void 0 : localDisabled.draggable) != null ? _localDisabled$dragga : globalDisabled.draggable,
    droppable: (_localDisabled$droppa = localDisabled == null ? void 0 : localDisabled.droppable) != null ? _localDisabled$droppa : globalDisabled.droppable
  };
}
function hasSortableData(entry) {
  if (!entry) {
    return false;
  }
  const data = entry.data.current;
  if (data && "sortable" in data && typeof data.sortable === "object" && "containerId" in data.sortable && "items" in data.sortable && "index" in data.sortable) {
    return true;
  }
  return false;
}
const directions = [KeyboardCode.Down, KeyboardCode.Right, KeyboardCode.Up, KeyboardCode.Left];
const sortableKeyboardCoordinates = (event, _ref) => {
  let {
    context: {
      active,
      collisionRect,
      droppableRects,
      droppableContainers,
      over,
      scrollableAncestors
    }
  } = _ref;
  if (directions.includes(event.code)) {
    event.preventDefault();
    if (!active || !collisionRect) {
      return;
    }
    const filteredContainers = [];
    droppableContainers.getEnabled().forEach((entry) => {
      if (!entry || entry != null && entry.disabled) {
        return;
      }
      const rect = droppableRects.get(entry.id);
      if (!rect) {
        return;
      }
      switch (event.code) {
        case KeyboardCode.Down:
          if (collisionRect.top < rect.top) {
            filteredContainers.push(entry);
          }
          break;
        case KeyboardCode.Up:
          if (collisionRect.top > rect.top) {
            filteredContainers.push(entry);
          }
          break;
        case KeyboardCode.Left:
          if (collisionRect.left > rect.left) {
            filteredContainers.push(entry);
          }
          break;
        case KeyboardCode.Right:
          if (collisionRect.left < rect.left) {
            filteredContainers.push(entry);
          }
          break;
      }
    });
    const collisions = closestCorners({
      collisionRect,
      droppableRects,
      droppableContainers: filteredContainers
    });
    let closestId = getFirstCollision(collisions, "id");
    if (closestId === (over == null ? void 0 : over.id) && collisions.length > 1) {
      closestId = collisions[1].id;
    }
    if (closestId != null) {
      const activeDroppable = droppableContainers.get(active.id);
      const newDroppable = droppableContainers.get(closestId);
      const newRect = newDroppable ? droppableRects.get(newDroppable.id) : null;
      const newNode = newDroppable == null ? void 0 : newDroppable.node.current;
      if (newNode && newRect && activeDroppable && newDroppable) {
        const newScrollAncestors = getScrollableAncestors(newNode);
        const hasDifferentScrollAncestors = newScrollAncestors.some((element, index) => scrollableAncestors[index] !== element);
        const hasSameContainer = isSameContainer(activeDroppable, newDroppable);
        const isAfterActive = isAfter(activeDroppable, newDroppable);
        const offset = hasDifferentScrollAncestors || !hasSameContainer ? {
          x: 0,
          y: 0
        } : {
          x: isAfterActive ? collisionRect.width - newRect.width : 0,
          y: isAfterActive ? collisionRect.height - newRect.height : 0
        };
        const rectCoordinates = {
          x: newRect.left,
          y: newRect.top
        };
        const newCoordinates = offset.x && offset.y ? rectCoordinates : subtract(rectCoordinates, offset);
        return newCoordinates;
      }
    }
  }
  return void 0;
};
function isSameContainer(a, b) {
  if (!hasSortableData(a) || !hasSortableData(b)) {
    return false;
  }
  return a.data.current.sortable.containerId === b.data.current.sortable.containerId;
}
function isAfter(a, b) {
  if (!hasSortableData(a) || !hasSortableData(b)) {
    return false;
  }
  if (!isSameContainer(a, b)) {
    return false;
  }
  return a.data.current.sortable.index < b.data.current.sortable.index;
}
const MODIFIER_PATTERN = /^(tag|group|url|title):(.+)$/i;
function normalize(value) {
  return value.trim().toLowerCase();
}
function includesValue(value, query) {
  return Boolean(value && normalize(value).includes(query));
}
function parseSearchQuery(query) {
  const tokens = query.trim().split(/\s+/).map((part) => {
    const modifier = part.match(MODIFIER_PATTERN);
    if (modifier) {
      const value2 = normalize(modifier[2]);
      return value2 ? { field: modifier[1].toLowerCase(), value: value2 } : null;
    }
    const value = normalize(part);
    return value ? { value } : null;
  }).filter((token) => token !== null);
  return { raw: query, tokens };
}
function searchHasQuery(parsed) {
  return parsed.tokens.length > 0;
}
function linkMatchesToken(group, link, token) {
  var _a, _b;
  switch (token.field) {
    case "group":
      return includesValue(group.title, token.value);
    case "tag":
      return Boolean((_a = link.tags) == null ? void 0 : _a.some((tag) => includesValue(tag, token.value)));
    case "title":
      return includesValue(link.title, token.value);
    case "url":
      return includesValue(link.url, token.value);
    default:
      return includesValue(group.title, token.value) || includesValue(link.title, token.value) || includesValue(link.url, token.value) || includesValue(link.description, token.value) || Boolean((_b = link.tags) == null ? void 0 : _b.some((tag) => includesValue(tag, token.value)));
  }
}
function linkMatchesSearch(group, link, parsed) {
  if (!searchHasQuery(parsed)) return true;
  return parsed.tokens.every((token) => linkMatchesToken(group, link, token));
}
function filterGroupsForSearch(groups, parsed) {
  if (!searchHasQuery(parsed)) {
    return groups;
  }
  return groups.map((group) => {
    const links = group.links.filter((link) => linkMatchesSearch(group, link, parsed));
    if (!links.length) return null;
    return { ...group, collapsed: false, links };
  }).filter((group) => group !== null);
}
function flattenSearchResults(groups) {
  return groups.flatMap(
    (group) => group.links.slice().sort((a, b) => a.order - b.order).map((link) => ({ groupId: group.id, link }))
  );
}
function searchResultId(groupId, linkId) {
  return `${groupId}::${linkId}`;
}
function searchHighlightTerms(parsed) {
  return Array.from(new Set(parsed.tokens.map((token) => token.value).filter((value) => value.length >= 2)));
}
function findNextMatch(text, terms, start) {
  const lowerText = text.toLowerCase();
  let next = null;
  for (const term of terms) {
    const normalized = term.trim().toLowerCase();
    if (!normalized) continue;
    const index = lowerText.indexOf(normalized, start);
    if (index < 0) continue;
    if (!next || index < next.index || index === next.index && normalized.length > next.length) {
      next = { index, length: normalized.length };
    }
  }
  return next;
}
function HighlightedText({ text, terms }) {
  if (!terms.length || !text) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: text });
  }
  const parts = [];
  let cursor = 0;
  while (cursor < text.length) {
    const match = findNextMatch(text, terms, cursor);
    if (!match) {
      parts.push(text.slice(cursor));
      break;
    }
    if (match.index > cursor) {
      parts.push(text.slice(cursor, match.index));
    }
    parts.push(
      /* @__PURE__ */ jsxRuntimeExports.jsx("mark", { className: "search-highlight", children: text.slice(match.index, match.index + match.length) }, `${match.index}-${match.length}`)
    );
    cursor = match.index + match.length;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: parts });
}
function BookmarkLinkItem({
  link,
  groupId,
  settings,
  editMode,
  dragging = false,
  highlightTerms = [],
  selected = false,
  dragAttributes,
  dragListeners,
  onEdit,
  onDelete
}) {
  var _a;
  const language = settings.language;
  const stopDragActivation = (event) => {
    event.stopPropagation();
  };
  const content = /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "bookmark-title", children: /* @__PURE__ */ jsxRuntimeExports.jsx(HighlightedText, { terms: highlightTerms, text: link.title }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "bookmark-url", children: /* @__PURE__ */ jsxRuntimeExports.jsx(HighlightedText, { terms: highlightTerms, text: link.url }) }),
    settings.showDescriptions && link.description && !settings.compactMode ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "bookmark-description", children: /* @__PURE__ */ jsxRuntimeExports.jsx(HighlightedText, { terms: highlightTerms, text: link.description }) }) : null,
    ((_a = link.tags) == null ? void 0 : _a.length) && !settings.compactMode ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "bookmark-tags", children: link.tags.map((tag) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "bookmark-tag", children: /* @__PURE__ */ jsxRuntimeExports.jsx(HighlightedText, { terms: highlightTerms, text: tag }) }, tag)) }) : null
  ] });
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: `bookmark-row group ${editMode ? "bookmark-row-editing" : ""} ${dragging ? "dragging" : ""} ${selected ? "bookmark-row-selected" : ""}`,
      "data-search-result-id": searchResultId(groupId, link.id),
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bookmark-row-inner", children: [
        editMode ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "bookmark-drag-zone",
            ...dragAttributes,
            ...dragListeners,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  "aria-label": t(language, "dragLink", { title: link.title }),
                  className: "bookmark-handle",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(GripVertical, { size: 13 })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bookmark-link bookmark-link-editing", children: content })
            ]
          }
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "a",
          {
            "aria-current": selected ? "true" : void 0,
            className: "bookmark-link",
            href: link.url,
            rel: settings.openLinksInNewTab ? "noopener noreferrer" : void 0,
            target: settings.openLinksInNewTab ? "_blank" : void 0,
            children: content
          }
        ),
        editMode ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bookmark-actions", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              "aria-label": t(language, "editLinkAria", { title: link.title }),
              className: "bookmark-action",
              type: "button",
              onPointerDown: stopDragActivation,
              onClick: () => onEdit(groupId, link),
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { size: 13 })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              "aria-label": t(language, "deleteGroupAria", { title: link.title }),
              className: "bookmark-action danger-action",
              type: "button",
              onPointerDown: stopDragActivation,
              onClick: () => onDelete(groupId, link),
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { size: 13 })
            }
          )
        ] }) : null
      ] })
    }
  );
}
function SortableLinkItem({
  link,
  groupId,
  settings,
  disabled,
  editMode,
  highlightTerms,
  isDropPending,
  selected,
  onEdit,
  onDelete
}) {
  const sortable = useSortable({
    id: `link:${link.id}`,
    disabled,
    data: { type: "link", linkId: link.id, groupId },
    transition: {
      duration: 145,
      easing: "cubic-bezier(0.2, 0, 0, 1)"
    }
  });
  const transform = sortable.transform ? CSS.Translate.toString(sortable.transform) : void 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: "sortable-link-shell",
      ref: sortable.setNodeRef,
      style: { transform, transition: sortable.transition },
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        BookmarkLinkItem,
        {
          dragAttributes: sortable.attributes,
          dragListeners: sortable.listeners,
          dragging: sortable.isDragging || isDropPending,
          editMode,
          groupId,
          highlightTerms,
          link,
          selected,
          settings,
          onDelete,
          onEdit
        }
      )
    }
  );
}
function BookmarkGroupCard({
  group,
  settings,
  searchMode,
  editMode,
  activeLinkId,
  highlightTerms = [],
  selectedSearchResultId,
  sortable,
  onAddLink,
  onEditGroup,
  onDeleteGroup,
  onToggle,
  onEditLink,
  onDeleteLink
}) {
  const droppable = useDroppable({
    id: `group-drop:${group.id}`,
    data: { type: "group-drop", groupId: group.id },
    disabled: searchMode || !editMode
  });
  const collapsed = group.collapsed && !searchMode;
  const sortedLinks = group.links.slice().sort((a, b) => a.order - b.order);
  const language = settings.language;
  const stopDragActivation = (event) => {
    event.stopPropagation();
  };
  const content = /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "section",
    {
      className: `bookmark-group ${editMode ? "bookmark-group-editing" : ""} ${(sortable == null ? void 0 : sortable.isDragging) || (sortable == null ? void 0 : sortable.isDropPending) ? "group-placeholder" : ""}`,
      children: [
        editMode && (sortable == null ? void 0 : sortable.listeners) ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "group-drag-rail",
            ...sortable.listeners
          }
        ) : null,
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "group-name-row",
            ...editMode ? (sortable == null ? void 0 : sortable.attributes) ?? {} : {},
            ...editMode ? (sortable == null ? void 0 : sortable.listeners) ?? {} : {},
            children: [
              editMode ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  "aria-label": t(language, "dragGroup", { title: group.title }),
                  className: "group-handle",
                  type: "button",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(GripVertical, { size: 13 })
                }
              ) : null,
              editMode ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", className: "group-fold group-fold-disabled", children: collapsed ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { size: 13 }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { size: 13 }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  "aria-label": collapsed ? t(language, "expandGroup", { title: group.title }) : t(language, "collapseGroup", { title: group.title }),
                  className: "group-fold",
                  type: "button",
                  onPointerDown: stopDragActivation,
                  onClick: () => onToggle(group.id),
                  children: collapsed ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { size: 13 }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { size: 13 })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "group-name", title: t(language, "linksCount", { count: group.links.length }), children: /* @__PURE__ */ jsxRuntimeExports.jsx(HighlightedText, { terms: highlightTerms, text: group.title }) }),
              editMode ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    "aria-label": t(language, "addLinkTo", { title: group.title }),
                    className: "group-action",
                    type: "button",
                    onPointerDown: stopDragActivation,
                    onClick: () => onAddLink(group.id),
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { size: 13 })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    "aria-label": t(language, "renameGroupAria", { title: group.title }),
                    className: "group-action",
                    type: "button",
                    onPointerDown: stopDragActivation,
                    onClick: () => onEditGroup(group),
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { size: 13 })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    "aria-label": t(language, "deleteGroupAria", { title: group.title }),
                    className: "group-action danger-action",
                    type: "button",
                    onPointerDown: stopDragActivation,
                    onClick: () => onDeleteGroup(group),
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { size: 13 })
                  }
                )
              ] }) : null
            ]
          }
        ),
        !collapsed ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bookmark-list", ref: droppable.setNodeRef, children: sortedLinks.length ? searchMode ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: sortedLinks.map((link) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          BookmarkLinkItem,
          {
            groupId: group.id,
            editMode,
            link,
            highlightTerms,
            selected: selectedSearchResultId === searchResultId(group.id, link.id),
            settings,
            onDelete: onDeleteLink,
            onEdit: onEditLink
          },
          link.id
        )) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(SortableContext, { items: sortedLinks.map((link) => `link:${link.id}`), strategy: verticalListSortingStrategy, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: sortedLinks.map((link) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          SortableLinkItem,
          {
            isDropPending: activeLinkId === link.id,
            disabled: searchMode || !editMode,
            editMode,
            groupId: group.id,
            highlightTerms,
            link,
            selected: selectedSearchResultId === searchResultId(group.id, link.id),
            settings,
            onDelete: onDeleteLink,
            onEdit: onEditLink
          },
          link.id
        )) }) }) : editMode ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: "empty-group-button",
            type: "button",
            onClick: () => onAddLink(group.id),
            children: t(language, "emptyGroupButton")
          }
        ) : null }) : null
      ]
    }
  );
  if (!sortable) {
    return content;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: "sortable-group-shell",
      ref: sortable.setNodeRef,
      style: { transform: sortable.transform ?? void 0, transition: sortable.transition },
      children: content
    }
  );
}
function SortableGroupCard(props) {
  const sortable = useSortable({
    id: `group:${props.group.id}`,
    disabled: props.searchMode || !props.editMode,
    data: { type: "group", groupId: props.group.id },
    transition: {
      duration: 165,
      easing: "cubic-bezier(0.2, 0, 0, 1)"
    }
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    BookmarkGroupCard,
    {
      ...props,
      sortable: {
        attributes: sortable.attributes,
        isDragging: sortable.isDragging,
        isDropPending: props.isDropPending,
        listeners: sortable.listeners,
        setNodeRef: sortable.setNodeRef,
        transform: sortable.transform ? CSS.Translate.toString(sortable.transform) ?? null : null,
        transition: sortable.transition
      }
    }
  );
}
function stripPrefix(value, prefix) {
  return value.startsWith(prefix) ? value.slice(prefix.length) : void 0;
}
function findGroupForLink(groups, linkId) {
  return groups.find((group) => group.links.some((link) => link.id === linkId));
}
function findLink(groups, linkId) {
  return groups.flatMap((group) => group.links).find((link) => link.id === linkId);
}
function isActiveAfterOver(event) {
  var _a;
  const activeRect = event.active.rect.current.translated ?? event.active.rect.current.initial;
  const overRect = (_a = event.over) == null ? void 0 : _a.rect;
  if (!activeRect || !overRect) return false;
  return activeRect.top + activeRect.height / 2 > overRect.top + overRect.height / 2;
}
function beforeLinkIdForDrop(activeLinkId, targetGroup, overLinkId, insertAfter) {
  var _a;
  const targetLinks = targetGroup.links.slice().sort((a, b) => a.order - b.order).filter((link) => link.id !== activeLinkId);
  const overIndex = targetLinks.findIndex((link) => link.id === overLinkId);
  if (overIndex < 0) {
    return void 0;
  }
  return (_a = targetLinks[insertAfter ? overIndex + 1 : overIndex]) == null ? void 0 : _a.id;
}
const responsiveCollisionDetection = (args) => {
  const activeId = String(args.active.id);
  if (stripPrefix(activeId, "group:")) {
    const groupContainers = args.droppableContainers.filter((container) => {
      const containerId = String(container.id);
      return containerId.startsWith("group:");
    });
    const intersections = rectIntersection({
      ...args,
      droppableContainers: groupContainers
    });
    if (intersections.length) {
      return intersections;
    }
    const pointerCollisions = pointerWithin({
      ...args,
      droppableContainers: groupContainers
    });
    return pointerCollisions.length ? pointerCollisions : closestCenter({
      ...args,
      droppableContainers: groupContainers
    });
  }
  if (stripPrefix(activeId, "link:")) {
    const linkContainers = args.droppableContainers.filter((container) => {
      const containerId = String(container.id);
      return containerId.startsWith("link:");
    });
    const groupDropContainers = args.droppableContainers.filter(
      (container) => String(container.id).startsWith("group-drop:")
    );
    const containers = [...linkContainers, ...groupDropContainers];
    for (const droppableContainers of [linkContainers, containers]) {
      const intersections = rectIntersection({ ...args, droppableContainers });
      if (intersections.length) return intersections;
      const pointerCollisions = pointerWithin({ ...args, droppableContainers });
      if (pointerCollisions.length) return pointerCollisions;
    }
    return closestCenter({
      ...args,
      droppableContainers: containers
    });
  }
  return closestCenter(args);
};
function gridStyle(columns) {
  if (columns === "auto") {
    return { gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 23rem), 27rem))" };
  }
  return { gridTemplateColumns: `repeat(${columns}, minmax(0, 27rem))` };
}
function GroupGrid({
  data,
  editMode,
  groups,
  highlightTerms = [],
  searchMode,
  selectedSearchResultId,
  onAddLink,
  onEditGroup,
  onDeleteGroup,
  onToggle,
  onEditLink,
  onDeleteLink,
  onReorderGroups,
  onMoveLink
}) {
  const [activeGroupId, setActiveGroupId] = reactExports.useState(null);
  const [activeLinkId, setActiveLinkId] = reactExports.useState(null);
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 3 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );
  const sortedGroups = groups.slice().sort((a, b) => a.order - b.order);
  const groupIds = sortedGroups.map((group) => group.id);
  const activeGroup = activeGroupId ? sortedGroups.find((group) => group.id === activeGroupId) : void 0;
  const activeLink = activeLinkId ? findLink(data.groups, activeLinkId) : void 0;
  function handleDragStart(event) {
    const activeId = String(event.active.id);
    const groupId = stripPrefix(activeId, "group:");
    const linkId = stripPrefix(activeId, "link:");
    setActiveGroupId(groupId ?? null);
    setActiveLinkId(linkId ?? null);
  }
  function clearGroupDragState() {
    setActiveGroupId(null);
    setActiveLinkId(null);
  }
  async function handleDragEnd(event) {
    const activeId = String(event.active.id);
    const overId = event.over ? String(event.over.id) : "";
    const activeGroupId2 = stripPrefix(activeId, "group:");
    const overGroupId = stripPrefix(overId, "group:");
    if (activeGroupId2) {
      try {
        const activeIndex = groupIds.indexOf(activeGroupId2);
        const overIndex = overGroupId ? groupIds.indexOf(overGroupId) : -1;
        if (activeIndex >= 0 && overIndex >= 0 && activeIndex !== overIndex) {
          const finalOrder = arrayMove(groupIds, activeIndex, overIndex);
          await onReorderGroups(finalOrder);
        }
      } finally {
        clearGroupDragState();
      }
      return;
    }
    const activeLinkId2 = stripPrefix(activeId, "link:");
    if (!activeLinkId2) {
      clearGroupDragState();
      return;
    }
    try {
      if (!overId) return;
      const overLinkId = stripPrefix(overId, "link:");
      if (overLinkId) {
        if (overLinkId === activeLinkId2) return;
        const targetGroup = findGroupForLink(data.groups, overLinkId);
        if (targetGroup) {
          await onMoveLink(
            activeLinkId2,
            targetGroup.id,
            beforeLinkIdForDrop(activeLinkId2, targetGroup, overLinkId, isActiveAfterOver(event))
          );
        }
        return;
      }
      const dropGroupId = stripPrefix(overId, "group-drop:");
      if (dropGroupId) {
        await onMoveLink(activeLinkId2, dropGroupId);
      }
    } finally {
      clearGroupDragState();
    }
  }
  if (searchMode) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: `aura-group-grid ${data.settings.columns === 1 ? "aura-group-grid-left" : ""}`,
        style: gridStyle(data.settings.columns),
        children: sortedGroups.map((group) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          BookmarkGroupCard,
          {
            group,
            highlightTerms,
            selectedSearchResultId,
            searchMode: true,
            editMode: false,
            settings: data.settings,
            onAddLink: (groupId) => onAddLink(groupId),
            onDeleteGroup,
            onDeleteLink,
            onEditGroup,
            onEditLink,
            onToggle
          },
          group.id
        ))
      }
    );
  }
  if (!editMode) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: `aura-group-grid ${data.settings.columns === 1 ? "aura-group-grid-left" : ""}`,
        style: gridStyle(data.settings.columns),
        children: sortedGroups.map((group) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          BookmarkGroupCard,
          {
            group,
            highlightTerms,
            selectedSearchResultId,
            searchMode: false,
            editMode: false,
            settings: data.settings,
            onAddLink: (groupId) => onAddLink(groupId),
            onDeleteGroup,
            onDeleteLink,
            onEditGroup,
            onEditLink,
            onToggle
          },
          group.id
        ))
      }
    );
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    DndContext,
    {
      collisionDetection: responsiveCollisionDetection,
      measuring: { droppable: { strategy: MeasuringStrategy.Always } },
      sensors,
      onDragCancel: clearGroupDragState,
      onDragEnd: handleDragEnd,
      onDragStart: handleDragStart,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SortableContext, { items: sortedGroups.map((group) => `group:${group.id}`), strategy: rectSortingStrategy, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: `aura-group-grid ${data.settings.columns === 1 ? "aura-group-grid-left" : ""}`,
            style: gridStyle(data.settings.columns),
            children: sortedGroups.map((group) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              SortableGroupCard,
              {
                group,
                highlightTerms,
                isDropPending: activeGroupId === group.id,
                selectedSearchResultId,
                editMode,
                searchMode: false,
                settings: data.settings,
                onAddLink: (groupId) => onAddLink(groupId),
                onDeleteGroup,
                onDeleteLink,
                onEditGroup,
                onEditLink,
                activeLinkId,
                onToggle
              },
              group.id
            ))
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(DragOverlay, { adjustScale: false, dropAnimation: null, children: activeGroup ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "group-drag-overlay", style: gridStyle(1), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bookmark-group", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "group-name-row", children: /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "group-name", children: activeGroup.title }) }),
          !activeGroup.collapsed ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bookmark-list", children: activeGroup.links.slice().sort((a, b) => a.order - b.order).map((link) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bookmark-row", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bookmark-row-inner", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "bookmark-link", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "bookmark-title", children: link.title }) }) }) }, link.id)) }) : null
        ] }) }) : activeLink ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "link-drag-overlay", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bookmark-row", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bookmark-row-inner", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "bookmark-link", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "bookmark-title", children: activeLink.title }) }) }) }) }) : null })
      ]
    }
  );
}
function exportColumnCount(data) {
  const columns = data.settings.columns === "auto" ? 3 : data.settings.columns;
  return Math.min(Math.max(columns, 1), 7);
}
function safeName(value, fallback) {
  const trimmed = value.trim();
  return trimmed || fallback;
}
function uniqueGroupName(group, usedNames) {
  const baseName = safeName(group.title, "Untitled group");
  const key2 = baseName.toLocaleLowerCase();
  const nextCount = (usedNames.get(key2) ?? 0) + 1;
  usedNames.set(key2, nextCount);
  return nextCount === 1 ? baseName : `${baseName} (${nextCount})`;
}
function toAFineStartBookmark(link) {
  return {
    name: safeName(link.title, link.url),
    url: link.url.trim()
  };
}
function createAFineStartExportCode(data) {
  const columns = Array.from({ length: exportColumnCount(data) }, () => []);
  const usedGroupNames = /* @__PURE__ */ new Map();
  data.groups.slice().sort((a, b) => a.order - b.order).forEach((group, groupIndex) => {
    const bookmarks = group.links.slice().sort((a, b) => a.order - b.order).filter((link) => link.url.trim()).map(toAFineStartBookmark);
    columns[groupIndex % columns.length].push({
      name: uniqueGroupName(group, usedGroupNames),
      bookmarks
    });
  });
  return JSON.stringify(columns);
}
function exportAFineStartCode(data) {
  downloadTextFile(
    `aura-start-for-a-fine-start-${dateForFile()}.txt`,
    createAFineStartExportCode(data),
    "text/plain;charset=utf-8"
  );
}
function escapeCsvCell(value) {
  if (/[",\n\r]/.test(value)) {
    return `"${value.replaceAll('"', '""')}"`;
  }
  return value;
}
function createCsvBookmarks(data) {
  const rows = [["group", "title", "url", "description", "tags", "createdAt", "updatedAt"]];
  data.groups.slice().sort((a, b) => a.order - b.order).forEach((group) => {
    group.links.slice().sort((a, b) => a.order - b.order).forEach((link) => {
      var _a;
      rows.push([
        group.title,
        link.title,
        link.url,
        link.description ?? "",
        ((_a = link.tags) == null ? void 0 : _a.join(";")) ?? "",
        link.createdAt,
        link.updatedAt
      ]);
    });
  });
  return `${rows.map((row) => row.map(escapeCsvCell).join(",")).join("\n")}
`;
}
function exportCsv(data) {
  downloadTextFile(
    `aura-start-bookmarks-${dateForFile()}.csv`,
    createCsvBookmarks(data),
    "text/csv;charset=utf-8"
  );
}
function escapeHtml(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
function createHtmlBookmarks(data) {
  const lines = [
    "<!DOCTYPE NETSCAPE-Bookmark-file-1>",
    '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">',
    "<TITLE>Bookmarks</TITLE>",
    "<H1>Bookmarks</H1>",
    "<DL><p>"
  ];
  data.groups.slice().sort((a, b) => a.order - b.order).forEach((group) => {
    lines.push(`  <DT><H3>${escapeHtml(group.title)}</H3>`);
    lines.push("  <DL><p>");
    group.links.slice().sort((a, b) => a.order - b.order).forEach((link) => {
      const addDate = toUnixSeconds(link.createdAt);
      lines.push(
        `    <DT><A HREF="${escapeHtml(link.url)}" ADD_DATE="${addDate}">${escapeHtml(
          link.title
        )}</A>`
      );
    });
    lines.push("  </DL><p>");
  });
  lines.push("</DL><p>");
  return `${lines.join("\n")}
`;
}
function exportHtmlBookmarks(data) {
  downloadTextFile(
    `aura-start-bookmarks-${dateForFile()}.html`,
    createHtmlBookmarks(data),
    "text/html;charset=utf-8"
  );
}
function cleanMarkdownText(value) {
  return value.replaceAll("\r", " ").replaceAll("\n", " ").trim();
}
function escapeMarkdownLinkText(value) {
  return cleanMarkdownText(value).replaceAll("[", "\\[").replaceAll("]", "\\]");
}
function createMarkdownBookmarks(data) {
  const lines = ["# Aura Start Bookmarks", ""];
  data.groups.slice().sort((a, b) => a.order - b.order).forEach((group) => {
    lines.push(`## ${cleanMarkdownText(group.title)}`, "");
    group.links.slice().sort((a, b) => a.order - b.order).forEach((link) => {
      var _a;
      lines.push(`- [${escapeMarkdownLinkText(link.title)}](${link.url})`);
      if (link.description) {
        lines.push(`  ${cleanMarkdownText(link.description)}`);
      }
      if ((_a = link.tags) == null ? void 0 : _a.length) {
        lines.push(`  Tags: ${link.tags.map((tag) => `\`${cleanMarkdownText(tag)}\``).join(", ")}`);
      }
    });
    lines.push("");
  });
  return `${lines.join("\n").trim()}
`;
}
function exportMarkdown(data) {
  downloadTextFile(
    `aura-start-bookmarks-${dateForFile()}.md`,
    createMarkdownBookmarks(data),
    "text/markdown;charset=utf-8"
  );
}
function ExportMenu({ data, onError }) {
  const [open, setOpen] = reactExports.useState(false);
  const menuRef = reactExports.useRef(null);
  const language = data.settings.language;
  const fullBackupJsonLabel = t(language, "fullBackupJson");
  const htmlBookmarksLabel = t(language, "htmlBookmarks");
  const markdownLabel = t(language, "markdown");
  const csvLabel = t(language, "csv");
  const aFineStartLabel = t(language, "aFineStartExportCode");
  const exportOptions = [
    {
      label: htmlBookmarksLabel,
      description: t(language, "exportHtmlDescription"),
      action: exportHtmlBookmarks
    },
    {
      label: markdownLabel,
      description: t(language, "exportMarkdownDescription"),
      action: exportMarkdown
    },
    {
      label: csvLabel,
      description: t(language, "exportCsvDescription"),
      action: exportCsv
    },
    {
      label: aFineStartLabel,
      description: t(language, "exportAFineStartDescription"),
      action: exportAFineStartCode
    }
  ];
  reactExports.useEffect(() => {
    function handlePointerDown(event) {
      var _a;
      if (!((_a = menuRef.current) == null ? void 0 : _a.contains(event.target))) {
        setOpen(false);
      }
    }
    document.addEventListener("pointerdown", handlePointerDown);
    return () => document.removeEventListener("pointerdown", handlePointerDown);
  }, []);
  const runExport = (label, action) => {
    try {
      action(data);
      setOpen(false);
    } catch (error) {
      onError(error instanceof Error ? error.message : t(language, "exportFormatFailed", { label }));
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "export-menu relative", ref: menuRef, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary", type: "button", onClick: () => setOpen((value) => !value), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { size: 17 }),
      t(language, "export"),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { size: 16 })
    ] }),
    open ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "export-menu-popover surface absolute right-0 top-12 z-20 w-80 max-w-[calc(100vw-2rem)] rounded-xl p-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold", children: t(language, "exportBackupTitle") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted mt-1 text-xs leading-5", children: t(language, "exportTrustMessage") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          className: "btn btn-primary mb-2 h-auto w-full items-start justify-start px-3 py-2 text-left",
          type: "button",
          onClick: () => runExport(fullBackupJsonLabel, exportJsonBackup),
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "mt-0.5 shrink-0", size: 16 }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-sm font-semibold", children: t(language, "exportAllData") }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "block text-xs font-normal leading-5 opacity-90", children: [
                fullBackupJsonLabel,
                ": ",
                t(language, "exportJsonDescription")
              ] })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-1", children: exportOptions.map((option) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          className: "btn btn-ghost h-auto w-full flex-col items-start justify-start gap-1 px-3 py-2 text-left",
          type: "button",
          onClick: () => runExport(option.label, option.action),
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-semibold", children: option.label }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "muted text-xs leading-5", children: option.description })
          ]
        },
        option.label
      )) })
    ] }) : null
  ] });
}
const SearchBar = reactExports.forwardRef(function SearchBar2({ language, value, visible, hint, onChange }, ref) {
  if (!visible) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "search-control", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex w-full items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: t(language, "searchLinks") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { "aria-hidden": "true", className: "shrink-0 text-[var(--muted)]", size: 18 }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "relative min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            className: "field h-11 pr-10",
            placeholder: t(language, "searchPlaceholder"),
            ref,
            type: "search",
            value,
            onChange: (event) => onChange(event.target.value)
          }
        ),
        value ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            "aria-label": t(language, "clearSearch"),
            className: "btn btn-ghost absolute right-1 top-1/2 h-9 w-9 -translate-y-1/2 p-0",
            type: "button",
            onClick: () => onChange(""),
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 16 })
          }
        ) : null
      ] })
    ] }),
    hint ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "search-help-row", children: hint }) : null
  ] });
});
function Header({
  data,
  search,
  searchOpen,
  editMode,
  syncStatus,
  syncMessage,
  searchInputRef,
  onSearchChange,
  onOpenSearch,
  onToggleEditMode,
  onOpenCommandPalette,
  onAddGroup,
  onAddLink,
  onOpenSettings,
  onOpenImport,
  onExportError
}) {
  const linkCount = data.groups.reduce((total, group) => total + group.links.length, 0);
  const searchVisible = data.settings.showSearch && (searchOpen || search.length > 0);
  const language = data.settings.language;
  const sync = data.settings.sync;
  const showSyncMarker = sync.mode !== "off" && Boolean(sync.connected);
  const syncMarkerLabel = sync.accountName ?? sync.accountEmail ?? t(language, "googleDriveConnectedShort");
  const syncMarkerTitle = [
    syncStatus === "syncing" ? t(language, "googleDriveSyncing") : syncStatus === "error" ? t(language, "googleDriveSyncFailed") : syncStatus === "conflict" ? t(language, "googleDriveConflictDetected") : t(language, "googleDriveConnected"),
    sync.accountEmail ?? sync.accountName,
    sync.lastSyncedAt ? t(language, "googleDriveLastSynced", { time: formatDateTime(sync.lastSyncedAt) }) : void 0,
    syncMessage
  ].filter(Boolean).join("\n");
  const SyncIcon = syncStatus === "syncing" ? RefreshCw : syncStatus === "error" || syncStatus === "conflict" ? CircleAlert : Cloud;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "aura-header", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "aura-actions", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aura-brand", title: t(language, "groupsLinksCount", { groups: data.groups.length, links: linkCount }), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "aura-brand-line", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { className: "aura-logo", src: "/logo.png", alt: "", "aria-hidden": "true" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Aura Start" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "aura-inspired", children: t(language, "inspiredBy") })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "aura-action-list", children: [
        data.settings.showSearch ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            className: "btn btn-ghost",
            type: "button",
            "aria-pressed": searchVisible,
            title: t(language, "pressSlashToSearch"),
            onClick: onOpenSearch,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { size: 14 }),
              t(language, "search")
            ]
          }
        ) : null,
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            className: "btn btn-ghost",
            title: t(language, "commandPaletteShortcutNote"),
            type: "button",
            onClick: onOpenCommandPalette,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Command, { size: 17 }),
              t(language, "commandPalette")
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-ghost", type: "button", onClick: onAddLink, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { size: 17 }),
          t(language, "add")
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            "aria-label": editMode ? t(language, "disableEditMode") : t(language, "enableEditMode"),
            "aria-pressed": editMode,
            className: `btn btn-ghost ${editMode ? "btn-toggle-active" : ""}`,
            type: "button",
            onClick: onToggleEditMode,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { size: 17 }),
              t(language, "edit")
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-ghost", type: "button", onClick: onAddGroup, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(FolderPlus, { size: 17 }),
          t(language, "newGroup")
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ExportMenu, { data, onError: onExportError }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-ghost", type: "button", onClick: onOpenImport, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { size: 17 }),
          t(language, "import")
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "aura-settings-cluster", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-ghost", type: "button", onClick: onOpenSettings, "aria-label": t(language, "openSettings"), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { size: 17 }),
            t(language, "settings")
          ] }),
          showSyncMarker ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              className: `sync-account-marker ${syncStatus === "error" || syncStatus === "conflict" ? "sync-account-marker-error" : ""} ${syncStatus === "syncing" ? "sync-account-marker-syncing" : ""}`,
              title: syncMarkerTitle,
              type: "button",
              onClick: onOpenSettings,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SyncIcon, { size: 14 }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: syncMarkerLabel })
              ]
            }
          ) : null
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "aura-slogan", children: t(language, "brandSlogan") })
    ] }),
    searchVisible ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "aura-search-row", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        SearchBar,
        {
          ref: searchInputRef,
          language,
          hint: search ? t(language, "pressEscToClear") : t(language, "searchModifiersHint"),
          value: search,
          visible: searchVisible,
          onChange: onSearchChange
        }
      ),
      search ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "search-mode-label", children: t(language, "searchMode") }) : null
    ] }) : null
  ] });
}
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isAfsBookmark(value) {
  return isRecord(value) && typeof value.name === "string" && typeof value.url === "string";
}
function isAfsGroup(value) {
  return isRecord(value) && typeof value.name === "string" && Array.isArray(value.bookmarks) && value.bookmarks.every(isAfsBookmark);
}
function parseJsonLikeText(text) {
  const trimmed = text.trim();
  if (!trimmed) {
    throw new Error("Paste the A Fine Start export code first.");
  }
  try {
    return JSON.parse(trimmed);
  } catch {
    const firstArray = trimmed.indexOf("[");
    const lastArray = trimmed.lastIndexOf("]");
    if (firstArray >= 0 && lastArray > firstArray) {
      try {
        return JSON.parse(trimmed.slice(firstArray, lastArray + 1));
      } catch {
        throw new Error("A Fine Start export code must be valid JSON. Copy the whole code from Export bookmarks.");
      }
    }
    throw new Error("A Fine Start export code must be valid JSON. Copy the whole code from Export bookmarks.");
  }
}
function parseColumns(value) {
  if (isRecord(value)) {
    if (Array.isArray(value.columns)) {
      return parseColumns(value.columns);
    }
    if (Array.isArray(value.bookmarks)) {
      return parseColumns(value.bookmarks);
    }
    if (Array.isArray(value.groups)) {
      return parseColumns(value.groups);
    }
  }
  if (!Array.isArray(value)) {
    throw new Error("A Fine Start export must be a JSON array.");
  }
  if (value.every(isAfsGroup)) {
    return [value];
  }
  const maybeV2 = value.length > 0 && value.every((column) => isRecord(column) && Array.isArray(column.groups));
  const columns = maybeV2 ? value.map((column) => column.groups) : value;
  if (!columns.every((column) => Array.isArray(column) && column.every(isAfsGroup))) {
    throw new Error("This does not look like a valid A Fine Start export code.");
  }
  return columns;
}
function isProbablyAFineStartSelfLink(title) {
  return title.trim().toLowerCase() === "a fine start";
}
function normalizeAfsBookmarkUrl(title, rawUrl, groupTitle) {
  const normalizedUrl = normalizeUrl(rawUrl);
  if (normalizedUrl.ok) {
    return { url: normalizedUrl.url };
  }
  if (isProbablyAFineStartSelfLink(title)) {
    return {
      url: "https://afinestart.me/bookmarks/",
      warning: `"${title}" in "${groupTitle}" used an internal A Fine Start URL, so it was converted to https://afinestart.me/bookmarks/.`
    };
  }
  return {
    warning: `"${title}" in "${groupTitle}" was skipped: ${normalizedUrl.message}`
  };
}
function parseAFineStartExportWithReport(text) {
  const parsed = parseJsonLikeText(text);
  const columns = parseColumns(parsed);
  const createdAt = nowIso();
  const errors = [];
  const warnings = [];
  const groups = [];
  let rejectedLinks = 0;
  let sourceGroups = 0;
  let sourceLinks = 0;
  columns.forEach((column) => {
    column.forEach((afsGroup) => {
      sourceGroups += 1;
      const title = afsGroup.name.trim();
      if (!title) {
        errors.push("A group has an empty name.");
        return;
      }
      const links = [];
      afsGroup.bookmarks.forEach((bookmark) => {
        sourceLinks += 1;
        const linkTitle = bookmark.name.trim();
        if (!linkTitle) {
          errors.push(`A bookmark in "${title}" has an empty title.`);
          return;
        }
        const normalizedUrl = normalizeAfsBookmarkUrl(linkTitle, bookmark.url, title);
        if (normalizedUrl.warning) {
          warnings.push(normalizedUrl.warning);
        }
        if (!normalizedUrl.url) {
          rejectedLinks += 1;
          return;
        }
        links.push({
          id: createId("link"),
          title: linkTitle,
          url: normalizedUrl.url,
          order: links.length,
          createdAt,
          updatedAt: createdAt
        });
      });
      groups.push({
        id: createId("group"),
        title,
        collapsed: false,
        order: groups.length,
        links
      });
    });
  });
  if (errors.length) {
    const visible = errors.slice(0, 5).join(" ");
    const remaining = errors.length > 5 ? ` ${errors.length - 5} more problems were found.` : "";
    throw new Error(`${visible}${remaining}`);
  }
  if (!groups.length || groups.every((group) => group.links.length === 0)) {
    throw new Error("This A Fine Start export does not contain bookmarks to import.");
  }
  return {
    data: {
      version: DATA_VERSION,
      updatedAt: createdAt,
      settings: DEFAULT_SETTINGS,
      groups,
      restorePoints: []
    },
    warnings,
    rejectedLinks,
    sourceGroups,
    sourceLinks
  };
}
function countLinks$1(data) {
  return data.groups.reduce((count, group) => count + group.links.length, 0);
}
function countPotentialDuplicates(current, imported) {
  const currentGroupTitles = new Set(current.groups.map((group) => group.title.trim().toLowerCase()).filter(Boolean));
  const currentLinkUrls = new Set(
    current.groups.flatMap((group) => group.links.map((link) => link.url.trim().toLowerCase())).filter(Boolean)
  );
  return {
    groups: imported.groups.filter((group) => currentGroupTitles.has(group.title.trim().toLowerCase())).length,
    links: imported.groups.flatMap((group) => group.links).filter((link) => currentLinkUrls.has(link.url.trim().toLowerCase())).length
  };
}
function importErrorMessage(language, format, error) {
  const message = error instanceof Error ? error.message : "";
  if (format !== "a_fine_start") {
    return localizedKnownMessage(language, message) ?? (message || t(language, "couldNotParseImportData"));
  }
  if (/does not contain bookmarks|no valid links/i.test(message)) {
    return t(language, "noValidLinksFound");
  }
  if (/json|valid A Fine Start|look like|array|unsupported/i.test(message)) {
    return t(language, "invalidExportCode");
  }
  return message || t(language, "invalidExportCode");
}
function localizedKnownMessage(language, message) {
  if (!message) return void 0;
  if (/^URL is required\.$/i.test(message)) return t(language, "urlRequired");
  if (/^Only http and https links are allowed\.$/i.test(message)) return t(language, "urlHttpOnly");
  if (/^URL must include a valid host\.$/i.test(message)) return t(language, "urlHostRequired");
  if (/^Enter a valid URL/i.test(message)) return t(language, "urlInvalidExample");
  if (/^Link title is required\.$/i.test(message)) return t(language, "linkTitleRequired");
  if (/^Group title is required\.$/i.test(message)) return t(language, "groupTitleRequired");
  if (/Every link must be an object|Every group must be an object|Backup root must be an object|backup version|not valid JSON/i.test(message)) {
    return t(language, "couldNotParseImportData");
  }
  return void 0;
}
function importWarningMessage(language, warning) {
  const converted = warning.match(/^"(.+)" in "(.+)" used an internal A Fine Start URL, so it was converted to https:\/\/afinestart\.me\/bookmarks\/\.$/);
  if (converted) {
    return t(language, "aFineStartInternalUrlConverted", { title: converted[1], groupTitle: converted[2] });
  }
  const skipped = warning.match(/^"(.+)" in "(.+)" was skipped: (.+)$/);
  if (skipped) {
    return t(language, "aFineStartLinkSkipped", {
      title: skipped[1],
      groupTitle: skipped[2],
      reason: localizedKnownMessage(language, skipped[3]) ?? skipped[3]
    });
  }
  return localizedKnownMessage(language, warning) ?? warning;
}
function ImportDialog({
  language,
  open,
  currentData,
  initialFormat = "aura_json",
  onClose,
  onImport,
  onError
}) {
  const [format, setFormat] = reactExports.useState(initialFormat);
  const [mode, setMode] = reactExports.useState("merge");
  const [fileName, setFileName] = reactExports.useState("");
  const [rawText, setRawText] = reactExports.useState("");
  const [parsed, setParsed] = reactExports.useState(null);
  const [importWarnings, setImportWarnings] = reactExports.useState([]);
  const [rejectedLinks, setRejectedLinks] = reactExports.useState(0);
  const [sourceCounts, setSourceCounts] = reactExports.useState({ groups: 0, links: 0 });
  const [localError, setLocalError] = reactExports.useState(null);
  const [pendingReplace, setPendingReplace] = reactExports.useState(null);
  function parseText(text, nextFormat = format) {
    if (nextFormat === "a_fine_start") {
      const result = parseAFineStartExportWithReport(text);
      return {
        ...result,
        data: {
          ...result.data,
          settings: {
            ...result.data.settings,
            language
          }
        }
      };
    }
    const data = parseJsonBackup(text);
    return {
      data,
      warnings: [],
      rejectedLinks: 0,
      sourceGroups: data.groups.length,
      sourceLinks: countLinks$1(data)
    };
  }
  function setParsedResult(result) {
    setParsed(result.data);
    setImportWarnings(result.warnings);
    setRejectedLinks(result.rejectedLinks);
    setSourceCounts({ groups: result.sourceGroups, links: result.sourceLinks });
  }
  function validateText(text, nextFormat = format) {
    setLocalError(null);
    setParsed(null);
    setImportWarnings([]);
    setRejectedLinks(0);
    setSourceCounts({ groups: 0, links: 0 });
    if (!text.trim()) return;
    try {
      const result = parseText(text, nextFormat);
      setParsedResult(result);
    } catch (error) {
      setLocalError(importErrorMessage(language, nextFormat, error));
    }
  }
  reactExports.useEffect(() => {
    if (!open) return;
    setFormat(initialFormat);
    validateText(rawText, initialFormat);
  }, [initialFormat, open]);
  reactExports.useEffect(() => {
    if (!open) {
      setPendingReplace(null);
    }
  }, [open]);
  async function handleFile(file) {
    setLocalError(null);
    setParsed(null);
    setFileName((file == null ? void 0 : file.name) ?? "");
    if (!file) return;
    try {
      const text = await file.text();
      setRawText(text);
      const result = parseText(text);
      setParsedResult(result);
    } catch (error) {
      setImportWarnings([]);
      setRejectedLinks(0);
      setSourceCounts({ groups: 0, links: 0 });
      setLocalError(importErrorMessage(language, format, error));
    }
  }
  const validLinkCount = parsed ? countLinks$1(parsed) : 0;
  const potentialDuplicates = parsed ? countPotentialDuplicates(currentData, parsed) : { groups: 0, links: 0 };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Modal,
      {
        open,
        title: format === "a_fine_start" ? t(language, "importFromAFineStart") : t(language, "importBackup"),
        description: t(language, "importBackupDescription"),
        closeLabel: t(language, "closeDialog"),
        onClose,
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "form",
          {
            className: "space-y-5",
            onSubmit: (event) => {
              event.preventDefault();
              if (!rawText.trim()) {
                setLocalError(t(language, "pickImportData"));
                return;
              }
              let dataToImport;
              try {
                const result = parseText(rawText);
                dataToImport = result.data;
                setParsedResult(result);
                setLocalError(null);
              } catch (error) {
                setParsed(null);
                setImportWarnings([]);
                setRejectedLinks(0);
                setSourceCounts({ groups: 0, links: 0 });
                setLocalError(importErrorMessage(language, format, error));
                return;
              }
              if (mode === "replace") {
                setPendingReplace({ data: dataToImport, format });
                return;
              }
              void onImport(dataToImport, mode, format).then(onClose).catch((error) => onError(error instanceof Error ? error.message : t(language, "importFailed")));
            },
            children: [
              format === "a_fine_start" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-[var(--border)] bg-[var(--surface-strong)] p-4 text-sm", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: t(language, "aFineStartImportStepsTitle") }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("ol", { className: "muted mt-2 list-decimal space-y-1 pl-5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "aFineStartImportStepOpen") }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "aFineStartImportStepSettings") }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "aFineStartImportStepCopy") }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "aFineStartImportStepPaste") }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "aFineStartImportStepMode") }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "aFineStartImportStepReview") })
                ] })
              ] }) : null,
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-sm font-semibold", children: t(language, "importFormat") }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "select",
                  {
                    className: "field",
                    value: format,
                    onChange: (event) => {
                      const nextFormat = event.target.value;
                      setFormat(nextFormat);
                      validateText(rawText, nextFormat);
                    },
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "aura_json", children: t(language, "auraStartBackupJson") }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "a_fine_start", children: t(language, "aFineStartExportCode") })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block rounded-xl border border-dashed border-[var(--border)] p-5 text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "mx-auto text-[var(--accent)]", size: 28 }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-3 block text-sm font-semibold", children: fileName || t(language, "chooseImportFile") }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "muted mt-1 block text-xs", children: t(language, "noUploadHappens") }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    accept: "application/json,text/plain,.json,.txt",
                    className: "sr-only",
                    type: "file",
                    onChange: (event) => {
                      var _a;
                      void handleFile((_a = event.target.files) == null ? void 0 : _a[0]);
                    }
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-sm font-semibold", children: format === "a_fine_start" ? t(language, "pasteAFineStartCode") : t(language, "pasteAuraJson") }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "textarea",
                  {
                    className: "field min-h-32 resize-y",
                    placeholder: format === "a_fine_start" ? t(language, "pasteAFineStartPlaceholder") : t(language, "pasteFullBackupJson"),
                    value: rawText,
                    onChange: (event) => {
                      const text = event.target.value;
                      setRawText(text);
                      setFileName("");
                      validateText(text);
                    }
                  }
                )
              ] }),
              parsed ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg bg-[var(--accent-soft)] p-3 text-sm text-[var(--accent-strong)]", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: t(language, "reviewImport") }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("dl", { className: "mt-2 grid gap-2 sm:grid-cols-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("dt", { className: "text-xs uppercase tracking-wide opacity-75", children: t(language, "importPreviewPayload") }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("dd", { children: t(language, "importPreviewGroupsLinks", { groups: sourceCounts.groups, links: sourceCounts.links }) })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("dt", { className: "text-xs uppercase tracking-wide opacity-75", children: t(language, "importPreviewValid") }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("dd", { children: t(language, "importPreviewGroupsLinks", { groups: parsed.groups.length, links: validLinkCount }) })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("dt", { className: "text-xs uppercase tracking-wide opacity-75", children: t(language, "importPreviewMode") }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("dd", { children: mode === "merge" ? t(language, "merge") : t(language, "replace") })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("dt", { className: "text-xs uppercase tracking-wide opacity-75", children: t(language, "importPreviewWillAdd") }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("dd", { children: t(language, "importPreviewGroupsLinks", { groups: parsed.groups.length, links: validLinkCount }) })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("dt", { className: "text-xs uppercase tracking-wide opacity-75", children: t(language, "importPreviewPotentialDuplicates") }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("dd", { children: t(language, "importPreviewGroupsLinks", { groups: potentialDuplicates.groups, links: potentialDuplicates.links }) })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("dt", { className: "text-xs uppercase tracking-wide opacity-75", children: t(language, "importPreviewRejected") }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("dd", { children: t(language, "linksCount", { count: rejectedLinks }) })
                  ] })
                ] }),
                mode === "replace" ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-sm", children: t(language, "exportBackupBeforeImport") }) : null
              ] }) : null,
              importWarnings.length ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-[var(--border)] bg-[var(--surface-strong)] p-3 text-sm", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-[var(--warning)]", children: t(language, "importWarnings", { count: importWarnings.length }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "muted mt-2 list-disc space-y-1 pl-5", children: importWarnings.slice(0, 4).map((warning) => /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: importWarningMessage(language, warning) }, warning)) }),
                importWarnings.length > 4 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "muted mt-2", children: t(language, "moreWarnings", { count: importWarnings.length - 4 }) }) : null
              ] }) : null,
              localError ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-lg bg-[var(--danger-soft)] p-3 text-sm text-[var(--danger)]", children: localError }) : null,
              /* @__PURE__ */ jsxRuntimeExports.jsxs("fieldset", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("legend", { className: "text-sm font-semibold", children: t(language, "importMode") }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-start gap-3 rounded-lg border border-[var(--border)] p-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      checked: mode === "merge",
                      className: "mt-1",
                      name: "importMode",
                      type: "radio",
                      value: "merge",
                      onChange: () => setMode("merge")
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-sm font-semibold", children: t(language, "mergeWithCurrentData") }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "muted block text-sm", children: t(language, "mergeDescription") })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-start gap-3 rounded-lg border border-[var(--border)] p-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      checked: mode === "replace",
                      className: "mt-1",
                      name: "importMode",
                      type: "radio",
                      value: "replace",
                      onChange: () => setMode("replace")
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-sm font-semibold", children: t(language, "replaceCurrentData") }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "muted block text-sm", children: t(language, "replaceDescription") })
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", type: "button", onClick: onClose, children: t(language, "cancel") }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-primary", type: "submit", children: t(language, "import") })
              ] })
            ]
          }
        )
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      ConfirmDialog,
      {
        cancelLabel: t(language, "cancel"),
        confirmLabel: t(language, "importReplaceConfirmAction"),
        message: t(language, "importReplaceConfirmMessage"),
        open: pendingReplace !== null,
        title: t(language, "importReplaceConfirmTitle"),
        onCancel: () => setPendingReplace(null),
        onConfirm: async () => {
          if (!pendingReplace) return;
          try {
            await onImport(pendingReplace.data, "replace", pendingReplace.format);
            setPendingReplace(null);
            onClose();
          } catch (error) {
            onError(error instanceof Error ? error.message : t(language, "importFailed"));
          }
        }
      }
    )
  ] });
}
function OnboardingDialog({
  data,
  open,
  onClose,
  onComplete,
  onImportAFineStart,
  onImportBackup,
  onRestoreGoogleDrive,
  onUpdateSettings,
  onError
}) {
  const [step, setStep] = reactExports.useState("start");
  const language = data.settings.language;
  reactExports.useEffect(() => {
    if (open) {
      setStep("start");
    }
  }, [open]);
  async function finish() {
    try {
      await onComplete();
      onClose();
    } catch (error) {
      onError(error instanceof Error ? error.message : t(language, "couldNotUpdateSettings"));
    }
  }
  async function chooseTheme(theme) {
    try {
      await onUpdateSettings({ theme });
      setStep("layout");
    } catch (error) {
      onError(error instanceof Error ? error.message : t(language, "couldNotUpdateSettings"));
    }
  }
  async function chooseLayout(compactMode) {
    try {
      await onUpdateSettings({ compactMode });
      setStep("finish");
    } catch (error) {
      onError(error instanceof Error ? error.message : t(language, "couldNotUpdateSettings"));
    }
  }
  async function completeAndOpenImport(action) {
    await finish();
    action();
  }
  async function completeAndRestoreGoogleDrive() {
    try {
      const restored = await onRestoreGoogleDrive();
      if (!restored) {
        onError(t(language, "googleDriveNoSyncFileFound"));
        return;
      }
      await onComplete();
      onClose();
    } catch (error) {
      onError(error instanceof Error ? error.message : t(language, "googleDriveSyncFailed"));
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    Modal,
    {
      open,
      title: t(language, "welcomeToAuraStart"),
      description: t(language, "onboardingDescription"),
      closeLabel: t(language, "closeDialog"),
      onClose,
      size: "lg",
      children: [
        step === "start" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold", children: t(language, "chooseHowToStart") }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "surface-flat rounded-lg border border-[var(--border)] p-4 text-left", type: "button", onClick: () => setStep("appearance"), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "mb-3 text-[var(--accent)]", size: 22 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: t(language, "startFresh") })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "surface-flat rounded-lg border border-[var(--border)] p-4 text-left", type: "button", onClick: () => void completeAndRestoreGoogleDrive(), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Cloud, { className: "mb-3 text-[var(--accent)]", size: 22 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: t(language, "restoreFromGoogleDriveOnboarding") })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "surface-flat rounded-lg border border-[var(--border)] p-4 text-left", type: "button", onClick: () => void completeAndOpenImport(onImportAFineStart), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(FileUp, { className: "mb-3 text-[var(--accent)]", size: 22 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: t(language, "importFromAFineStart") })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "surface-flat rounded-lg border border-[var(--border)] p-4 text-left", type: "button", onClick: () => void completeAndOpenImport(onImportBackup), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(FileUp, { className: "mb-3 text-[var(--accent)]", size: 22 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: t(language, "importBackupFile") })
            ] })
          ] })
        ] }) : null,
        step === "appearance" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Palette, { className: "text-[var(--accent)]", size: 22 }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold", children: t(language, "chooseAppearance") })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 sm:grid-cols-3", children: ["system", "light", "dark"].map((theme) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: `btn ${data.settings.theme === theme ? "btn-primary" : "btn-secondary"} w-full`,
              type: "button",
              onClick: () => void chooseTheme(theme),
              children: t(language, theme)
            },
            theme
          )) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-between", children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-ghost", type: "button", onClick: () => setStep("start"), children: t(language, "back") }) })
        ] }) : null,
        step === "layout" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold", children: t(language, "optionalLayout") }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: `btn ${!data.settings.compactMode ? "btn-primary" : "btn-secondary"} w-full`, type: "button", onClick: () => void chooseLayout(false), children: t(language, "comfortable") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: `btn ${data.settings.compactMode ? "btn-primary" : "btn-secondary"} w-full`, type: "button", onClick: () => void chooseLayout(true), children: t(language, "compact") })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-between", children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-ghost", type: "button", onClick: () => setStep("appearance"), children: t(language, "back") }) })
        ] }) : null,
        step === "finish" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5 text-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "mx-auto text-[var(--accent)]", size: 34 }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold", children: t(language, "finish") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted mt-1 text-sm", children: t(language, "onboardingFinishDescription") })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-primary", type: "button", onClick: () => void finish(), children: t(language, "finish") })
        ] }) : null
      ]
    }
  );
}
function RecoveryScreen({ language, message, raw, onReset, onError }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "app-shell flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "surface w-full max-w-2xl rounded-xl p-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[var(--danger-soft)] text-[var(--danger)]", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { size: 22 }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-semibold", children: t(language, "recoveryTitle") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted mt-2 text-sm leading-6", children: t(language, "recoveryDescription") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 rounded-lg bg-[var(--danger-soft)] p-3 text-sm text-[var(--danger)]", children: message })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-wrap gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          className: "btn btn-secondary",
          type: "button",
          onClick: () => downloadTextFile(
            `aura-start-corrupt-storage-${dateForFile()}.json`,
            raw || "{}",
            "application/json;charset=utf-8"
          ),
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { size: 17 }),
            t(language, "exportRawData")
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          className: "btn btn-danger",
          type: "button",
          onClick: () => {
            void onReset().catch(
              (error) => onError(error instanceof Error ? error.message : t(language, "couldNotResetLocalData"))
            );
          },
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { size: 17 }),
            t(language, "resetLocalData")
          ]
        }
      )
    ] })
  ] }) });
}
function restoreReasonLabel(language, reason) {
  switch (reason) {
    case "auto":
      return t(language, "restoreReasonAuto");
    case "before_delete":
      return t(language, "restoreReasonBeforeDelete");
    case "before_import":
      return t(language, "restoreReasonBeforeImport");
    case "before_reset":
      return t(language, "restoreReasonBeforeReset");
    case "manual":
      return t(language, "restoreReasonManual");
  }
}
function countLinks(point) {
  return point.data.groups.reduce((count, group) => count + group.links.length, 0);
}
function restorePointAsBackup(point) {
  return {
    ...point.data,
    restorePoints: []
  };
}
function RestorePointsDialog({
  language,
  open,
  restorePoints,
  onClose,
  onCreate,
  onRestore,
  onDelete,
  onDeleteAll,
  onError
}) {
  const [name, setName] = reactExports.useState(t(language, "manualCheckpoint"));
  const [pending, setPending] = reactExports.useState(null);
  function exportPoint(point) {
    try {
      downloadTextFile(
        `aura-start-restore-point-${dateForFile(new Date(point.createdAt))}.json`,
        createJsonBackup(restorePointAsBackup(point)),
        "application/json;charset=utf-8"
      );
    } catch (error) {
      onError(error instanceof Error ? error.message : t(language, "couldNotExportBackup"));
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Modal,
      {
        open,
        title: t(language, "restorePoints"),
        description: t(language, "restorePointsDescription", { count: MAX_RESTORE_POINTS }),
        closeLabel: t(language, "closeDialog"),
        onClose,
        size: "lg",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "form",
            {
              className: "mb-5 flex flex-col gap-2 sm:flex-row",
              onSubmit: (event) => {
                event.preventDefault();
                void onCreate(name).catch(
                  (error) => onError(error instanceof Error ? error.message : t(language, "couldNotCreateRestorePoint"))
                );
              },
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    className: "field",
                    maxLength: 120,
                    value: name,
                    onChange: (event) => setName(event.target.value)
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary shrink-0", type: "submit", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldPlus, { size: 17 }),
                  t(language, "create")
                ] })
              ]
            }
          ),
          restorePoints.length ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-ghost text-[var(--danger)]", type: "button", onClick: () => setPending({ type: "deleteAll" }), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { size: 16 }),
            t(language, "deleteAllOldRestorePoints")
          ] }) }) : null,
          restorePoints.length ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: restorePoints.map((point) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "surface-flat flex flex-col gap-3 rounded-lg p-3 sm:flex-row sm:items-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "truncate text-sm font-semibold", children: point.name }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "muted text-xs", children: [
                formatDateTime(point.createdAt),
                " · ",
                restoreReasonLabel(language, point.reason),
                " ·",
                " ",
                t(language, "groupsCount", { count: point.data.groups.length }),
                " ·",
                " ",
                t(language, "linksCount", { count: countLinks(point) })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary", type: "button", onClick: () => setPending({ type: "restore", point }), children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { size: 16 }),
                t(language, "restore")
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary", type: "button", onClick: () => exportPoint(point), children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { size: 16 }),
                t(language, "exportRestorePoint")
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  "aria-label": t(language, "deleteRestorePointAria", { name: point.name }),
                  className: "btn btn-ghost text-[var(--danger)]",
                  type: "button",
                  onClick: () => setPending({ type: "delete", point }),
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { size: 16 })
                }
              )
            ] })
          ] }, point.id)) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "surface-flat rounded-xl p-8 text-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold", children: t(language, "noRestorePoints") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted mt-1 text-sm", children: t(language, "noRestorePointsDescription") })
          ] })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      ConfirmDialog,
      {
        cancelLabel: t(language, "cancel"),
        confirmLabel: (pending == null ? void 0 : pending.type) === "restore" ? t(language, "restore") : (pending == null ? void 0 : pending.type) === "deleteAll" ? t(language, "deleteAllOldRestorePoints") : t(language, "delete"),
        message: (pending == null ? void 0 : pending.type) === "restore" ? t(language, "restoreThisPointMessage") : (pending == null ? void 0 : pending.type) === "deleteAll" ? t(language, "deleteAllRestorePointsMessage") : t(language, "deleteRestorePointMessage"),
        open: pending !== null,
        title: (pending == null ? void 0 : pending.type) === "restore" ? t(language, "restoreThisPoint") : (pending == null ? void 0 : pending.type) === "deleteAll" ? t(language, "deleteAllOldRestorePoints") : t(language, "deleteRestorePoint"),
        onCancel: () => setPending(null),
        onConfirm: async () => {
          if (!pending) return;
          try {
            if (pending.type === "restore") {
              await onRestore(pending.point.id);
            } else if (pending.type === "delete") {
              await onDelete(pending.point.id);
            } else {
              await onDeleteAll();
            }
            setPending(null);
          } catch (error) {
            onError(error instanceof Error ? error.message : t(language, "restorePointActionFailed"));
          }
        }
      }
    )
  ] });
}
function isBusy(status) {
  return status === "connecting" || status === "syncing";
}
function GoogleDriveSyncPanel({
  data,
  syncStatus,
  syncMessage,
  syncConflict,
  onConnect,
  onDeleteBackupAndDisconnect,
  onResolveConflict,
  onError
}) {
  const [pendingConfirm, setPendingConfirm] = reactExports.useState(null);
  const language = data.settings.language;
  const sync = data.settings.sync;
  const busy = isBusy(syncStatus);
  const hasGoogleConnection = Boolean(sync.connected);
  const connected = sync.mode !== "off" && hasGoogleConnection;
  const canManageConnection = hasGoogleConnection && !busy;
  const displayMessage = hasGoogleConnection && syncMessage ? syncMessage : sync.mode === "off" ? t(language, "googleDriveSyncDisabled") : connected ? t(language, "googleDriveConnected") : t(language, "googleDriveNotConnected");
  function run(action) {
    void action().catch((error) => {
      if (error instanceof GoogleDriveSyncError) return;
      onError(error instanceof Error ? error.message : t(language, "googleDriveSyncFailed"));
    });
  }
  async function runConfirmed(action) {
    try {
      await action();
    } catch (error) {
      if (error instanceof GoogleDriveSyncError) return;
      onError(error instanceof Error ? error.message : t(language, "googleDriveSyncFailed"));
    }
  }
  function handleExportLocal() {
    try {
      exportJsonBackup(data);
    } catch (error) {
      onError(error instanceof Error ? error.message : t(language, "couldNotExportBackup"));
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "surface-flat rounded-xl p-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold", children: t(language, "googleDriveSyncTitle") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted mt-1 text-sm leading-6", children: t(language, "googleDriveSyncDescription") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Cloud, { className: syncStatus === "error" || syncStatus === "conflict" ? "text-[var(--danger)]" : "text-[var(--accent)]", size: 20 })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "muted mt-3 list-disc space-y-1 pl-5 text-sm leading-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "googleDriveSyncOffByDefault") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "googleDriveAutoSyncActive") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "googleDriveGoogleWindow") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "googleDriveMinimalScope") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "googleDriveSyncUsesAppData") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "googleDriveNoFullDrive") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "googleDriveNoTracking") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: t(language, "googleDriveManualExportStillWorks") })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 rounded-lg border border-[var(--border)] p-3 text-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: displayMessage }),
      sync.accountEmail || sync.accountName ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "muted mt-1", children: sync.accountName ?? sync.accountEmail }) : null,
      hasGoogleConnection && sync.lastSyncedAt ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "muted mt-1", children: t(language, "googleDriveLastSynced", { time: formatDateTime(sync.lastSyncedAt) }) }) : null,
      hasGoogleConnection && sync.lastCloudUpdatedAt ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "muted mt-1", children: t(language, "googleDriveLastCloudUpdate", { time: formatDateTime(sync.lastCloudUpdatedAt) }) }) : null
    ] }),
    pendingConfirm === "delete_backup_and_disconnect" ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 rounded-xl border border-[var(--danger)] bg-[var(--danger-soft)] p-4 text-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-[var(--danger-soft)] text-[var(--danger)]", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { size: 20 }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: t(language, "googleDriveDeleteBackupAndDisconnect") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              "aria-label": t(language, "cancel"),
              className: "btn btn-ghost h-8 w-8 shrink-0 p-0",
              type: "button",
              onClick: () => setPendingConfirm(null),
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 16 })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted mt-2 leading-6", children: t(language, "googleDriveDeleteBackupAndDisconnectConfirmMessage") }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex flex-wrap justify-end gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", type: "button", onClick: () => setPendingConfirm(null), children: t(language, "cancel") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: "btn btn-danger",
              type: "button",
              onClick: () => {
                setPendingConfirm(null);
                void runConfirmed(onDeleteBackupAndDisconnect);
              },
              children: t(language, "googleDriveDeleteBackupAndDisconnectConfirm")
            }
          )
        ] })
      ] })
    ] }) }) : null,
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4", children: !hasGoogleConnection ? /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-primary h-11 min-w-0 w-full justify-center whitespace-nowrap px-3 text-sm", disabled: busy, type: "button", onClick: () => run(onConnect), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Cloud, { className: "shrink-0", size: 17 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: t(language, "googleDriveConnect") })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        className: "btn btn-danger h-11 min-w-0 w-full justify-center whitespace-nowrap px-3 text-sm",
        disabled: !canManageConnection,
        type: "button",
        onClick: () => setPendingConfirm("delete_backup_and_disconnect"),
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "shrink-0", size: 17 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: t(language, "googleDriveDeleteBackupAndDisconnect") })
        ]
      }
    ) }),
    syncConflict ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 rounded-lg border border-[var(--danger)] bg-[var(--danger-soft)] p-3 text-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-[var(--danger)]", children: t(language, "googleDriveConflictDetected") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 leading-6", children: t(language, "googleDriveConflictTimes", {
        local: formatDateTime(syncConflict.localUpdatedAt),
        cloud: formatDateTime(syncConflict.cloudUpdatedAt)
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-primary", disabled: busy, type: "button", onClick: () => run(() => onResolveConflict("keep_local")), children: t(language, "googleDriveKeepLocal") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", disabled: busy, type: "button", onClick: () => run(() => onResolveConflict("keep_cloud")), children: t(language, "googleDriveKeepCloud") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", type: "button", onClick: handleExportLocal, children: t(language, "googleDriveExportLocalBackup") })
      ] })
    ] }) : null
  ] });
}
const columnOptions = ["auto", 1, 2, 3, 4, 5, 6];
const privacyPolicyUrl = "https://github.com/communism420/Aura-Start/blob/main/PRIVACY.md";
function SettingsDialog({
  open,
  data,
  syncStatus,
  syncMessage,
  syncConflict,
  onClose,
  onUpdateSettings,
  onOpenImport,
  onOpenImportAFineStart,
  onOpenDuplicateFinder,
  onOpenRestorePoints,
  onOpenOnboarding,
  onReset,
  hasDemoData,
  onRemoveDemoData,
  onConnectGoogleDrive,
  onDeleteGoogleDriveBackupAndDisconnect,
  onResolveSyncConflict,
  onError
}) {
  const settings = data.settings;
  const language = settings.language;
  const privacyPromises = [
    t(language, "noAnalytics"),
    t(language, "noTracking"),
    t(language, "noAds"),
    t(language, "noBackend"),
    t(language, "noRequiredAccount"),
    t(language, "noBrowserHistoryPermission"),
    t(language, "noBrowserBookmarksPermission"),
    t(language, "driveSyncOptionalOffByDefault"),
    t(language, "driveSyncAppDataFolderOnly")
  ];
  const shortcuts = [
    ["Ctrl/⌘ K", t(language, "shortcutOpenCommandPalette")],
    ["/", t(language, "shortcutFocusSearch")],
    ["Esc", t(language, "shortcutClearSearch")],
    ["Enter", t(language, "shortcutOpenSelectedResult")],
    ["E", t(language, "shortcutToggleEditMode")],
    ["N", t(language, "shortcutCreateNewLink")],
    ["G", t(language, "shortcutCreateNewGroup")]
  ];
  function update(settingsPatch) {
    void onUpdateSettings(settingsPatch).catch(
      (error) => onError(error instanceof Error ? error.message : t(language, "couldNotUpdateSettings"))
    );
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Modal, { open, title: t(language, "settings"), description: t(language, "settingsDescription"), closeLabel: t(language, "closeDialog"), onClose, size: "xl", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-5 lg:grid-cols-[1fr_0.9fr]", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-sm font-semibold", children: t(language, "theme") }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { className: "field", value: settings.theme, onChange: (event) => update({ theme: event.target.value }), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "system", children: t(language, "system") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "light", children: t(language, "light") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "dark", children: t(language, "dark") })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-sm font-semibold", children: t(language, "language") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("select", { className: "field", value: settings.language, onChange: (event) => update({ language: event.target.value }), children: languageOptions.map((option) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: option.code, children: option.label }, option.code)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mb-1 block text-sm font-semibold", children: t(language, "columns") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "select",
          {
            className: "field",
            value: String(settings.columns),
            onChange: (event) => {
              const value = event.target.value;
              update({ columns: value === "auto" ? "auto" : Number(value) });
            },
            children: columnOptions.map((option) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: option, children: option === "auto" ? t(language, "auto") : option }, option))
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: [
        ["compactMode", t(language, "compactMode")],
        ["showDescriptions", t(language, "showDescriptions")],
        ["showSearch", t(language, "showSearch")],
        ["openLinksInNewTab", t(language, "openLinksInNewTab")]
      ].map(([key2, label]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center justify-between gap-4 rounded-lg border border-[var(--border)] p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-sm font-semibold", children: label }),
          key2 === "openLinksInNewTab" ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "muted block text-xs", children: t(language, "openLinksInNewTabDescription") }) : null
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            checked: Boolean(settings[key2]),
            type: "checkbox",
            onChange: (event) => update({ [key2]: event.target.checked })
          }
        )
      ] }, key2)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "surface-flat rounded-xl p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold", children: t(language, "dataOwnership") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted mt-1 text-sm leading-6", children: t(language, "dataOwnershipDescription") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "surface-flat rounded-xl p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold", children: t(language, "tools") }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex flex-wrap gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary", type: "button", onClick: onOpenDuplicateFinder, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(SearchCheck, { size: 17 }),
            t(language, "duplicateFinder")
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ExportMenu, { data, onError }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary", type: "button", onClick: onOpenImport, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { size: 17 }),
            t(language, "importBackup")
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary", type: "button", onClick: onOpenImportAFineStart, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(FileUp, { size: 17 }),
            t(language, "importFromAFineStart")
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary", type: "button", onClick: onOpenRestorePoints, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { size: 17 }),
            t(language, "restorePoints")
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "surface-flat rounded-xl p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "text-[var(--accent)]", size: 18 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold", children: t(language, "privacyPromise") })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-3 grid gap-2 text-sm sm:grid-cols-2", children: privacyPromises.map((promise) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--accent)]" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: promise })
        ] }, promise)) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            className: "btn btn-secondary mt-4",
            href: privacyPolicyUrl,
            rel: "noreferrer",
            target: "_blank",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { size: 16 }),
              t(language, "privacyPolicy")
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "surface-flat rounded-xl p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Keyboard, { className: "text-[var(--accent)]", size: 18 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold", children: t(language, "keyboardShortcuts") })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "muted mt-1 text-sm", children: [
          t(language, "searchShortcuts"),
          ": ",
          t(language, "pressSlashToSearch"),
          " · ",
          t(language, "pressEscToClear")
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 grid gap-2 text-sm sm:grid-cols-2", children: shortcuts.map(([shortcut, label]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3 rounded-lg border border-[var(--border)] px-3 py-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "muted", children: label }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("kbd", { className: "shortcut-key", children: shortcut })
        ] }, shortcut)) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted mt-3 text-sm", children: t(language, "commandPaletteShortcutNote") }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "muted mt-3 text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-[var(--text)]", children: t(language, "searchModifiers") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1", children: t(language, "searchModifiersExamples") })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary w-full justify-start", type: "button", onClick: onOpenOnboarding, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleHelp, { size: 17 }),
        t(language, "openOnboardingHelpAgain")
      ] }),
      hasDemoData ? /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "btn btn-secondary w-full justify-start", type: "button", onClick: onRemoveDemoData, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { size: 17 }),
        t(language, "removeDemoData")
      ] }) : null,
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-danger w-full justify-start", type: "button", onClick: onReset, children: t(language, "resetAllData") })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "lg:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      GoogleDriveSyncPanel,
      {
        data,
        syncConflict,
        syncMessage,
        syncStatus,
        onConnect: onConnectGoogleDrive,
        onDeleteBackupAndDisconnect: onDeleteGoogleDriveBackupAndDisconnect,
        onError,
        onResolveConflict: onResolveSyncConflict
      }
    ) })
  ] }) });
}
const iconByType = {
  info: Info,
  success: CircleCheck,
  error: CircleAlert
};
function Toasts() {
  const toasts = useAuraStore((state) => state.toasts);
  const removeToast = useAuraStore((state) => state.removeToast);
  const language = useAuraStore((state) => {
    var _a;
    return ((_a = state.data) == null ? void 0 : _a.settings.language) ?? "en";
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed bottom-4 right-4 z-50 flex w-[min(380px,calc(100vw-2rem))] flex-col gap-3", children: toasts.map((toast) => {
    const Icon = iconByType[toast.type];
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "surface rounded-xl p-4", role: "status", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Icon,
        {
          className: toast.type === "error" ? "text-[var(--danger)]" : "text-[var(--accent)]",
          size: 20
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold", children: toast.title }),
        toast.message ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "muted mt-1 text-sm", children: toast.message }) : null,
        toast.actionLabel && toast.onAction ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: "mt-3 text-sm font-semibold text-[var(--accent-strong)]",
            type: "button",
            onClick: () => {
              var _a;
              void ((_a = toast.onAction) == null ? void 0 : _a.call(toast));
              removeToast(toast.id);
            },
            children: toast.actionLabel
          }
        ) : null
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          "aria-label": t(language, "dismissNotification"),
          className: "btn btn-ghost h-8 w-8 p-0",
          type: "button",
          onClick: () => removeToast(toast.id),
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 16 })
        }
      )
    ] }) }, toast.id);
  }) });
}
const TOGGLE_COMMAND_PALETTE_MESSAGE = "aura-start:toggle-command-palette";
function isTextInput(target) {
  if (!(target instanceof HTMLElement)) return false;
  if (target.dataset.keyboardFocusTarget === "true") return false;
  const tag = target.tagName.toLowerCase();
  return tag === "input" || tag === "textarea" || tag === "select" || target.isContentEditable;
}
function isInteractiveControl(target) {
  if (!(target instanceof HTMLElement)) return false;
  return Boolean(target.closest("button,a,[role='button'],[role='link']"));
}
function resultIdentity(result) {
  return searchResultId(result.groupId, result.link.id);
}
function scrollSearchResultIntoView(id) {
  window.requestAnimationFrame(() => {
    const element = Array.from(document.querySelectorAll("[data-search-result-id]")).find(
      (candidate) => candidate.dataset.searchResultId === id
    );
    element == null ? void 0 : element.scrollIntoView({ block: "nearest" });
  });
}
function App({ initialSettingsOpen = false }) {
  const {
    data,
    status,
    error,
    corruptRaw,
    usingFallbackStorage,
    syncStatus,
    syncMessage,
    syncConflict,
    onboardingCompleted,
    demoData,
    load,
    completeOnboarding,
    resetCorruptData,
    updateSettings,
    addGroup,
    updateGroupTitle,
    toggleGroupCollapsed,
    deleteGroup,
    addLink,
    updateLink,
    deleteLink,
    deleteLinksWithRestorePoint,
    reorderGroups,
    moveLink,
    addDemoData,
    removeDemoData,
    importBackup,
    resetAllData,
    createManualRestorePoint,
    restoreRestorePoint,
    deleteRestorePoint,
    deleteAllRestorePoints,
    connectGoogleDrive,
    deleteGoogleDriveBackupAndDisconnect,
    restoreFromGoogleDrive,
    resolveSyncConflict,
    addToast
  } = useAuraStore();
  const [search, setSearch] = reactExports.useState("");
  const [searchOpen, setSearchOpen] = reactExports.useState(false);
  const [selectedSearchResultId, setSelectedSearchResultId] = reactExports.useState(null);
  const [commandPaletteOpen, setCommandPaletteOpen] = reactExports.useState(false);
  const [editMode, setEditMode] = reactExports.useState(false);
  const [groupDialogOpen, setGroupDialogOpen] = reactExports.useState(false);
  const [editingGroup, setEditingGroup] = reactExports.useState(null);
  const [linkDialogOpen, setLinkDialogOpen] = reactExports.useState(false);
  const [initialLinkGroupId, setInitialLinkGroupId] = reactExports.useState();
  const [editingLink, setEditingLink] = reactExports.useState(null);
  const [settingsOpen, setSettingsOpen] = reactExports.useState(initialSettingsOpen);
  const [importOpen, setImportOpen] = reactExports.useState(false);
  const [importFormat, setImportFormat] = reactExports.useState("aura_json");
  const [restoreOpen, setRestoreOpen] = reactExports.useState(false);
  const [duplicateFinderOpen, setDuplicateFinderOpen] = reactExports.useState(false);
  const [onboardingOpen, setOnboardingOpen] = reactExports.useState(false);
  const [pendingDanger, setPendingDanger] = reactExports.useState(null);
  const keyboardFocusRef = reactExports.useRef(null);
  const searchInputRef = reactExports.useRef(null);
  const autoOnboardingCheckedRef = reactExports.useRef(false);
  const fallbackLanguage = DEFAULT_SETTINGS.language;
  reactExports.useEffect(() => {
    void load();
  }, [load]);
  const hasUserGroupsOrLinks = Boolean(data && data.groups.length > 0);
  const hasTrackedDemoData = reactExports.useMemo(() => {
    if (!data) return false;
    const demoGroupIds = new Set(demoData.groupIds);
    const demoLinkIds = new Set(demoData.linkIds);
    return data.groups.some((group) => demoGroupIds.has(group.id) || group.links.some((link) => demoLinkIds.has(link.id)));
  }, [data, demoData]);
  reactExports.useEffect(() => {
    if (!data || onboardingCompleted || !hasUserGroupsOrLinks) return;
    void completeOnboarding().catch(() => void 0);
  }, [completeOnboarding, data, hasUserGroupsOrLinks, onboardingCompleted]);
  reactExports.useEffect(() => {
    if (!data || autoOnboardingCheckedRef.current || onboardingCompleted || hasUserGroupsOrLinks) return;
    autoOnboardingCheckedRef.current = true;
    setOnboardingOpen(true);
  }, [data, hasUserGroupsOrLinks, onboardingCompleted]);
  reactExports.useEffect(() => {
    if (!data) return;
    const root = document.documentElement;
    const systemDark = window.matchMedia("(prefers-color-scheme: dark)");
    const theme = data.settings.theme;
    root.lang = data.settings.language;
    function applyTheme() {
      const dark = theme === "dark" || theme === "system" && systemDark.matches;
      root.classList.toggle("dark", dark);
    }
    applyTheme();
    systemDark.addEventListener("change", applyTheme);
    return () => systemDark.removeEventListener("change", applyTheme);
  }, [data]);
  reactExports.useEffect(() => {
    if (searchOpen) {
      window.requestAnimationFrame(() => {
        var _a;
        return (_a = searchInputRef.current) == null ? void 0 : _a.focus();
      });
    }
  }, [searchOpen]);
  reactExports.useEffect(() => {
    const focusKeyboardScope = () => {
      var _a;
      if (document.visibilityState !== "visible") return;
      if (isTextInput(document.activeElement) || isInteractiveControl(document.activeElement)) {
        return;
      }
      window.focus();
      (_a = keyboardFocusRef.current) == null ? void 0 : _a.focus({ preventScroll: true });
    };
    window.requestAnimationFrame(focusKeyboardScope);
    const timeoutIds = [0, 50, 150, 300, 700, 1200].map((delay) => window.setTimeout(focusKeyboardScope, delay));
    window.addEventListener("pageshow", focusKeyboardScope);
    window.addEventListener("focus", focusKeyboardScope);
    document.addEventListener("visibilitychange", focusKeyboardScope);
    return () => {
      timeoutIds.forEach((timeoutId) => window.clearTimeout(timeoutId));
      window.removeEventListener("pageshow", focusKeyboardScope);
      window.removeEventListener("focus", focusKeyboardScope);
      document.removeEventListener("visibilitychange", focusKeyboardScope);
    };
  }, []);
  const parsedSearch = reactExports.useMemo(() => parseSearchQuery(search), [search]);
  const searchMode = searchHasQuery(parsedSearch);
  const searchTerms = reactExports.useMemo(() => searchHighlightTerms(parsedSearch), [parsedSearch]);
  const filteredGroups = reactExports.useMemo(() => {
    if (!data) return [];
    const sortedGroups = data.groups.slice().sort((a, b) => a.order - b.order);
    return filterGroupsForSearch(sortedGroups, parsedSearch);
  }, [data, parsedSearch]);
  const searchResults = reactExports.useMemo(() => searchMode ? flattenSearchResults(filteredGroups) : [], [filteredGroups, searchMode]);
  reactExports.useEffect(() => {
    if (!searchMode || !searchResults.length) {
      setSelectedSearchResultId(null);
      return;
    }
    setSelectedSearchResultId((current) => {
      if (current && searchResults.some((result) => resultIdentity(result) === current)) {
        return current;
      }
      return resultIdentity(searchResults[0]);
    });
  }, [searchMode, searchResults]);
  const openSearchResult = (result) => {
    if (!data) return;
    if (data.settings.openLinksInNewTab) {
      window.open(result.link.url, "_blank", "noopener");
      return;
    }
    window.location.assign(result.link.url);
  };
  const selectSearchResult = (offset) => {
    if (!searchResults.length) return;
    const currentIndex = selectedSearchResultId ? searchResults.findIndex((result) => resultIdentity(result) === selectedSearchResultId) : -1;
    const nextIndex = currentIndex < 0 ? 0 : (currentIndex + offset + searchResults.length) % searchResults.length;
    const nextId = resultIdentity(searchResults[nextIndex]);
    setSelectedSearchResultId(nextId);
    scrollSearchResultIntoView(nextId);
  };
  reactExports.useEffect(() => {
    function handleKeyDown(event) {
      const blockingModalOpen = groupDialogOpen || linkDialogOpen || settingsOpen || importOpen || restoreOpen || duplicateFinderOpen || onboardingOpen || pendingDanger;
      const modalOpen = blockingModalOpen || commandPaletteOpen;
      const searchInputFocused = event.target === searchInputRef.current;
      const typingTarget = isTextInput(event.target);
      const key2 = event.key.toLowerCase();
      const code = event.code;
      const modified = event.altKey || event.metaKey || event.ctrlKey;
      const commandPaletteShortcut = (event.ctrlKey || event.metaKey) && (key2 === "k" || code === "KeyK");
      if (commandPaletteShortcut && !typingTarget) {
        if (event.cancelable) {
          event.preventDefault();
        }
        event.stopPropagation();
        setCommandPaletteOpen((open) => {
          if (open) return false;
          return blockingModalOpen ? open : true;
        });
        return;
      }
      if (event.defaultPrevented) return;
      if (modalOpen) {
        return;
      }
      if ((event.key === "/" || code === "Slash") && !typingTarget) {
        event.preventDefault();
        setSearchOpen(true);
        return;
      }
      if (event.key === "Escape" && (search || searchOpen)) {
        event.preventDefault();
        setSearch("");
        setSearchOpen(false);
        return;
      }
      if (typingTarget && !searchInputFocused) {
        return;
      }
      if (searchMode && (event.key === "ArrowDown" || event.key === "ArrowUp")) {
        event.preventDefault();
        selectSearchResult(event.key === "ArrowDown" ? 1 : -1);
        return;
      }
      if (searchMode && event.key === "Enter" && selectedSearchResultId && (searchInputFocused || !isInteractiveControl(event.target))) {
        const selected = searchResults.find((result) => resultIdentity(result) === selectedSearchResultId);
        if (selected) {
          event.preventDefault();
          openSearchResult(selected);
        }
        return;
      }
      if (modified || typingTarget) {
        return;
      }
      if (key2 === "e" || code === "KeyE") {
        event.preventDefault();
        setEditMode((value) => !value);
        return;
      }
      if (key2 === "n" || code === "KeyN") {
        event.preventDefault();
        openAddLink();
        return;
      }
      if (key2 === "g" || code === "KeyG") {
        event.preventDefault();
        openAddGroup();
      }
    }
    window.addEventListener("keydown", handleKeyDown, true);
    return () => window.removeEventListener("keydown", handleKeyDown, true);
  }, [
    groupDialogOpen,
    commandPaletteOpen,
    duplicateFinderOpen,
    importOpen,
    linkDialogOpen,
    onboardingOpen,
    pendingDanger,
    restoreOpen,
    search,
    searchMode,
    searchOpen,
    searchResults,
    selectedSearchResultId,
    settingsOpen
  ]);
  reactExports.useEffect(() => {
    var _a;
    if (typeof chrome === "undefined" || !((_a = chrome.runtime) == null ? void 0 : _a.onMessage)) return;
    const blockingModalOpen = Boolean(
      groupDialogOpen || linkDialogOpen || settingsOpen || importOpen || restoreOpen || duplicateFinderOpen || onboardingOpen || pendingDanger
    );
    const handleRuntimeMessage = (message) => {
      if (!message || typeof message !== "object" || message.type !== TOGGLE_COMMAND_PALETTE_MESSAGE) {
        return;
      }
      if (document.visibilityState !== "visible") return;
      setCommandPaletteOpen((open) => open ? false : !blockingModalOpen);
    };
    chrome.runtime.onMessage.addListener(handleRuntimeMessage);
    return () => chrome.runtime.onMessage.removeListener(handleRuntimeMessage);
  }, [
    duplicateFinderOpen,
    groupDialogOpen,
    importOpen,
    linkDialogOpen,
    onboardingOpen,
    pendingDanger,
    restoreOpen,
    settingsOpen
  ]);
  const showError = (message) => {
    addToast({ type: "error", title: t((data == null ? void 0 : data.settings.language) ?? fallbackLanguage, "actionFailed"), message });
  };
  const openAddGroup = () => {
    setEditingGroup(null);
    setGroupDialogOpen(true);
  };
  const openAddLink = (groupId) => {
    setEditingLink(null);
    setInitialLinkGroupId(groupId);
    setLinkDialogOpen(true);
  };
  const toggleSearch = () => {
    if (searchOpen || search) {
      setSearch("");
      setSearchOpen(false);
      return;
    }
    setSearchOpen(true);
  };
  const closeSettingsAndOpenImport = () => {
    setSettingsOpen(false);
    openImport("aura_json");
  };
  const closeSettingsAndOpenAFineStartImport = () => {
    setSettingsOpen(false);
    openImport("a_fine_start");
  };
  const closeSettingsAndOpenRestore = () => {
    setSettingsOpen(false);
    setRestoreOpen(true);
  };
  const closeSettingsAndOpenDuplicateFinder = () => {
    setSettingsOpen(false);
    setDuplicateFinderOpen(true);
  };
  const openImport = (format) => {
    setImportFormat(format);
    setImportOpen(true);
  };
  const keyboardFocusTarget = /* @__PURE__ */ jsxRuntimeExports.jsx(
    "input",
    {
      ref: keyboardFocusRef,
      "data-keyboard-focus-target": "true",
      tabIndex: -1,
      readOnly: true,
      "aria-label": t((data == null ? void 0 : data.settings.language) ?? fallbackLanguage, "keyboardShortcuts"),
      className: "sr-only",
      autoFocus: true
    }
  );
  if (status === "loading" || status === "idle") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      keyboardFocusTarget,
      /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "app-shell flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "surface rounded-xl px-5 py-4 text-sm font-semibold", children: t(fallbackLanguage, "loadingAuraStart") }) })
    ] });
  }
  if (status === "corrupt") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      keyboardFocusTarget,
      /* @__PURE__ */ jsxRuntimeExports.jsx(RecoveryScreen, { language: fallbackLanguage, message: error ?? t(fallbackLanguage, "storageCorrupt"), raw: corruptRaw, onError: showError, onReset: resetCorruptData }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toasts, {})
    ] });
  }
  if (!data) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      keyboardFocusTarget,
      /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "app-shell flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "surface rounded-xl p-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-semibold", children: t(fallbackLanguage, "unavailableTitle") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted mt-2 text-sm", children: error ?? t(fallbackLanguage, "couldNotLoadLocalData") })
      ] }) })
    ] });
  }
  const hasLinks = data.groups.some((group) => group.links.length > 0);
  const language = data.settings.language;
  const openSettingsSection = () => {
    setSettingsOpen(true);
  };
  const commands = [
    {
      id: "search",
      title: t(language, "commandSearchLinks"),
      description: t(language, "pressSlashToSearch"),
      keywords: ["find", "links"],
      action: () => setSearchOpen(true)
    },
    {
      id: "new-group",
      title: t(language, "commandCreateNewGroup"),
      keywords: ["group", "create"],
      action: openAddGroup
    },
    {
      id: "new-link",
      title: t(language, "commandCreateNewLink"),
      keywords: ["link", "create"],
      action: () => openAddLink()
    },
    {
      id: "toggle-edit",
      title: t(language, "commandToggleEditMode"),
      keywords: ["edit"],
      action: () => setEditMode((value) => !value)
    },
    {
      id: "export-backup",
      title: t(language, "commandExportBackup"),
      description: t(language, "exportJsonDescription"),
      keywords: ["backup", "json", "export"],
      action: () => exportJsonBackup(data)
    },
    {
      id: "import-backup",
      title: t(language, "commandImportBackup"),
      keywords: ["backup", "json", "import"],
      action: () => openImport("aura_json")
    },
    {
      id: "import-afs",
      title: t(language, "commandImportFromAFineStart"),
      keywords: ["a fine start", "migration"],
      action: () => openImport("a_fine_start")
    },
    {
      id: "settings",
      title: t(language, "commandOpenSettings"),
      keywords: ["settings"],
      action: openSettingsSection
    },
    {
      id: "theme",
      title: t(language, "commandToggleTheme"),
      keywords: ["theme", "dark", "light"],
      action: async () => updateSettings({ theme: data.settings.theme === "dark" ? "light" : "dark" })
    },
    {
      id: "restore-points",
      title: t(language, "commandOpenRestorePoints"),
      keywords: ["restore", "backup"],
      action: () => setRestoreOpen(true)
    },
    {
      id: "privacy",
      title: t(language, "commandOpenPrivacyPromise"),
      description: t(language, "commandOpensSettingsSection"),
      keywords: ["privacy"],
      action: openSettingsSection
    },
    {
      id: "shortcuts",
      title: t(language, "commandOpenKeyboardShortcuts"),
      description: t(language, "commandOpensSettingsSection"),
      keywords: ["keyboard", "shortcuts"],
      action: openSettingsSection
    },
    {
      id: "duplicates",
      title: t(language, "commandOpenDuplicateFinder"),
      keywords: ["duplicate", "cleanup"],
      action: () => setDuplicateFinderOpen(true)
    },
    data.settings.sync.connected ? {
      id: "disconnect-drive",
      title: t(language, "commandDisconnectGoogleDrive"),
      description: t(language, "commandOpensSettingsSection"),
      keywords: ["google", "drive", "disconnect"],
      action: openSettingsSection
    } : {
      id: "connect-drive",
      title: t(language, "commandConnectGoogleDrive"),
      keywords: ["google", "drive", "sync"],
      action: connectGoogleDrive
    }
  ];
  const dangerTitle = (() => {
    switch (pendingDanger == null ? void 0 : pendingDanger.type) {
      case "resetAll":
        return t(language, "resetAuraStart");
      case "removeDemoData":
        return t(language, "removeDemoData");
      case "deleteGroup":
        return t(language, "deleteThisGroup");
      case "deleteLink":
        return t(language, "deleteThisLink");
      default:
        return "";
    }
  })();
  const dangerMessage = (() => {
    switch (pendingDanger == null ? void 0 : pendingDanger.type) {
      case "resetAll":
        return t(language, "resetAllDataMessage");
      case "removeDemoData":
        return t(language, "removeDemoDataMessage");
      case "deleteGroup":
        return t(language, "deleteThisGroupMessage", { title: pendingDanger.group.title });
      case "deleteLink":
        return t(language, "deleteThisLinkMessage", { title: pendingDanger.link.title });
      default:
        return "";
    }
  })();
  const dangerConfirmLabel = (() => {
    switch (pendingDanger == null ? void 0 : pendingDanger.type) {
      case "resetAll":
        return t(language, "resetAllData");
      case "removeDemoData":
        return t(language, "removeDemoData");
      case "deleteLink":
        return t(language, "delete");
      case "deleteGroup":
        return t(language, "deleteGroup");
      default:
        return t(language, "delete");
    }
  })();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `afs-like ${data.settings.compactMode ? "compact" : ""}`, children: [
    keyboardFocusTarget,
    /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "app-shell", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container-narrow", children: [
      usingFallbackStorage ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 rounded-lg border border-[var(--border)] bg-[var(--accent-soft)] px-4 py-3 text-sm text-[var(--accent-strong)]", children: t(language, "storageFallbackNotice") }) : null,
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Header,
        {
          data,
          editMode,
          search,
          searchInputRef,
          syncMessage,
          syncStatus,
          onAddGroup: openAddGroup,
          onAddLink: () => openAddLink(),
          onExportError: showError,
          onOpenCommandPalette: () => setCommandPaletteOpen(true),
          onOpenImport: () => openImport("aura_json"),
          onOpenSettings: () => setSettingsOpen(true),
          onOpenSearch: toggleSearch,
          onToggleEditMode: () => setEditMode((value) => !value),
          onSearchChange: (value) => {
            setSearch(value);
            if (value) {
              setSearchOpen(true);
            }
          },
          searchOpen
        }
      ),
      filteredGroups.length ? /* @__PURE__ */ jsxRuntimeExports.jsx(
        GroupGrid,
        {
          data,
          editMode,
          groups: filteredGroups,
          highlightTerms: searchTerms,
          searchMode,
          selectedSearchResultId,
          onAddLink: openAddLink,
          onDeleteGroup: (group) => setPendingDanger({ type: "deleteGroup", group }),
          onDeleteLink: (groupId, link) => setPendingDanger({ type: "deleteLink", groupId, link }),
          onEditGroup: (group) => {
            setEditingGroup(group);
            setGroupDialogOpen(true);
          },
          onEditLink: (groupId, link) => {
            setEditingLink({ groupId, link });
            setLinkDialogOpen(true);
          },
          onMoveLink: (linkId, targetGroupId, overLinkId) => {
            return moveLink(linkId, targetGroupId, overLinkId).catch(
              (caught) => showError(caught instanceof Error ? caught.message : t(language, "couldNotMoveLink"))
            );
          },
          onReorderGroups: (orderedGroupIds) => {
            return reorderGroups(orderedGroupIds).catch(
              (caught) => showError(caught instanceof Error ? caught.message : t(language, "couldNotReorderGroups"))
            );
          },
          onToggle: (groupId) => {
            void toggleGroupCollapsed(groupId).catch(
              (caught) => showError(caught instanceof Error ? caught.message : t(language, "couldNotUpdateGroup"))
            );
          }
        }
      ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
        EmptyState,
        {
          mode: searchMode || hasLinks ? "search" : "empty",
          language,
          onAddGroup: openAddGroup,
          onAddDemoData: () => {
            void addDemoData().catch(
              (caught) => showError(caught instanceof Error ? caught.message : t(language, "couldNotCompleteAction"))
            );
          },
          onImportAFineStart: () => openImport("a_fine_start"),
          onImportBackup: () => openImport("aura_json")
        }
      )
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      AddEditGroupDialog,
      {
        group: editingGroup,
        language,
        open: groupDialogOpen,
        onClose: () => setGroupDialogOpen(false),
        onError: showError,
        onSubmit: async (title) => {
          if (editingGroup) {
            await updateGroupTitle(editingGroup.id, title);
          } else {
            await addGroup(title);
          }
        }
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      AddEditLinkDialog,
      {
        editing: editingLink,
        groups: data.groups,
        initialGroupId: initialLinkGroupId,
        language,
        open: linkDialogOpen,
        onAdd: addLink,
        onClose: () => setLinkDialogOpen(false),
        onCreateGroup: addGroup,
        onError: showError,
        onUpdate: updateLink
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      SettingsDialog,
      {
        data,
        open: settingsOpen,
        syncConflict,
        syncMessage,
        syncStatus,
        onConnectGoogleDrive: connectGoogleDrive,
        onClose: () => setSettingsOpen(false),
        onDeleteGoogleDriveBackupAndDisconnect: deleteGoogleDriveBackupAndDisconnect,
        onError: showError,
        hasDemoData: hasTrackedDemoData,
        onOpenDuplicateFinder: closeSettingsAndOpenDuplicateFinder,
        onOpenImport: closeSettingsAndOpenImport,
        onOpenImportAFineStart: closeSettingsAndOpenAFineStartImport,
        onOpenOnboarding: () => {
          setSettingsOpen(false);
          setOnboardingOpen(true);
        },
        onOpenRestorePoints: closeSettingsAndOpenRestore,
        onRemoveDemoData: () => setPendingDanger({ type: "removeDemoData" }),
        onResolveSyncConflict: resolveSyncConflict,
        onReset: () => setPendingDanger({ type: "resetAll" }),
        onUpdateSettings: updateSettings
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      ImportDialog,
      {
        currentData: data,
        initialFormat: importFormat,
        language,
        open: importOpen,
        onClose: () => setImportOpen(false),
        onError: showError,
        onImport: importBackup
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      OnboardingDialog,
      {
        data,
        open: onboardingOpen,
        onClose: () => setOnboardingOpen(false),
        onComplete: completeOnboarding,
        onError: showError,
        onImportAFineStart: () => openImport("a_fine_start"),
        onImportBackup: () => openImport("aura_json"),
        onRestoreGoogleDrive: () => restoreFromGoogleDrive({ requireExistingFile: true }),
        onUpdateSettings: updateSettings
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      RestorePointsDialog,
      {
        language,
        open: restoreOpen,
        restorePoints: data.restorePoints,
        onClose: () => setRestoreOpen(false),
        onCreate: createManualRestorePoint,
        onDeleteAll: deleteAllRestorePoints,
        onDelete: deleteRestorePoint,
        onError: showError,
        onRestore: restoreRestorePoint
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      DuplicateFinderDialog,
      {
        data,
        language,
        open: duplicateFinderOpen,
        onClose: () => setDuplicateFinderOpen(false),
        onDeleteSelected: deleteLinksWithRestorePoint,
        onError: showError
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      CommandPalette,
      {
        commands,
        language,
        open: commandPaletteOpen,
        onClose: () => setCommandPaletteOpen(false),
        onError: showError
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      ConfirmDialog,
      {
        cancelLabel: t(language, "cancel"),
        confirmLabel: dangerConfirmLabel,
        message: dangerMessage,
        open: pendingDanger !== null,
        title: dangerTitle,
        onCancel: () => setPendingDanger(null),
        onConfirm: async () => {
          try {
            if ((pendingDanger == null ? void 0 : pendingDanger.type) === "resetAll") {
              await resetAllData();
            }
            if ((pendingDanger == null ? void 0 : pendingDanger.type) === "removeDemoData") {
              await removeDemoData();
            }
            if ((pendingDanger == null ? void 0 : pendingDanger.type) === "deleteGroup") {
              await deleteGroup(pendingDanger.group.id);
            }
            if ((pendingDanger == null ? void 0 : pendingDanger.type) === "deleteLink") {
              await deleteLink(pendingDanger.groupId, pendingDanger.link.id);
            }
            setPendingDanger(null);
          } catch (caught) {
            showError(caught instanceof Error ? caught.message : t(language, "couldNotCompleteAction"));
          }
        }
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Toasts, {})
  ] });
}
export {
  App as A
};
