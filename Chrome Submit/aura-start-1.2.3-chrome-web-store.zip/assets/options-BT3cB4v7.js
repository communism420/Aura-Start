import { c as clientExports, j as jsxRuntimeExports } from "./styles-Bx0ca_OT.js";
import { A as App } from "./App-C7RIpSHV.js";
clientExports.createRoot(document.getElementById("options-root")).render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, { initialSettingsOpen: true }));
